﻿using System;
using System.Collections.Generic;

namespace COBLoggingDashboard.Models
{
    public partial class TWellnessMemberLinkClientLevel
    {
        public int RowId { get; set; }
        public int AccountId { get; set; }
        public string ClientName { get; set; }
        public double? MatchLevel { get; set; }
        public DateTime? Loaddt { get; set; }
        public int? Previousdata { get; set; }
        public int? CurrentDayInventory { get; set; }
        public int? MatchCountDiff { get; set; }
        public decimal? PercentDiff { get; set; }
        public string AuditMgrName { get; set; }
        public int? AuditMgrId { get; set; }
        public DateTime? LastUpdateDate { get; set; }
    }
}
