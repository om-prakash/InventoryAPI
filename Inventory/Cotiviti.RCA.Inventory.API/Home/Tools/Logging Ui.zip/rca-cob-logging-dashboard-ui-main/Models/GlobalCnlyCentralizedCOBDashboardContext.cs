﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace COBLoggingDashboard.Models
{
    public partial class GlobalCnlyCentralizedCOBDashboardContext : DbContext
    {
        public GlobalCnlyCentralizedCOBDashboardContext()
        {
        }

        public GlobalCnlyCentralizedCOBDashboardContext(DbContextOptions<GlobalCnlyCentralizedCOBDashboardContext> options)
            : base(options)
        {
        }
        public virtual DbSet<TAccount> TAccount { get; set; }
        public virtual DbSet<TAccountAttributes> TAccountAttributes { get; set; }
        public virtual DbSet<TAccountDashboardPsConfig> TAccountDashboardPsConfig { get; set; }
        public virtual DbSet<TAccountLexisNexis> TAccountLexisNexis { get; set; }
        public virtual DbSet<TWellnessAutomatedNovaReportDetailDaily> TWellnessAutomatedNovaReportDetailDaily { get; set; }
        public virtual DbSet<TWellnessAutomatedNovaReportDetailMonthly> TWellnessAutomatedNovaReportDetailMonthly { get; set; }
        public virtual DbSet<TWellnessAutomatedNovaReportDetailWeekly> TWellnessAutomatedNovaReportDetailWeekly { get; set; }
        public virtual DbSet<TWellnessAutomatedNovaReportDetailYearly> TWellnessAutomatedNovaReportDetailYearly { get; set; }
        public virtual DbSet<TWellnessAutomatedNovaReportSummary> TWellnessAutomatedNovaReportSummary { get; set; }
        public virtual DbSet<TWellnessCaseMgmtStatus> TWellnessCaseMgmtStatus { get; set; }
        public virtual DbSet<TWellnessCobJobsStatus> TWellnessCobJobsStatus { get; set; }
        public virtual DbSet<TWellnessMemberLinkClientStatus> TWellnessMemberLinkClientStatus { get; set; }
        public virtual DbSet<TWellnessMemberlinkRuntime> TWellnessMemberlinkRuntime { get; set; }
        public virtual DbSet<TWellnessDataLoadCount> TWellnessDataLoadCount { get; set; }
        public virtual DbSet<TWellnessMemberLinkClientLevel> TWellnessMemberLinkClientLevel { get; set; }
        public virtual DbSet<TWellnessCobJobsStatusFinal> TWellnessCobJobsStatusFinal { get; set; }
        public virtual DbSet<TWellnessPcobFileStatus> TWellnessPcobFileStatus { get; set; }
        public virtual DbSet<TWellnessLexisNexisCount> TWellnessLexisNexisCount { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
//            if (!optionsBuilder.IsConfigured)
//            {
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
//                optionsBuilder.UseSqlServer("Server=DC-ALTA;Database=GlobalCnlyCentralizedCOBDashboard;Trusted_Connection=True;");
//            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:DefaultSchema", "CCA-AUDIT\\abdullahnoor.mohamed");

            modelBuilder.Entity<TAccount>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("T_Account", "dbo");

                entity.Property(e => e.AccountId).HasColumnName("ACCOUNT_ID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasColumnName("ACTIVE")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.AuditId).HasColumnName("AUDIT_ID");

                entity.Property(e => e.CheckDelay).HasColumnName("CHECK_DELAY");

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasColumnName("CLIENT_NAME")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DashboardReady).HasColumnName("DASHBOARD_READY");

                entity.Property(e => e.ParentAccountId).HasColumnName("PARENT_ACCOUNT_ID");

                entity.Property(e => e.PlatformId).HasColumnName("PLATFORM_ID");

                entity.Property(e => e.Retired).HasColumnName("RETIRED");
            });

            modelBuilder.Entity<TAccountAttributes>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("T_Account_Attributes", "dbo");

                entity.Property(e => e.AccountId).HasColumnName("ACCOUNT_ID");

                entity.Property(e => e.CollectionAdminLink)
                    .HasColumnName("COLLECTION_ADMIN_LINK")
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.CustomCodeLocation)
                    .HasColumnName("CUSTOM_CODE_LOCATION")
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.DbCobTracker)
                    .HasColumnName("DB_COB_TRACKER")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DbDev)
                    .HasColumnName("DB_DEV")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DbDevScreens)
                    .HasColumnName("DB_DEV_SCREENS")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DbProd)
                    .HasColumnName("DB_PROD")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DbProdBase)
                    .HasColumnName("DB_PROD_BASE")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DbProdScreens)
                    .HasColumnName("DB_PROD_SCREENS")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DbQa)
                    .HasColumnName("DB_QA")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DbQaScreens)
                    .HasColumnName("DB_QA_SCREENS")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DbRootName)
                    .HasColumnName("DB_ROOT_NAME")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DbTest)
                    .HasColumnName("DB_TEST")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DbTestScreens)
                    .HasColumnName("DB_TEST_SCREENS")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DecipherName)
                    .HasColumnName("DECIPHER_NAME")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DevDecipherPath)
                    .HasColumnName("DEV_DECIPHER_PATH")
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.ImageName)
                    .HasColumnName("IMAGE_NAME")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LocalTeamDecipherFileProd)
                    .HasColumnName("LOCAL_TEAM_DECIPHER_FILE_PROD")
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.LocalTeamFolder)
                    .HasColumnName("LOCAL_TEAM_FOLDER")
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.ProdDecipherPath)
                    .HasColumnName("PROD_DECIPHER_PATH")
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.ServerDev)
                    .HasColumnName("SERVER_DEV")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ServerProd)
                    .HasColumnName("SERVER_PROD")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ServerQa)
                    .HasColumnName("SERVER_QA")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ServerTest)
                    .HasColumnName("SERVER_TEST")
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TAccountDashboardPsConfig>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("T_Account_Dashboard_PS_Config", "dbo");

                entity.Property(e => e.AccountId).HasColumnName("ACCOUNT_ID");

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasColumnName("CLIENT_NAME")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Command)
                    .IsRequired()
                    .HasMaxLength(8000)
                    .IsUnicode(false);

                entity.Property(e => e.CommandArgs)
                    .IsRequired()
                    .HasMaxLength(8000)
                    .IsUnicode(false);

                entity.Property(e => e.ExecType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FileName)
                    .IsRequired()
                    .HasColumnName("File_Name")
                    .HasMaxLength(8000)
                    .IsUnicode(false);

                entity.Property(e => e.FilePath)
                    .IsRequired()
                    .HasColumnName("File_Path")
                    .HasMaxLength(8000)
                    .IsUnicode(false);

                entity.Property(e => e.ScriptText).IsUnicode(false);

                entity.Property(e => e.UpdateDt).HasColumnType("datetime");

                entity.Property(e => e.UpdateUser)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TAccountLexisNexis>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("T_Account_LexisNexis", "dbo");

                entity.Property(e => e.AccountId).HasColumnName("ACCOUNT_ID");

                entity.Property(e => e.FolderPath)
                    .IsRequired()
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.Property(e => e.PreProcessingSproc)
                    .HasMaxLength(1000)
                    .IsUnicode(false);
            });
            modelBuilder.Entity<TWellnessAutomatedNovaReportDetailDaily>(entity =>
            {
                entity.HasKey(e => e.RowId)
                    .HasName("PK__T_Wellne__FFEE74516C64E874");

                entity.ToTable("T_Wellness_AutomatedNovaReportDetailDaily", "dbo");

                entity.Property(e => e.RowId).HasColumnName("RowID");

                entity.Property(e => e.AccountId).HasColumnName("Account_ID");

                entity.Property(e => e.AuditMgrId).HasColumnName("Audit_MgrID");

                entity.Property(e => e.AuditMgrName)
                    .HasColumnName("Audit_MgrName")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasColumnName("Client_Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.HitRate).HasColumnName("Hit Rate");

                entity.Property(e => e.HoursWorked).HasColumnName("Hours Worked");

                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .HasColumnType("money");

                entity.Property(e => e.IdHour).HasColumnName("ID/Hour");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnName("LastUpdate_date")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LaunchDate)
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TWellnessAutomatedNovaReportDetailMonthly>(entity =>
            {
                entity.HasKey(e => e.RowId)
                    .HasName("PK__T_Wellne__FFEE745188E386E1");

                entity.ToTable("T_Wellness_AutomatedNovaReportDetailMonthly", "dbo");

                entity.Property(e => e.RowId).HasColumnName("RowID");

                entity.Property(e => e.AccountId).HasColumnName("Account_ID");

                entity.Property(e => e.AuditMgrId).HasColumnName("Audit_MgrID");

                entity.Property(e => e.AuditMgrName)
                    .HasColumnName("Audit_MgrName")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasColumnName("Client_Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.HitRate).HasColumnName("Hit Rate");

                entity.Property(e => e.HoursWorked).HasColumnName("Hours Worked");

                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .HasColumnType("money");

                entity.Property(e => e.IdHour).HasColumnName("ID/Hour");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnName("LastUpdate_date")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LaunchDate)
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TWellnessAutomatedNovaReportDetailWeekly>(entity =>
            {
                entity.HasKey(e => e.RowId)
                    .HasName("PK__T_Wellne__FFEE7451CAE3466B");

                entity.ToTable("T_Wellness_AutomatedNovaReportDetailWeekly", "dbo");

                entity.Property(e => e.RowId).HasColumnName("RowID");

                entity.Property(e => e.AccountId).HasColumnName("Account_ID");

                entity.Property(e => e.AuditMgrId).HasColumnName("Audit_MgrID");

                entity.Property(e => e.AuditMgrName)
                    .HasColumnName("Audit_MgrName")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasColumnName("Client_Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.HitRate).HasColumnName("Hit Rate");

                entity.Property(e => e.HoursWorked).HasColumnName("Hours Worked");

                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .HasColumnType("money");

                entity.Property(e => e.IdHour).HasColumnName("ID/Hour");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnName("LastUpdate_date")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LaunchDate)
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TWellnessAutomatedNovaReportDetailYearly>(entity =>
            {
                entity.HasKey(e => e.RowId)
                    .HasName("PK__T_Wellne__FFEE74511EF1BAB2");

                entity.ToTable("T_Wellness_AutomatedNovaReportDetailYearly", "dbo");

                entity.Property(e => e.RowId).HasColumnName("RowID");

                entity.Property(e => e.AccountId).HasColumnName("Account_ID");

                entity.Property(e => e.AuditMgrId).HasColumnName("Audit_MgrID");

                entity.Property(e => e.AuditMgrName)
                    .HasColumnName("Audit_MgrName")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasColumnName("Client_Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.HitRate).HasColumnName("Hit Rate");

                entity.Property(e => e.HoursWorked).HasColumnName("Hours Worked");

                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .HasColumnType("money");

                entity.Property(e => e.IdHour).HasColumnName("ID/Hour");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnName("LastUpdate_date")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LaunchDate).HasColumnType("date");
            });

            modelBuilder.Entity<TWellnessAutomatedNovaReportSummary>(entity =>
            {
                entity.HasKey(e => e.RowId)
                    .HasName("PK__T_Wellne__FFEE745120C481AD");

                entity.ToTable("T_Wellness_AutomatedNovaReportSummary", "dbo");

                entity.Property(e => e.RowId).HasColumnName("RowID");

                entity.Property(e => e.AvgOvpMbr)
                    .HasColumnName("AvgOvp/Mbr")
                    .HasColumnType("money");

                entity.Property(e => e.DailyIdRate)
                    .HasColumnName("Daily ID Rate")
                    .HasColumnType("money");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnName("LastUpdate_date")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.MbrHr).HasColumnName("Mbr/Hr");

                entity.Property(e => e.OverallIdHour).HasColumnName("Overall ID/Hour");

                entity.Property(e => e.OvpHitRt).HasColumnName("OVP Hit/Rt");

                entity.Property(e => e.RowLabel).HasColumnName("Row_label");

                entity.Property(e => e.TotalIdytd)
                    .HasColumnName("TotalIDYTD")
                    .HasColumnType("money");

                entity.Property(e => e.WorkingDaysSinceProjectLaunch).HasColumnName("Working Days Since Project Launch");

                entity.Property(e => e.Ytddate)
                    .HasColumnName("YTDDate")
                    .HasColumnType("date");
            });

            modelBuilder.Entity<TWellnessCaseMgmtStatus>(entity =>
            {
                entity.HasKey(e => e.AccountId)
                    .HasName("PK__T_Wellne__B19E45C9F67E0400");

                entity.ToTable("T_Wellness_CaseMgmt_Status", "dbo");

                entity.Property(e => e.AccountId)
                    .HasColumnName("Account_ID")
                    .ValueGeneratedNever();

                entity.Property(e => e.AuditMgrId).HasColumnName("Audit_MgrID");

                entity.Property(e => e.AuditMgrName)
                    .HasColumnName("Audit_MgrName")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BacklogRunDate).HasColumnType("datetime");

                entity.Property(e => e.ClientId)
                    .HasColumnName("Client_ID")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ClientName)
                    .HasColumnName("Client_Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastExportDate)
                    .HasColumnName("LAST_EXPORT_DATE")
                    .HasColumnType("datetime");

                entity.Property(e => e.LastImportDate)
                    .HasColumnName("LAST_IMPORT_DATE")
                    .HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDt)
                    .HasColumnName("LastUpdate_date")
                    .HasColumnType("datetime");
                    //.HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<TWellnessCobJobsStatus>(entity =>
            {
                entity.HasKey(e => e.RowId)
                    .HasName("PK__T_Wellne__FFEE7451EB5A3363");

                entity.ToTable("T_Wellness_CobJobs_Status", "dbo");

                entity.Property(e => e.RowId).HasColumnName("RowID");

                entity.Property(e => e.AccountId).HasColumnName("Account_ID");

                entity.Property(e => e.AuditMgrId).HasColumnName("Audit_MgrID");

                entity.Property(e => e.AuditMgrName)
                    .HasColumnName("Audit_MgrName")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasColumnName("Client_Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ControllerDate)
                    .HasColumnName("Controller_date")
                    .HasColumnType("datetime");

                entity.Property(e => e.LastSuccessDate)
                    .HasColumnName("LastSuccess_Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.FieldList).HasColumnName("field_list");

                entity.Property(e => e.Interval)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.LastRunTime)
                    .HasColumnName("last_run_time")
                    .HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnName("LastUpdate_date")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Location)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.MaxRuntime).HasColumnName("Max_Runtime");

                entity.Property(e => e.ProcessDesc).HasColumnName("Process_desc");

                entity.Property(e => e.Procname)
                    .IsRequired()
                    .HasColumnName("procname")
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.Property(e => e.Status)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.StepNo).HasColumnName("Step_no");

                entity.Property(e => e.Type).HasMaxLength(50);
            });

            modelBuilder.Entity<TWellnessMemberLinkClientStatus>(entity =>
            {
                entity.HasKey(e => e.RowId)
                    .HasName("PK_T_Wellness_MemberLink_ClientStatus_RowID");

                entity.ToTable("T_Wellness_MemberLink_ClientStatus", "dbo");

                entity.Property(e => e.RowId).HasColumnName("RowID");

                entity.Property(e => e.AccountId).HasColumnName("Account_ID");

                entity.Property(e => e.AuditMgrId).HasColumnName("Audit_MgrID");

                entity.Property(e => e.AuditMgrName)
                    .HasColumnName("Audit_MgrName")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasColumnName("Client_Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastProcessedDt).HasColumnType("date");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnName("LastUpdate_date")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<TWellnessMemberlinkRuntime>(entity =>
            {
                entity.HasKey(e => e.RowId)
                    .HasName("PK__T_Wellne__FFEE7451C4BC4F3D");

                entity.ToTable("T_Wellness_Memberlink_Runtime", "dbo");

                entity.Property(e => e.RowId).HasColumnName("RowID");

                entity.Property(e => e.EndTime)
                    .HasColumnName("end_time")
                    .HasColumnType("datetime");

                entity.Property(e => e.Extra).HasMaxLength(100);

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnName("LastUpdate_date")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ProcessName)
                    .HasColumnName("process_name")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.StartTime)
                    .HasColumnName("Start_time")
                    .HasColumnType("datetime");

                entity.Property(e => e.StepName)
                    .HasColumnName("Step_name")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Type)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });
            modelBuilder.Entity<TWellnessDataLoadCount>(entity =>
            {
                entity.HasKey(e => e.AccountId)
                    .HasName("PK_T_Wellness_DataLoad_Count_AccountId");

                entity.ToTable("T_Wellness_DataLoad_Count", "dbo");

                entity.Property(e => e.AccountId).ValueGeneratedNever();

                entity.Property(e => e.AccountMgr)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastClaimsCount).HasColumnName("Last_ClaimsCount");

                entity.Property(e => e.LastLoadDate)
                    .HasColumnName("Last_LoadDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.LastMemberCount).HasColumnName("Last_MemberCount");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnName("LastUpdate_date")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.NextLoadDate)
                    .HasColumnName("Next_LoadDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.TotalClaimsCount).HasColumnName("Total_ClaimsCount");

                entity.Property(e => e.TotalMemberCount).HasColumnName("Total_MemberCount");
            });
            modelBuilder.Entity<TWellnessMemberLinkClientLevel>(entity =>
            {
                entity.HasKey(e => e.RowId)
                    .HasName("PK_T_Wellness_MemberLink_Client_Level_RowID");

                entity.ToTable("T_Wellness_MemberLink_Client_Level", "dbo");

                entity.Property(e => e.RowId).HasColumnName("RowID");

                entity.Property(e => e.AccountId).HasColumnName("Account_id");

                entity.Property(e => e.AuditMgrId).HasColumnName("Audit_MgrID");

                entity.Property(e => e.AuditMgrName)
                    .HasColumnName("Audit_MgrName")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasColumnName("client_name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CurrentDayInventory).HasColumnName("Current_day_inventory");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnName("LastUpdate_date")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Loaddt)
                    .HasColumnName("loaddt")
                    .HasColumnType("date");

                entity.Property(e => e.MatchCountDiff).HasColumnName("Match_Count_Diff");

                entity.Property(e => e.MatchLevel).HasColumnName("match_level");

                entity.Property(e => e.PercentDiff).HasColumnType("decimal(5, 2)");
            });

            modelBuilder.Entity<TWellnessCobJobsStatusFinal>(entity =>
            {
                entity.HasKey(e => e.RowId)
                    .HasName("PK__T_Wellne__FFEE745179FC9E8A");

                entity.ToTable("T_Wellness_CobJobs_Status_Final", "dbo");

                entity.Property(e => e.RowId).HasColumnName("RowID");

                entity.Property(e => e.AccountId).HasColumnName("Account_ID");

                entity.Property(e => e.AuditMgrId).HasColumnName("Audit_MgrID");

                entity.Property(e => e.AuditMgrName)
                    .HasColumnName("Audit_MgrName")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasColumnName("Client_Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ControllerDate)
                    .HasColumnName("Controller_date")
                    .HasColumnType("datetime");

                entity.Property(e => e.FieldList).HasColumnName("field_list");

                entity.Property(e => e.Interval)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.LastRunTime)
                    .HasColumnName("last_run_time")
                    .HasColumnType("datetime");

                entity.Property(e => e.LastSuccessDate)
                    .HasColumnName("LastSuccess_Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnName("LastUpdate_date")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Location)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.MaxRuntime).HasColumnName("Max_Runtime");

                entity.Property(e => e.ProcessDesc).HasColumnName("Process_desc");

                entity.Property(e => e.Procname)
                    .IsRequired()
                    .HasColumnName("procname")
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.Property(e => e.Status)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.StepNo).HasColumnName("Step_no");

                entity.Property(e => e.Type).HasMaxLength(50);
            });

            modelBuilder.Entity<TWellnessPcobFileStatus>(entity =>
            {
                entity.HasKey(e => e.RowId)
                    .HasName("PK__T_Wellne__FFEE7451F2A32419");

                entity.ToTable("T_Wellness_PCOB_File_Status", "dbo");

                entity.Property(e => e.RowId).HasColumnName("RowID");

                entity.Property(e => e.ClientName)
                    .HasColumnName("Client_Name")
                    .HasMaxLength(100);

                entity.Property(e => e.FileName).HasColumnName("File_Name");

                entity.Property(e => e.FileTransferDate)
                    .HasColumnName("File_Transfer_date")
                    .HasColumnType("datetime");

                entity.Property(e => e.ProcessName)
                    .HasColumnName("Process_Name")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TWellnessLexisNexisCount>(entity =>
            {
                entity.HasKey(e => e.RowId)
                    .HasName("PK__T_Wellne__FFEE74517E9E0829");

                entity.ToTable("T_Wellness_LexisNexis_Count", "dbo");

                entity.Property(e => e.RowId).HasColumnName("RowID");

                entity.Property(e => e.AccountId).HasColumnName("Account_id");

                entity.Property(e => e.ClientName)
                    .HasColumnName("client_name")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ExportComments)
                    .HasColumnName("Export_Comments")
                    .HasMaxLength(8000)
                    .IsUnicode(false);

                entity.Property(e => e.ExportCounts).HasColumnName("Export_counts");

                entity.Property(e => e.ExportDate)
                    .HasColumnName("Export_date")
                    .HasColumnType("datetime");

                entity.Property(e => e.ExportStatus)
                    .HasColumnName("Export_status")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.FolderName)
                    .HasColumnName("Folder_name")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ImportComments)
                    .HasColumnName("Import_Comments")
                    .HasMaxLength(8000)
                    .IsUnicode(false);

                entity.Property(e => e.ImportCounts).HasColumnName("Import_counts");

                entity.Property(e => e.ImportDate)
                    .HasColumnName("Import_date")
                    .HasColumnType("datetime");

                entity.Property(e => e.ImportHit).HasColumnName("Import_hit");

                entity.Property(e => e.ImportMiss).HasColumnName("Import_miss");

                entity.Property(e => e.ImportStatus)
                    .HasColumnName("Import_status")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.LastExportSuccessCounts).HasColumnName("LastExportSuccess_counts");

                entity.Property(e => e.LastExportSuccessDate)
                    .HasColumnName("LastExportSuccess_date")
                    .HasColumnType("datetime");

                entity.Property(e => e.LastImportSuccessCounts).HasColumnName("LastImportSuccess_counts");

                entity.Property(e => e.LastImportSuccessDate)
                    .HasColumnName("LastImportSuccess_date")
                    .HasColumnType("datetime");

                entity.Property(e => e.LastImportSuccessHit).HasColumnName("LastImportSuccess_hit");

                entity.Property(e => e.LastImportSuccessMiss).HasColumnName("LastImportSuccess_miss");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnName("LastUpdate_date")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
