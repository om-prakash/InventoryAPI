﻿using System;
using System.Collections.Generic;

namespace COBLoggingDashboard.Models
{
    public partial class TWellnessMemberlinkRuntime
    {
        public int RowId { get; set; }
        public string StepName { get; set; }
        public string ProcessName { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public string Extra { get; set; }
        public string Type { get; set; }
        public DateTime? LastUpdateDate { get; set; }
    }
}
