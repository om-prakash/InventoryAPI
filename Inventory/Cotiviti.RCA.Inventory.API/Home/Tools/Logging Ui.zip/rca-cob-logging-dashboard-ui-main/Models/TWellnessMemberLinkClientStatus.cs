﻿using System;
using System.Collections.Generic;

namespace COBLoggingDashboard.Models
{
    public partial class TWellnessMemberLinkClientStatus
    {
        public int RowId { get; set; }
        public int AccountId { get; set; }
        public string ClientName { get; set; }
        public int? MatchCount { get; set; }
        public DateTime? LastProcessedDt { get; set; }
        public string AuditMgrName { get; set; }
        public int? AuditMgrId { get; set; }
        public DateTime? LastUpdateDate { get; set; }
    }
}
