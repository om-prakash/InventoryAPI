﻿using System;
using System.Collections.Generic;

namespace COBLoggingDashboard.Models
{
    public partial class TWellnessCobJobsStatus
    {
        public int RowId { get; set; }
        public string Procname { get; set; }
        public int AccountId { get; set; }
        public string ClientName { get; set; }
        public string Location { get; set; }
        public int? MaxRuntime { get; set; }
        public string Interval { get; set; }
        public DateTime? LastRunTime { get; set; }
        public string Status { get; set; }
        public string ProcessDesc { get; set; }
        public string Type { get; set; }
        public string FieldList { get; set; }
        public DateTime? ControllerDate { get; set; }
        public int? StepNo { get; set; }
        public string AuditMgrName { get; set; }
        public int? AuditMgrId { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public DateTime? LastSuccessDate { get; set; }
    }

    
}
