﻿using System;
using System.Collections.Generic;

namespace COBLoggingDashboard.Models
{
    public partial class TWellnessAutomatedNovaReportDetailDaily
    {
        public int RowId { get; set; }
        public string LaunchDate { get; set; }
        public int AccountId { get; set; }
        public string ClientName { get; set; }
        public int? MembersReviewed { get; set; }
        public int? MembersPositivelyIdentified { get; set; }
        public double? HitRate { get; set; }
        public decimal? Id { get; set; }
        public double? HoursWorked { get; set; }
        public double? IdHour { get; set; }
        public string AuditMgrName { get; set; }
        public int? AuditMgrId { get; set; }
        public DateTime? LastUpdateDate { get; set; }
    }
}
