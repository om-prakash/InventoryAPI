﻿using System;
using System.Collections.Generic;

namespace COBLoggingDashboard.Models
{
    public partial class TWellnessPcobFileStatus
    {
        public int RowId { get; set; }
        public string ProcessName { get; set; }
        public string ClientName { get; set; }
        public string FileName { get; set; }
        public DateTime? FileTransferDate { get; set; }
    }
}
