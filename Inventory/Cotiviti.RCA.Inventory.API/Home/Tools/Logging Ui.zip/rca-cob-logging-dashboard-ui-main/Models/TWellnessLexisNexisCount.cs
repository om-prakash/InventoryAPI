﻿using System;
using System.Collections.Generic;

namespace COBLoggingDashboard.Models
{
    public partial class TWellnessLexisNexisCount
    {
        public int RowId { get; set; }
        public int? AccountId { get; set; }
        public string ClientName { get; set; }
        public string ExportStatus { get; set; }
        public DateTime? ExportDate { get; set; }
        public int? ExportCounts { get; set; }
        public DateTime? LastExportSuccessDate { get; set; }
        public int? LastExportSuccessCounts { get; set; }
        public string ImportStatus { get; set; }
        public DateTime? ImportDate { get; set; }
        public int? ImportCounts { get; set; }
        public int? ImportHit { get; set; }
        public int? ImportMiss { get; set; }
        public DateTime? LastImportSuccessDate { get; set; }
        public int? LastImportSuccessCounts { get; set; }
        public int? LastImportSuccessHit { get; set; }
        public int? LastImportSuccessMiss { get; set; }
        public int? Active { get; set; }
        public string FolderName { get; set; }
        public string ExportComments { get; set; }
        public string ImportComments { get; set; }
        public DateTime? LastUpdateDate { get; set; }
    }
}
