﻿using System;
using System.Collections.Generic;

namespace COBLoggingDashboard.Models
{
    public partial class TAccountLexisNexis
    {
        public int AccountId { get; set; }
        public bool ThreePassMethod { get; set; }
        public string FolderPath { get; set; }
        public string PreProcessingSproc { get; set; }
    }
}
