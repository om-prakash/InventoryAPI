﻿using System;
using System.Collections.Generic;

namespace COBLoggingDashboard.Models
{
    public partial class TWellnessCaseMgmtStatus
    {
        public int AccountId { get; set; }
        public string ClientName { get; set; }
        public string ClientId { get; set; }
        public string AuditMgrName { get; set; }
        public int? AuditMgrId { get; set; }
        public DateTime? LastExportDate { get; set; }
        public DateTime? LastImportDate { get; set; }
        public DateTime? BacklogRunDate { get; set; }
        public int? CallCount { get; set; }
        public int? MissedCallCount { get; set; }
        public DateTime? LastUpdateDt { get; set; }
    }
}
