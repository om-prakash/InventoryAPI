﻿using System;
using System.Collections.Generic;

namespace COBLoggingDashboard.Models
{
    public partial class TAccount
    {
        public int AccountId { get; set; }
        public string ClientName { get; set; }
        public int AuditId { get; set; }
        public string Active { get; set; }
        public int DashboardReady { get; set; }
        public int? Retired { get; set; }
        public int? CheckDelay { get; set; }
        public int? PlatformId { get; set; }
        public int? ParentAccountId { get; set; }
    }
}
