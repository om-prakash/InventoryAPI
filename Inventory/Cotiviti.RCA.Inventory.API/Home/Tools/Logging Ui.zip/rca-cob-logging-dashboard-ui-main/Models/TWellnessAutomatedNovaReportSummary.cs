﻿using System;
using System.Collections.Generic;

namespace COBLoggingDashboard.Models
{
    public partial class TWellnessAutomatedNovaReportSummary
    {
        public int RowId { get; set; }
        public DateTime? Ytddate { get; set; }
        public int RowLabel { get; set; }
        public decimal TotalIdytd { get; set; }
        public double OverallIdHour { get; set; }
        public long WorkingDaysSinceProjectLaunch { get; set; }
        public decimal DailyIdRate { get; set; }
        public double Growth { get; set; }
        public decimal AvgOvpMbr { get; set; }
        public double TotalHoursWorked { get; set; }
        public double MbrHr { get; set; }
        public double OvpHitRt { get; set; }
        public DateTime? LastUpdateDate { get; set; }
    }
}
