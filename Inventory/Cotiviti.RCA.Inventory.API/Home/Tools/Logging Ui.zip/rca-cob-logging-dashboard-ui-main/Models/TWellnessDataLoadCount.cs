﻿using System;
using System.Collections.Generic;

namespace COBLoggingDashboard.Models
{
    public partial class TWellnessDataLoadCount
    {
        public int AccountId { get; set; }
        public string ClientName { get; set; }
        public string AccountMgr { get; set; }
        public DateTime? LastLoadDate { get; set; }
        public DateTime? NextLoadDate { get; set; }
        public int? TotalClaimsCount { get; set; }
        public int? LastClaimsCount { get; set; }
        public int? TotalMemberCount { get; set; }
        public int? LastMemberCount { get; set; }
        public int? AuditMgrId { get; set; }
        public DateTime? LastUpdateDate { get; set; }
    }
}
