﻿using System;
using System.Collections.Generic;

namespace COBLoggingDashboard.Models
{
    public partial class TAccountDashboardPsConfig
    {
        public int AccountId { get; set; }
        public string ClientName { get; set; }
        public string ExecType { get; set; }
        public string ScriptText { get; set; }
        public string FilePath { get; set; }
        public string FileName { get; set; }
        public string Command { get; set; }
        public string CommandArgs { get; set; }
        public int? ExecOrder { get; set; }
        public int? IsActive { get; set; }
        public string UpdateUser { get; set; }
        public DateTime? UpdateDt { get; set; }
    }
}
