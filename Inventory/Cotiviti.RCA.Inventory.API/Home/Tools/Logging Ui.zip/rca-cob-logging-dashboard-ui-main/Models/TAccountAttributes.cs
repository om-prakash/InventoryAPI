﻿using System;
using System.Collections.Generic;

namespace COBLoggingDashboard.Models
{
    public partial class TAccountAttributes
    {
        public int AccountId { get; set; }
        public string ServerDev { get; set; }
        public string ServerProd { get; set; }
        public string DbDev { get; set; }
        public string DbProd { get; set; }
        public string DbDevScreens { get; set; }
        public string DbProdScreens { get; set; }
        public string DbProdBase { get; set; }
        public string CustomCodeLocation { get; set; }
        public string DecipherName { get; set; }
        public string ProdDecipherPath { get; set; }
        public string DevDecipherPath { get; set; }
        public string ImageName { get; set; }
        public string LocalTeamDecipherFileProd { get; set; }
        public string LocalTeamFolder { get; set; }
        public string CollectionAdminLink { get; set; }
        public string DbCobTracker { get; set; }
        public string DbRootName { get; set; }
        public string ServerTest { get; set; }
        public string ServerQa { get; set; }
        public string DbTest { get; set; }
        public string DbQa { get; set; }
        public string DbTestScreens { get; set; }
        public string DbQaScreens { get; set; }
    }
}
