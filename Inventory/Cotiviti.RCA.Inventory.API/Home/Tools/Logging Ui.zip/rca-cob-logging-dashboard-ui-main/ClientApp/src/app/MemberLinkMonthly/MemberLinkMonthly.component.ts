import { AfterViewInit, Component, Inject, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
declare var jQuery: any;


@Component({
  selector: 'app-MemberLinkMonthly',
  templateUrl: './MemberLinkMonthly.component.html'
})
export class MemberLinkMonthlyComponent implements OnDestroy, OnInit, AfterViewInit {

  @ViewChild(DataTableDirective, { static: false })
  public datatableElement: DataTableDirective;
  dtOptions: any = {};
  dtTrigger: Subject<any> = new Subject();
  public myAppUrl: string = "";
  public lastUpdate;

  public mlnkMonthly: memberLinkMonthly[];
    
  public footer_membersReviewed: number = 0;
  public footer_membersPositivelyIdentified: number = 0;
  public footer_id: number = 0;

  dt = new Date()  //current date of week
  firstPrevMonth = new Date(this.dt.getMonth() == 0 ? this.dt.getFullYear() - 1 : this.dt.getFullYear(), this.dt.getMonth() == 0 ? 11 : this.dt.getMonth() - 1 ,1)
  firstNextMonth = new Date(this.dt.getFullYear(), this.dt.getMonth(), 1)
  lastPrevMonth = new Date(this.firstPrevMonth.getFullYear(), this.firstPrevMonth.getMonth()+1,this.firstNextMonth.getDate() - 1) //(this.lastWeek.getDay() +( 5 - this.lastWeek.getDay()))))


  constructor(private http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    this.myAppUrl = baseUrl;
    //http.get<memberLinkMonthly[]>(baseUrl + 'api/TMgAutomatedNovaReportDetailMonthlyDashboards').subscribe(result => {
    //  this.mlnkMonthly = result;
    //  for (let j = 0; j < this.mlnkMonthly.length; j++) {
       
    //    this.footer_membersReviewed = this.footer_membersReviewed + this.mlnkMonthly[j].membersReviewed;
    //    this.footer_membersPositivelyIdentified += this.mlnkMonthly[j].membersPositivelyIdentified;
    //    this.footer_id += this.mlnkMonthly[j].id;

       
        
    //  }
    //  //this._mlnksummary = this.mlnksummary.splice(0,1)
    //}, error => console.error(error));         


  }


  ngOnInit(): void {

    (function ($) {
      $(document).ready(function () {
        $('[data-toggle="tooltip"]').tooltip();
      });
    })(jQuery);

    this.dtOptions = {
      pageLength: 50,
      columns: [{
        //title: 'Account',
        data: 'clientName'
      },
        {
          //title: 'Account',
          data: 'auditMgrName'
        },
      {
        //title: 'Launch Date',
        data: 'launchDate'
      },
      {
        //title: 'Mbrs Reviewed',
        data: 'membersReviewed'
      },
      {
        //title: 'Mbrs Positively IDs',
        data: 'membersPositivelyIdentified'
      },
      {
        //title: 'Hit Rate',
        data: 'hitRate'
      },
      {
       // title: 'ID ($)',
        data: 'id'
      },
      {
       // title: 'Hrs Worked',
        data: 'hoursWorked'
      },
      {
        //title: 'ID/Hour',
        data: 'idHour'
      }

      ],
      dom: 'Bfrtip',
      lengthMenu: [
        [10, 25, 50, -1],
        ['10 rows', '25 rows', '50 rows', 'Show all']
      ],
      buttons: [
        'pageLength',
        { extend: 'pdf', text: '<i class="fas fa-file-pdf fa-1x" ></i><span class="dt-button buttons-pdf buttons-html5"> PDF</span>' },
        { extend: 'csv', text: '<i class="fas fa-file-csv fa-1x" ></i><span class="dt-button buttons-csv buttons-html5"> CSV</span>' },
        { extend: 'excel', text: '<i class="fas fa-file-excel fa-1x" ></i><span class="dt-button buttons-excel buttons-html5"> Excel</span>'}
        
        
      ]
    };

    this.http
      .get<memberLinkMonthly[]>(
        this.myAppUrl + 'api/TWellnessAutomatedNovaReportDetailMonthlies'
      )
      //.pipe(map(this.extractData))
      .subscribe((result: memberLinkMonthly[]) => {
        this.mlnkMonthly = result;
        this.lastUpdate = this.mlnkMonthly[0].lastUpdateDate;
        for (let j = 0; j < this.mlnkMonthly.length; j++) {

          this.footer_membersReviewed = this.footer_membersReviewed + this.mlnkMonthly[j].membersReviewed;
          this.footer_membersPositivelyIdentified += this.mlnkMonthly[j].membersPositivelyIdentified;
          this.footer_id += this.mlnkMonthly[j].id;



        }


        this.dtTrigger.next();
      });//, error => console.error(error));
  }





  ngAfterViewInit(): void {
    this.dtTrigger.subscribe(() => {
      this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
        dtInstance.columns().every(function () {
          const that = this;
          $('input', this.header()).on('keyup change', function () {
            if (that.search() !== this['value']) {
              that
                .search(this['value'])
                .draw();
            }
          });
          $('input', this.footer()).on('keyup change', function () {
            if (that.search() !== this['value']) {
              that
                .search(this['value'])
                .draw();
            }
          });

        });

      });

    });


  }

  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }

  


}
interface memberLinkMonthly
{
  rowId: number;
  launchDate: string;
  accountId: number;
  clientName: string;
  membersReviewed: number;
  membersPositivelyIdentified: number;
  hitRate: string;
  id: number;
  hoursWorked: string;
  idHour: number;
  auditMgrName: string;
  auditMgrId: string;
  lastUpdateDate: string;
  
}
