import { Component } from '@angular/core';

@Component({
  selector: 'app-Test',
  templateUrl: './Test.component.html'
  //styleUrls: ['./sb-admin-2.min.css', './vendor/fontawesome-free/css/all.min.css', './Fonts.css']  
  
})
export class TestComponent {
}
