import { AfterViewInit, Component, Inject, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { getLocaleDateFormat, formatDate, DatePipe, NumberFormatStyle, formatNumber } from '@angular/common';

declare var jQuery: any;

@Component({
  selector: 'app-LexisNexisCount',
  templateUrl: './LexisNexisCount.component.html'
  
  
})
export class LexisNexisCountComponent implements OnDestroy, OnInit, AfterViewInit {

  @ViewChild(DataTableDirective, { static: false })
  public datatableElement: DataTableDirective;
  dtOptions: any = {};
  dtTrigger: Subject<any> = new Subject();
  public myAppUrl: string = "";
  public _var: number = 0;
  public lastUpdate;
  public LexisNexis: string = "";
  
  public jobStatusSmry: jobStatusSummary[];

  //public jobStsCust: jobStatusCustom[];
  currentDate = new Date();
  prev_date = this.currentDate.setDate(this.currentDate.getDate() - 1)

  //lastYear = this.dt.getFullYear()  //(this.lastWeek.getDay() +( 5 - this.lastWeek.getDay()))))

  //deleteTest(e, test): void {
  //  e.preventDefault();

  //  // first unscribe any existing api subscription
  //  if (!!this.deleteSub) this.deleteSub.unsubscribe();

  //  // recall the server api with the latest data
  //  this.deleteSub = this.apiService.delete(`${this.urls.test}(${test.Id})`).subscribe(response => {

  //    this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
  //      // Destroy the table first
  //      dtInstance.destroy();

  //      // load the test grid again with new data
  //      this.getTestGrid();
  //    });
  //  },
  //    (error) => {
  //      this.error = true;
  //      this.dtTrigger.next();
  //    });
  //}

  //getTestGrid(): void {
  //  // first unscribe any existing api subscription
  //  if (!!this.apiSub) this.apiSub.unsubscribe();

  //  // load data
  //  this.apiSub = this.apiService.get(this.urls.test).subscribe(tests => {
  //    this.tests = tests;
  //    // Calling the DT trigger to manually render the table
  //    this.dtTrigger.next();
  //    this.error = false;
  //  },
  //    (error) => {
  //      this.error = true;
  //      this.dtTrigger.next();
  //    });
  //}

  constructor(private http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    this.myAppUrl = baseUrl;
    //http.get<memberLinkYearly[]>(baseUrl + 'api/TMgAutomatedNovaReportDetailDashboards').subscribe(result => {
    //  this.mlnkYearly = result;
    //  for (let j = 0; j < this.mlnkYearly.length; j++) {

    //    this.footer_membersReviewed = this.footer_membersReviewed + this.mlnkYearly[j].membersReviewed;
    //    this.footer_membersPositivelyIdentified += this.mlnkYearly[j].membersPositivelyIdentified;
    //    this.footer_id += this.mlnkYearly[j].id;



    //  }
    //  //this._mlnksummary = this.mlnksummary.splice(0,1)
    //}, error => console.error(error));         


  }

  //testEvent() {
   
  //  //this.render();
  //  alert('TEst');
  //}


  public render() {

  }

  ngOnInit(): void {

    this.render();


    (function ($) {
      $(document).ready(function () {
        $('[data-toggle="tooltip"]').tooltip();
      });
    })(jQuery);

    this.dtOptions = {
      pageLength: 50,
      //select: true,
      //orderCellsTop: true,
      //fixedHeader: true,
      columns: [{
        //title: 'Account',
        data: 'clientName'
      },
      //{
      //  //title: 'Account',
      //  data: 'clientName'
      //},
      {
        //title: 'Account',
        data: 'exportDate'
      },
      {
        //title: 'Account',
        data: 'exportCounts',

        },
        {
          //title: 'Account',
          data: 'exportStatus',
          //defaultContent: "<button>Export</button>"
          render: function (data, type, row) {
            if (type === 'display' && data == 'Success') {

              return '<button id="btnExportMsg" title="' + data + '" class = "btn btn-success btn-icon-split"> <span class="icon text-white-50"> <i id="i_Export"class="fas fa-check"></i></span></button><span id="spnExport"> ' + data+'</span>';
            }
            else if (type === 'display' && data == 'Failure') {

              return '<button id="btnExportMsg" title="' + data + '" class = "btn btn-danger btn-icon-split"> <span class="icon text-white-50"> <i id="i_Export" class="fas fa-times"></i></span></button><span id="spnExport">  ' + data + '</span>';
            }
            else{

              //return '<button id="btnNoRun" title="' + data + '" class = "btn btn-warning btn-icon-split"> <span class="icon text-white-50"> <i id="i_NoRun"class="fa-exclamation-triangle"></i></span></button><span id="spnNoRun"> ' + data + '</span>';
            
              return '<button id="btnExportMsg" title="Did Not Run" class = "btn btn-warning btn-icon-split"> <span class="icon text-white-50"> <i id="i_Export" class="fas fa-exclamation-triangle"></i></span></button><span id="spnExport"> ' + data + '</span>';
            }
            //else {

            //  return '<span title="' + data + '" class = "btn btn-danger btn-icon-split"> <span class="icon text-white-50"> <i class="fas fa-exclamation-triangle"></i></span></span> ' + data;
            //}
          }
           
        },
      {
        //title: 'Account',
        data: 'export',
        //defaultContent: "<button>Export</button>"

      },
      {
        //title: 'Account',
        data: 'importDate'
      },
      {
        //title: 'Account',
        data: 'importCounts'
      },
      {
        //title: 'Run Date',
        data: 'hit'
      },
      {
        //title: 'Environment',
        data: 'miss'
        },
        {
          //title: 'Account',
          data: 'importStatus',
          //defaultContent: "<button>Export</button>"
          render: function (data, type, row) {
            if (type === 'display' && data == 'Success') {

              return '<button id="btnImportMsg" title="' + data + '" class = "btn btn-success btn-icon-split"> <span class="icon text-white-50"> <i id="i_Import"class="fas fa-check"></i></span></button><span id="spnImport"> ' + data + '</span>';
            }
            else if (type === 'display' && data === 'Failure') {
              
              return '<button id="btnImportMsg" title="' + data + '" class = "btn btn-danger btn-icon-split"> <span class="icon text-white-50"> <i id="i_Import" class="fas fa-times"></i></span></button><span id="spnImport">  ' + data + '</span>';
            }
            else {

              //return '<button id="btnNoRun" title="' + data + '" class = "btn btn-warning btn-icon-split"> <span class="icon text-white-50"> <i id="i_NoRun"class="fa-exclamation-triangle"></i></span></button><span id="spnNoRun"> ' + data + '</span>';

              return '<button id="btnImportMsg" title="Did Not Run" class = "btn btn-warning btn-icon-split"> <span class="icon text-white-50"> <i id="i_Import" class="fas fa-exclamation-triangle"></i></span></button><span id="spnImport"> ' + data + '</span>';
            }
            //else {

            //  return '<span title="' + data + '" class = "btn btn-danger btn-icon-split"> <span class="icon text-white-50"> <i class="fas fa-exclamation-triangle"></i></span></span> ' + data;
            //}
          }
        },
      {
        //title: 'Account',
        data: 'import'
        },
        {
          //title: 'Account',
          data: 'lastExportSuccessDate',
          class: 'none'
        },
        {
          //title: 'Account',
          data: 'lastExportSuccessCounts',
          class: 'none'
        },
        {
          //title: 'Account',
          data: 'lastImportSuccessDate',
          class: 'none'
        },
        {
          //title: 'Account',
          data: 'lastImportSuccessCounts',
          class: 'none'
        },
        {
          //title: 'Account',
          data: 'lastImportSuccessHit',
          class: 'none'
        },
        {
          //title: 'Account',
          data: 'lastImportSuccessMiss',
          class: 'none'
        }
      ],
      dom: 'Bfrtip',
      buttons: [
        'pageLength',
        { extend: 'pdf', text: '<i class="fas fa-file-pdf fa-1x" ></i><span class="dt-button buttons-pdf buttons-html5"> PDF</span>' },
        { extend: 'csv', text: '<i class="fas fa-file-csv fa-1x" ></i><span class="dt-button buttons-csv buttons-html5"> CSV</span>' },
        { extend: 'excel', text: '<i class="fas fa-file-excel fa-1x" ></i><span class="dt-button buttons-excel buttons-html5"> Excel</span>' }
        //{

        //  text: '<i class="fas fa-file-excel fa-1x" ></i><span class="dt-button buttons-excel buttons-html5">Export All </span>',
        //  action: function (e, dt, node, config) {
        //    alert('Button activated');

        //  }
        //}


      ],
      responsive: true


    };

    this.http
      .get<jobStatusSummary[]>(
        this.myAppUrl + 'api/TWellnessLexisNexisCount'
      )
      //.pipe(map(this.extractData))
      .subscribe((result: jobStatusSummary[]) => {
        this.jobStatusSmry = result;
        this.lastUpdate = this.jobStatusSmry[0].lastUpdateDate;

        for (let j = 0; j < this.jobStatusSmry.length; j++) {

          if (this.lastUpdate < this.jobStatusSmry[j].lastUpdateDate) {
            this.lastUpdate = this.jobStatusSmry[j].lastUpdateDate;
          }
        }


        this.dtTrigger.next();
      });//, error => console.error(error));
   
  
   
  }
   


  ngAfterViewInit(): void {

    //let example: any = $('#datatable').;
    
    //$('#datatable').DataTable({
    //  "createdRow": function (row, data, index) {

    //    $('td', row).eq(5).addClass('highlight');
    
    //  }
    //});

    /*
    this.dtTrigger.subscribe(() => {
      this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
        dtInstance.buttons().action(function () {
          const that = this;

          $('button').on('click',  function () {

            alert('Test');
            //var _header = $('tbody th', this.header());
            //_header.each(function () {
            //  var sTitle;
            //  var nTds = $('td', this);
            //  var sBrowser = $(nTds[1]).text();
            //  alert(nTds);

            //  if (sBrowser == "Account")
            //    sTitle = 'Test';

            //  this.setAttribute('title', sTitle);
            //});

          });
        });

      });




    });
    */

    this.dtTrigger.subscribe(() => {
      this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
          dtInstance.columns().every(function () {
            const that = this;
            
 

            //$('input', this.data()).on('click', 'td button', function () {
            //  alert('Test');
              
            //  //if (that.search() !== this['value']) {
            //  //  that
            //  //    .search(this['value'])
            //  //    .draw();
            //  //}

            //});


            $('input', this.header()).on('keyup change', function () {
              //alert(this['value']);
            if (that.search() !== this['value']) {
              that
                .search(this['value'])
                .draw();
              }
             
            });

            $('input', this.footer()).on('keyup change', function () {
              if (that.search() !== this['value']) {
                that
                  .search(this['value'])
                  .draw();
              }
              //alert(this['value']);
            });
        });

      });


 

      });

    /*
    $('#tblDatatable tbody').on('click', '.btn btn-success btn-icon-split', function () {


      var $row = $(this).closest("tr");       // Finds the closest row <tr>
      var $Account = $row.find("td:eq(0)").text().trim();
      var $Action = $row.find("td:eq(3)").text().trim();
      //alert($Account + ":" + $Action);
      $('.modal-header').html("LexisNexis Export");
      $('.modal-body').html("Import has been completed successfully for " + $Account );
      (<any>$('#InfoModalCenter')).modal('show');
           
    });

    $('#tblDatatable tbody').on('click', '#btnFailure', function () {


      var $row = $(this).closest("tr");       // Finds the closest row <tr>
      var $Account = $row.find("td:eq(0)").text().trim();
      var $Action = $row.find("td:eq(3)").text().trim();
      //alert($Account + ":" + $Action);
      $('.modal-header').html("LexisNexis Export");
      $('.modal-body').html("Import has been completed successfully for " + $Account);

      (<any>$('#InfoModalCenter')).modal('show');

    });

*/
    
    $('#tblDatatable tbody').on('click', '#btnExport', function (e) {

      console.log(e);
      var $row = $(this).closest("tr");       // Finds the closest row <tr>
      var $Account = $row.find("td:eq(0)").text().trim();
      var $Action = "Export"
      //alert($Account + ":" + $Action);
      $('.modal-header').html("LexisNexis Export");
      $('.modal-body').html("Are you sure you want to run export for " + $Account +"?");
            
      (<any>$('#ImpExpModalCenter')).modal('show');




      $('#idConfirm').one('click', function (e) {
        //alert($Account);
      //var $row = $(this).closest("tr");       // Finds the closest row <tr>
      //var $Account = $row.find("td:eq(0)").text().trim();
      //alert('Export: ' + $row.find("td:eq(0)").text()); // Finds the 2nd <td> element
      //$row.find("td:eq(0)").html($Account+":Test");

      //alert($('#tblDatatable tbody tr').find("td:eq(0)").text());
        (<any>$('#ImpExpModalCenter')).modal('hide');
        console.log(e);
        $.ajax({
          contentType: 'application/json',
          type: "GET",
          beforeSend: function () {
            $('#loadingmessage').show();


          },
          url: "http://dev.cobloggingdashboard.cotiviti.com/api/TWellnessLexisNexisCount/LexisNexis?client_name=" + $Account + "&&action=" + $Action,
          dataType: "json",
          success: function (result, status, xhr) {
            const datepipe: DatePipe = new DatePipe('en-US');
            

            $row.find("td:eq(1)").html(datepipe.transform(result[0].exportDate, "MM/dd/yyyy h:mm a"));
            $row.find("td:eq(2)").html(result[0].exportCounts);
            $row.find("td:eq(11)").html(datepipe.transform(result[0].lastExportSuccessDate, "MM/dd/yyyy h:mm a"));  
            $row.find("td:eq(12)").html(result[0].lastExportSuccessCounts);
            $row.find("td:eq(3) #btnExportMsg").removeClass();
            $row.find("td:eq(3) #i_Export").removeClass();
            $row.find("td:eq(3) #spnExport").html(" " + result[0].exportStatus);
            var mdlbody = "";
            if (result[0].exportStatus == "Success") {

              $row.find("td:eq(3) #btnExportMsg").addClass("btn btn-success btn-icon-split")
              $row.find("td:eq(3) #i_Export").addClass("fas fa-check")


              /*
              if ($row.find("td:eq(3) #spnUnknown").length > 0) {

                
                $row.find("td:eq(3) #btnoRun").removeClass("btn btn-warning btn-icon-split");
                $row.find("td:eq(3) #i_noRun").removeClass("fas fa-exclamation-triangle");
                $row.find("td:eq(3) #spnUnknown").html(" " + result[0].exportStatus);
                $row.find("td:eq(3) #btnoRun").addClass("btn btn-success btn-icon-split");
                $row.find("td:eq(3) #i_noRun").addClass("fas fa-check");
              }
              if ($row.find("td:eq(3) #spnFailure").length > 0) {

              
                $row.find("td:eq(3) #btnFailure").removeClass("btn btn-danger btn-icon-split");                
                $row.find("td:eq(3) #i_fail").removeClass("fas fa-times");
                $row.find("td:eq(3) #spnFailure").html(" " + result[0].exportStatus);
                $row.find("td:eq(3) #btnFailure").addClass("btn btn-success btn-icon-split");
                $row.find("td:eq(3) #i_fail").addClass("fas fa-check");

              }
              */

              mdlbody = "<b>Export has been completed successfully for " + $Account + "</b><br>";
              mdlbody += "Folder Name:  " + result[0].folderName + " <br>";
              mdlbody += "File Name: " + result[0].exportComments + "<br><br>";
              mdlbody += "Next Step: <br>";
              mdlbody += "1.	Go to shared path folder to grab the file <br>";
              mdlbody += "2.	Go to <a href='https://batchwebgateway.lexisnexis.com/app/bwg/main' target='_blank'>LexisNexis</a> and login through user credentials <br>";
              mdlbody += "3.	Feed the export file to <a href='https://batchwebgateway.lexisnexis.com/app/bwg/main' target='_blank'>LexisNexis</a> and complete the export <br>";



            }
            else if (result[0].exportStatus == "Failure") {


              $row.find("td:eq(3) #btnExportMsg").addClass("btn btn-danger btn-icon-split")
              $row.find("td:eq(3) #i_Export").addClass("fas fa-times")

              /*
              if ($row.find("td:eq(3) #spnUnknown").length > 0) {

               
                $row.find("td:eq(3) #btnoRun").removeClass("btn btn-warning btn-icon-split");
                $row.find("td:eq(3) #i_noRun").removeClass("fas fa-exclamation-triangle");
                $row.find("td:eq(3) #spnUnknown").html(" " + result[0].exportStatus);
                $row.find("td:eq(3) #btnoRun").addClass("btn btn-danger btn-icon-split");
                $row.find("td:eq(3) #i_noRun").addClass("fas fa-times");
              }
              if ($row.find("td:eq(3) #spnSuccess").length > 0) {

                $row.find("td:eq(3) #btnSuccess").removeClass("btn btn-success btn-icon-split");
                $row.find("td:eq(3) #i_success").removeClass("fas fa-check");
                $row.find("td:eq(3) #spnSuccess").html(" " + result[0].exportStatus);
                $row.find("td:eq(3) #btnSuccess").addClass("btn btn-danger btn-icon-split");
                $row.find("td:eq(3) #i_success").addClass("fas fa-times");
                
              }
              */

              mdlbody = "Export has been failed for " + $Account + "<br>";
              mdlbody += "Error Details: <br>";
              mdlbody += result[0].exportComments;

              //if ($row.find("td:eq(3) #spnUnknown").length > 0) {

              //  $row.find("td:eq(3) #spnUnknown").html(" " + result[0].exportStatus);
              //}
              //if ($row.find("td:eq(3) #spnSuccess").length > 0) {

              //  $row.find("td:eq(3) #spnSuccess").html(" " + result[0].exportStatus);
              //}
            }
            else if (result[0].importStatus == "DNR-x") {

              $row.find("td:eq(3) #btnExportMsg").addClass("btn btn-warning btn-icon-split")
              $row.find("td:eq(3) #i_Export").addClass("fas fa-exclamation-triangle")
              mdlbody = "Export has been failed for " + $Account + "<br>";
              mdlbody += "Error Details: <br>";
              mdlbody += result[0].exportComments;
            }
            //if ($row.find("td:eq(3) #btnFailure").length > 0) {

            //  $row.find("td:eq(3) #btnFailure").removeClass("btn btn-danger");
            //  $row.find("td:eq(3) #btnFailure").addClass("btn btn-success btn-icon-split");
            //  $row.find("td:eq(3) #i_Failure").removeClass("fas fa-times");
            //  $row.find("td:eq(3) #i_Failure").addClass("fas fa-check");
              
            //  $row.select();
            //}
            //else if ($row.find("td:eq(3) #btnoRun").length > 0) {

            //  $row.find("td:eq(3) #btnoRun").removeClass("btn btn-warning btn-icon-split");
            //  $row.find("td:eq(3) #i_noRun").removeClass("fas fa-exclamation-triangle");
            //  $row.find("td:eq(3) #btnoRun").addClass("btn btn-success btn-icon-split");              
            //  $row.find("td:eq(3) #i_noRun").addClass("fas fa-check");
            //}
       

            //var mdlbody = "Import has been completed successfully for " + $Account + ".<br>";
            //mdlbody += "Folder Name: 2020-02-01 <br>";
            //mdlbody += "File Name: " + result[0].exportComments;
            //mdlbody += "Next Step: ";


            $('.modal-header').html("LexisNexis Export");
            $('.modal-body').html(mdlbody);
            (<any>$('#InfoModalCenter')).modal('show');

          },
          error: function (xhr, status, error) {
            //alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
            var mdlbody = "Export has been failed for " + $Account + "<br>";
            mdlbody += "Error Details: " + status +"<br>";
            mdlbody += xhr.status + "<br>";
            mdlbody += xhr.statusText + "<br>";

            $('.modal-header').html("LexisNexis Export");
            $('.modal-body').html(mdlbody);
            (<any>$('#InfoModalCenter')).modal('show');
          }
          //timeout: 3000

        })
          .done(function (data) {
            $('#loadingmessage').hide();
          });

    });

    });


    $('#tblDatatable tbody').on('click', '#btnImport', function (e) {


      console.log(e);
      var $row = $(this).closest("tr");       // Finds the closest row <tr>
      var $Account = $row.find("td:eq(0)").text().trim();
      var $Action = "Import"
      //alert($Account + ":" + $Action);
      $('.modal-header').html("LexisNexis Import");
      $('.modal-body').html("Are you sure you want to run import for " + $Account + "? <br><br> <small>Note: Please make sure the import file placed on same folder used to export file.</small>");

      (<any>$('#ImpExpModalCenter')).modal('show');




      $('#idConfirm').one('click', function (e) {
        //alert($Account);
        //var $row = $(this).closest("tr");       // Finds the closest row <tr>
        //var $Account = $row.find("td:eq(0)").text().trim();
        //alert('Export: ' + $row.find("td:eq(0)").text()); // Finds the 2nd <td> element
        //$row.find("td:eq(0)").html($Account+":Test");

        //alert($('#tblDatatable tbody tr').find("td:eq(0)").text());
        (<any>$('#ImpExpModalCenter')).modal('hide');
        console.log(e);
        $.ajax({
          contentType: 'application/json',
          type: "GET",
          beforeSend: function () {
            $('#loadingmessage').show();


          },
          url: "http://dev.cobloggingdashboard.cotiviti.com/api/TWellnessLexisNexisCount/LexisNexis?client_name=" + $Account + "&&action=" + $Action,
          dataType: "json",
          success: function (result, status, xhr) {
            var mdlbody = "";
            const impdatepipe: DatePipe = new DatePipe('en-US');

            $row.find("td:eq(5)").html(impdatepipe.transform(result[0].importDate, "MM/dd/yyyy h:mm a"));   
            $row.find("td:eq(6)").html(result[0].importCounts);
            $row.find("td:eq(7)").html(result[0].importHit);
            $row.find("td:eq(8)").html(result[0].importMiss);
            $row.find("td:eq(13)").html(impdatepipe.transform(result[0].lastImportSuccessDate, "MM/dd/yyyy h:mm a")); 
            $row.find("td:eq(14)").html(result[0].lastImportSuccessCounts);
            $row.find("td:eq(15)").html(result[0].lastImportSuccessHit);
            $row.find("td:eq(16)").html(result[0].lastImportSuccessMiss);
            $row.find("td:eq(9) #btnImportMsg").removeClass();
            $row.find("td:eq(9) #i_Import").removeClass();
            $row.find("td:eq(9) #spnImport").html(" " + result[0].importStatus);
            if (result[0].importStatus =="Success") {
              $row.find("td:eq(9) #btnImportMsg").addClass("btn btn-success btn-icon-split")
              $row.find("td:eq(9) #i_Import").addClass("fas fa-check")
              /*
              if ($row.find("td:eq(9) #spnImpUnknown").length > 0) {


                $row.find("td:eq(9) #btImpnoRun").removeClass("btn btn-warning btn-icon-split");
                $row.find("td:eq(9) #Imp_noRun").removeClass("fas fa-exclamation-triangle"); 
                $row.find("td:eq(9) #spnImpUnknown").html(" " + result[0].importStatus);
                $row.find("td:eq(9) #btImpnoRun").addClass("btn btn-success btn-icon-split");
                $row.find("td:eq(9) #Imp_noRun").addClass("fas fa-check");
              }
              if ($row.find("td:eq(9) #spnImpFailure").length > 0) {


                $row.find("td:eq(9) #btnImpFailure").removeClass("btn btn-danger btn-icon-split");
                $row.find("td:eq(9) #Imp_fail").removeClass("fas fa-times");
                $row.find("td:eq(9) #spnImpFailure").html(" " + result[0].importStatus);
                $row.find("td:eq(9) #btnImpFailure").addClass("btn btn-success btn-icon-split");
                $row.find("td:eq(9) #Imp_fail").addClass("fas fa-check");

              }
              */

              mdlbody = "<b>Import has been completed successfully for " + $Account + " </b><br>";
              mdlbody += "Folder Name:" + result[0].folderName + "<br>";
              mdlbody += "File Name: " + result[0].importComments + "<br>";
           
            }
            else if (result[0].importStatus == "Failure") {

              $row.find("td:eq(9) #btnImportMsg").addClass("btn btn-danger btn-icon-split")
              $row.find("td:eq(9) #i_Import").addClass("fas fa-times")
              /*
              if ($row.find("td:eq(9) #spnImpUnknown").length > 0) {


                $row.find("td:eq(9) #btImpnoRun").removeClass("btn btn-warning btn-icon-split");
                $row.find("td:eq(9) #Imp_noRun").removeClass("fas fa-exclamation-triangle");
                $row.find("td:eq(9) #spnImpUnknown").html(" " + result[0].importStatus);
                $row.find("td:eq(9) #btImpnoRun").addClass("btn btn-danger btn-icon-split");
                $row.find("td:eq(9) #Imp_noRun").addClass("fas fa-times");
              }
              if ($row.find("td:eq(9) #spnImpSuccess").length > 0) {

                $row.find("td:eq(9) #btnImpSuccess").removeClass("btn btn-success btn-icon-split");
                $row.find("td:eq(9) #Imp_success").removeClass("fas fa-check");
                $row.find("td:eq(9) #spnImpSuccess").html(" " + result[0].importStatus);
                $row.find("td:eq(9) #btnImpSuccess").addClass("btn btn-danger btn-icon-split");
                $row.find("td:eq(9) #Imp_success").addClass("fas fa-times");

              }
              */
              mdlbody = "Import has been failed for " + $Account + "<br>";
              mdlbody += "Error Details: <br>";
              mdlbody += result[0].importComments;

              //if ($row.find("td:eq(3) #spnUnknown").length > 0) {

              //  $row.find("td:eq(3) #spnUnknown").html(" " + result[0].exportStatus);
              //}
              //if ($row.find("td:eq(3) #spnSuccess").length > 0) {

              //  $row.find("td:eq(3) #spnSuccess").html(" " + result[0].exportStatus);
              //}
            }
            else if (result[0].importStatus == "DNR-x") {

              $row.find("td:eq(9) #btnImportMsg").addClass("btn btn-warning btn-icon-split")
              $row.find("td:eq(9) #i_Import").addClass("fas fa-exclamation-triangle")
              mdlbody = "Export has been failed for " + $Account + "<br>";
              mdlbody += "Error Details: <br>";
              mdlbody += result[0].exportComments;
            }
            //if ($row.find("td:eq(3) #btnFailure").length > 0) {

            //  $row.find("td:eq(3) #btnFailure").removeClass("btn btn-danger");
            //  $row.find("td:eq(3) #btnFailure").addClass("btn btn-success btn-icon-split");
            //  $row.find("td:eq(3) #i_Failure").removeClass("fas fa-times");
            //  $row.find("td:eq(3) #i_Failure").addClass("fas fa-check");

            //  $row.select();
            //}
            //else if ($row.find("td:eq(3) #btnoRun").length > 0) {

            //  $row.find("td:eq(3) #btnoRun").removeClass("btn btn-warning btn-icon-split");
            //  $row.find("td:eq(3) #i_noRun").removeClass("fas fa-exclamation-triangle");
            //  $row.find("td:eq(3) #btnoRun").addClass("btn btn-success btn-icon-split");              
            //  $row.find("td:eq(3) #i_noRun").addClass("fas fa-check");
            //}


            //var mdlbody = "Import has been completed successfully for " + $Account + ".<br>";
            //mdlbody += "Folder Name: 2020-02-01 <br>";
            //mdlbody += "File Name: " + result[0].exportComments;
            //mdlbody += "Next Step: ";


            $('.modal-header').html("LexisNexis Import");
            $('.modal-body').html(mdlbody);
            (<any>$('#InfoModalCenter')).modal('show');

          },
          error: function (xhr, status, error) {
            //alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
            var mdlbody = "Import has been failed for " + $Account + ".<br>";
            mdlbody += "Error Details: " + status + "<br>";
            mdlbody += xhr.status + "<br>";
            mdlbody += xhr.statusText + "<br>";

            $('.modal-header').html("LexisNexis Export");
            $('.modal-body').html(mdlbody);
            (<any>$('#InfoModalCenter')).modal('show');
          }
          //timeout: 3000

        })
          .done(function (data) {
            $('#loadingmessage').hide();
          });

      });
      /*
      var $row = $(this).closest("tr");       // Finds the closest row <tr>
      var $Account = $row.find("td:eq(0)").text().trim();
      var $Action = $row.find("td:eq(8)").text().trim();
      alert($Account + ":" + $Action);
      $('.modal-header').html("LexisNexis Import");
      $('.modal-body').html("Are you sure you want to run import for " + $Account + "?");
      (<any>$('#exampleModalCenter')).modal('show');

      $('#idConfirm').one('click', function (e) {
        
        $.ajax({
          contentType: 'application/json',
          type: "GET",
          url: "http://localhost:50373/api/TWellnessLexisNexisCount/LexisNexis?client_name=" + $Account + "&&action=" + $Action,
          dataType: "json",
          success: function (result, status, xhr) {
            alert(result[0].exportCounts);
          },
          error: function (xhr, status, error) {
            alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
          },
          timeout: 3000

        });

        (<any>$('#exampleModalCenter')).modal('hide');


      });
      */

    });

 


  }

  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
}

interface jobStatusSummary {
  rowId: number;
  accountId: number;
  clientName: string;
  exportStatus: string;
  exportDate: string;
  exportCounts: number;
  lastExportSuccessDate: string;
  lastExportSuccessCounts: number;
  importStatus: string;
  importDate: string;
  importCounts: number;
  importHit: number;
  importMiss: number;
  lastImportSuccessDate: string;
lastImportSuccessCounts: number;
lastImportSuccessHit: number;
lastImportSuccessMiss: number;
active: number;
  exportComments: string;
  importComments: string;
  lastUpdateDate: string;

  
}

/*
interface jobStatusCustom {
  clientNm: string;
  location: string;
  maxRuntime: number;
  interval: string;
  lastRunTime: string;
  status: string;
  processDesc: string;
  ErrorsuccDesc?: string;
  opsEng: string;
  fieldList: string;
  controllerDate: string;
  auditMgr: string;
}*/

