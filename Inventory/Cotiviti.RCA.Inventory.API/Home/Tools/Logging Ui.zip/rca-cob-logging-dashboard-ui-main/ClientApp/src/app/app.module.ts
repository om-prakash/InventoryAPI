import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { CounterComponent } from './counter/counter.component';
import { FetchDataComponent } from './fetch-data/fetch-data.component';
import { NightlyJobsComponent } from './NightlyJobs/NightlyJobs.component';
import { DataLoadsComponent } from './DataLoads/DataLoads.component';
import { MemberLinkSummaryComponent } from './MemberLinkSummary/MemberLinkSummary.component';
import { MemberLinkDailyComponent } from './MemberLinkDaily/MemberLinkDaily.component';
import { MemberLinkWeeklyComponent } from './MemberLinkWeekly/MemberLinkWeekly.component';
import { MemberLinkMonthlyComponent } from './MemberLinkMonthly/MemberLinkMonthly.component';
import { MemberLinkYearlyComponent } from './MemberLinkYearly/MemberLinkYearly.component';
import { AutoDialerComponent } from './AutoDialer/AutoDialer.component';
import { MemberLinkRuntimeComponent } from './MemberLinkRuntime/MemberLinkRuntime.component';
import { MemberLinkClientComponent } from './MemberLinkClient/MemberLinkClient.component';
import { DataLoadCountsComponent } from './DataLoadCounts/DataLoadCounts.component';
import { MemberLinkClientLevelComponent } from './MemberLinkClientLevel/MemberLinkClientLevel.component';
import { PCOBFileStatusComponent } from './PCOBFileStatus/PCOBFileStatus.component';
import { LexisNexisCountComponent } from './LexisNexisCount/LexisNexisCount.component';
import { TestComponent } from './Test/Test.component';
import { DataTablesModule } from 'angular-datatables';

@NgModule({
  declarations: [
    AppComponent,
    NavMenuComponent,
    HeaderComponent,
    HomeComponent,
    CounterComponent,
    FetchDataComponent,
    NightlyJobsComponent,
    DataLoadsComponent,
    MemberLinkSummaryComponent,
    MemberLinkDailyComponent,
    MemberLinkWeeklyComponent,
    MemberLinkMonthlyComponent,
    MemberLinkYearlyComponent,
    MemberLinkRuntimeComponent,
    MemberLinkClientComponent,
    DataLoadCountsComponent,
    MemberLinkClientLevelComponent,
    PCOBFileStatusComponent,
    LexisNexisCountComponent,
    TestComponent,
    AutoDialerComponent
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
    DataTablesModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot([
      { path: '', component: HomeComponent, pathMatch: 'full' },
      { path: 'home', component: HomeComponent },
      { path: 'counter', component: CounterComponent },
      { path: 'fetch-data', component: FetchDataComponent },
      { path: 'NightlyJobs', component: NightlyJobsComponent },
      { path: 'DataLoads', component: DataLoadsComponent },
      { path: 'MemberLinkSummary', component: MemberLinkSummaryComponent },
      { path: 'MemberLinkDaily', component: MemberLinkDailyComponent },
      { path: 'MemberLinkWeekly', component: MemberLinkWeeklyComponent },
      { path: 'MemberLinkMonthly', component: MemberLinkMonthlyComponent },
      { path: 'MemberLinkYearly', component: MemberLinkYearlyComponent },
      { path: 'MemberLinkRuntime', component: MemberLinkRuntimeComponent },
      { path: 'MemberLinkClient', component: MemberLinkClientComponent },
      { path: 'DataLoadCounts', component: DataLoadCountsComponent },
      { path: 'AutoDialer', component: AutoDialerComponent },
      { path: 'MemberLinkClientLevel', component: MemberLinkClientLevelComponent },
      { path: 'PCOBFileStatus', component: PCOBFileStatusComponent },
      { path: 'LexisNexisCount', component: LexisNexisCountComponent },
      { path: 'Test', component: TestComponent }
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
