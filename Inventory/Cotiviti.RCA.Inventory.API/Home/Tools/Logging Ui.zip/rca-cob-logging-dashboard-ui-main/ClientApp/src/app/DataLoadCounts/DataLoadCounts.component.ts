import { AfterViewInit, Component, Inject, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { DatePipe } from '@angular/common';
declare var jQuery: any;

@Component({
  selector: 'app-DataLoadCounts',
  templateUrl: './DataLoadCounts.component.html',
  providers: [DatePipe]
  
})
export class DataLoadCountsComponent implements OnDestroy, OnInit, AfterViewInit {

  @ViewChild(DataTableDirective, { static: false })
  public datatableElement: DataTableDirective;
  dtOptions: any = {};
  dtTrigger: Subject<any> = new Subject();
  public myAppUrl: string = "";
  public _var: number = 0;
  public lastUpdate;
  public currentDate = new Date();
  public countSmry: dataloadCountSummary[];
  public countSmryCustm: dataloadCountSummary[];
  public dateformat;
  public datePipe: DatePipe;
  public futDate = this.currentDate.setDate(this.currentDate.getDate() + 10)

  constructor(private http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    this.myAppUrl = baseUrl;
  

  }


  ngOnInit(): void {

    (function ($) {
      $(document).ready(function () {
        $('[data-toggle="tooltip"]').tooltip();
      });
    })(jQuery);

    this.dtOptions = {
      pageLength: 50,
      //orderCellsTop: true,
      //fixedHeader: true,
      columns: [{
        //title: 'Account',
        data: 'clientName'
      },
      {
        //title: 'Account',
        data: 'accountMgr'
      },
      {
        //title: 'Run Date',
        data: 'lastLoadDate'
      },
      {
        //title: 'Environment',
        data: 'nextLoadDate'
        //render: function (data, type, row) {
        //  var data_ = data.split("$", 2);
        //  var datefrt = new Date(data_[0]).toLocaleDateString();

        //  if (type === 'display' && data_[1] == 'R') {
           
        //    return '<span title="' + data + '" data-toggle="tooltip" data-placement="bottom" class = "btn btn-warning btn-circle btn-sm""> <i class="fas fa-exclamation-triangle"></i></span> ' + datefrt ;
        //  }
        //  else if (type === 'display' && data_[1] == 'G') {

        //    return '<span title="' + data + '"  data-toggle="tooltip" data-placement="bottom" class = "btn btn-success btn-circle btn-sm"> <i class="fas fa-check"></i></span> ' + datefrt;
        //  }
         
        //  else {

        //    return datefrt;
        //  }

        //}
      },
      {
        //title: 'Total Run Time',
        data: 'totalClaimsCount'
        },
        {
          //title: 'Total Run Time',
          data: 'lastClaimsCount'
        },
        {
          //title: 'Total Run Time',
          data: 'totalMemberCount'
        },
        {
          //title: 'Total Run Time',
          data: 'lastMemberCount'
        }

      ],
      dom: 'Bfrtip',
      buttons: [
        'pageLength',
        { extend: 'pdf', text: '<i class="fas fa-file-pdf fa-1x" ></i><span class="dt-button buttons-pdf buttons-html5"> PDF</span>' },
        { extend: 'csv', text: '<i class="fas fa-file-csv fa-1x" ></i><span class="dt-button buttons-csv buttons-html5"> CSV</span>' },
        { extend: 'excel', text: '<i class="fas fa-file-excel fa-1x" ></i><span class="dt-button buttons-excel buttons-html5"> Excel</span>' }


      ],
      
    };

    this.http
      .get<dataloadCountSummary[]>(
        this.myAppUrl + 'api/TWellnessDataLoadCounts'
      )
      //.pipe(map(this.extractData))
      .subscribe((result: dataloadCountSummary[]) => {
        this.countSmry = result;
        this.lastUpdate = this.countSmry[0].lastUpdateDate;

        //this.countSmryCustm = this.countSmry;



        //for (let j = 0; j < this.countSmry.length; j++) {

        //  //  this.jobStsCust[j].clientNm = this.jobStatusSmry[j].clientNm;
        //  //this.jobStsCust[j].lastRunTime = this.jobStatusSmry[j].lastRunTime;

        //  if (this.currentDate > new Date(this.countSmry[j].nextLoadDate)) {

        //    this.countSmryCustm[j].nextLoadDate = this.countSmry[j].nextLoadDate + "$R";
        //  }

          //if (this.currentDate <= new Date(this.countSmry[j].nextLoadDate) && (new Date(this.futDate) >= new Date(this.countSmry[j].nextLoadDate))) {

          //  this.countSmryCustm[j].nextLoadDate = this.countSmry[j].nextLoadDate + "$G";
          //}


          //if ((this.currentDate.valueOf() - new Date(this.countSmry[j].nextLoadDate).valueOf() ) < 0 ){

          //  this.countSmryCustm[j].nextLoadDate = this.countSmry[j].nextLoadDate + "$R";
          //}

          //if (((this.currentDate.valueOf() - new Date(this.countSmry[j].nextLoadDate).valueOf()) >= 0) && ((this.currentDate.valueOf() - new Date(this.countSmry[j].nextLoadDate).valueOf()) <=3) ) {

          //  this.countSmryCustm[j].nextLoadDate = this.countSmry[j].nextLoadDate + "$G";
          //}

          //if (this.jobStatusSmry[j].location == 'prod') {
          //  this.jobStsCust[j].location = 'PROD';
          //}
          //else {
          //  this.jobStsCust[j].location = this.jobStatusSmry[j].location;
          //}

          ////this.jobStsCust[j].maxRuntime = this.jobStatusSmry[j].maxRuntime;
          //if (this.jobStatusSmry[j].interval == 'L') {
          //  this.jobStsCust[j].interval = 'Monthly';
          //}
          //else if (this.jobStatusSmry[j].interval == 'D') {
          //  this.jobStsCust[j].interval = 'Daily';
          //}
          //if (this.jobStatusSmry[j].status == 'Success') {

          //  this.jobStsCust[j].ErrorsuccDesc = 'None';
          //  this.jobStsCust[j].status = this.jobStatusSmry[j].status;
          //}
          //else {
          //  this.jobStsCust[j].ErrorsuccDesc = this.jobStatusSmry[j].status;
          //  this.jobStsCust[j].status = 'Failure';

          //}
          //this.jobStsCust[j].processDesc = this.jobStatusSmry[j].processDesc;
        //}


        this.dtTrigger.next();
      });//, error => console.error(error));
  }
   


  ngAfterViewInit(): void {

    //let example: any = $('#datatable').;
    
    //$('#datatable').DataTable({
    //  "createdRow": function (row, data, index) {

    //    $('td', row).eq(5).addClass('highlight');
    
    //  }
    //});

    this.dtTrigger.subscribe(() => {
      this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
          dtInstance.columns().every(function () {
          const that = this;
          
          //var _header = $('tbody th', this.header());
          //_header.each(function () {
          //  var sTitle;
          //  var nTds = $('td', this);
          //  var sBrowser = $(nTds[1]).text();
          //  alert(nTds);

          //  if (sBrowser == "Account")
          //    sTitle = 'Test';

          //  this.setAttribute('title', sTitle);
          //});


            $('input', this.header()).on('keyup change', function () {
              //alert(this['value']);
            if (that.search() !== this['value']) {
              that
                .search(this['value'])
                .draw();
              }
             
            });

            $('input', this.footer()).on('keyup change', function () {
              if (that.search() !== this['value']) {
                that
                  .search(this['value'])
                  .draw();
              }
              //alert(this['value']);
            });
        });

      });


 

      });



    //});


  }

  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
}

interface dataloadCountSummary {
  accountId: number;
  clientName: string;
  accountMgr: string;
  lastLoadDate: string;
  nextLoadDate: string;
  totalClaimsCount: number;
  lastClaimsCount: number;
  totalMemberCount: number;
  lastMemberCount: number;
  lastUpdateDate: string;
  
}

