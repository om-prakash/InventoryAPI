import { AfterViewInit, Component, Inject, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
declare var jQuery: any;

@Component({
  selector: 'app-MemberLinkSummary',
  templateUrl: './MemberLinkSummary.component.html'
})

export class MemberLinkSummaryComponent implements OnDestroy, OnInit,AfterViewInit {

  @ViewChild(DataTableDirective, { static: false })
  public datatableElement: DataTableDirective;
  dtOptions: any = {};
  dtTrigger: Subject<any> = new Subject();
  public myAppUrl: string = "";
  public lastUpdate;

  public mlnksummary: memberLinkSummary[];
  public _mlnksummary: memberLinkSummary[];

  public header_rowId: number;
  public header_ytddate: string;
  public header_rowLabel: string;
  public header_totalIdytd: number;
  public header_overallIdHour: string;
  public header_workingDaysSinceProjectLaunch: string;
  public header_dailyIdRate: string;
  public header_growth: string;
  public header_avgOvpMbr: string;
  public header_totalHoursWorked: string;
  public header_mbrHr: string;
  public header_ovpHitRt: string;
  public _userName: string = "Test";

  //constructor(private http: HttpClient) {
  //}

  constructor(private http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    this.myAppUrl = baseUrl;
    http.get(baseUrl + 'api/TWellnessAutomatedNovaReportSummaries/Search').subscribe((result: string) => {
      this._userName = result;
    //  for (let j = 0; j < this.mlnksummary.length; j++) {
    //    if (j==0)
    //    {
    //      this.header_totalIdytd = this.mlnksummary[j].totalIdytd;
    //      this.header_overallIdHour = this.mlnksummary[j].overallIdHour;
    //      this.header_workingDaysSinceProjectLaunch = this.mlnksummary[j].workingDaysSinceProjectLaunch;
    //      this.header_dailyIdRate = this.mlnksummary[j].dailyIdRate;
    //      this.header_growth = this.mlnksummary[j].growth;
    //      this.header_avgOvpMbr = this.mlnksummary[j].avgOvpMbr;
    //      this.header_totalHoursWorked = this.mlnksummary[j].totalHoursWorked;
    //      this.header_mbrHr = this.mlnksummary[j].mbrHr;
    //      this.header_ovpHitRt = this.mlnksummary[j].ovpHitRt;
    //    }


      //}
      //this._mlnksummary = this.mlnksummary.splice(0,1)
    }, error => console.error(error));         


  }

  ngOnInit(): void {

    (function ($) {
      $(document).ready(function () {
        $('[data-toggle="tooltip"]').tooltip();
      });
    })(jQuery);

    this.dtOptions = {
     // pagingType: 'full_numbers',
      pageLength: 5,
      columns: [{
        title: 'Start To Current Date',
        data: 'ytddate'
       },
        {
          title: 'Total ID StartToCurrent',
        data: 'totalIdytd'
        },
        {
          title: 'Overall ID/ Hr',
        data: 'overallIdHour'
      },
      {
        title: 'Work Days Since Launch',
        data: 'workingDaysSinceProjectLaunch'
      },
      {
        title: 'Daily ID Rate',
        data: 'dailyIdRate'
      },
      {
        title: 'Growth',
        data: 'growth'
      },
      {
        title: 'Avg Ovp/ Mbr',
        data: 'avgOvpMbr'
      },
      {
        title: ' Total Hrs Worked',
        data: 'totalHoursWorked'
      },
      {
        title: ' Mbr/Hr',
        data: 'mbrHr'
      },
      {
        title: 'OVP Hit/ Rt',
        data: 'ovpHitRt'
      }

      ],
      dom: 'Bfrtip',
      buttons: [
        { extend: 'pdf', text: '<i class="fas fa-file-pdf fa-1x" ></i><span class="dt-button buttons-pdf buttons-html5"> PDF</span>' },
        { extend: 'csv', text: '<i class="fas fa-file-csv fa-1x" ></i><span class="dt-button buttons-csv buttons-html5"> CSV</span>' },
        { extend: 'excel', text: '<i class="fas fa-file-excel fa-1x" ></i><span class="dt-button buttons-excel buttons-html5"> Excel</span>' }


      ]
    };

    this.http
      .get<memberLinkSummary[]>(
        this.myAppUrl + 'api/TWellnessAutomatedNovaReportSummaries'
      )
      //.pipe(map(this.extractData))
      .subscribe((result: memberLinkSummary[]) => {
        this.mlnksummary = result;
        this.lastUpdate = this.mlnksummary[0].lastUpdateDate;
        for (let j = 0; j < this.mlnksummary.length; j++) {
          if (j == 0) {
            this.header_totalIdytd = this.mlnksummary[j].totalIdytd;
            this.header_overallIdHour = this.mlnksummary[j].overallIdHour;
            this.header_workingDaysSinceProjectLaunch = this.mlnksummary[j].workingDaysSinceProjectLaunch;
            this.header_dailyIdRate = this.mlnksummary[j].dailyIdRate;
            this.header_growth = this.mlnksummary[j].growth;
            this.header_avgOvpMbr = this.mlnksummary[j].avgOvpMbr;
            this.header_totalHoursWorked = this.mlnksummary[j].totalHoursWorked;
            this.header_mbrHr = this.mlnksummary[j].mbrHr;
            this.header_ovpHitRt = this.mlnksummary[j].ovpHitRt;
          }
        }

        this._mlnksummary = this.mlnksummary.splice(0, 1)
        this.dtTrigger.next();
      });//, error => console.error(error));


  }



  ngAfterViewInit(): void {
    //this.dtTrigger.subscribe(() => {
    //  this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
    //    dtInstance.columns().every(function () {
    //      const that = this;
    //      $('input', this.footer()).on('keyup change', function () {
    //        if (that.search() !== this['value']) {
    //          that
    //            .search(this['value'])
    //            .draw();
    //        }
    //      });
    //    });
    //    dtInstance.cells().every(function () {
    //      if (this.data() > 1) {
    //        $(this.node()).addClass('.bg-gradient-success');
    //      }

    //    });
    //      });
        
    //  });

   
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }


}
interface memberLinkSummary {
  rowId: number;
  ytddate: string;
  rowLabel: string;
  totalIdytd: number;
  overallIdHour: string;
  workingDaysSinceProjectLaunch: string;
  dailyIdRate: string;
  growth: string;
  avgOvpMbr: string;
  totalHoursWorked: string;
  mbrHr: string;
  ovpHitRt: string;
  lastUpdateDate: string;
}

