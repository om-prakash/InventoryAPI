import { AfterViewInit, Component, Inject, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
declare var jQuery: any;

@Component({
  selector: 'app-MemberLinkClientLevel',
  templateUrl: './MemberLinkClientLevel.component.html'
  
  
})
export class MemberLinkClientLevelComponent implements OnDestroy, OnInit, AfterViewInit {

  @ViewChild(DataTableDirective, { static: false })
  public datatableElement: DataTableDirective;
  dtOptions: any = {};
  dtTrigger: Subject<any> = new Subject();
  public myAppUrl: string = "";
  public _var: number = 0;
  public lastUpdate;
  
  public jobStatusSmry: jobStatusSummary[];
  public footer_totprvDaycount: number = 0;
  public footer_totLastDaycount: number = 0;
  public footer_totMatchcntDiff: number = 0;
  public footer_totPercntDiff: string = "";

 // public jobStsCust: jobStatusCustom[];
  currentDate = new Date();
  prev_date = this.currentDate.setDate(this.currentDate.getDate() - 1)

  //lastYear = this.dt.getFullYear()  //(this.lastWeek.getDay() +( 5 - this.lastWeek.getDay()))))


  constructor(private http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    this.myAppUrl = baseUrl;
    //http.get<memberLinkYearly[]>(baseUrl + 'api/TMgAutomatedNovaReportDetailDashboards').subscribe(result => {
    //  this.mlnkYearly = result;
    //  for (let j = 0; j < this.mlnkYearly.length; j++) {

    //    this.footer_membersReviewed = this.footer_membersReviewed + this.mlnkYearly[j].membersReviewed;
    //    this.footer_membersPositivelyIdentified += this.mlnkYearly[j].membersPositivelyIdentified;
    //    this.footer_id += this.mlnkYearly[j].id;



    //  }
    //  //this._mlnksummary = this.mlnksummary.splice(0,1)
    //}, error => console.error(error));         


  }


  ngOnInit(): void {

    (function ($) {
      $(document).ready(function () {
        $('[data-toggle="tooltip"]').tooltip();
      });
    })(jQuery);

    this.dtOptions = {
      pageLength: 50,
      //orderCellsTop: true,
      //fixedHeader: true,
      columns: [{
        //title: 'Account',
        data: 'clientName'
      },
      {
        //title: 'Account',
        data: 'auditMgrName'
      },
      {
        //title: 'Run Date',
        data: 'loaddt'
        },
        {
          //title: 'Environment',
          data: 'matchLevel'
        },
      {
        //title: 'Environment',
        data: 'previousdata'
      },
        {
          //title: 'Environment',
          data: 'currentDayInventory'
        },
        {
          //title: 'Environment',
          data: 'matchCountDiff'
        },
       
        {
          //title: 'Environment',
          data: 'percentDiff'
        }

      ],
      dom: 'Bfrtip',
      buttons: [
        'pageLength',
        { extend: 'pdf', text: '<i class="fas fa-file-pdf fa-1x" ></i><span class="dt-button buttons-pdf buttons-html5"> PDF</span>' },
        { extend: 'csv', text: '<i class="fas fa-file-csv fa-1x" ></i><span class="dt-button buttons-csv buttons-html5"> CSV</span>' },
        { extend: 'excel', text: '<i class="fas fa-file-excel fa-1x" ></i><span class="dt-button buttons-excel buttons-html5"> Excel</span>' }


      ],
      
    };

    this.http
      .get<jobStatusSummary[]>(
        this.myAppUrl + 'api/TWellnessMemberLinkClientLevels'
      )
      //.pipe(map(this.extractData))
      .subscribe((result: jobStatusSummary[]) => {
        this.jobStatusSmry = result;
        this.lastUpdate = this.jobStatusSmry[0].lastUpdateDate;
        for (let j = 0; j < this.jobStatusSmry.length; j++) {

          this.footer_totprvDaycount += this.jobStatusSmry[j].previousdata;
          this.footer_totLastDaycount += this.jobStatusSmry[j].currentDayInventory;
          this.footer_totMatchcntDiff += this.jobStatusSmry[j].matchCountDiff;
          this.footer_totPercntDiff = ((this.footer_totMatchcntDiff / ((this.footer_totprvDaycount + this.footer_totLastDaycount) / 2)) * 100).toFixed();
          



        }
        /*this.jobStsCust = this.jobStatusSmry;

        for (let j = 0; j < this.jobStatusSmry.length; j++) {

          //  this.jobStsCust[j].clientNm = this.jobStatusSmry[j].clientNm;
          //this.jobStsCust[j].lastRunTime = this.jobStatusSmry[j].lastRunTime;
          if (this.jobStatusSmry[j].location == 'prod') {
            this.jobStsCust[j].location = 'PROD';
          }
          else {
            this.jobStsCust[j].location = this.jobStatusSmry[j].location;
          }

          //this.jobStsCust[j].maxRuntime = this.jobStatusSmry[j].maxRuntime;
          if (this.jobStatusSmry[j].interval == 'L') {
            this.jobStsCust[j].interval = 'Monthly';
          }
          else if (this.jobStatusSmry[j].interval == 'D') {
            this.jobStsCust[j].interval = 'Daily';
          }
          if (this.jobStatusSmry[j].status == 'Success') {

            this.jobStsCust[j].ErrorsuccDesc = 'None';
            this.jobStsCust[j].status = this.jobStatusSmry[j].status;
          }
          else {
            this.jobStsCust[j].ErrorsuccDesc = this.jobStatusSmry[j].status;
            this.jobStsCust[j].status = 'Failure';

          }
          //this.jobStsCust[j].processDesc = this.jobStatusSmry[j].processDesc;
        }*/


        this.dtTrigger.next();
      });//, error => console.error(error));
  }
   


  ngAfterViewInit(): void {

    //let example: any = $('#datatable').;
    
    //$('#datatable').DataTable({
    //  "createdRow": function (row, data, index) {

    //    $('td', row).eq(5).addClass('highlight');
    
    //  }
    //});

    this.dtTrigger.subscribe(() => {
      this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
          dtInstance.columns().every(function () {
          const that = this;
          
          //var _header = $('tbody th', this.header());
          //_header.each(function () {
          //  var sTitle;
          //  var nTds = $('td', this);
          //  var sBrowser = $(nTds[1]).text();
          //  alert(nTds);

          //  if (sBrowser == "Account")
          //    sTitle = 'Test';

          //  this.setAttribute('title', sTitle);
          //});


            $('input', this.header()).on('keyup change', function () {
              //alert(this['value']);
            if (that.search() !== this['value']) {
              that
                .search(this['value'])
                .draw();
              }
             
            });

            $('input', this.footer()).on('keyup change', function () {
              if (that.search() !== this['value']) {
                that
                  .search(this['value'])
                  .draw();
              }
              //alert(this['value']);
            });
        });

      });


 

      });



    //});


  }

  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
}

interface jobStatusSummary {
  rowId: number;
  accountId: number;
  clientName: string;
  matchLevel: number;
  loaddt: string;
  previousdata: number;
  currentDayInventory: number;
  matchCountDiff: number;
  percentDiff: number;
  auditMgrName: string;
  auditMgrId: string;
  lastUpdateDate: string
 
}

/*
interface jobStatusCustom {
  clientNm: string;
  location: string;
  maxRuntime: number;
  interval: string;
  lastRunTime: string;
  status: string;
  processDesc: string;
  ErrorsuccDesc?: string;
  opsEng: string;
  fieldList: string;
  controllerDate: string;
  auditMgr: string;
}
*/
