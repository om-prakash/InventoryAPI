﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using COBLoggingDashboard.Models;

namespace COBLoggingDashboard.Controllers
{
    [Route("api/TWellnessAutomatedNovaReportSummaries")]
    [ApiController]
    public class TWellnessAutomatedNovaReportSummariesController : ControllerBase
    {
        private readonly GlobalCnlyCentralizedCOBDashboardContext _context;

        public TWellnessAutomatedNovaReportSummariesController(GlobalCnlyCentralizedCOBDashboardContext context)
        {
            _context = context;
        }

        // GET: api/TWellnessAutomatedNovaReportSummaries
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TWellnessAutomatedNovaReportSummary>>> GetTWellnessAutomatedNovaReportSummary()
        {
            return await _context.TWellnessAutomatedNovaReportSummary.ToListAsync();
        }

        // GET: api/TWellnessAutomatedNovaReportSummaries/5
        [HttpGet("{id}")]
        public async Task<ActionResult<TWellnessAutomatedNovaReportSummary>> GetTWellnessAutomatedNovaReportSummary(int id)
        {
            var tWellnessAutomatedNovaReportSummary = await _context.TWellnessAutomatedNovaReportSummary.FindAsync(id);

            if (tWellnessAutomatedNovaReportSummary == null)
            {
                return NotFound();
            }

            return tWellnessAutomatedNovaReportSummary;
        }

        // PUT: api/TWellnessAutomatedNovaReportSummaries/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTWellnessAutomatedNovaReportSummary(int id, TWellnessAutomatedNovaReportSummary tWellnessAutomatedNovaReportSummary)
        {
            if (id != tWellnessAutomatedNovaReportSummary.RowId)
            {
                return BadRequest();
            }

            _context.Entry(tWellnessAutomatedNovaReportSummary).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TWellnessAutomatedNovaReportSummaryExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/TWellnessAutomatedNovaReportSummaries
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<TWellnessAutomatedNovaReportSummary>> PostTWellnessAutomatedNovaReportSummary(TWellnessAutomatedNovaReportSummary tWellnessAutomatedNovaReportSummary)
        {
            _context.TWellnessAutomatedNovaReportSummary.Add(tWellnessAutomatedNovaReportSummary);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetTWellnessAutomatedNovaReportSummary", new { id = tWellnessAutomatedNovaReportSummary.RowId }, tWellnessAutomatedNovaReportSummary);
        }

        // DELETE: api/TWellnessAutomatedNovaReportSummaries/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<TWellnessAutomatedNovaReportSummary>> DeleteTWellnessAutomatedNovaReportSummary(int id)
        {
            var tWellnessAutomatedNovaReportSummary = await _context.TWellnessAutomatedNovaReportSummary.FindAsync(id);
            if (tWellnessAutomatedNovaReportSummary == null)
            {
                return NotFound();
            }

            _context.TWellnessAutomatedNovaReportSummary.Remove(tWellnessAutomatedNovaReportSummary);
            await _context.SaveChangesAsync();

            return tWellnessAutomatedNovaReportSummary;
        }

        private bool TWellnessAutomatedNovaReportSummaryExists(int id)
        {
            return _context.TWellnessAutomatedNovaReportSummary.Any(e => e.RowId == id);
        }
    }
}
