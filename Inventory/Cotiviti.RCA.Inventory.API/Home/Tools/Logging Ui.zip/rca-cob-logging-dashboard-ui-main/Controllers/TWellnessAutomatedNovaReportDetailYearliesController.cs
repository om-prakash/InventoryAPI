﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using COBLoggingDashboard.Models;

namespace COBLoggingDashboard.Controllers
{
    [Route("api/TWellnessAutomatedNovaReportDetailYearlies")]
    [ApiController]
    public class TWellnessAutomatedNovaReportDetailYearliesController : ControllerBase
    {
        private readonly GlobalCnlyCentralizedCOBDashboardContext _context;

        public TWellnessAutomatedNovaReportDetailYearliesController(GlobalCnlyCentralizedCOBDashboardContext context)
        {
            _context = context;
        }

        // GET: api/TWellnessAutomatedNovaReportDetailYearlies
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TWellnessAutomatedNovaReportDetailYearly>>> GetTWellnessAutomatedNovaReportDetailYearly()
        {
            return await _context.TWellnessAutomatedNovaReportDetailYearly.ToListAsync();
        }

        // GET: api/TWellnessAutomatedNovaReportDetailYearlies/5
        [HttpGet("{id}")]
        public async Task<ActionResult<TWellnessAutomatedNovaReportDetailYearly>> GetTWellnessAutomatedNovaReportDetailYearly(int id)
        {
            var tWellnessAutomatedNovaReportDetailYearly = await _context.TWellnessAutomatedNovaReportDetailYearly.FindAsync(id);

            if (tWellnessAutomatedNovaReportDetailYearly == null)
            {
                return NotFound();
            }

            return tWellnessAutomatedNovaReportDetailYearly;
        }

        // PUT: api/TWellnessAutomatedNovaReportDetailYearlies/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTWellnessAutomatedNovaReportDetailYearly(int id, TWellnessAutomatedNovaReportDetailYearly tWellnessAutomatedNovaReportDetailYearly)
        {
            if (id != tWellnessAutomatedNovaReportDetailYearly.RowId)
            {
                return BadRequest();
            }

            _context.Entry(tWellnessAutomatedNovaReportDetailYearly).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TWellnessAutomatedNovaReportDetailYearlyExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/TWellnessAutomatedNovaReportDetailYearlies
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<TWellnessAutomatedNovaReportDetailYearly>> PostTWellnessAutomatedNovaReportDetailYearly(TWellnessAutomatedNovaReportDetailYearly tWellnessAutomatedNovaReportDetailYearly)
        {
            _context.TWellnessAutomatedNovaReportDetailYearly.Add(tWellnessAutomatedNovaReportDetailYearly);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetTWellnessAutomatedNovaReportDetailYearly", new { id = tWellnessAutomatedNovaReportDetailYearly.RowId }, tWellnessAutomatedNovaReportDetailYearly);
        }

        // DELETE: api/TWellnessAutomatedNovaReportDetailYearlies/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<TWellnessAutomatedNovaReportDetailYearly>> DeleteTWellnessAutomatedNovaReportDetailYearly(int id)
        {
            var tWellnessAutomatedNovaReportDetailYearly = await _context.TWellnessAutomatedNovaReportDetailYearly.FindAsync(id);
            if (tWellnessAutomatedNovaReportDetailYearly == null)
            {
                return NotFound();
            }

            _context.TWellnessAutomatedNovaReportDetailYearly.Remove(tWellnessAutomatedNovaReportDetailYearly);
            await _context.SaveChangesAsync();

            return tWellnessAutomatedNovaReportDetailYearly;
        }

        private bool TWellnessAutomatedNovaReportDetailYearlyExists(int id)
        {
            return _context.TWellnessAutomatedNovaReportDetailYearly.Any(e => e.RowId == id);
        }
    }
}
