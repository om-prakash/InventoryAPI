﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using COBLoggingDashboard.Models;

namespace COBLoggingDashboard.Controllers
{
    [Route("api/TWellnessCaseMgmtStatus")]
    [ApiController]
    public class TWellnessCaseMgmtStatusController : ControllerBase
    {
        private readonly GlobalCnlyCentralizedCOBDashboardContext _context;

        public TWellnessCaseMgmtStatusController(GlobalCnlyCentralizedCOBDashboardContext context)
        {
            _context = context;
        }

        // GET: api/TWellnessCaseMgmtStatus
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TWellnessCaseMgmtStatus>>> GetTWellnessCaseMgmtStatus()
        {
            return await _context.TWellnessCaseMgmtStatus.ToListAsync();
        }

        // GET: api/TWellnessCaseMgmtStatus/5
        [HttpGet("{id}")]
        public async Task<ActionResult<TWellnessCaseMgmtStatus>> GetTWellnessCaseMgmtStatus(int id)
        {
            var tWellnessCaseMgmtStatus = await _context.TWellnessCaseMgmtStatus.FindAsync(id);

            if (tWellnessCaseMgmtStatus == null)
            {
                return NotFound();
            }

            return tWellnessCaseMgmtStatus;
        }

        // PUT: api/TWellnessCaseMgmtStatus/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTWellnessCaseMgmtStatus(int id, TWellnessCaseMgmtStatus tWellnessCaseMgmtStatus)
        {
            if (id != tWellnessCaseMgmtStatus.AccountId)
            {
                return BadRequest();
            }

            _context.Entry(tWellnessCaseMgmtStatus).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TWellnessCaseMgmtStatusExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/TWellnessCaseMgmtStatus
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<TWellnessCaseMgmtStatus>> PostTWellnessCaseMgmtStatus(TWellnessCaseMgmtStatus tWellnessCaseMgmtStatus)
        {
            _context.TWellnessCaseMgmtStatus.Add(tWellnessCaseMgmtStatus);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (TWellnessCaseMgmtStatusExists(tWellnessCaseMgmtStatus.AccountId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetTWellnessCaseMgmtStatus", new { id = tWellnessCaseMgmtStatus.AccountId }, tWellnessCaseMgmtStatus);
        }

        // DELETE: api/TWellnessCaseMgmtStatus/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<TWellnessCaseMgmtStatus>> DeleteTWellnessCaseMgmtStatus(int id)
        {
            var tWellnessCaseMgmtStatus = await _context.TWellnessCaseMgmtStatus.FindAsync(id);
            if (tWellnessCaseMgmtStatus == null)
            {
                return NotFound();
            }

            _context.TWellnessCaseMgmtStatus.Remove(tWellnessCaseMgmtStatus);
            await _context.SaveChangesAsync();

            return tWellnessCaseMgmtStatus;
        }

        private bool TWellnessCaseMgmtStatusExists(int id)
        {
            return _context.TWellnessCaseMgmtStatus.Any(e => e.AccountId == id);
        }
    }
}
