﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using COBLoggingDashboard.Models;

namespace COBLoggingDashboard.Controllers
{
    [Produces("application/json")]
    [Route("api/TWellnessCobJobsStatus")]
    [ApiController]
    public class TWellnessCobJobsStatusController : ControllerBase
    {
        private readonly GlobalCnlyCentralizedCOBDashboardContext _context;

        public TWellnessCobJobsStatusController(GlobalCnlyCentralizedCOBDashboardContext context)
        {
            _context = context;
        }

        // GET: api/TWellnessCobJobsStatus
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TWellnessCobJobsStatus>>> GetTWellnessCobJobsStatus()
        {
            var dFirstDayOfThisMonth = DateTime.Today.AddDays(-(DateTime.Today.Day - 1));
            var dFirstDayOfLastMonth = dFirstDayOfThisMonth.AddMonths(-1);

            var maxLastupdate = _context.TWellnessCobJobsStatus
                                .Where(result => result.Interval == "D")
                                .Max(result => result.ControllerDate);

            return await _context.TWellnessCobJobsStatus
                 .Where(result => result.Interval == "D" && (result.ControllerDate >= maxLastupdate))
                 .OrderBy(or => or.LastRunTime)
                 .ToListAsync();

            //var nightly = _context.TWellnessCobJobsStatus
            //            .Where(_where => _where.Interval == "D" && (_where.ControllerDate >= dFirstDayOfLastMonth))
            //           .GroupBy(grp => new
            //           {
            //               AccountId = grp.AccountId,
            //               //ProcessDesc = grp.ProcessDesc,
            //               ControllerDate = grp.ControllerDate
            //           })
            //           .Select(slt => new
            //           {
            //               AccountId = slt.Key.AccountId,
            //               //ProcessDesc = slt.Key.ProcessDesc,
            //               ControllerDate = slt.Max(x => x.ControllerDate)
            //           });

            //var maxLastupdate = _context.TWellnessCobJobsStatus
            //                    .Join(test, T1 => new { T1.AccountId, T1.ProcessDesc, T1.ControllerDate },
            //                                T2 => new { T2.AccID, T2.ProcDes, T2.ControlDate },
            //                                (T1, T2) => T1);
            //     .Where(result => result.Interval == "D")
            //    .Max(result => result.ControllerDate);

            //return await _context.TWellnessCobJobsStatus
            //    .Join(nightly, 
            //            T1 => new { T1.AccountId, T1.ProcessDesc, T1.ControllerDate },
            //            T2 => new { T2.AccountId, T2.ProcessDesc, T2.ControllerDate },
            //            (T1, T2) => T1)                
            //    .Where(T1 => T1.Interval == "D")                
            //    .OrderBy(T1 => T1.LastRunTime)
            //    .ToListAsync();
        }

        [HttpGet("Dataload")]
        public async Task<ActionResult<IEnumerable<TWellnessCobJobsStatus>>> GetTWellnessDataLoadStatus()
        {

            var dFirstDayOfThisMonth = DateTime.Today.AddDays(-(DateTime.Today.Day - 1));
            var dFirstDayOfLastMonth = dFirstDayOfThisMonth.AddMonths(-1);

            //var loadly = _context.TWellnessCobJobsStatus
            //            .Where(_where => _where.Interval == "L" && (_where.ControllerDate >= dFirstDayOfLastMonth))
            //           .GroupBy(grp => new
            //           {
            //               AccountId = grp.AccountId,
            //               ProcessDesc = grp.ProcessDesc,
                          
            //           })
            //           .Select(slt => new
            //           {
            //               AccountId = slt.Key.AccountId,
            //               ProcessDesc = slt.Key.ProcessDesc,
            //               ControllerDate = slt.Max(x => x.ControllerDate)
            //           });

            var maxLastupdate = _context.TWellnessCobJobsStatus
                                .Where(result => result.Interval == "L")
                                .Max(result => result.ControllerDate);

            return await _context.TWellnessCobJobsStatus
                 .Where(result => result.Interval == "L" && (result.ControllerDate >= maxLastupdate))
                 .OrderBy(or => or.LastRunTime)
                 .ToListAsync();
            //return await _context.TWellnessCobJobsStatus
            //    .Join(loadly,
            //            T1 => new { T1.AccountId, T1.ProcessDesc, T1.ControllerDate },
            //            T2 => new { T2.AccountId, T2.ProcessDesc, T2.ControllerDate },
            //            (T1, T2) => T1)
            //    .Where(T1 => T1.Interval == "L")
            //    .OrderBy(T1 => T1.LastRunTime)
            //    .ToListAsync();

        }

        // GET: api/TWellnessCobJobsStatus/5
        [HttpGet("{id}")]
        public async Task<ActionResult<TWellnessCobJobsStatus>> GetTWellnessCobJobsStatus(int id)
        {
            var tWellnessCobJobsStatus = await _context.TWellnessCobJobsStatus.FindAsync(id);

            if (tWellnessCobJobsStatus == null)
            {
                return NotFound();
            }

            return tWellnessCobJobsStatus;
        }

        // PUT: api/TWellnessCobJobsStatus/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTWellnessCobJobsStatus(int id, TWellnessCobJobsStatus tWellnessCobJobsStatus)
        {
            if (id != tWellnessCobJobsStatus.RowId)
            {
                return BadRequest();
            }

            _context.Entry(tWellnessCobJobsStatus).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TWellnessCobJobsStatusExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/TWellnessCobJobsStatus
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<TWellnessCobJobsStatus>> PostTWellnessCobJobsStatus(TWellnessCobJobsStatus tWellnessCobJobsStatus)
        {
            _context.TWellnessCobJobsStatus.Add(tWellnessCobJobsStatus);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetTWellnessCobJobsStatus", new { id = tWellnessCobJobsStatus.RowId }, tWellnessCobJobsStatus);
        }

        // DELETE: api/TWellnessCobJobsStatus/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<TWellnessCobJobsStatus>> DeleteTWellnessCobJobsStatus(int id)
        {
            var tWellnessCobJobsStatus = await _context.TWellnessCobJobsStatus.FindAsync(id);
            if (tWellnessCobJobsStatus == null)
            {
                return NotFound();
            }

            _context.TWellnessCobJobsStatus.Remove(tWellnessCobJobsStatus);
            await _context.SaveChangesAsync();

            return tWellnessCobJobsStatus;
        }

        private bool TWellnessCobJobsStatusExists(int id)
        {
            return _context.TWellnessCobJobsStatus.Any(e => e.RowId == id);
        }
    }
}
