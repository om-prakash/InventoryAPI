﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using COBLoggingDashboard.Models;

namespace COBLoggingDashboard.Controllers
{
    [Route("api/TWellnessAutomatedNovaReportDetailMonthlies")]
    [ApiController]
    public class TWellnessAutomatedNovaReportDetailMonthliesController : ControllerBase
    {
        private readonly GlobalCnlyCentralizedCOBDashboardContext _context;

        public TWellnessAutomatedNovaReportDetailMonthliesController(GlobalCnlyCentralizedCOBDashboardContext context)
        {
            _context = context;
        }

        // GET: api/TWellnessAutomatedNovaReportDetailMonthlies
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TWellnessAutomatedNovaReportDetailMonthly>>> GetTWellnessAutomatedNovaReportDetailMonthly()
        {
            return await _context.TWellnessAutomatedNovaReportDetailMonthly.ToListAsync();
        }

        // GET: api/TWellnessAutomatedNovaReportDetailMonthlies/5
        [HttpGet("{id}")]
        public async Task<ActionResult<TWellnessAutomatedNovaReportDetailMonthly>> GetTWellnessAutomatedNovaReportDetailMonthly(int id)
        {
            var tWellnessAutomatedNovaReportDetailMonthly = await _context.TWellnessAutomatedNovaReportDetailMonthly.FindAsync(id);

            if (tWellnessAutomatedNovaReportDetailMonthly == null)
            {
                return NotFound();
            }

            return tWellnessAutomatedNovaReportDetailMonthly;
        }

        // PUT: api/TWellnessAutomatedNovaReportDetailMonthlies/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTWellnessAutomatedNovaReportDetailMonthly(int id, TWellnessAutomatedNovaReportDetailMonthly tWellnessAutomatedNovaReportDetailMonthly)
        {
            if (id != tWellnessAutomatedNovaReportDetailMonthly.RowId)
            {
                return BadRequest();
            }

            _context.Entry(tWellnessAutomatedNovaReportDetailMonthly).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TWellnessAutomatedNovaReportDetailMonthlyExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/TWellnessAutomatedNovaReportDetailMonthlies
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<TWellnessAutomatedNovaReportDetailMonthly>> PostTWellnessAutomatedNovaReportDetailMonthly(TWellnessAutomatedNovaReportDetailMonthly tWellnessAutomatedNovaReportDetailMonthly)
        {
            _context.TWellnessAutomatedNovaReportDetailMonthly.Add(tWellnessAutomatedNovaReportDetailMonthly);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetTWellnessAutomatedNovaReportDetailMonthly", new { id = tWellnessAutomatedNovaReportDetailMonthly.RowId }, tWellnessAutomatedNovaReportDetailMonthly);
        }

        // DELETE: api/TWellnessAutomatedNovaReportDetailMonthlies/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<TWellnessAutomatedNovaReportDetailMonthly>> DeleteTWellnessAutomatedNovaReportDetailMonthly(int id)
        {
            var tWellnessAutomatedNovaReportDetailMonthly = await _context.TWellnessAutomatedNovaReportDetailMonthly.FindAsync(id);
            if (tWellnessAutomatedNovaReportDetailMonthly == null)
            {
                return NotFound();
            }

            _context.TWellnessAutomatedNovaReportDetailMonthly.Remove(tWellnessAutomatedNovaReportDetailMonthly);
            await _context.SaveChangesAsync();

            return tWellnessAutomatedNovaReportDetailMonthly;
        }

        private bool TWellnessAutomatedNovaReportDetailMonthlyExists(int id)
        {
            return _context.TWellnessAutomatedNovaReportDetailMonthly.Any(e => e.RowId == id);
        }
    }
}
