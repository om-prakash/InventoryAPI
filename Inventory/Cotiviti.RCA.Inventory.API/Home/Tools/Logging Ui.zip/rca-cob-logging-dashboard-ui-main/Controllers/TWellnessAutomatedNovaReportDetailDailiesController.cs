﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using COBLoggingDashboard.Models;

namespace COBLoggingDashboard.Controllers
{
    [Route("api/TWellnessAutomatedNovaReportDetailDailies")]
    [ApiController]
    public class TWellnessAutomatedNovaReportDetailDailiesController : ControllerBase
    {
        private readonly GlobalCnlyCentralizedCOBDashboardContext _context;

        public TWellnessAutomatedNovaReportDetailDailiesController(GlobalCnlyCentralizedCOBDashboardContext context)
        {
            _context = context;
        }

        // GET: api/TWellnessAutomatedNovaReportDetailDailies
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TWellnessAutomatedNovaReportDetailDaily>>> GetTWellnessAutomatedNovaReportDetailDaily()
        {
            return await _context.TWellnessAutomatedNovaReportDetailDaily.ToListAsync();
        }

        // GET: api/TWellnessAutomatedNovaReportDetailDailies/5
        [HttpGet("{id}")]
        public async Task<ActionResult<TWellnessAutomatedNovaReportDetailDaily>> GetTWellnessAutomatedNovaReportDetailDaily(int id)
        {
            var tWellnessAutomatedNovaReportDetailDaily = await _context.TWellnessAutomatedNovaReportDetailDaily.FindAsync(id);

            if (tWellnessAutomatedNovaReportDetailDaily == null)
            {
                return NotFound();
            }

            return tWellnessAutomatedNovaReportDetailDaily;
        }

        // PUT: api/TWellnessAutomatedNovaReportDetailDailies/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTWellnessAutomatedNovaReportDetailDaily(int id, TWellnessAutomatedNovaReportDetailDaily tWellnessAutomatedNovaReportDetailDaily)
        {
            if (id != tWellnessAutomatedNovaReportDetailDaily.RowId)
            {
                return BadRequest();
            }

            _context.Entry(tWellnessAutomatedNovaReportDetailDaily).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TWellnessAutomatedNovaReportDetailDailyExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/TWellnessAutomatedNovaReportDetailDailies
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<TWellnessAutomatedNovaReportDetailDaily>> PostTWellnessAutomatedNovaReportDetailDaily(TWellnessAutomatedNovaReportDetailDaily tWellnessAutomatedNovaReportDetailDaily)
        {
            _context.TWellnessAutomatedNovaReportDetailDaily.Add(tWellnessAutomatedNovaReportDetailDaily);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetTWellnessAutomatedNovaReportDetailDaily", new { id = tWellnessAutomatedNovaReportDetailDaily.RowId }, tWellnessAutomatedNovaReportDetailDaily);
        }

        // DELETE: api/TWellnessAutomatedNovaReportDetailDailies/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<TWellnessAutomatedNovaReportDetailDaily>> DeleteTWellnessAutomatedNovaReportDetailDaily(int id)
        {
            var tWellnessAutomatedNovaReportDetailDaily = await _context.TWellnessAutomatedNovaReportDetailDaily.FindAsync(id);
            if (tWellnessAutomatedNovaReportDetailDaily == null)
            {
                return NotFound();
            }

            _context.TWellnessAutomatedNovaReportDetailDaily.Remove(tWellnessAutomatedNovaReportDetailDaily);
            await _context.SaveChangesAsync();

            return tWellnessAutomatedNovaReportDetailDaily;
        }

        private bool TWellnessAutomatedNovaReportDetailDailyExists(int id)
        {
            return _context.TWellnessAutomatedNovaReportDetailDaily.Any(e => e.RowId == id);
        }
    }
}
