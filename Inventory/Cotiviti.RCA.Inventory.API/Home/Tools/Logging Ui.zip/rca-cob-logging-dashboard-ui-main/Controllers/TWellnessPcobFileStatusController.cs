﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using COBLoggingDashboard.Models;
using System.Collections.ObjectModel;
using System.Diagnostics;

namespace COBLoggingDashboard.Controllers
{
    [Route("api/TWellnessPcobFileStatus")]
    [ApiController]
    public class TWellnessPcobFileStatusController : ControllerBase
    {
        private readonly GlobalCnlyCentralizedCOBDashboardContext _context;

        public TWellnessPcobFileStatusController(GlobalCnlyCentralizedCOBDashboardContext context)
        {
            _context = context;
        }

        // GET: api/TWellnessPcobFileStatus
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TWellnessPcobFileStatus>>> GetTWellnessPcobFileStatus()
        {
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = @"powershell.exe";
            startInfo.Arguments = @"& 'c:\Scripts\test.ps1'";
            startInfo.RedirectStandardOutput = true;
            startInfo.RedirectStandardError = true;
            startInfo.UseShellExecute = false;
            startInfo.CreateNoWindow = true;
            Process process = new Process();
            process.StartInfo = startInfo;
            process.Start();
            string output = process.StandardOutput.ReadToEnd();
            
            return await _context.TWellnessPcobFileStatus.ToListAsync();
            

        }


       

        // GET: api/TWellnessPcobFileStatus/5
        [HttpGet("{id}")]
        public async Task<ActionResult<TWellnessPcobFileStatus>> GetTWellnessPcobFileStatus(int id)
        {
            var tWellnessPcobFileStatus = await _context.TWellnessPcobFileStatus.FindAsync(id);

            if (tWellnessPcobFileStatus == null)
            {
                return NotFound();
            }

            return tWellnessPcobFileStatus;
        }

        // PUT: api/TWellnessPcobFileStatus/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTWellnessPcobFileStatus(int id, TWellnessPcobFileStatus tWellnessPcobFileStatus)
        {
            if (id != tWellnessPcobFileStatus.RowId)
            {
                return BadRequest();
            }

            _context.Entry(tWellnessPcobFileStatus).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TWellnessPcobFileStatusExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/TWellnessPcobFileStatus
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<TWellnessPcobFileStatus>> PostTWellnessPcobFileStatus(TWellnessPcobFileStatus tWellnessPcobFileStatus)
        {
            _context.TWellnessPcobFileStatus.Add(tWellnessPcobFileStatus);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetTWellnessPcobFileStatus", new { id = tWellnessPcobFileStatus.RowId }, tWellnessPcobFileStatus);
        }

        // DELETE: api/TWellnessPcobFileStatus/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<TWellnessPcobFileStatus>> DeleteTWellnessPcobFileStatus(int id)
        {
            var tWellnessPcobFileStatus = await _context.TWellnessPcobFileStatus.FindAsync(id);
            if (tWellnessPcobFileStatus == null)
            {
                return NotFound();
            }

            _context.TWellnessPcobFileStatus.Remove(tWellnessPcobFileStatus);
            await _context.SaveChangesAsync();

            return tWellnessPcobFileStatus;
        }

        private bool TWellnessPcobFileStatusExists(int id)
        {
            return _context.TWellnessPcobFileStatus.Any(e => e.RowId == id);
        }
    }
}
