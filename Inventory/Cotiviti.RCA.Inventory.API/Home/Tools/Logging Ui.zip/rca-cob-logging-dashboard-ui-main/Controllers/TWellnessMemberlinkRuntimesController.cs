﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using COBLoggingDashboard.Models;

namespace COBLoggingDashboard.Controllers
{
    [Route("api/TWellnessMemberlinkRuntimes")]
    [ApiController]
    public class TWellnessMemberlinkRuntimesController : ControllerBase
    {
        private readonly GlobalCnlyCentralizedCOBDashboardContext _context;

        public TWellnessMemberlinkRuntimesController(GlobalCnlyCentralizedCOBDashboardContext context)
        {
            _context = context;
        }

        // GET: api/TWellnessMemberlinkRuntimes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TWellnessMemberlinkRuntime>>> GetTWellnessMemberlinkRuntime()
        {
            return await _context.TWellnessMemberlinkRuntime.ToListAsync();
        }

        // GET: api/TWellnessMemberlinkRuntimes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<TWellnessMemberlinkRuntime>> GetTWellnessMemberlinkRuntime(int id)
        {
            var tWellnessMemberlinkRuntime = await _context.TWellnessMemberlinkRuntime.FindAsync(id);

            if (tWellnessMemberlinkRuntime == null)
            {
                return NotFound();
            }

            return tWellnessMemberlinkRuntime;
        }

        // PUT: api/TWellnessMemberlinkRuntimes/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTWellnessMemberlinkRuntime(int id, TWellnessMemberlinkRuntime tWellnessMemberlinkRuntime)
        {
            if (id != tWellnessMemberlinkRuntime.RowId)
            {
                return BadRequest();
            }

            _context.Entry(tWellnessMemberlinkRuntime).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TWellnessMemberlinkRuntimeExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/TWellnessMemberlinkRuntimes
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<TWellnessMemberlinkRuntime>> PostTWellnessMemberlinkRuntime(TWellnessMemberlinkRuntime tWellnessMemberlinkRuntime)
        {
            _context.TWellnessMemberlinkRuntime.Add(tWellnessMemberlinkRuntime);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetTWellnessMemberlinkRuntime", new { id = tWellnessMemberlinkRuntime.RowId }, tWellnessMemberlinkRuntime);
        }

        // DELETE: api/TWellnessMemberlinkRuntimes/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<TWellnessMemberlinkRuntime>> DeleteTWellnessMemberlinkRuntime(int id)
        {
            var tWellnessMemberlinkRuntime = await _context.TWellnessMemberlinkRuntime.FindAsync(id);
            if (tWellnessMemberlinkRuntime == null)
            {
                return NotFound();
            }

            _context.TWellnessMemberlinkRuntime.Remove(tWellnessMemberlinkRuntime);
            await _context.SaveChangesAsync();

            return tWellnessMemberlinkRuntime;
        }

        private bool TWellnessMemberlinkRuntimeExists(int id)
        {
            return _context.TWellnessMemberlinkRuntime.Any(e => e.RowId == id);
        }
    }
}
