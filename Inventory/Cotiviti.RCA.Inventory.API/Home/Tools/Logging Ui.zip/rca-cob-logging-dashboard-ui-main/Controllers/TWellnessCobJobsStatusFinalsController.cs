﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using COBLoggingDashboard.Models;

namespace COBLoggingDashboard.Controllers
{
    [Produces("application/json")]
    [Route("api/TWellnessCobJobsStatusFinal")]
    [ApiController]
    public class TWellnessCobJobsStatusFinalsController : ControllerBase
    {
        private readonly GlobalCnlyCentralizedCOBDashboardContext _context;

        public TWellnessCobJobsStatusFinalsController(GlobalCnlyCentralizedCOBDashboardContext context)
        {
            _context = context;
        }

        // GET: api/TWellnessCobJobsStatusFinals
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TWellnessCobJobsStatusFinal>>> GetTWellnessCobJobsStatusFinal()
        {

            return await _context.TWellnessCobJobsStatusFinal
                 .Where(result => result.Interval == "D")
                 .OrderBy(or => or.LastRunTime)
                 .ToListAsync();
            //return await _context.TWellnessCobJobsStatusFinal.ToListAsync();
        }
        [HttpGet("Dataload")]
        public async Task<ActionResult<IEnumerable<TWellnessCobJobsStatusFinal>>> GetTWellnessDataLoadStatusFinal()
        {
            
            return await _context.TWellnessCobJobsStatusFinal
                 .Where(result => result.Interval == "L")
                 .OrderBy(or => or.LastRunTime)
                 .ToListAsync();
            

        }

        // GET: api/TWellnessCobJobsStatusFinals/5
        [HttpGet("{id}")]
        public async Task<ActionResult<TWellnessCobJobsStatusFinal>> GetTWellnessCobJobsStatusFinal(int id)
        {
            var tWellnessCobJobsStatusFinal = await _context.TWellnessCobJobsStatusFinal.FindAsync(id);

            if (tWellnessCobJobsStatusFinal == null)
            {
                return NotFound();
            }

            return tWellnessCobJobsStatusFinal;
        }

        // PUT: api/TWellnessCobJobsStatusFinals/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTWellnessCobJobsStatusFinal(int id, TWellnessCobJobsStatusFinal tWellnessCobJobsStatusFinal)
        {
            if (id != tWellnessCobJobsStatusFinal.RowId)
            {
                return BadRequest();
            }

            _context.Entry(tWellnessCobJobsStatusFinal).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TWellnessCobJobsStatusFinalExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/TWellnessCobJobsStatusFinals
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<TWellnessCobJobsStatusFinal>> PostTWellnessCobJobsStatusFinal(TWellnessCobJobsStatusFinal tWellnessCobJobsStatusFinal)
        {
            _context.TWellnessCobJobsStatusFinal.Add(tWellnessCobJobsStatusFinal);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetTWellnessCobJobsStatusFinal", new { id = tWellnessCobJobsStatusFinal.RowId }, tWellnessCobJobsStatusFinal);
        }

        // DELETE: api/TWellnessCobJobsStatusFinals/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<TWellnessCobJobsStatusFinal>> DeleteTWellnessCobJobsStatusFinal(int id)
        {
            var tWellnessCobJobsStatusFinal = await _context.TWellnessCobJobsStatusFinal.FindAsync(id);
            if (tWellnessCobJobsStatusFinal == null)
            {
                return NotFound();
            }

            _context.TWellnessCobJobsStatusFinal.Remove(tWellnessCobJobsStatusFinal);
            await _context.SaveChangesAsync();

            return tWellnessCobJobsStatusFinal;
        }

        private bool TWellnessCobJobsStatusFinalExists(int id)
        {
            return _context.TWellnessCobJobsStatusFinal.Any(e => e.RowId == id);
        }
    }
}
