﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using COBLoggingDashboard.Models;

namespace COBLoggingDashboard.Controllers
{
    [Route("api/TWellnessMemberLinkClientLevels")]
    [ApiController]
    public class TWellnessMemberLinkClientLevelsController : ControllerBase
    {
        private readonly GlobalCnlyCentralizedCOBDashboardContext _context;

        public TWellnessMemberLinkClientLevelsController(GlobalCnlyCentralizedCOBDashboardContext context)
        {
            _context = context;
        }

        // GET: api/TWellnessMemberLinkClientLevels
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TWellnessMemberLinkClientLevel>>> GetTWellnessMemberLinkClientLevel()
        {
            var maxLastupdate = _context.TWellnessMemberLinkClientLevel
                   .Max(result => result.LastUpdateDate);

            return await _context.TWellnessMemberLinkClientLevel
                .Where(result => result.LastUpdateDate >= maxLastupdate)
                .OrderBy(or => or.LastUpdateDate)
                .ToListAsync();

            //return await _context.TWellnessMemberLinkClientLevel.ToListAsync();
        }

        // GET: api/TWellnessMemberLinkClientLevels/5
        [HttpGet("{id}")]
        public async Task<ActionResult<TWellnessMemberLinkClientLevel>> GetTWellnessMemberLinkClientLevel(int id)
        {
            var tWellnessMemberLinkClientLevel = await _context.TWellnessMemberLinkClientLevel.FindAsync(id);

            if (tWellnessMemberLinkClientLevel == null)
            {
                return NotFound();
            }

            return tWellnessMemberLinkClientLevel;
        }

        // PUT: api/TWellnessMemberLinkClientLevels/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTWellnessMemberLinkClientLevel(int id, TWellnessMemberLinkClientLevel tWellnessMemberLinkClientLevel)
        {
            if (id != tWellnessMemberLinkClientLevel.RowId)
            {
                return BadRequest();
            }

            _context.Entry(tWellnessMemberLinkClientLevel).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TWellnessMemberLinkClientLevelExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/TWellnessMemberLinkClientLevels
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<TWellnessMemberLinkClientLevel>> PostTWellnessMemberLinkClientLevel(TWellnessMemberLinkClientLevel tWellnessMemberLinkClientLevel)
        {
            _context.TWellnessMemberLinkClientLevel.Add(tWellnessMemberLinkClientLevel);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetTWellnessMemberLinkClientLevel", new { id = tWellnessMemberLinkClientLevel.RowId }, tWellnessMemberLinkClientLevel);
        }

        // DELETE: api/TWellnessMemberLinkClientLevels/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<TWellnessMemberLinkClientLevel>> DeleteTWellnessMemberLinkClientLevel(int id)
        {
            var tWellnessMemberLinkClientLevel = await _context.TWellnessMemberLinkClientLevel.FindAsync(id);
            if (tWellnessMemberLinkClientLevel == null)
            {
                return NotFound();
            }

            _context.TWellnessMemberLinkClientLevel.Remove(tWellnessMemberLinkClientLevel);
            await _context.SaveChangesAsync();

            return tWellnessMemberLinkClientLevel;
        }

        private bool TWellnessMemberLinkClientLevelExists(int id)
        {
            return _context.TWellnessMemberLinkClientLevel.Any(e => e.RowId == id);
        }
    }
}
