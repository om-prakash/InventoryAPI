﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using COBLoggingDashboard.Models;

namespace COBLoggingDashboard.Controllers
{
    [Route("api/TWellnessMemberLinkClientStatus")]
    [ApiController]
    public class TWellnessMemberLinkClientStatusController : ControllerBase
    {
        private readonly GlobalCnlyCentralizedCOBDashboardContext _context;

        public TWellnessMemberLinkClientStatusController(GlobalCnlyCentralizedCOBDashboardContext context)
        {
            _context = context;
        }

        // GET: api/TWellnessMemberLinkClientStatus
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TWellnessMemberLinkClientStatus>>> GetTWellnessMemberLinkClientStatus()
        {
            return await _context.TWellnessMemberLinkClientStatus.ToListAsync();
        }

        // GET: api/TWellnessMemberLinkClientStatus/5
        [HttpGet("{id}")]
        public async Task<ActionResult<TWellnessMemberLinkClientStatus>> GetTWellnessMemberLinkClientStatus(int id)
        {
            var tWellnessMemberLinkClientStatus = await _context.TWellnessMemberLinkClientStatus.FindAsync(id);

            if (tWellnessMemberLinkClientStatus == null)
            {
                return NotFound();
            }

            return tWellnessMemberLinkClientStatus;
        }

        // PUT: api/TWellnessMemberLinkClientStatus/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTWellnessMemberLinkClientStatus(int id, TWellnessMemberLinkClientStatus tWellnessMemberLinkClientStatus)
        {
            if (id != tWellnessMemberLinkClientStatus.RowId)
            {
                return BadRequest();
            }

            _context.Entry(tWellnessMemberLinkClientStatus).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TWellnessMemberLinkClientStatusExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/TWellnessMemberLinkClientStatus
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<TWellnessMemberLinkClientStatus>> PostTWellnessMemberLinkClientStatus(TWellnessMemberLinkClientStatus tWellnessMemberLinkClientStatus)
        {
            _context.TWellnessMemberLinkClientStatus.Add(tWellnessMemberLinkClientStatus);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetTWellnessMemberLinkClientStatus", new { id = tWellnessMemberLinkClientStatus.RowId }, tWellnessMemberLinkClientStatus);
        }

        // DELETE: api/TWellnessMemberLinkClientStatus/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<TWellnessMemberLinkClientStatus>> DeleteTWellnessMemberLinkClientStatus(int id)
        {
            var tWellnessMemberLinkClientStatus = await _context.TWellnessMemberLinkClientStatus.FindAsync(id);
            if (tWellnessMemberLinkClientStatus == null)
            {
                return NotFound();
            }

            _context.TWellnessMemberLinkClientStatus.Remove(tWellnessMemberLinkClientStatus);
            await _context.SaveChangesAsync();

            return tWellnessMemberLinkClientStatus;
        }

        private bool TWellnessMemberLinkClientStatusExists(int id)
        {
            return _context.TWellnessMemberLinkClientStatus.Any(e => e.RowId == id);
        }
    }
}
