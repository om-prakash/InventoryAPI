﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using COBLoggingDashboard.Models;

namespace COBLoggingDashboard.Controllers
{
    [Route("api/TWellnessAutomatedNovaReportDetailWeeklies")]
    [ApiController]
    public class TWellnessAutomatedNovaReportDetailWeekliesController : ControllerBase
    {
        private readonly GlobalCnlyCentralizedCOBDashboardContext _context;

        public TWellnessAutomatedNovaReportDetailWeekliesController(GlobalCnlyCentralizedCOBDashboardContext context)
        {
            _context = context;
        }

        // GET: api/TWellnessAutomatedNovaReportDetailWeeklies
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TWellnessAutomatedNovaReportDetailWeekly>>> GetTWellnessAutomatedNovaReportDetailWeekly()
        {
            return await _context.TWellnessAutomatedNovaReportDetailWeekly.ToListAsync();
        }

        // GET: api/TWellnessAutomatedNovaReportDetailWeeklies/5
        [HttpGet("{id}")]
        public async Task<ActionResult<TWellnessAutomatedNovaReportDetailWeekly>> GetTWellnessAutomatedNovaReportDetailWeekly(int id)
        {
            var tWellnessAutomatedNovaReportDetailWeekly = await _context.TWellnessAutomatedNovaReportDetailWeekly.FindAsync(id);

            if (tWellnessAutomatedNovaReportDetailWeekly == null)
            {
                return NotFound();
            }

            return tWellnessAutomatedNovaReportDetailWeekly;
        }

        // PUT: api/TWellnessAutomatedNovaReportDetailWeeklies/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTWellnessAutomatedNovaReportDetailWeekly(int id, TWellnessAutomatedNovaReportDetailWeekly tWellnessAutomatedNovaReportDetailWeekly)
        {
            if (id != tWellnessAutomatedNovaReportDetailWeekly.RowId)
            {
                return BadRequest();
            }

            _context.Entry(tWellnessAutomatedNovaReportDetailWeekly).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TWellnessAutomatedNovaReportDetailWeeklyExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/TWellnessAutomatedNovaReportDetailWeeklies
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<TWellnessAutomatedNovaReportDetailWeekly>> PostTWellnessAutomatedNovaReportDetailWeekly(TWellnessAutomatedNovaReportDetailWeekly tWellnessAutomatedNovaReportDetailWeekly)
        {
            _context.TWellnessAutomatedNovaReportDetailWeekly.Add(tWellnessAutomatedNovaReportDetailWeekly);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetTWellnessAutomatedNovaReportDetailWeekly", new { id = tWellnessAutomatedNovaReportDetailWeekly.RowId }, tWellnessAutomatedNovaReportDetailWeekly);
        }

        // DELETE: api/TWellnessAutomatedNovaReportDetailWeeklies/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<TWellnessAutomatedNovaReportDetailWeekly>> DeleteTWellnessAutomatedNovaReportDetailWeekly(int id)
        {
            var tWellnessAutomatedNovaReportDetailWeekly = await _context.TWellnessAutomatedNovaReportDetailWeekly.FindAsync(id);
            if (tWellnessAutomatedNovaReportDetailWeekly == null)
            {
                return NotFound();
            }

            _context.TWellnessAutomatedNovaReportDetailWeekly.Remove(tWellnessAutomatedNovaReportDetailWeekly);
            await _context.SaveChangesAsync();

            return tWellnessAutomatedNovaReportDetailWeekly;
        }

        private bool TWellnessAutomatedNovaReportDetailWeeklyExists(int id)
        {
            return _context.TWellnessAutomatedNovaReportDetailWeekly.Any(e => e.RowId == id);
        }
    }
}
