﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using COBLoggingDashboard.Models;
using System.Diagnostics;
using System.Management.Automation;
using System.Collections.ObjectModel;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Data.SqlClient;
using System.Text;

namespace COBLoggingDashboard.Controllers
{
    [Route("api/TWellnessLexisNexisCount")]
    [ApiController]
    public class TWellnessLexisNexisCountsController : ControllerBase
    {
        private readonly GlobalCnlyCentralizedCOBDashboardContext _context;

        public TWellnessLexisNexisCountsController(GlobalCnlyCentralizedCOBDashboardContext context)
        {
            _context = context;
        }

        // GET: api/TWellnessLexisNexisCounts
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TWellnessLexisNexisCount>>> GetTWellnessLexisNexisCount()
        {
            return await _context.TWellnessLexisNexisCount.ToListAsync();
        }

        // GET: api/TWellnessLexisNexisCounts/5
        //[HttpGet("{id}")]
        //public async Task<ActionResult<TWellnessLexisNexisCount>> GetTWellnessLexisNexisCount(int id)
        //{
        //    var tWellnessLexisNexisCount = await _context.TWellnessLexisNexisCount.FindAsync(id);

        //    if (tWellnessLexisNexisCount == null)
        //    {
        //        return NotFound();
        //    }

        //    return tWellnessLexisNexisCount;
        //}

 
        [HttpGet("LexisNexis")]
        public async Task<ActionResult<IEnumerable<TWellnessLexisNexisCount>>> GetTWellnessLexisNexisCByClient(string client_name, string action)
        {

           

            var loggingFileRef = @"\\cca-audit\dfs-dc-01\Data\FS01-M\Healthcare\COB\Scheduled Tasks\Process Config\Subscripts\Mendix Apps\COB Eligibility\Shared\Logging.ps1";
            var rdloggingFileRef = System.IO.File.ReadAllText(loggingFileRef);
            var sqlFileRef = @"\\cca-audit\dfs-dc-01\Data\FS01-M\Healthcare\COB\Scheduled Tasks\Process Config\Subscripts\Mendix Apps\COB Eligibility\Shared\SQLBCP_Modules.ps1";
            var rdsqlFileRef = System.IO.File.ReadAllText(sqlFileRef);
            var sysInit = @"System.Data.SqlClient.SQLConnection";
            var logfilePath = @"\\ccaintranet.com\dfs-dc-01\Data\FS01-M\Healthcare\COB\Apps\LexisNexis\Logs\Acc_" + client_name + ".log";
            var runPS1 = "";
            if (action=="Export")
            {

                var rsPath = (from tn in _context.TAccountLexisNexis
                              join ta in _context.TAccountAttributes on tn.AccountId equals ta.AccountId
                              join acc in _context.TAccount on ta.AccountId equals acc.AccountId
                              where acc.ClientName == client_name
                              select new
                              {
                                  FilePath = tn.FolderPath,
                                  AccID = acc.AccountId

                              }
                           ).Take(1);


                foreach (var fr in rsPath)
                {
                    var filePath = fr.FilePath;
                    string folderName = DateTime.Now.ToString("yyyy-MM-dd");
                    var finalPath = filePath + "\\" + folderName;
                    finalPath = finalPath.Replace("Y:", "\\\\ccaintranet.com\\dfs-dc-01");
                    if (!Directory.Exists(finalPath))
                    {

                        Directory.CreateDirectory(finalPath);
                    }



                }

                runPS1 = @"\\ccaintranet.com\dfs-dc-01\Data\FS01-M\Healthcare\COB\Apps\LexisNexis\Dashboard\LexisNexisFile_Export.ps1";
                 //logfilePath = @"\\ccaintranet.com\dfs-dc-01\Data\FS01-M\Healthcare\COB\Apps\LexisNexis\Logs\Acc_" + client_name + ".log";
            }

            else if(action == "Import")
            {

                 runPS1 = @"\\ccaintranet.com\dfs-dc-01\Data\FS01-M\Healthcare\COB\Apps\LexisNexis\Dashboard\LexisNexisFile_Import.ps1";
                 //logfilePath = @"\\ccaintranet.com\dfs-dc-01\Data\FS01-M\Healthcare\COB\Apps\LexisNexis\Logs\Acc_" + client_name + ".log";
            }
            var rdrunPS1 = System.IO.File.ReadAllText(runPS1);

            InitialSessionState iss = InitialSessionState.CreateDefault();
            Runspace rs = RunspaceFactory.CreateRunspace(iss);
            rs.Open();
            PowerShell ps = PowerShell.Create();

            ps.Runspace = rs;

            ps.AddScript(rdloggingFileRef)
                .AddParameter("LogFullName", logfilePath)
                .Invoke();

            ps.AddScript(rdsqlFileRef)
               .Invoke();

            ps.AddCommand("New-Object")
                .AddArgument(sysInit)
                .Invoke();

            ps.AddScript(@"Import-Module SqlServer")
                .Invoke();

            ps.AddScript(@"Set-ExecutionPolicy -Scope CurrentUser Unrestricted")
                .Invoke();

            ps.AddScript(rdrunPS1);


            //ps.AddParameter("UserFullName", "AbdullahNoorMohamed");
            ps.AddParameter("Client_name", client_name);

            Collection<ScriptInfo> result = ps.Invoke<ScriptInfo>();
            //Collection<PSObject> result = ps.Invoke();
            rs.Close();

            //StringBuilder stringBuilder = new StringBuilder();
            //foreach (PSObject obj in result)
            //{
            //    stringBuilder.AppendLine(obj.ToString());
            //}
            
            /*
            var fileName = @"\\ccaintranet.com\dfs-dc-01\Data\FS01-M\Healthcare\COB\Scheduled Tasks\Process Config\Subscripts\TestDashboard\LexisNexis\CreateLexisNexisFile_BKP.ps1";
            var profileScript = System.IO.File.ReadAllText(fileName);

            var fileName2 = @"\\cca-audit\dfs-dc-01\Data\FS01-M\Healthcare\COB\Scheduled Tasks\Process Config\Subscripts\Mendix Apps\COB Eligibility\Shared\Logging.ps1";
            var profileScript2 = System.IO.File.ReadAllText(fileName2);
            var fileName3 = @"\\cca-audit\dfs-dc-01\Data\FS01-M\Healthcare\COB\Scheduled Tasks\Process Config\Subscripts\Mendix Apps\COB Eligibility\Shared\SQLBCP_Modules.ps1";
            var profileScript3 = System.IO.File.ReadAllText(fileName3);
            var logfile = @"\\ccaintranet.com\dfs-dc-01\Data\FS01-M\Healthcare\COB\Scheduled Tasks\Process Config\Subscripts\TestDashboard\LexisNexis\Logs\Acc_"+ client_name+".log";
            var cmd1 = @"System.Data.SqlClient.SQLConnection";
            //var cmd1 = @"System.Data";

            //var cmd = @"[System.Reflection.Assembly]::LoadWithPartialName(""Microsoft.SqlServer.SMO"")";

            InitialSessionState iss = InitialSessionState.CreateDefault();
            Runspace rs = RunspaceFactory.CreateRunspace(iss);
            rs.Open();
            PowerShell ps = PowerShell.Create();

            ps.Runspace = rs;         

            ps.AddScript(profileScript2)
                .AddParameter("LogFullName", logfile)
                .Invoke();

            ps.AddScript(profileScript3)               
               .Invoke();

            ps.AddCommand("New-Object")                
                .AddArgument(cmd1)
                .Invoke();

            ps.AddScript(@"Import-Module SqlServer")
                .Invoke();

            ps.AddScript(@"Set-ExecutionPolicy -Scope CurrentUser Unrestricted")
                .Invoke();

            ps.AddScript(profileScript);


            //ps.AddParameter("UserFullName", "AbdullahNoorMohamed");
            ps.AddParameter("Client_name", client_name);
            
            Collection<ScriptInfo> result = ps.Invoke<ScriptInfo>();
            */
            
            var tWellnessLexisNexisCount = await _context.TWellnessLexisNexisCount
                                            .Where(result => result.ClientName == client_name)
                                           .ToListAsync();
            if (tWellnessLexisNexisCount == null)
            {
                return NotFound();
            }

            return tWellnessLexisNexisCount;
        }

        // PUT: api/TWellnessLexisNexisCounts/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTWellnessLexisNexisCount(int id, TWellnessLexisNexisCount tWellnessLexisNexisCount)
        {
            if (id != tWellnessLexisNexisCount.RowId)
            {
                return BadRequest();
            }

            _context.Entry(tWellnessLexisNexisCount).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TWellnessLexisNexisCountExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/TWellnessLexisNexisCounts
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<TWellnessLexisNexisCount>> PostTWellnessLexisNexisCount(TWellnessLexisNexisCount tWellnessLexisNexisCount)
        {
            _context.TWellnessLexisNexisCount.Add(tWellnessLexisNexisCount);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetTWellnessLexisNexisCount", new { id = tWellnessLexisNexisCount.RowId }, tWellnessLexisNexisCount);
        }

        // DELETE: api/TWellnessLexisNexisCounts/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<TWellnessLexisNexisCount>> DeleteTWellnessLexisNexisCount(int id)
        {
            var tWellnessLexisNexisCount = await _context.TWellnessLexisNexisCount.FindAsync(id);
            if (tWellnessLexisNexisCount == null)
            {
                return NotFound();
            }

            _context.TWellnessLexisNexisCount.Remove(tWellnessLexisNexisCount);
            await _context.SaveChangesAsync();

            return tWellnessLexisNexisCount;
        }

        private bool TWellnessLexisNexisCountExists(int id)
        {
            return _context.TWellnessLexisNexisCount.Any(e => e.RowId == id);
        }
    }
}
