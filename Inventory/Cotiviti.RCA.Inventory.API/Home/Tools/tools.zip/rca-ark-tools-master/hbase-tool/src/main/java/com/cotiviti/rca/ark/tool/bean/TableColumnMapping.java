package com.cotiviti.rca.ark.tool.bean;

import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.HashMap;
import java.util.Map;

/**
 * A class represents HBase table and column mapping
 */
@SuppressWarnings("unused")
public class TableColumnMapping {

    @JsonProperty(value = "table")
    private String table;

    @JsonProperty(value = "cf")
    private String columnFamily;

    @JsonProperty(value = "rk")
    private String rowKey;

    // dynamic column mapping pairs
    private final Map<String, String> columns = new HashMap<>();

    @JsonAnySetter
    public void setColumnMapping(String target, String source) {
        columns.put(target, source);
    }

    public Map<String, String> getColumnMapping() {
        return columns;
    }

    public String getTable() {
        return table;
    }

    public void setTable(String table) {
        this.table = table;
    }

    public String getColumnFamily() {
        return columnFamily;
    }

    public void setColumnFamily(String columnFamily) {
        this.columnFamily = columnFamily;
    }

    public String getRowKey() {
        return rowKey;
    }

    public void setRowKey(String rowKey) {
        this.rowKey = rowKey;
    }
}
