package com.cotiviti.rca.ark.tool.config;

@SuppressWarnings("unused")
public class HBaseSampleLoaderConfig {

    public static HBaseSampleLoaderConfig parse(String[] args) {
        if (args == null || args.length != 2) {
            throw new IllegalArgumentException("two arguments are required. <data path> <config path>");
        }
        String data = args[0];
        String config = args[1];
        // check extension
        if (!data.endsWith(".json") || !config.endsWith(".json")) {
            throw new IllegalArgumentException("data and config argument must point to a json file.");
        }
        return new HBaseSampleLoaderConfig(data, config);
    }

    private String data;
    private String config;

    private HBaseSampleLoaderConfig(String data, String config) {
        this.data = data;
        this.config = config;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getConfig() {
        return config;
    }

    public void setConfig(String config) {
        this.config = config;
    }
}
