package com.cotiviti.rca.ark.tool;

import com.cotiviti.rca.ark.tool.bean.SampleData;
import com.cotiviti.rca.ark.tool.bean.TableColumnMapping;
import com.cotiviti.rca.ark.tool.config.HBaseSampleLoaderConfig;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.util.Bytes;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * A class to load sample data in json file into HBase table
 */
public class HBaseSampleLoader {
    /**
     * entry point
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        // load config from arguments
        HBaseSampleLoaderConfig config = null;
        try {
            config = HBaseSampleLoaderConfig.parse(args);
        } catch (Exception ex) {
            ex.printStackTrace();
            System.exit(-1);
        }
        try {
            // get mapping
            TableColumnMapping mapping = getTableColumnMapping(config);
            // get sample data
            SampleData[] data = getSampleData(config);
            // load sample data into HBase table
            loadSampleData(data, mapping);
        } catch (Exception ex) {
            ex.printStackTrace();
            System.exit(-1);
        }
    }

    /**
     * deserialize mapping from specified json file
     *
     * @param config an instance of {@link HBaseSampleLoaderConfig}
     * @return an instance of {@link TableColumnMapping}
     * @throws Exception unhandled exception
     */
    private static TableColumnMapping getTableColumnMapping(HBaseSampleLoaderConfig config) throws Exception {
        ObjectMapper om = new ObjectMapper();
        return om.readValue(new File(config.getConfig()), TableColumnMapping.class);
    }

    /**
     * deserialize sample data from specified json file
     *
     * @param config an instance of {@link HBaseSampleLoaderConfig}
     * @return an array of {@link SampleData}
     * @throws Exception unhandled exception
     */
    private static SampleData[] getSampleData(HBaseSampleLoaderConfig config) throws Exception {
        ObjectMapper om = new ObjectMapper();
        return om.readValue(new File(config.getData()), SampleData[].class);
    }

    /**
     * load sample data into specified HBase table
     *
     * @param data    an array of {@link SampleData}
     * @param mapping an instance of {@link TableColumnMapping}
     * @throws Exception unhandled exception
     */
    private static void loadSampleData(SampleData[] data, TableColumnMapping mapping) throws Exception {
        Configuration conf = HBaseConfiguration.create();
        try (Connection conn = ConnectionFactory.createConnection(conf)) {
            try (Table table = conn.getTable(TableName.valueOf(mapping.getTable()))) {
                List<Put> puts = new ArrayList<>();
                for (SampleData item : data) {
                    puts.add(createPutMutation(item, mapping));
                }
                table.put(puts);
            }
        }
    }

    /**
     * create HBase Put instance based on sample data and mapping
     *
     * @param data    an instance of {@link SampleData}
     * @param mapping an instance of {@link TableColumnMapping}
     * @return an instance of {@link Put}
     */
    private static Put createPutMutation(SampleData data, TableColumnMapping mapping) {
        // get value of row key from sample data
        Object rowKey = data.getValue(mapping.getRowKey());
        if (rowKey == null) return null;
        Put put = new Put(toBytes(rowKey));
        // add all other columns that defined in mapping
        Map<String, String> columns = mapping.getColumnMapping();
        String targetCol;
        String sourceCol;
        Object value;
        for (Map.Entry<String, String> pair : columns.entrySet()) {
            targetCol = pair.getKey();
            sourceCol = pair.getValue();
            value = data.getValue(sourceCol);
            // if we do not get the value from sample data, then we do not add the column in HBase table
            if (value != null) {
                put.addColumn(Bytes.toBytes(mapping.getColumnFamily()), Bytes.toBytes(targetCol), toBytes(value));
            }
        }
        return put;
    }

    /**
     * convert an object to byte array based on its type
     *
     * @param value an object that represents a primitive value
     * @return byte array
     */
    private static byte[] toBytes(Object value) {
        byte[] result = null;
        if (value instanceof String) {
            result = Bytes.toBytes((String) value);
        }
        if (value instanceof Short) {
            result = Bytes.toBytes((short) value);
        }
        if (value instanceof Integer) {
            result = Bytes.toBytes((int) value);
        }
        if (value instanceof Long) {
            result = Bytes.toBytes((long) value);
        }
        if (value instanceof Float) {
            result = Bytes.toBytes((float) value);
        }
        if (value instanceof Double) {
            result = Bytes.toBytes((double) value);
        }
        if (value instanceof Boolean) {
            result = Bytes.toBytes((boolean) value);
        }
        return result;
    }
}
