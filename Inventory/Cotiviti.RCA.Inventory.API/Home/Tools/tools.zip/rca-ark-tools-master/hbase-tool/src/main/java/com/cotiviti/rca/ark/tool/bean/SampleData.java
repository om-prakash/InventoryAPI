package com.cotiviti.rca.ark.tool.bean;

import com.fasterxml.jackson.annotation.JsonAnySetter;

import java.util.HashMap;
import java.util.Map;


@SuppressWarnings("unused")
public class SampleData {


    private final Map<String, Object> data = new HashMap<>();

    public Map<String, Object> getData() {
        return data;
    }

    @JsonAnySetter
    public void setData(String key, Object value) {
        data.put(key, value);
    }

    public Object getValue(String key) {
        return data.getOrDefault(key, null);
    }


}
