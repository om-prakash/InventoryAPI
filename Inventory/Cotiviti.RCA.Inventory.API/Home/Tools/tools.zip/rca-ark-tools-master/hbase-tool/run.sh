#!/usr/bin/env bash

# this tool is used to load sample data from specified json file to specified HBase table

# parameters
data=${data:-''}
mapping=${mapping:-''}

# https://brianchildress.co/named-parameters-in-bash/
while [ $# -gt 0 ]; do
   if [[ $1 == *"--"* ]]; then
        param="${1/--/}"
        declare $param="$2"
        # echo $1 $2 // Optional to see the parameter:value result
   fi
  shift
done

# check parameters
if [ -z "$data" ]
then
  echo "Parameter data cannot be empty."
  exit
fi

if [ -z "$mapping" ]
then
  echo "Parameter mapping cannot be empty."
  exit
fi

# get the classpath of HBase on edge node
HBASE_CP=$(hbase classpath)

# launch jvm and start our Java application
java -cp "${HBASE_CP}:./hbase-tool-1.0-SNAPSHOT.jar" com.cotiviti.rca.ark.tool.HBaseSampleLoader ${data} ${mapping}

exit 0