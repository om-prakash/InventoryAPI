# HBase Tools

This project includes HBase related tools.

## HBase Sample Data Loader

This tool only applicable to old version HBase that installed on our cluster. When HBase upgraded to HBase 2.x,
we can use Spark to load sample data into HBase directly.
  
This tool loads sample data from specified json file and then put those data into specified HBase table. The
mapping between source and target configured by a config json file.

### How it works

- **Deploy**

  We need to deploy this tool to our edge node, and it has below folder structure:
  
  ![folder structure](images/loader-folder-structure.PNG)
  
  In the config folder, we store the mapping json, and in the data folder, we store sample data json. The schema
  of sample data can be **very flexible**. 
  
    Mapping JSON
  
    ```json
    {
      "table": "spring-test",
      "cf": "cf1",
      "rk": "claimKey",
      "aa": "allowedAmt",
      "bb": "svcProvider"
    }
    ```
  
    Sample Data JSON
  
    ```json
    [
      {
        "claimKey": "X12345",
        "allowedAmt": 456.78,
        "svcProvider": "Provider 1"
      },
      {
        "claimKey": "X23456",
        "allowedAmt": 98.34,
        "svcProvider": "Provider 2"
      }
    ]
    ```
  
- **Run**

  Use below command line to launch this tool:
  
  ```shell script
  # launch hbase sample data loader
  ./run.sh --data ./data/sample.json --mapping ./config/mapping.json
  ```
  
- **Result**

  After the run, the sample data should be loaded into HBase table you specified. Use below 
  command to check the result:
  
  ```shell script
  # launch hbase shell on edge node
  hbase shell
  
  # inside the shell, use the hbase scan command to check the content of table
  scan 'spring-test'
  ```
  
  ![result](images/loader-result.PNG)
  
  
  