package com.cotiviti.rca.ark.tools.model;

/**
 * A class represents a configured retention policy
 */
@SuppressWarnings("unused")
public class RetentionPolicy {
    private String path;
    private int retention;

    public RetentionPolicy() {

    }

    public RetentionPolicy(String path, int retention) {
        if (path == null || path.trim().length() == 0) {
            throw new IllegalArgumentException("Path cannot be empty.");
        }

        if (retention < 1) {
            throw new IllegalArgumentException("Retention cannot be less than 1.");
        }

        this.path = path;
        this.retention = retention;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        if (path == null || path.trim().length() == 0) {
            throw new IllegalArgumentException("Path cannot be empty.");
        }
        this.path = path;
    }

    public int getRetention() {
        return retention;
    }

    public void setRetention(int retention) {
        if (retention < 1) {
            throw new IllegalArgumentException("Retention cannot be less than 1.");
        }
        this.retention = retention;
    }
}
