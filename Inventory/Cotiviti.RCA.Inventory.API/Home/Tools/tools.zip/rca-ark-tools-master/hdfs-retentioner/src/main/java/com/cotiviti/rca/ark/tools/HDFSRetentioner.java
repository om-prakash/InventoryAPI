package com.cotiviti.rca.ark.tools;


import com.cotiviti.rca.ark.tools.model.RetentionPolicy;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class HDFSRetentioner {

    private final static Logger logger = Logger.getLogger(HDFSRetentioner.class);

    public static void main(String[] args) {
        // configure hadoop FileSystem
        String hdfsConfigurationPath = System.getenv().get("HADOOP_CONF_DIR");
        if (hdfsConfigurationPath == null || hdfsConfigurationPath.trim().length() == 0) {
            logger.error("HDFS_CONF_DIR environment variable not set.");
            System.exit(-1);
        }

        Configuration conf = new Configuration();
        conf.addResource(new Path(hdfsConfigurationPath + Path.SEPARATOR + "core-site.xml"));
        conf.addResource(new Path(hdfsConfigurationPath + Path.SEPARATOR + "hdfs-site.xml"));

        try {
            logger.info("Loading retention policy...");
            Map<String, Integer> policies = getRetentionPolicy();
            logger.info("Retention policy loaded successfully.");
            logger.info("Applying retention policy...");
            try (FileSystem fs = FileSystem.get(conf)) {
                applyRetentionPolicy(fs, policies);
            }
            logger.info("Retention policy applied successfully.");
        } catch (Exception ex) {
            logger.error(ex);
        }
    }

    /**
     * apply the retention polices to directories in HDFS and delete directories if their modified timestamp
     * exceed the allowed max retention days that defined in the retention policy
     *
     * @param fs       hadoop {@link FileSystem}
     * @param policies a map which holds retention policy
     * @throws Exception an instance of {@link Exception}
     */
    private static void applyRetentionPolicy(FileSystem fs, Map<String, Integer> policies) throws Exception {
        Path target;
        Integer retentionInDays;
        String message;
        long now = System.currentTimeMillis();
        for (Map.Entry<String, Integer> pair : policies.entrySet()) {
            target = new Path(pair.getKey());
            retentionInDays = pair.getValue();
            message = String.format("Applying retention policy for %s, max allowed retention days: %d",
                    target, retentionInDays);
            logger.info(message);
            // if the target folder does not exist, then continue
            if (!fs.exists(target)) continue;
            FileStatus targetFileStatus = fs.getFileStatus(target);
            // check if the target is a directory, otherwise continue
            if (!targetFileStatus.isDirectory()) continue;
            // enum sub folders and files to check its modified timestamp
            FileStatus[] stats = fs.listStatus(target);
            long diff = (long) retentionInDays * 24 * 60 * 60 * 1000;
            for (FileStatus stat : stats) {
                if (stat.isFile()) continue;
                if (now - stat.getModificationTime() > diff) {
                    message = String.format("Retention policy matched. Path: %s", stat.getPath().toString());
                    logger.info(message);
                    // delete matched directory recursively
                    fs.delete(stat.getPath(), true);
                    message = String.format("%s been deleted.", stat.getPath().toString());
                    logger.info(message);
                }
            }
        }
    }

    /**
     * read retention policy json file and return an instance of {@link HashMap}
     *
     * @return an instance of {@link HashMap}
     * @throws Exception an instance of {@link Exception}
     */
    private static Map<String, Integer> getRetentionPolicy() throws Exception {
        Map<String, Integer> result = new HashMap<>();
        // try to get the retention policy configuration file via environment variable
        String retentionPolicy = System.getenv().get("RETENTION_POLICY");
        if (retentionPolicy == null || retentionPolicy.trim().length() == 0) {
            // if we cannot find the retention policy file via the environment variable,
            // then we try to get it in the resource folder
            ClassLoader loader = ClassLoader.getSystemClassLoader();
            URL url = loader.getResource("config.json");
            if (url != null) {
                retentionPolicy = url.getFile();
            } else {
                throw new Exception("Retention policy cannot be found.");
            }
        }
        // check the retention policy file extension must be json
        if (!retentionPolicy.endsWith(".json")) {
            throw new Exception("Retention policy file extension must be json.");
        }

        ObjectMapper om = new ObjectMapper();
        try (InputStream in = new BufferedInputStream(new FileInputStream(retentionPolicy))) {
            RetentionPolicy[] policies = om.readValue(in, RetentionPolicy[].class);
            for (RetentionPolicy policy : policies) {
                result.put(policy.getPath(), policy.getRetention());
            }
        }
        return result;
    }

}
