# RCA HDFS Retention Tool

This simple tool can help us apply retention policy to RCA HDFS folders. The retention policy 
configured in a JSON file and at runtime the tool will load the file and apply retention 
policies based on the configuration.

## How it works

### Deploy

We need to deploy artifacts to the edge node of our cluster. After the 
deployment, it looks like below:

![Deployment](images/deploy.PNG)

In above deployment folder, the retention-policy.json file is the configuration file. Its content
looks like:

![Retention Policy](images/json.PNG)

We can configure the path and retention days in the configuration file. If the modified timestamp of 
a folder is earlier than the current system time minus the retention days, then the folder will be deleted.

### Run

```shell script
# use below command to run 

./run.sh --config "path to retention-policy.json file"
```

### Result

![Result](images/result.PNG)