#!/usr/bin/env bash

# this utility applies retention policies against RCA HDFS folders based on a specified JSON file

# Parameters
config=${config:-''}

# https://brianchildress.co/named-parameters-in-bash/
while [ $# -gt 0 ]; do
   if [[ $1 == *"--"* ]]; then
        param="${1/--/}"
        declare $param="$2"
        # echo $1 $2 // Optional to see the parameter:value result
   fi
  shift
done


if [ -z "$config" ]
then
  echo "Parameter config cannot be empty."
  exit
fi


# Env
HADOOP_CP=$(hadoop classpath)
export HADOOP_CONF_DIR=${HADOOP_CP}
export RETENTION_POLICY=${config}

java -cp "${HADOOP_CP}:./hdfs-retentioner-1.0-SNAPSHOT.jar" com.cotiviti.rca.ark.tools.HDFSRetentioner
