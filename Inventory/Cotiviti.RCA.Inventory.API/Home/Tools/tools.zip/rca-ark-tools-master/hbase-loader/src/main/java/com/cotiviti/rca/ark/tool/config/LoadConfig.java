package com.cotiviti.rca.ark.tool.config;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

/**
 * A class representing the configuration to run.
 */
@SuppressWarnings("unused")
public class LoadConfig {

    @JsonProperty(value = "sources")
    private List<Source> sources;
    @JsonProperty(value = "flows")
    private List<Flow> flows;
    @JsonProperty(value = "sinks")
    private List<Sink> sinks;

    public List<Source> getSources() {
        return sources;
    }

    public List<Flow> getFlows() {
        return flows;
    }

    public List<Sink> getSinks() {
        return sinks;
    }

    /**
     * Validate if the config is valid or not
     *
     * @return A list of error. If the size of list is 0, it means the config is valid.
     */
    public List<String> validate() {
        List<String> errors = new ArrayList<>();
        if (sources == null || sources.size() == 0) {
            errors.add("no source definitions found.");
        }
        if (flows == null || flows.size() == 0) {
            errors.add("no flow definitions found.");
        }
        if (sinks == null || sinks.size() == 0) {
            errors.add("no sink definitions found.");
        }
        for (Source src : sources) {
            errors.addAll(src.validate());
        }
        for (Flow flow : flows) {
            errors.addAll(flow.validate());
        }
        for (Sink sink : sinks) {
            errors.addAll(sink.validate());
        }
        return errors;
    }

    public static class Source {
        @JsonProperty(value = "format")
        private String format;
        @JsonProperty(value = "select_column")
        private String select_column;
        @JsonProperty(value = "where_clause")
        private String where_clause;
        @JsonProperty(value = "temp_view")
        private String temp_view;
        @JsonProperty(value = "key")
        private String key;
        @JsonProperty(value = "cache")
        private boolean cache;
        @JsonProperty(value = "path")
        private String path;

        public String getFormat() {
            return format;
        }

        public String getSelect_column() {
            return select_column;
        }

        public String getWhere_clause() {
            return where_clause;
        }

        public String getTemp_view() {
            return temp_view;
        }

        public String getKey() {
            return key;
        }

        public boolean getCache() {
            return cache;
        }

        public String getPath() {
            return path;
        }

        public List<String> validate() {
            List<String> errors = new ArrayList<>();
            if (format == null || format.trim().length() == 0) {
                errors.add("source format cannot be null or empty.");
            }
            if (temp_view == null || temp_view.trim().length() == 0) {
                errors.add("source temp view cannot be null or empty.");
            }
            if (key == null || key.trim().length() == 0) {
                errors.add("source key cannot be null or empty.");
            }
            if (path == null || path.trim().length() == 0) {
                errors.add("source path cannot be null or empty.");
            }
            return errors;
        }
    }

    public static class Flow {
        @JsonProperty(value = "sql")
        private String sql;
        @JsonProperty(value = "temp_view")
        private String temp_view;
        @JsonProperty(value = "key")
        private String key;
        @JsonProperty(value = "cache")
        private boolean cache;

        public String getSql() {
            return sql;
        }

        public String getTemp_view() {
            return temp_view;
        }

        public String getKey() {
            return key;
        }

        public boolean getCache() {
            return cache;
        }

        public List<String> validate() {
            List<String> errors = new ArrayList<>();
            if (sql == null || sql.trim().length() == 0) {
                errors.add("flow sql cannot be null or empty.");
            } else {
                if (!sql.toLowerCase().endsWith(".sql")) {
                    errors.add("flow sql must be a sql file.");
                }
            }
            if (key == null || key.trim().length() == 0) {
                errors.add("flow key cannot be null or empty.");
            }
            return errors;
        }
    }

    public static class Sink {
        @JsonProperty(value = "key")
        private String key;
        @JsonProperty(value = "hbase_table")
        private String hbase_table;
        @JsonProperty(value = "column_family")
        private String column_family;

        public String getKey() {
            return key;
        }

        public String getHbase_table() {
            return hbase_table;
        }

        public String getColumn_family() {
            return column_family;
        }

        public List<String> validate() {
            List<String> errors = new ArrayList<>();
            if (key == null || key.trim().length() == 0) {
                errors.add("sink key cannot be null or empty.");
            }
            if (hbase_table == null || hbase_table.trim().length() == 0) {
                errors.add("sink hbase table cannot be null or empty.");
            }
            if (column_family == null || column_family.trim().length() == 0) {
                errors.add("sink hbase column family cannot be null or empty.");
            }
            return errors;
        }
    }

}
