package com.cotiviti.rca.ark.tool;

import com.cotiviti.rca.ark.tool.config.HBaseLoaderArg;
import com.cotiviti.rca.ark.tool.config.LoadConfig;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.spark.JavaHBaseContext;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.SparkFiles;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;

import java.io.*;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * A utility class to load Spark dataframe into specified HBase tables
 */
public class HBaseLoader {

    // a hash map to contain pointers to all generated dataframes
    private final static Map<String, Dataset<Row>> DATASET_MAP = new HashMap<>();
    // a hash map to contain pointers to all cached dataframes
    private final static Map<String, Dataset<Row>> CACHED_DATASET_MAP = new HashMap<>();

    public static void main(String[] args) {
        // parse command line arguments, if any exception occurred, then exit directly with error code
        HBaseLoaderArg arg = null;
        try {
            arg = HBaseLoaderArg.parse(args);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            System.exit(-1);
        }

        boolean hasError = false;

        try (SparkSession spark = SparkSession.builder().getOrCreate()) {
            try {
                // add config, schema and sql files to SparkFiles folder
                addSparkFiles(spark, arg);
                // load config and validate
                LoadConfig config = getConfig();
                List<String> errors = config.validate();
                if (errors != null && errors.size() > 0) {
                    throw new Exception("Invalid config.");
                }
                // extract
                extract(spark, config);
                // transform
                transform(spark, config);
                // load
                sink(spark, config);
            } catch (Exception ex) {
                hasError = true;
                ex.printStackTrace();
            } finally {
                // release any cached dataframes
                for (Map.Entry<String, Dataset<Row>> pair : CACHED_DATASET_MAP.entrySet()) {
                    if (pair.getValue() != null) {
                        pair.getValue().unpersist();
                    }
                }
            }
        }

        if (hasError) {
            System.exit(-1);
        }
    }

    /**
     * Add config and sql files to SparkFiles folder
     *
     * @param spark An instance of {@link SparkSession}
     * @param arg   An instance of {@link HBaseLoaderArg}
     */
    private static void addSparkFiles(SparkSession spark, HBaseLoaderArg arg) {
        String[] resources = arg.getInput().split(",");
        for (String rs : resources) {
            spark.sparkContext().addFile(rs);
        }
    }

    /**
     * Load global config and deserialize to an instance of {@link LoadConfig}
     * the name of config file is *_config.json by naming convention
     *
     * @return An instance of {@link LoadConfig}
     * @throws IOException I/O exception
     */
    private static LoadConfig getConfig() throws IOException {
        Path root = Paths.get(SparkFiles.getRootDirectory());
        Path config = null;
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(root, "*_config.json")) {
            for (Path file : stream) {
                config = file;
                break;
            }
        }
        if (config == null) {
            throw new IOException("config file not found.");
        }
        return new ObjectMapper().readValue(new File(config.toString()), LoadConfig.class);
    }

    /**
     * Load configured data sources and create temp views in Hive meta store
     *
     * @param spark  An instance of {@link SparkSession}
     * @param config An instance of {@link LoadConfig}
     * @throws Exception An exception
     */
    private static void extract(SparkSession spark, LoadConfig config) throws Exception {
        List<LoadConfig.Source> sources = config.getSources();
        if (sources == null || sources.size() == 0) {
            throw new Exception("The configuration of source is invalid.");
        }
        String format;
        for (LoadConfig.Source sc : sources) {
            format = sc.getFormat().toLowerCase();
            switch (format) {
                case "avro":
                case "parquet":
                    extractFromFileSource(spark, sc);
                    break;
                default:
                    throw new Exception(String.format("The source format (%s) is not supported", format));
            }
        }
    }

    /**
     * Load file based data sources and create temp views in Hive meta store
     * the possible formats can be parquet, avro, etc.
     *
     * @param spark An instance of {@link SparkSession}
     * @param sc    An instance of {@link LoadConfig.Source}
     * @throws Exception An exception
     */
    private static void extractFromFileSource(SparkSession spark, LoadConfig.Source sc) throws Exception {
        String path = sc.getPath();
        if (path.trim().length() == 0) {
            throw new Exception("The path of file data source is invalid.");
        }
        String view = sc.getTemp_view();
        boolean cache = sc.getCache();
        String key = sc.getKey().trim();
        if (cache && key.isEmpty()) {
            throw new Exception("Key cannot be empty if cache is enabled.");
        }
        Dataset<Row> dfSource = spark
                .read()
                .format(sc.getFormat())
                .load(path);
        dfSource = applyFilterAndProject(dfSource, sc);
        if (cache) {
            dfSource = dfSource.cache();
            CACHED_DATASET_MAP.putIfAbsent(key, dfSource);
        }
        if (!view.trim().isEmpty()) {
            dfSource.createOrReplaceTempView(view);
        }
        if (!key.isEmpty()) {
            DATASET_MAP.putIfAbsent(key, dfSource);
        }
    }

    /**
     * Apply filters and projections against a dataframe and return
     * the revised dataframe
     *
     * @param origin An instance of {@link Dataset<Row>}
     * @param sc     An instance of {@link LoadConfig.Source}
     * @return A revised dataframe
     */
    private static Dataset<Row> applyFilterAndProject(Dataset<Row> origin, LoadConfig.Source sc) {
        String columns = sc.getSelect_column();
        String where = sc.getWhere_clause();
        // apply filter if where_clause is not empty in config
        if (where.trim().length() > 0) {
            origin = origin.where(where);
        }
        // apply projection if select_columns contain comma char in config
        if (columns.trim().contains(",")) {
            String[] cols = Arrays.stream(columns.split(","))
                    .map(String::trim)
                    .toArray(String[]::new);
            String firstColumn = cols[0];
            String[] restColumns = Arrays.copyOfRange(cols, 1, cols.length);
            origin = origin.select(firstColumn, restColumns);
        }
        return origin;
    }

    /**
     * Transform loaded source datasets based on a list of {@link LoadConfig.Flow} definition
     *
     * @param spark  An instance of {@link SparkSession}
     * @param config An instance of {@link LoadConfig}
     * @throws Exception An exception
     */
    public static void transform(SparkSession spark, LoadConfig config) throws Exception {
        List<LoadConfig.Flow> flows = config.getFlows();
        for (LoadConfig.Flow flow : flows) {
            enrich(spark, flow);
        }
    }

    /**
     * Transform loaded source datasets based on a flow configuration
     *
     * @param spark An instance of {@link SparkSession}
     * @param flow  An instance of {@link LoadConfig.Flow}
     * @throws Exception An exception
     */
    private static void enrich(SparkSession spark, LoadConfig.Flow flow) throws Exception {
        String sql = flow.getSql();
        if (sql.trim().isEmpty()) {
            throw new Exception("The sql of enrichment is invalid.");
        }
        String view = flow.getTemp_view().trim();
        boolean cache = flow.getCache();
        String key = flow.getKey().trim();
        if (cache && key.isEmpty()) {
            throw new Exception("Key cannot be empty if cache is enabled.");
        }
        // if sql is a file, then read its content from resources
        if (sql.endsWith(".sql")) {
            sql = getFileFromSpark(sql);
            if (sql.trim().isEmpty()) {
                throw new Exception("The content of sql file is empty.");
            }
        }
        Dataset<Row> df = spark.sql(sql);
        if (cache) {
            df = df.cache();
            CACHED_DATASET_MAP.putIfAbsent(key, df);
        }
        if (!view.isEmpty()) {
            df.createOrReplaceTempView(view);
        }
        if (!key.isEmpty()) {
            DATASET_MAP.putIfAbsent(key, df);
        }
    }

    /**
     * Sink dataframe into specified HBase table and column family
     *
     * @param spark An instance of {@link SparkSession}
     * @param ec    An instance of {@link LoadConfig.Sink}
     * @throws Exception An exception
     */
    private static void sink(SparkSession spark, LoadConfig ec) throws Exception {
        List<LoadConfig.Sink> scs = ec.getSinks();
        if (scs == null || scs.isEmpty()) {
            throw new Exception("No sink config found.");
        }
        // create Hadoop Configuration and add HBase related configuration
        // ensure the hbase-site.xml file in the class path
        Configuration conf = HBaseConfiguration.create();
        // construct JavaHBaseContext
        JavaSparkContext jsc = JavaSparkContext.fromSparkContext(spark.sparkContext());
        JavaHBaseContext ctx = new JavaHBaseContext(jsc, conf);

        String key, hbase_table;
        for (LoadConfig.Sink config : scs) {
            // sink to HBase
            key = config.getKey();
            hbase_table = config.getHbase_table();
            final String column_family = config.getColumn_family();
            ctx.bulkPut(DATASET_MAP.get(key).toJavaRDD(), TableName.valueOf(hbase_table),
                    row -> buildPutFromRow(row, column_family));
        }
    }

    /**
     * Return content of resource from Spark files folder based on the specified name of resource
     *
     * @param path name of resource
     * @return content of resource
     * @throws IOException I/O exception
     */
    private static String getFileFromSpark(String path) throws IOException {
        Path target = Paths.get(SparkFiles.getRootDirectory(), path);
        try (InputStream is = new FileInputStream(target.toString())) {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int length;
            while ((length = is.read(buffer)) != -1) {
                baos.write(buffer, 0, length);
            }
            return baos.toString();
        }
    }

    /**
     * Create HBase Put instance based on the row data
     *
     * @param row An instance of {@link Row}
     * @return an instance of {@link Put}
     */
    private static Put buildPutFromRow(Row row, String cf) {
        Put put = new Put(Bytes.toBytes(row.getAs("row_key").toString()));
        // get all struct fields without row key
        List<StructField> others = Arrays.stream(row.schema().fields())
                .filter(f -> !f.name().equals("row_key"))
                .collect(Collectors.toList());
        String name;
        DataType type;
        Object value;
        byte[] bytes;
        for (StructField field : others) {
            name = field.name();
            type = field.dataType();
            value = row.getAs(name);
            System.out.println(String.format("name: %s, type: %s", name, type.typeName()));
            if (value != null) {
                bytes = toBytes(value, type);
                if (bytes != null) {
                    put.addColumn(Bytes.toBytes(cf), Bytes.toBytes(name), bytes);
                }
            }
        }
        return put;
    }

    /**
     * Convert an object to byte array based on its type
     *
     * @param value an object that represents a primitive value
     * @return byte array
     */
    private static byte[] toBytes(Object value, DataType type) {
        byte[] result = null;
        if (type == DataTypes.BooleanType) {
            result = Bytes.toBytes((boolean) value);
        }
        if (type == DataTypes.StringType) {
            result = Bytes.toBytes(value.toString());
        }
        if (type == DataTypes.IntegerType || type == DataTypes.ShortType || type == DataTypes.ByteType) {
            result = Bytes.toBytes((int) value);
        }
        if (type == DataTypes.LongType) {
            result = Bytes.toBytes((long) value);
        }
        if (type == DataTypes.DoubleType || type == DataTypes.FloatType) {
            result = Bytes.toBytes((double) value);
        }
        // TODO: Handle Parquet TimeStamp type
        return result;
    }
}
