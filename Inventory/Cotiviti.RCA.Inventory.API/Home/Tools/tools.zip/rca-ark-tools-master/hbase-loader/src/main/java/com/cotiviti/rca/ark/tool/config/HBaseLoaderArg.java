package com.cotiviti.rca.ark.tool.config;

/**
 * A class that represents the command line argument of HBase Loader
 * <p>
 * Only one argument accepted. The argument specifies the name of resources that delimited by comma
 */
public class HBaseLoaderArg {

    public static HBaseLoaderArg parse(String[] args) {
        if (args == null || args.length != 1) {
            throw new IllegalArgumentException("Invalid arguments found.");
        }
        // we need an argument to specify the name of resources
        String input = args[0];
        if (input.trim().length() == 0) {
            throw new IllegalArgumentException("Invalid arguments found.");
        }
        return new HBaseLoaderArg(input);
    }

    private final String input;

    private HBaseLoaderArg(String input) {
        this.input = input;
    }

    public String getInput() {
        return input;
    }
}
