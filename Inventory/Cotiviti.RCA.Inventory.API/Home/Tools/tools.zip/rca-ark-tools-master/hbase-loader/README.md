# HBase Loader

HBase Loader is a tool which is used to load claim (header and detail), exclusion or any other dataset
that required into HBase.

## Architecture

![architecture](images/architecture.PNG)

## Configuration

This tool can be used for all clients, it is client agnostic. When we have a new client, we need to
conduct below actions:

- Create a dedicated configuration for the new client in the conf folder. For instance: if we need to load
datasets for Centene into HBase, then we need to create a new configuration file called centene_config.json.

- Based on the configuration file, create necessary sql files under the sql folder. Each client will have
a sub folder under the sql folder. For instance: all sql files for Centene will be located in the sql/centene folder.

**P.S.** If a dataset which needs to be loaded into HBase, the dataset must have a column called **"row_key"**, and the 
value of this column must be unique because we use the value of this column as the row key of HBase table. Also, we 
need to follow best practices of how to design a row key in HBase for the optimized performance when we 
have a huge dataset in HBase. Some of best practises of row key design in HBase are below:

- Value must be unique 
- Value should be distributed relatively even
- Value should be able to regenerated based on available data (DO NOT USE random or 
system generated values like auto incremental)
 
## Run

Each client has a dedicated shell script to run. Below code snippet is the shell script for Anthem:

```shell script
#!/usr/bin/env bash

# This shell script is used to submit a Spark job to load Anthem HBase datasets

SQL=$(ls -t ./sql/anthem/ | tr '\n', ',' | sed 's/,$//')
CONF='anthem_config.json'
RES="${CONF},${SQL}"
LIB_PATH=$(ls -t ./lib/*.jar | tr '\n', ',')

spark-submit \
--class com.cotiviti.rca.ark.tool.HBaseLoader \
--jars ${LIB_PATH} \
--master yarn \
--deploy-mode cluster \
--name "Ark Anthem HBase Loader" \
--num-executors 1 \
--executor-memory 20G \
--executor-cores 1 \
--driver-memory 20G \
--files ./conf/anthem_config.json,./sql/anthem/* \
hbase-loader-1.0-SNAPSHOT.jar "${RES}"

exit 0
```

Based on above code snippet, we need to supply necessary libraries (HBase dependencies) before running
the script. All necessary libraries can be found in the Cloudera installation folder. In our case, the path
is **/opt/cloudera/parcels/CDH/lib/hbase** on the edge node.

After copying necessary libraries to the lib folder, it looks like below: 

![libs](images/libs.PNG)

 

