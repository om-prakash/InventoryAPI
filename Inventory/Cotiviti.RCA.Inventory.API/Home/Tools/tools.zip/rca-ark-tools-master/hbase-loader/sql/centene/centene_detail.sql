SELECT
    concat_ws('_', claim_key, c.line_number) AS row_key,
    c.line_number as lnid,
    c.line_paid_units as punt,
    IFNULL(c.line_cpt_hcpcs_code, '') as cpt,
    IFNULL(c.line_cpt_hcpcs_modifier [0], '') AS mod,
    IFNULL(c.line_revenue_code, '') AS revcd,
    ''AS mkey
FROM
(
    SELECT
        claim_key,
        subscriber_client_id,
        client_platform_id,
        client_claim_id,
        patient_key,
        inline(claim_detail)
    FROM
        claim_data
) c
INNER JOIN CenteneHeader h
  ON c.claim_key = h.ck