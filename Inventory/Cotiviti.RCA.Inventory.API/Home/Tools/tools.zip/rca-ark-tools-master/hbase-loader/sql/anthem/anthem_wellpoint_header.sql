SELECT
    h.claim_key AS ck,
    CONCAT(
        h.subscriber_client_id,
        '_',
        h.client_platform_id,
        '_',
        h.client_claim_id
    ) AS row_key,
    IFNULL(h.admitting_diagnosis_code, '') AS adx,
    double(h.claim_allowed_amount) AS allamt,
    IFNULL(h.legacy_sys_ids ['clmroot'], '') AS aclm,
    h.claim_service_from_date AS bdos,
    IFNULL(h.type_of_bill_code, '') AS btc,
    double(h.claim_charge_amount) AS crgamt,
    IFNULL(h.check_number, '') AS chk,
    h.client_platform_id AS pltcd,
    double(h.claim_coinsurance_amount) AS coiamt,
    double(h.claim_copay_amount) AS copamt,
    COALESCE(h.submitted_drg_code, h.allowed_drg_code) AS drgc,
    IFNULL(h.discharge_status_code, '') AS dchrg,
    h.claim_service_to_date AS edos,
    h.adjudicated_date AS invdt,
    h.length_of_stay AS los,
    h.client_claim_id AS mclm,
    IFNULL(h.rendering_provider_NPI, '') AS npi,
    double(h.claim_paid_amount) AS pamt,
    h.claim_paid_date AS pdt,
    h.diagnosis_codes [0] AS pdx,
    IFNULL(sor.CodeDefinition, '') AS relcd,
    IFNULL(h.rendering_provider_client_id, '') AS sprvid,
    IFNULL(h.rendering_provider_full_name, '') AS sprvnm,
    5 AS stid,
    COALESCE(
        h.rendering_provider_tax_id,
        h.billing_provider_tax_id
    ) AS tin,
    CASE
        h.insurance_lob
        WHEN 'DUAL' THEN 1
        WHEN 'MCA' THEN 1
        WHEN 'MCS' THEN 1
        WHEN 'MCD' THEN 2
        WHEN 'COM' THEN 3
    END AS lob,
    h.billing_provider_in_network_indicator AS par,
    IF(h.claim_type = 'F', 2, 1) AS prvtyp,
    IF(h.funding_type = 'FI', 2, 1) AS fndtyp,
    CASE
        WHEN substring(h.employer_group_number, 3, 3) NOT IN ('MCA', 'MCS') THEN CASE
            h.benefit_product_code
            WHEN 'MPPEP' THEN 7
            WHEN 'MHMSHM' THEN 2
            WHEN 'MPSHM' THEN 3
            WHEN 'MPPPP' THEN 1
            ELSE null
        END
        ELSE CASE
            WHEN h.benefit_product_code IN ('MPPMS', 'MPPMA', 'MPLMA') THEN 1
            WHEN h.benefit_product_code IN ('MHMSN', 'MHLMA') THEN 2
            WHEN h.benefit_product_code IN ('MFFMS', 'MFFSR') THEN 6
            ELSE null
        END
    END AS plntyp,
    IFNULL(h.claim_place_of_service_code, '') AS pos,
    IFNULL(h.billing_provider_client_id, '') AS bprvid,
    coalesce(
        h.billing_provider_full_name,
        h.rendering_provider_full_name
    ) AS bprvnm,
    IF(
        h.rendering_provider_state = 'UNK',
        '',
        h.rendering_provider_state
    ) AS sprvst,
    IFNULL(h.employer_group_number, '') AS egn,
    IFNULL(h.document_control_number, '') AS dcu,
    h.subscriber_client_id AS subid,
    h.client_lob AS clob,
    IFNULL(h.benefit_product_code, '') AS bpc,
    IFNULL(h.its_bluecard_claim_type, '') AS bct,
    IFNULL(h.patient_medical_record_number, '') AS pmct,
    h.patient_first_name AS pfn,
    h.patient_last_name AS pln,
    h.patient_birth_date AS pbd,
    IFNULL(h.patient_ssn, '') AS ssn,
    21 AS u62,
    CASE
        WHEN h.client_platform_id <> 808 THEN ''
        WHEN h.rendering_provider_medicare_id <> '' THEN h.rendering_provider_medicare_id
        WHEN h.billing_provider_client_id <> '' THEN h.billing_provider_client_id
        ELSE ''
    END AS vid2,
    IFNULL(h.rendering_provider_state, '') AS vst,
    CASE
        h.its_bluecard_claim_type
        WHEN 'LOCL' THEN 0
        WHEN 'HOME' THEN 1
        WHEN 'HOST' THEN 2
        ELSE null
    END AS bind,
    '' AS hmpc,
    '' AS hspc,
    '' AS snum
FROM claim_data h
LEFT OUTER JOIN
(
SELECT
    CodeDefinition,
    CodeValue
FROM code_set
WHERE FieldName = 'MBR_RLTNSHP_CD'
) sor
    ON h.patient_relationship_to_subscriber = sor.CodeValue
WHERE h.client_platform_id != 1104 LIMIT 1000