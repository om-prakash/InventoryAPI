SELECT
    h.claim_key AS ck,
    CONCAT(
        h.subscriber_client_id,
        '_',
        h.client_platform_id,
        '_',
        h.client_claim_id
    ) AS row_key,
    IFNULL(h.admitting_diagnosis_code, '') AS adx,
    double(h.claim_allowed_amount) AS allamt,
    IFNULL(h.legacy_sys_ids ['clmroot'], '') AS aclm,
    h.claim_service_from_date AS bdos,
    IFNULL(h.type_of_bill_code, '') AS btc,
    double(h.claim_charge_amount) AS crgamt,
    IFNULL(h.check_number, '') AS chk,
    h.client_platform_id AS pltcd,
    double(h.claim_coinsurance_amount) AS coiamt,
    double(h.claim_copay_amount) AS copamt,
    COALESCE(h.submitted_drg_code, h.allowed_drg_code) AS drgc,
    IFNULL(h.discharge_status_code, '') AS dchrg,
    h.claim_service_to_date AS edos,
    h.adjudicated_date AS invdt,
    h.length_of_stay AS los,
    h.client_claim_id AS mclm,
    IFNULL(h.rendering_provider_NPI, '') AS npi,
    double(h.claim_paid_amount) AS pamt,
    h.claim_paid_date AS pdt,
    IFNULL(h.diagnosis_codes [0], '') AS pdx,
    IFNULL(sor.CodeDefinition, '') AS relcd,
    IFNULL(h.rendering_provider_client_id, '') AS sprvid,
    IFNULL(h.rendering_provider_full_name, '') AS sprvnm,
    152 AS stid,
    COALESCE(
        h.rendering_provider_tax_id,
        h.billing_provider_tax_id
    ) AS tin,
    CASE
        h.insurance_lob
        WHEN 'DUAL' THEN 1
        WHEN 'MCA' THEN 1
        WHEN 'MCS' THEN 1
        WHEN 'MCD' THEN 2
        WHEN 'COM' THEN 3
    END AS lob,
    h.billing_provider_in_network_indicator AS par,
    IF(h.claim_type = 'F', 2, 1) AS prvtyp,
    IF(h.funding_type = 'FI', 2, 1) AS fndtyp,
    CASE
        WHEN substring(h.employer_group_number, 3, 3) NOT IN ('MCA', 'MCS') THEN CASE
            h.benefit_product_code
            WHEN 'MPPEP' THEN 7
            WHEN 'MHMSHM' THEN 2
            WHEN 'MPSHM' THEN 3
            WHEN 'MPPPP' THEN 1
            ELSE null
        END
        ELSE CASE
            WHEN h.benefit_product_code IN ('MPPMS', 'MPPMA', 'MPLMA') THEN 1
            WHEN h.benefit_product_code IN ('MHMSN', 'MHLMA') THEN 2
            WHEN h.benefit_product_code IN ('MFFMS', 'MFFSR') THEN 6
            ELSE null
        END
    END AS plntyp,
    IFNULL(h.claim_place_of_service_code, '') AS pos,
    IFNULL(h.billing_provider_client_id, '') AS bprvid,
    coalesce(
        h.billing_provider_full_name,
        h.rendering_provider_full_name
    ) AS bprvnm,
    IF(
        h.rendering_provider_state = 'UNK',
        '',
        h.rendering_provider_state
    ) AS sprvst,
    IF(h.claim_type = 'F', 'UB', 'HCFA') AS u04,
    0 AS u07,
    IFNULL(h.pcs_procedure_codes [0], '') AS u08,
    IFNULL(h.allowed_drg_code, '') AS adrg,
    IF(h.check_number = '0', 'EFT', h.check_number) AS u19,
    IFNULL(h.patient_member_id, '') AS mem,
    concat(h.patient_last_name, ', ', h.patient_first_name) AS u22,
    IFNULL(h.patient_medical_record_number, '') AS pmrn,
    CASE
        LEFT(h.employer_group_number, 2)
        WHEN 'XT' THEN 'KY'
        WHEN 'TX' THEN CASE
            WHEN substring(h.employer_group_number, 3, 3) IN ('MCD', 'SET') THEN CASE
                WHEN h.benefit_class_code IN (
                    'TXFTW',
                    'TXDAL',
                    'TXHOU',
                    'TXAUS',
                    'TXSAN',
                    'TXCOR',
                    'TXBET',
                    'TXELP',
                    'TXLUB',
                    'TXRSC',
                    'TXRSW'
                ) THEN h.benefit_class_code
                ELSE 'TXRSN'
            END
            ELSE 'TX'
        END
        ELSE LEFT(h.employer_group_number, 2)
    END AS u25,
    CASE
        WHEN substring(h.employer_group_number, 3, 3) NOT IN ('MMP', 'MCD', 'MCR', 'SET', 'SUP', 'EGR') THEN h.benefit_product_code
        ELSE CASE
            substring(h.employer_group_number, 3, 3)
            WHEN 'SUP' THEN 'SUP'
            WHEN 'MMP' THEN 'MMP'
            WHEN 'MCD' THEN CASE
                SUBSTRING(h.employer_group_number, 3, 6)
                WHEN 'MCR000' THEN 'VANT'
                WHEN 'MCRWP0' THEN CASE
                    LEFT(h.benefit_class_code, 1)
                    WHEN 'V' THEN 'VANT'
                    ELSE 'CARE'
                END
                ELSE 'CARE'
            END
            WHEN 'EGR' THEN 'CARE'
            WHEN 'MDR' THEN CASE
                SUBSTRING(h.employer_group_number, 3, 6)
                WHEN 'MDR000' THEN 'VANT'
                ELSE 'CLARE'
            END
            ELSE CASE
                SUBSTRING(h.employer_group_number, 1, 5)
                WHEN 'TXSET' THEN 'CAID'
                ELSE ''
            END
        END
    END AS u26,
    IFNULL(h.patient_ssn, '') AS ssn,
    CASE
        WHEN SUBSTRING(h.employer_group_number, 3, 3) IN ('MCR', 'MDR', 'MMP', 'EGR') THEN 'CARE'
        WHEN (
            h.employer_group_number = 'CARE'
            OR h.benefit_product_code = 'VANT'
        ) THEN 'CARE'
        ELSE LEFT(h.employer_group_number, 2)
    END AS u31,
    IFNULL(h.employer_group_number, '') AS egn,
    IFNULL(h.benefit_product_code, '') AS bpc,
    CASE
        h.its_bluecard_claim_type
        WHEN 'LOCL' THEN 0
        WHEN 'HOME' THEN 1
        WHEN 'HOST' THEN 2
        ELSE null
    END AS bind,
    '' AS hmpc,
    '' AS hspc,
    '' AS snum
FROM claim_data h
LEFT OUTER JOIN
(
    SELECT
        CodeDefinition,
        CodeValue
    FROM code_set
    WHERE FieldName = 'MBR_RLTNSHP_CD'
) sor
    ON h.patient_relationship_to_subscriber = sor.CodeValue
WHERE h.client_platform_id = 1104 LIMIT 1000