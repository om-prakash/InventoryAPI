SELECT
    CONCAT(
        c.subscriber_client_id,
        '_',
        c.client_platform_id,
        '_',
        c.client_claim_id,
        '_',
        c.line_number
    ) AS row_key,
    c.line_number as lnid,
    c.line_paid_units as punt,
    IFNULL(c.line_cpt_hcpcs_code, '') as cpt,
    IFNULL(c.line_cpt_hcpcs_modifier [0], '') AS mod,
    IFNULL(c.line_revenue_code, '') AS revcd,
    IFNULL(split(c.patient_key, '_') [0], '') AS mkey
FROM
(
    SELECT
        claim_key,
        subscriber_client_id,
        client_platform_id,
        client_claim_id,
        patient_key,
        inline(claim_detail)
    FROM
        claim_data
) c
INNER JOIN WellPointHeader h
  ON c.claim_key = h.ck