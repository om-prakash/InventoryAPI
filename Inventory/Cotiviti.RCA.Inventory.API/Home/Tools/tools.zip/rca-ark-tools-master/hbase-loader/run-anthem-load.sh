#!/usr/bin/env bash

# This shell script is used to submit a Spark job to load Anthem HBase datasets

SQL=$(ls -t ./sql/anthem/ | tr '\n', ',' | sed 's/,$//')
CONF='anthem_config.json'
RES="${CONF},${SQL}"
LIB_PATH=$(ls -t ./lib/*.jar | tr '\n', ',')

spark-submit \
--class com.cotiviti.rca.ark.tool.HBaseLoader \
--jars ${LIB_PATH} \
--master yarn \
--deploy-mode cluster \
--name "Ark Anthem HBase Loader" \
--num-executors 1 \
--executor-memory 20G \
--executor-cores 1 \
--driver-memory 20G \
--files ./conf/anthem_config.json,./sql/anthem/* \
hbase-loader-1.0-SNAPSHOT.jar "${RES}"

exit 0
