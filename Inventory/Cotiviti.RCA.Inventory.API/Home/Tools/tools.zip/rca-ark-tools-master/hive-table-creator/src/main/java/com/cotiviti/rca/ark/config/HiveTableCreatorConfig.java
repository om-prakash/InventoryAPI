package com.cotiviti.rca.ark.config;

@SuppressWarnings("unused")
public class HiveTableCreatorConfig {

    public static HiveTableCreatorConfig parse(String[] args) {
        if (args == null || args.length == 0) {
            throw new IllegalArgumentException("Invalid arguments.");
        }
        if (args.length < 4) {
            throw new IllegalArgumentException("Invalid arguments.");
        }
        String sample, name, location, path, partition = null;
        sample = args[0];
        name = args[1];
        location = args[2];
        path = args[3];
        if (args.length > 4) {
            partition = args[4];
        }
        return new HiveTableCreatorConfig(sample, name, location, path, partition);
    }

    // path of sample parquet data file which contains schema
    private String sample;
    // name of Hive external table
    private String name;
    // location of HDFS folder
    private String location;
    // path of target
    private String path;
    // partition columns, used to generate PARTITIONED BY clause
    // for example: if the value of this field is "COL1 string, COL2 int", then
    // we will generate below PARTITIONED BY clause:
    // PARTITIONED BY (COL1 string, COL2 int)
    private String partition;

    private HiveTableCreatorConfig(String sample, String name, String location, String path, String partition) {
        this.sample = sample;
        this.name = name;
        this.location = location;
        this.path = path;
        this.partition = partition;
    }

    public String getSample() {
        return sample;
    }

    public void setSample(String sample) {
        this.sample = sample;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getPartition() {
        return partition;
    }

    public void setPartition(String partition) {
        this.partition = partition;
    }
}
