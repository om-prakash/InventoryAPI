package com.cotiviti.rca.ark;

import com.cotiviti.rca.ark.config.HiveTableCreatorConfig;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import java.util.Map;

public class HiveTableCreator {

    private final static String CREATE_EXTERNAL_TABLE_FORMAT = "CREATE EXTERNAL TABLE %s (\n";
    private final static String COLUMN_INDENT = "  ";
    private final static String COLUMN_FORMAT = "%s\r\n";
    private final static String PARTITION_FORMAT = "PARTITIONED BY (%s)\r\n";
    private final static String LOCATION_FORMAT = "LOCATION '%s';\r\n";

    public static void main(String[] args) {
        HiveTableCreatorConfig config = null;
        try {
            config = HiveTableCreatorConfig.parse(args);
        } catch(Exception ex) {
            ex.printStackTrace();
            System.exit(-1);
        }
        boolean hasError = false;
        try(SparkSession spark = SparkSession.builder()
//                .master("local[*]")
                .getOrCreate()) {
            try {
                // load the sample file into DataFrame
                Dataset<Row> df = spark.read().format("parquet").load(config.getSample());
                StructType schema = df.schema();
                // build sql statement of hive external table creation
                String sql = build(config, schema);
                // save the generated sql statement to HDFS
                saveToHDFS(config.getPath(), sql);
            } catch(Exception ex) {
                ex.printStackTrace();
                hasError = true;
            }
        }
        if (hasError) {
            System.exit(-1);
        }
    }

    /**
     * To store collected metric JSON file into specified HDFS path
     *
     * @param path    HDFS path to store metric JSON file
     * @param content JSON content
     * @throws Exception An exception that indicates HDFS IO exception
     */
    private static void saveToHDFS(String path, String content) throws Exception {
        Map<String, String> env = System.getenv();
        String hadoopConfDir = env.get("HADOOP_CONF_DIR");
        if (hadoopConfDir == null || hadoopConfDir.trim().length() == 0) {
            throw new Exception("HDFS_CONF_DIR environment variable not set.");
        }
        Configuration conf = new Configuration();
        conf.addResource(new Path(hadoopConfDir + Path.SEPARATOR + "core-site.xml"));
        conf.addResource(new Path(hadoopConfDir + Path.SEPARATOR + "hdfs-site.xml"));
        try (FileSystem fs = FileSystem.get(conf)) {
            try (FSDataOutputStream fos = fs.create(new Path(path))) {
                fos.writeBytes(content);
                fos.flush();
            }
        }
    }

    /**
     * To build Hive SQL statement to create external table based on the schema of sample dataset and
     * configuration.
     *
     * @param config An instance of {@link HiveTableCreatorConfig}
     * @param schema Struct of sample dataset
     * @return A string represents the Hive SQL statement to create external table
     */
    private static String build(HiveTableCreatorConfig config, StructType schema) {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format(CREATE_EXTERNAL_TABLE_FORMAT, config.getName()));
        int i = 0;
        for(StructField field : schema.fields()) {
            sb.append(COLUMN_INDENT);
            if (i > 0) {
                sb.append(",");
            }
            sb.append(String.format(COLUMN_FORMAT, field.toDDL()));
            i++;
        }
        sb.append(")\r\n");
        if (config.getPartition() != null && config.getPartition().trim().length() > 0) {
            sb.append(String.format(PARTITION_FORMAT, config.getPartition()));
        }
        sb.append("STORED AS PARQUET\r\n");
        sb.append(String.format(LOCATION_FORMAT, config.getLocation()));
        return sb.toString();
    }
}
