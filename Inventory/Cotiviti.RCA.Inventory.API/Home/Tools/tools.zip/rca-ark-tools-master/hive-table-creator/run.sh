#!/usr/bin/env bash

# this utility is used to generate the creation hive sql script for a specified dataset and store the generated file in HDFS

# parameters

sample=${sample:-''}
name=${name:-''}
location=${location:-''}
to=${to:-''}
partition=${partition:-''}


# https://brianchildress.co/named-parameters-in-bash/
while [ $# -gt 0 ]; do
   if [[ $1 == *"--"* ]]; then
        param="${1/--/}"
        declare $param="$2"
        # echo $1 $2 // Optional to see the parameter:value result
   fi
  shift
done

export HADOOP_CONF_DIR=/etc/hadoop/conf

spark-submit \
--class com.cotiviti.rca.ark.HiveTableCreator \
--master yarn \
--deploy-mode cluster \
--name "Ark Hive Table Creator" \
--num-executors 1 \
--executor-memory 20G \
--executor-cores 1 \
--driver-memory 20G \
hive-table-creator-1.0-SNAPSHOT.jar "${sample}" "${name}" "${location}" "${to}" "${partition}"

hdfs dfs -chmod 770 $to

exit 0