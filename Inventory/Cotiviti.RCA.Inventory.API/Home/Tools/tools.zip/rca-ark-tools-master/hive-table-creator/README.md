# Hive External Table Creator

This tool is to generate the Hive SQL script to create an external table which points to the specified
HDFS folder.

## How it works

- **Deploy**

  We need to deploy this tool to our edge node, and it has below folder structure:
  
  ![Deployment](images/deploy.PNG)
  
- **Run**

  Use below command line to launch this tool:
  
  ```shell script
   
  # Parameters:
  # 1. --sample - path of sample dataset
  # 2. --name - name of hive external table which is going to be created
  # 3. --location - root folder of hive external table
  # 4. --to - target folder which sql file will be generated in
  # 5. --partition - (optional) partition columns
  ./run.sh --sample "/rca/dev/centene/refined/claim/LoadYear=2021/LoadMonth=3/LoadDay=20/part-00091-a3dc6aac-ac12-453c-a409-35e8bfce38f5.c000.snappy.parquet" \
  --name "anthem_data_validation.centene_claim_raw" \
  --location "/rca/dev/centene/refined/claim" \
  --to "/rca/dev/centene/temp/claim_raw.sql" \
  --partition "LoadYear int, LoadMonth int, LoadDay int"
  
  ```
  
- **Result**

  The generated SQL file should be in the to folder:
  
  ![Result](images/result.PNG)
