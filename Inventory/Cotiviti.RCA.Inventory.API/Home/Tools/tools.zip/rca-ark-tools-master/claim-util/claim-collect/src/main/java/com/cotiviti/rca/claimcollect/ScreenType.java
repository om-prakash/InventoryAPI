package com.cotiviti.rca.claimcollect;

public enum ScreenType {
    Header, LinkedHeader, Detail, LinkedDetail
}
