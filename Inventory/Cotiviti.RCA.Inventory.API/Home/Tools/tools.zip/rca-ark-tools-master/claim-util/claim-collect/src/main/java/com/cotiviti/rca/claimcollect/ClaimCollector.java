package com.cotiviti.rca.claimcollect;

import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.SparkSession;

import java.io.Closeable;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;

public abstract class ClaimCollector implements Closeable, Runnable {

    private static final boolean IS_OS_WINDOWS = System.getProperty("os.name").toLowerCase().contains("win");

    private static final List<String> CLAIM_FIELDS = Arrays.asList(
            "client_name"
            , "client_platform_name"
            , "client_claim_id"
            , "patient_member_id"
            , "patient_key"
            , "patient_first_name||' '||M.patient_last_name as patient_full_name"
            , "rendering_provider_key"
            , "rendering_provider_client_id"
            , "rendering_provider_tax_id"
            , "rendering_provider_npi"
            , "rendering_provider_state"
            , "rendering_provider_full_name"
            , "claim_service_from_date"
            , "claim_service_to_date"
            , "claim_paid_date"
            , "client_received_date"
            , "type_of_bill_code"
            , "diagnosis_codes"
            , "claim_charge_amount"
            , "claim_allowed_amount"
            , "claim_paid_amount"
            , "claim_patient_liability_amount"
            , "claim_deductible_amount"
            , "claim_copay_amount"
            , "claim_coinsurance_amount"
            , "client_platform_id "
            , "claim_detail"
    );

    protected int batchId;

    protected ScreenType screenType;

    protected String contentInput;

    protected String claimModel;

    protected String jsonOutput;

    protected SparkSession spark;

    protected List<String> inputFields;

    public ClaimCollector(Properties prop) {
        this.batchId = Integer.parseInt(prop.getProperty("BatchId"));
        this.screenType = ScreenType.valueOf(prop.getProperty("ScreenType"));
        this.contentInput = prop.getProperty("ContentInput");
        this.claimModel = prop.getProperty("ClaimModel");
        this.jsonOutput = prop.getProperty("JsonOutput");

        this.spark = IS_OS_WINDOWS ? SparkSession.builder().master("local[*]").getOrCreate()
                : SparkSession.builder().getOrCreate();
    }

    public static ClaimCollector of(String... args) {
        Properties prop = new Properties();
        for (String arg : args) {
            int index = arg.indexOf('=');
            if (index > 0) {
                prop.putIfAbsent(arg.substring(0, index), arg.substring(index + 1));
            }
        }

        ScreenType screenType = ScreenType.valueOf(prop.getProperty("ScreenType"));
        switch (screenType) {
            case Header:
                return new HeaderCollector(prop);
            case Detail:
                return new DetailCollector(prop);
            case LinkedHeader:
                return new LinkedHeaderCollector(prop);
            case LinkedDetail:
                return new LinkedDetailCollector(prop);
            default:
                throw new IllegalStateException("Unexpected value: " + screenType);
        }
    }

    @Override
    public void close() throws IOException {
        if (this.spark != null) {
            this.spark.close();
        }
    }

    @Override
    public void run() {
        this.spark.read()
                .parquet(this.contentInput)
                .createOrReplaceTempView("ContentInput");

        this.spark.read()
                .parquet(this.claimModel)
                .createOrReplaceTempView("ClaimModel");

        StringBuilder sb = new StringBuilder("select ");
        int index = sb.length();
        this.inputFields.forEach(col -> sb.append(",I.").append(col));
        sb.deleteCharAt(index); // Remove the first comma(,)

        this.CLAIM_FIELDS.forEach(col -> sb.append(",M.").append(col));
        sb.append(" from ContentInput I join ClaimModel M on I.claim_key = M.claim_key");
        String query = sb.toString();
        this.spark.sql(query)
                .write().mode(SaveMode.Overwrite).json(this.jsonOutput);
    }
}
