package com.cotiviti.rca.claimcollect;

public class ClaimCollectApplication {
    public static void main(String[] args) throws Exception {
        try(ClaimCollector claimCollector = ClaimCollector.of(args)) {
            claimCollector.run();
        }
    }
}
