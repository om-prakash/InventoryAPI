package com.cotiviti.rca.claimcollect;

import java.util.Arrays;
import java.util.Properties;

public class LinkedHeaderCollector extends ClaimCollector {
    LinkedHeaderCollector(Properties properties) {
        super(properties);
        this.inputFields = Arrays.asList("claim_key", "link_id");
    }
}
