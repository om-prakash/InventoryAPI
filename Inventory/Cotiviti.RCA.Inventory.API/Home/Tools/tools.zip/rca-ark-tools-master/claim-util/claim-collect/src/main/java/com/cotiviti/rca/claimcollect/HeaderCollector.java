package com.cotiviti.rca.claimcollect;

import java.util.Arrays;
import java.util.Properties;

public class HeaderCollector extends ClaimCollector {
    public HeaderCollector(Properties properties) {
        super(properties);
        this.inputFields = Arrays.asList("claim_key");
    }
}
