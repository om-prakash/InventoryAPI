package com.cotiviti.rca.claimcollect;

import java.util.Arrays;
import java.util.Properties;

public class LinkedDetailCollector extends ClaimCollector {

    LinkedDetailCollector(Properties properties) {
        super(properties);
        this.inputFields = Arrays.asList("claim_key", "line_number", "link_id");
    }
}
