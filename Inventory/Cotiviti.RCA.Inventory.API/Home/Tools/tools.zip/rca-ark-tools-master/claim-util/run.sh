#!/usr/bin/env bash

# Setup the following parameters

# Increase the batch ID every time you run this script
BATCH_ID=1000

# Concept
CONCEPT_NAME=c_340b

# Screen type is limitted to one of these 4 values: Header, LinkedHeader, Detail, LinkedDetail
SCREEN_TYPE=Header

# HDFS path of the output of content results from manchine learning/deterministic rules
CONTENT_INPUT_HDFS=/rca/dev/centene/concept/c_340b/pol0002_1

# HDFS path of claim data from the client
CLAIM_MODEL=/rca/dev/centene/model/claim

# HDFS path of the output Json
JSON_OUTPUT_HDFS=/rca/dev/centene/temp/gene.zhu/json/c_340b/pol0002_1

# Normal file path of the output Json
JSON_OUTPUT=/home/gene.zhu/json/c_340b/pol0002_1.json


spark-submit \
--class com.cotiviti.rca.claimcollect.ClaimCollectApplication \
--master yarn \
--deploy-mode cluster \
--name "Gene Test" \
--num-executors 1 \
--executor-memory 20G \
--executor-cores 1 \
--driver-memory 20G \
claim-collect-0.0.1-SNAPSHOT.jar \
BatchId=$BATCH_ID \
ScreenType=$SCREEN_TYPE \
ContentInput=$CONTENT_INPUT_HDFS \
ClaimModel=$CLAIM_MODEL \
JsonOutput=$JSON_OUTPUT_HDFS

# Merge
hdfs dfs -getmerge $JSON_OUTPUT_HDFS $JSON_OUTPUT

# Submit
export CONCEPT_NAME
export SCREEN_TYPE
java -jar claim-submit-0.0.1-SNAPSHOT.jar $JSON_OUTPUT


exit 0

