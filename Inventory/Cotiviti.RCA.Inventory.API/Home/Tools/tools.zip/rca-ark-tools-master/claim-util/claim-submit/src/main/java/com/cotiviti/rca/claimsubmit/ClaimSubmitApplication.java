package com.cotiviti.rca.claimsubmit;

import com.cotiviti.rca.ce.dto.ClaimSubmission;
import com.cotiviti.rca.ce.dto.ClaimSubmissionResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;


@SpringBootApplication
public class ClaimSubmitApplication implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(ClaimSubmitApplication.class);
    private static final String USER = System.getenv("USER");
    private static final String CONCEPT_NAME = System.getenv("CONCEPT_NAME");
    private static final String SCREEN_TYPE = System.getenv("SCREEN_TYPE");

    @Value("${claimPublisher}")
    private String claimPublisher;

    @Value("${applicationName}")
    private String applicationName;

    @Value("${companyId}")
    private Integer companyId;

    @Value("${auditId}")
    private Integer auditId;

    @Value("${environment}")
    private String environment;


    private ObjectMapper mapper = new ObjectMapper();

    public static void main(String[] args) {
        SpringApplication.run(ClaimSubmitApplication.class, args);
    }

    @Override
    public void run(String... args) {
        //
        System.out.println(this.applicationName);
        System.out.println(this.auditId);
        System.out.println(this.companyId);
        System.out.println(this.environment);
        System.out.println(USER);
        System.out.println(CONCEPT_NAME);
        System.out.println(SCREEN_TYPE);
        //

        if (args.length == 0) {
            logger.error("Input JSOM file expected.");
            return;
        }

        try {
            List<ClaimSubmission> list = load(args[0]);
            ClaimSubmissionResponse response = post(list);
            logger.info(String.format("%s [batchId=%s]", response.getMessage(), response.getBatchId()));
        } catch (IOException e) {
            logger.error("IOException", e);
        }
    }

    public List<ClaimSubmission> load(String jsonPath) throws IOException {
        List<ClaimSubmission> list = new ArrayList<ClaimSubmission>();
        try (BufferedReader br = new BufferedReader(new FileReader(jsonPath))) {
            String record;
            while ((record = br.readLine()) != null) {
                Claim claim = mapper.readValue(record, Claim.class);
                ClaimSubmission cs = new ClaimSubmission();
                cs.setApplicationName(this.applicationName);
                cs.setCompanyId(this.companyId);
                cs.setAuditId(this.auditId);
                cs.setEnvironment(this.environment);

                cs.setPlatform(claim.getPlatform());

                cs.setClaimAuthor(USER);
                cs.setConceptName(CONCEPT_NAME);
                cs.setScreenName(SCREEN_TYPE);

                cs.setClaimNumber(claim.getClaimNumber());
                cs.setSubscriberNumber(claim.getSubscriberNumber());
                cs.setClaimDate(new Date());

                cs.getAdditionalProperties().putAll(claim.getAdditionalProperties());

                Integer lineNumber = claim.getLineNumber();
                if (lineNumber != null) {
                    Arrays.asList(claim.getLines())
                            .stream()
                            .filter(x -> lineNumber.equals(x.getLineNumber()))
                            .findFirst()
                            .ifPresent(
                                    cl -> {
                                        ClaimSubmission.Line csl = new ClaimSubmission.Line();
                                        csl.setLineNumber(cl.getLineNumber());
                                        csl.getLineProperties().putAll(cl.getLineProperties());
                                        cs.setLines(new ClaimSubmission.Line[] {csl});
                                    }
                    );
                }

                list.add(cs);
            }
        }
        return list;
    }

    public ClaimSubmissionResponse post(List<ClaimSubmission> submission) throws IOException {

        CloseableHttpClient httpclient = HttpClients.createDefault();
        HttpPost httpPost = new HttpPost(this.claimPublisher);

        String jsonString = mapper.writeValueAsString(submission);
        HttpEntity stringEntity = new StringEntity(jsonString, ContentType.APPLICATION_JSON);
        httpPost.setEntity(stringEntity);

        try (CloseableHttpResponse response = httpclient.execute(httpPost)) {
            HttpEntity entity = response.getEntity();
            String json = EntityUtils.toString(entity, StandardCharsets.UTF_8);
            return mapper.readValue(json, ClaimSubmissionResponse.class);
        }
    }
}
