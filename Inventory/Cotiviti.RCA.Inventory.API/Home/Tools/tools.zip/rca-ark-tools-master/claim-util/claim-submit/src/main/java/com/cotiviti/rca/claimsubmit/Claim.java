package com.cotiviti.rca.claimsubmit;

import com.fasterxml.jackson.annotation.*;
import lombok.Data;
import lombok.ToString;

import java.util.HashMap;
import java.util.Map;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@ToString(exclude = {"additionalProperties"})
public class Claim {

    @JsonProperty("client_platform_name")
    private String platform;

    @JsonProperty("client_claim_id")
    private String claimNumber;

    @JsonProperty("patient_member_id")
    private String subscriberNumber;

    @JsonProperty("line_number")
    private Integer lineNumber;

    @JsonProperty("claim_detail")
    private Line[] lines;

    // additional properties for mapping
    @JsonAnySetter
    private final Map<String, Object> additionalProperties = new HashMap<>();

    @JsonAnyGetter()
    public Map<String, Object> getAdditionalProperties() {
        return additionalProperties;
    }

    @Data
    public static class Line {
        @JsonProperty("line_number")
        private Integer lineNumber;

        @JsonAnySetter
        private final Map<String, Object> lineProperties = new HashMap<>();

        @JsonAnyGetter()
        public Map<String, Object> getLineProperties() {
            return lineProperties;
        }
    }
}
