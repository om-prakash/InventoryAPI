package com.cotiviti.rca.claimsubmit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClaimSubmitApplicationTests {

	@Test
	void contextLoads() {
	}

}
