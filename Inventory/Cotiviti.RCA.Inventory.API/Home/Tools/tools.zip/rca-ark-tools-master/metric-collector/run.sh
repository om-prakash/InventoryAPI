#!/usr/bin/env bash

# this utility collects metrics from a specified dataset and store the metrics report JSON file in HDFS

# parameters

name=${name:-''}
desc=${desc:-''}
path=${path:-''}
format=${format:-''}
columns=${columns:-''}
to=${to:-''}

# https://brianchildress.co/named-parameters-in-bash/
while [ $# -gt 0 ]; do
   if [[ $1 == *"--"* ]]; then
        param="${1/--/}"
        declare $param="$2"
        # echo $1 $2 // Optional to see the parameter:value result
   fi
  shift
done

export HADOOP_CONF_DIR=$(hadoop classpath)

spark2-submit \
--class com.cotiviti.rca.ark.tools.MetricCollector \
--master yarn \
--deploy-mode cluster \
--name "Ark Metric Collector" \
--packages org.apache.spark:spark-avro_2.11:2.4.0 \
--num-executors 10 \
--executor-memory 20G \
--executor-cores 5 \
--driver-memory 20G \
metric-collector-1.0-SNAPSHOT.jar "${name}" "${desc}" "${path}" "${format}" "${columns}" "${to}"

hdfs dfs -chmod 770 $to

exit 0