# Metrics Collector

This utility can be used to collect metrics from a dataset. Currently, we collect below metrics:

- count
- count distinct
- min
- max

We can extend this utility to support other metrics if needed.

## Parameters

This utility supports below parameters:

| Parameter | position     | Memo                                                                                                                                    |
|-----------|--------------|-----------------------------------------------------------------------------------------------------------------------------------------|
| name      | 1            | This parameter specifies the name of metric report                                                                                      |
| desc      | 2            | This parameter specifies the description of metric report                                                                               |
| path      | 3            | This parameter specifies the path of dataset that metrics collected from                                                                |
| format    | 4            | This parameter specifies the format of dataset. avro and parquet supported                                                              |
| columns   | 5            | This parameter specifies the columns of dataset that metrics collected against, multiple columns delimited by comma                     |
| to        | 6            | This parameter specifies the path of HDFS that metric report saved to, this  parameter only needed if we save the metric report to HDFS | 

## How it works

### Deployment

We need to deploy the generated jar file and associated ShellScript run.sh to edge node first. 

![Deployment](images/deployment.PNG)

### Run

After deploying the generated jar file and associated ShellScript to edge node, we can collect metrics via below command:

```shell script
# if the columns is empty, then we collect metrics for all columns in a dataset
./run.sh --name "Simply 20201125 Metrics Report" --desc "" --path "/rca/dev/anthem/refined/claim/simply/20201125" \
--format "parquet" --columns "" --to "/rca/dev/anthem/temp/metrics/simply-20201125-metrics.json"
```

### Result

After above command completed, we can get the metrics result in the specified HDFS path

![Result](images/result.PNG)
