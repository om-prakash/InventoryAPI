package com.cotiviti.rca.ark.tools.config;

@SuppressWarnings("unused")
public class MetricCollectorConfig {

    /**
     * To construct an instance of {@link MetricCollectorConfig} from command line parameters
     *
     * @param args arguments of command line
     * @return An instance of {@link MetricCollectorConfig}
     * @throws Exception An exception that indicates something is wrong
     */
    public static MetricCollectorConfig parse(String[] args) throws Exception {
        String name = args[0];
        String desc = args[1];
        String path = args[2];
        String format = args[3];
        String columns = args[4];
        String to = args[5];
        if (name == null || name.trim().length() == 0 || path == null || path.trim().length() == 0
                || format == null || format.trim().length() == 0) {
            throw new Exception("Invalid parameters found. Data source's name, path and format cannot be empty.");
        }
        format = format.toLowerCase();
        if (!format.equals("parquet") && !format.equals("avro")) {
            throw new Exception("Unsupported format found. Only parquet and avro format supported.");
        }
        if (desc == null || desc.trim().length() == 0) desc = "";
        if (to == null || to.trim().length() == 0) to = "";
        return new MetricCollectorConfig(name, desc, path, format, columns, to);
    }

    private String name;
    private String desc;
    private String path;
    private String format;
    private String columns;
    private String to;

    /**
     * Constructor to construct an instance of {@link MetricCollectorConfig}
     *
     * @param name    report name of collected metrics
     * @param desc    description of collected metrics
     * @param path    path of dataset that metrics collected from
     * @param format  format of dataset. only parquet and avro supported for now.
     * @param columns columns of dataset that metrics collected for. if it's empty, then collect metrics for all columns
     * @param to      path to store the report of collected metrics. HDFS path
     */
    private MetricCollectorConfig(String name, String desc, String path, String format, String columns, String to) {
        this.name = name;
        this.desc = desc;
        this.path = path;
        this.format = format;
        this.columns = columns;
        this.to = to;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getColumns() {
        return columns;
    }

    public void setColumns(String columns) {
        this.columns = columns;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    @Override
    public String toString() {
        return "MetricCollectorConfig{" +
                "name='" + name + '\'' +
                ", path='" + path + '\'' +
                ", format='" + format + '\'' +
                ", columns='" + columns + '\'' +
                ", to='" + to + '\'' +
                '}';
    }
}
