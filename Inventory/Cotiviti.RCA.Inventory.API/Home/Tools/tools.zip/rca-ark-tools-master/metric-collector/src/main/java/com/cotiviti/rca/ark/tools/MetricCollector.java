package com.cotiviti.rca.ark.tools;

import com.cotiviti.rca.ark.tools.config.MetricCollectorConfig;
import com.cotiviti.rca.ark.tools.model.ColumnMetric;
import com.cotiviti.rca.ark.tools.model.Metric;
import com.cotiviti.rca.ark.tools.model.MetricReport;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static java.lang.String.format;

/**
 * A class to collect metrics from a dataset via Spark
 * <p>
 * Currently we support count, count distinct, min and max metric, but it can be extended to support others
 */
public class MetricCollector {

    // a list to contain all columns of the loaded dataframe
    private final static List<String> COLUMNS = new ArrayList<>();

    /**
     * Entry point to run metric collector
     *
     * @param args arguments of command line
     */
    public static void main(String[] args) {
        MetricCollectorConfig config = null;
        try {
            // parse configuration from command line arguments
            config = MetricCollectorConfig.parse(args);
        } catch (Exception ex) {
            ex.printStackTrace();
            System.exit(-1);
        }
        boolean hasError = false;
        try (SparkSession spark = SparkSession.builder().master("local[*]").getOrCreate()) {
            try {
                // run metric collector against loaded dataframe and return metrics dataframe
                Dataset<Row> df_metric = getMetric(spark, config);
                // send metrics dataframe to drive node as a list of spark row object
                List<Row> metricList = df_metric.collectAsList();
                if (metricList.size() > 0) {
                    // should only one element in the list
                    Row metricRow = metricList.get(0);
                    // generate JSON report from the row object
                    String json = toJson(metricRow, config);
                    // if we run it on local, then just print out the collected JSON because we may not have
                    // hadoop installed locally; otherwise save the collected metrics report to HDFS
                    if (spark.sparkContext().isLocal()) {
                        System.out.println(json);
                    } else {
                        String to = config.getTo();
                        if (to.length() == 0) {
                            throw new Exception("HDFS path cannot be empty.");
                        }
                        saveToHDFS(to, json);
                    }
                } else {
                    throw new Exception("No metric row returned.");
                }
            } catch (Exception inx) {
                inx.printStackTrace();
                hasError = true;
            }
        }
        if (hasError) {
            System.exit(-1);
        }
    }

    /**
     * To store collected metric JSON file into specified HDFS path
     *
     * @param path    HDFS path to store metric JSON file
     * @param content JSON content
     * @throws Exception An exception that indicates HDFS IO exception
     */
    private static void saveToHDFS(String path, String content) throws Exception {
        Map<String, String> env = System.getenv();
        String hadoopConfDir = env.get("HADOOP_CONF_DIR");
        if (hadoopConfDir == null || hadoopConfDir.trim().length() == 0) {
            throw new Exception("HDFS_CONF_DIR environment variable not set.");
        }
        Configuration conf = new Configuration();
        conf.addResource(new Path(hadoopConfDir + Path.SEPARATOR + "core-site.xml"));
        conf.addResource(new Path(hadoopConfDir + Path.SEPARATOR + "hdfs-site.xml"));
        try (FileSystem fs = FileSystem.get(conf)) {
            try (FSDataOutputStream fos = fs.create(new Path(path))) {
                fos.writeBytes(content);
                fos.flush();
            }
        }
    }

    /**
     * To convert Spark Row object to JSON string
     *
     * @param row    An instance of {@link Row}
     * @param config An instance of {@link MetricCollectorConfig}
     * @return A string that represents collected metrics
     * @throws JsonProcessingException An exception that indicates Json processing error
     */
    private static String toJson(Row row, MetricCollectorConfig config) throws JsonProcessingException {
        List<ColumnMetric> metrics = new ArrayList<>();
        List<String> cols = COLUMNS;
        if (config.getColumns().length() > 0) {
            cols = Arrays.asList(config.getColumns().split(","));
        }
        ColumnMetric cm;
        for (String col : cols) {
            cm = new ColumnMetric();
            cm.setColumn(col);
            cm.setMetric(new Metric(row.getAs(col + "_count"), row.getAs(col + "_count_distinct"),
                    row.getAs(col + "_min"), row.getAs(col + "_max")));
            metrics.add(cm);
        }
        MetricReport mr = new MetricReport();
        mr.setName(config.getName());
        mr.setDesc(config.getDesc());
        mr.setPath(config.getPath());
        mr.setFormat(config.getFormat());
        mr.setMetrics(metrics);
        DateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
        return new ObjectMapper().setDateFormat(fmt).writerWithDefaultPrettyPrinter().writeValueAsString(mr);
    }

    /**
     * To load specified dataset and retrieve metric for all columns or specified columns
     *
     * @param spark  An instance of {@link SparkSession}
     * @param config An instance of {@link MetricCollectorConfig}
     * @return A Dataframe that contains collected metric row
     * @throws Exception An exception that indicates something is wrong
     */
    private static Dataset<Row> getMetric(SparkSession spark, MetricCollectorConfig config) throws Exception {
        Dataset<Row> df = spark.read().format(config.getFormat()).load(config.getPath());
        StructType st = df.schema();
        for (StructField sf : st.fields()) {
            COLUMNS.add(sf.name());
        }
        List<String> targetCols = COLUMNS;
        // if users specified columns, then check if columns are valid
        if (config.getColumns().length() > 0) {
            String[] cols = config.getColumns().split(",");
            for (String col : cols) {
                // if any user specified column cannot be found
                if (!COLUMNS.contains(col)) {
                    throw new Exception(format("The specified column %s not found.", col));
                }
            }
            // if user specified columns are all valid
            targetCols = Arrays.asList(cols);
        }
        df.createOrReplaceTempView("source");
        String sql = buildMetricSQL(targetCols);
        return spark.sql(sql);
    }

    /**
     * To build the Spark SQL statement to get count, count distinct, min and max metrics
     *
     * @param columns a list of column name
     * @return Spark SQL statement to get count, count district, min and max metrics
     */
    private static String buildMetricSQL(List<String> columns) {
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT ");
        int index = 0;
        for (String column : columns) {
            if (index == 0) {
                sb.append(format("count(%s) AS %s_count", column, column));
            } else {
                sb.append(format(",count(%s) AS %s_count", column, column));
            }
            sb.append(format(",count(DISTINCT %s) AS %s_count_distinct", column, column));
            sb.append(format(",min(%s) AS %s_min", column, column));
            sb.append(format(",max(%s) AS %s_max", column, column));
            index++;
        }
        sb.append(" FROM source");
        return sb.toString();
    }
}
