package com.cotiviti.rca.ark.tools.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@SuppressWarnings("unused")
public class MetricReport {
    @JsonProperty("name")
    private String name;
    @JsonProperty("description")
    private String desc;
    @JsonProperty("source")
    private String path;
    @JsonProperty("format")
    private String format;
    @JsonProperty("metrics")
    private List<ColumnMetric> metrics;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public List<ColumnMetric> getMetrics() {
        return metrics;
    }

    public void setMetrics(List<ColumnMetric> metrics) {
        this.metrics = metrics;
    }
}
