package com.cotiviti.rca.ark.tools.model;

import com.fasterxml.jackson.annotation.JsonProperty;

@SuppressWarnings("unused")
public class ColumnMetric {
    @JsonProperty("column")
    private String column;
    @JsonProperty("metric")
    private Metric metric;

    public String getColumn() {
        return column;
    }

    public void setColumn(String column) {
        this.column = column;
    }

    public Metric getMetric() {
        return metric;
    }

    public void setMetric(Metric metric) {
        this.metric = metric;
    }

    @Override
    public String toString() {
        return "ColumnMetric{" +
                "column='" + column + '\'' +
                ", metric=" + metric +
                '}';
    }
}
