package com.cotiviti.rca.ark.tools.model;

import com.fasterxml.jackson.annotation.JsonProperty;

@SuppressWarnings("unused")
public class Metric {
    @JsonProperty("count")
    private long count;
    @JsonProperty("count_distinct")
    private long countDistinct;
    @JsonProperty("min")
    private Object min;
    @JsonProperty("max")
    private Object max;

    public Metric() {

    }

    public Metric(long count, long countDistinct, Object min, Object max) {
        this.count = count;
        this.countDistinct = countDistinct;
        this.min = min;
        this.max = max;
    }

    public long getCount() {
        return count;
    }

    public void setCount(long count) {
        this.count = count;
    }

    public long getCountDistinct() {
        return countDistinct;
    }

    public void setCountDistinct(long countDistinct) {
        this.countDistinct = countDistinct;
    }

    public Object getMin() {
        return min;
    }

    public void setMin(Object min) {
        this.min = min;
    }

    public Object getMax() {
        return max;
    }

    public void setMax(Object max) {
        this.max = max;
    }

    @Override
    public String toString() {
        return "Metric{" +
                "count=" + count +
                ", countDistinct=" + countDistinct +
                '}';
    }
}
