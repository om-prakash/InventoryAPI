# RCA ARK Tools

This repository is the home of tools that developed by ARK team. Those tools can resolve a specific requirement or can improve team's productivity.

## List of Tools

- **HBase Tool**

  This tool is used to load sample data into HBase tables. 

- **HDFS Retentioner**

  This tool is used to enfore retention policies for specified HDFS folders. If a folder exceeds its retention period, the folder will be deleted.

- **Metrics Collector**

  This tool is used to collect some basic statistics metrics for a dataset. For example: Min value, Max value, etc.
  
- **HBase Loader**

  This tool is used to load claim, exclusion or other required datasets for a client into HBase.
  
- **Payload Generator**

  This tool is used to generate payload from the output of content engine for SpotCheck. It can generate payloads for four screen types: Header, Detail, Linked Header and Linked Detail.

