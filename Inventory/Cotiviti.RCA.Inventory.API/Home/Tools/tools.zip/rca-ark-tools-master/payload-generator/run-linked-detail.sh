#!/usr/bin/env bash

# This shell script is used to submit a Spark job to generate payloads for SpotCheck Linked Detail screen.

# Three required parameters
# [1]: input path
# [2]: model path
# [3]: output path

input=${input:-''}
model=${model:-''}
output=${output:-''}

# https://brianchildress.co/named-parameters-in-bash/
while [ $# -gt 0 ]; do
   if [[ $1 == *"--"* ]]; then
        param="${1/--/}"
        declare $param="$2"
        # echo $1 $2 // Optional to see the parameter:value result
   fi
  shift
done

UNAME=$USER
QUEUE="root.rca"

CONF="linked_detail_config.json"
SCHEMA=$(ls -t ./schema | tr '\n', ',' | sed 's/,$//')
SQL=$(ls -t ./sql | tr '\n', ',' | sed 's/,$//')
RES="${CONF},${SCHEMA},${SQL}"

JOB="linked_detail"

# Load util functions
. ./util.sh

# Check if required parameter supplied
if [ -z "$input" ]; then
  send_notification "Required parameter [--input] not supplied. User: ${UNAME} - Queue: ${QUEUE}"
  exit 1
fi

if [ -z "$model" ]; then
  send_notification "Required parameter [--model] not supplied. User: ${UNAME} - Queue: ${QUEUE}"
  exit 1
fi

if [ -z "$output" ]; then
  send_notification "Required parameter [--output] not supplied. User: ${UNAME} - Queue: ${QUEUE}"
  exit 1
fi

# Exit on error
set -e

# Trap ERR event to send notification
trap 'send_notification "ARK payload service failed. (Linked Detail) User: ${UNAME} - Queue: ${QUEUE}"' ERR

# Send started notification to Teams
send_notification "ARK payload service started. (Linked Detail) User: ${UNAME} - Queue: ${QUEUE}"

# Submit Spark job to cluster to generate payloads for SpotCheck Linked Detail screen
spark-submit \
--master yarn \
--deploy-mode cluster \
--name "ARK Payload Service (Linked Detail)" \
--queue ${QUEUE} \
--num-executors 40 \
--executor-memory 80G \
--executor-cores 5 \
--driver-memory 40G \
--py-files ./ark_etl_lib.zip,./jobs.zip \
--files ./conf/linked_detail_config.json,./schema/*,./sql/* \
--conf spark.sql.broadcastTimeout=600 \
./main.py --job ${JOB} --rs "${RES}" --job-args InputPath=${input} ModelPath=${model} OutputPath=${output}

# Set ACL
hdfs dfs -chmod -R 770 ${output}


# Send completed notification to Teams
send_notification "ARK payload service completed. (Linked Detail) User: ${UNAME} - Queue: ${QUEUE}"

# Exit
exit 0