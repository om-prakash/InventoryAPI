from ark_etl_lib import parse_nargs, get_configs, Log4j, JobContext, add_spark_files
from pyspark.sql import SparkSession
from os import listdir, path
import argparse
import traceback
import importlib

"""
Currently our cluster is using Python 2.7. The default encoding for Python 2.7 is ASCII not utf-8
we can use below statement to change the default encoding (Only for Python 2.7, the default encoding of Python 3.x
is utf-8.)
import sys

reload(sys)
sys.setdefaultencoding('utf-8')
"""


def add_sql_files(spark, in_folder="./sql"):
    """
    add all sql files to SparkFiles (a special place that files can be found on all nodes)
    this function only invoked while running on local
    :param spark: spark session
    :param in_folder: folder that contains sql files. default to ./sql
    :return: None
    """
    for sql in listdir(in_folder):
        if sql.endswith(".sql"):
            add_spark_files(path.join(in_folder, sql), spark)


def add_conf_files(spark, in_folder="./conf", local=True):
    """
    add all config files to SparkFiles (a special place that files can be found on all nodes)
    this function only invoked while running on local
    :param spark: spark session
    :param in_folder: folder that contains config files. default to ./conf
    :param local: a boolean value that indicates if the job is running locally
    :return: None
    """
    if local:
        conf_files = [f for f in listdir(in_folder) if f.endswith('_dev_config.json')]
    else:
        conf_files = [f for f in listdir(in_folder) if f.endswith('_config.json')]
    for conf in conf_files:
        add_spark_files(path.join(in_folder, conf), spark)


def add_schema_files(spark, in_folder="./schema"):
    """
    add all schema files to SparkFiles (a special place that files can be found on all nodes)
    this function only invoked while running on local
    :param spark: spark session
    :param in_folder: folder that contains schema files. default to ./schema
    :return: None
    """
    for schema in listdir(in_folder):
        if schema.endswith(".json"):
            add_spark_files(path.join(in_folder, schema), spark)


def main():
    # capture spark submit args
    parser = argparse.ArgumentParser()
    parser.add_argument('--job', dest='job_name', type=str, required=True,
                        help='The name of the job module you want to run. (ex: --job load will run jobs/load.py '
                             'the job script file should have a method named "run"')
    parser.add_argument('--job-args', dest='job_args', nargs='*',
                        help='Extra arguments to send to the PySpark job. arguments can be parsed in the job'
                             '(example: --job-args addlconfig=hdfs///rca/config.json customarg=anotherarg )')
    parser.add_argument('--rs', '--resource', dest='rs', type=str)
    parser.add_argument('--pks', '--packages', dest='pks', type=str, help='spark packages delimited by comma')
    args = parser.parse_args()
    args = parse_nargs(args, 'job_args')
    # set spark objects
    spark = None
    log = None
    has_error = False

    try:
        # Initialize the SparkSession and custom logger
        # On local if we need to use third party spark packages, we can use the pks parameter to configure
        # one or more packages (use comma to delimit) like below:
        # --pks com.crealytics:spark-excel_2.11:0.13.7,za.co.absa.cobrix:spark-cobol_2.11:2.2.2
        if args.pks is not None:
            spark = SparkSession.builder.config('spark.jars.packages', args.pks).getOrCreate()
        else:
            spark = SparkSession.builder.getOrCreate()
        log = Log4j(spark)

        # Get deploy mode
        mode = spark.sparkContext.getConf().get('spark.submit.deployMode', 'cluster')

        # Use different approach to deal with config and sql files for local and cluster environment
        if 'local' in spark.sparkContext.applicationId:
            # Add all SQL files under sql folder to SparkFiles
            add_sql_files(spark)
            # Add all dev config files under conf folder to SparkFiles
            add_conf_files(spark)
            # Add all schema files under schema folder to SparkFiles
            add_schema_files(spark)
        elif mode == 'client':
            # Add all SQL files under sql folder to SparkFiles
            add_sql_files(spark)
            # Add all prod config files under conf folder to SparkFiles
            add_conf_files(spark, local=False)
            # Add all schema files under schema folder to SparkFiles
            add_schema_files(spark)
        else:
            # if we run on cluster, use --files to upload required resource files
            # to all nodes and use --rs to specify file names delimited by comma
            for rs in args.rs.split(','):
                add_spark_files(rs, spark)

        # Initialize the master config dictionary class and load configuration
        config = get_configs(args=args)

        # Log global configuration
        log.info('global config: ' + str(config))

        # Construct an instance of JobContext
        context = JobContext(spark, config, log)

        # Load specified job module
        job_py = importlib.import_module('jobs.%s' % args.job_name)

        # log start time and execute job.  the job will need a run method that accepts the spark session the log
        # and the config class object
        log.info('Starting job ' + args.job_name)
        job_py.run(context)
        log.info('Completed job ' + args.job_name)

    except IOError:
        has_error = True
        log.error('An IO error occurred. ' + traceback.format_exc())

    except Exception as e:
        has_error = True
        log.error(str(e) + ' ' + traceback.format_exc())

    # stop spark session to release resources
    if spark is None:
        pass
    else:
        spark.stop()

    # if an error occurred, we need to mark the exit code to an non-zero value
    # in airflow, an non-zero exit code identifies a task failed, otherwise airflow
    # will keep running and never end
    if has_error:
        exit(1)


if __name__ == "__main__":
    main()
