# ARK Payload Generator

This tool is used to generate payload JSON files for SpotCheck. It can generate payloads for below
four screen types in SpotCheck:

- Header
- Detail
- Linked Header
- Linked Detail

## Diagram

![architecture](images/architecture.PNG)


## How to run

### Payload for Header

```shell script
./run-header.sh --input <HDFS Path to output of content> \
--model <HDFS Path to claim model> \
--output <HDFS Path to payload JSON>
```

### Payload for Detail

```shell script
./run-detail.sh --input <HDFS Path to output of content> \
--model <HDFS Path to claim model> \
--output <HDFS Path to payload JSON>
```

### Payload for Linked Header

```shell script
./run-linked-header.sh --input <HDFS Path to output of content> \
--model <HDFS Path to claim model> \
--output <HDFS Path to payload JSON>
```

### Payload for Linked Detail

```shell script
./run-linked-detail.sh --input <HDFS Path to output of content> \
--model <HDFS Path to claim model> \
--output <HDFS Path to payload JSON>
```