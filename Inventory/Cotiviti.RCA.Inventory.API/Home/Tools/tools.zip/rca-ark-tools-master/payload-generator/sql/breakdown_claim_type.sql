SELECT
  collect_list(struct(a.its_bluecard_claim_type, a.count)) as breakdown_its_bluecard_claim_type
FROM
(
    SELECT
      its_bluecard_claim_type
      ,count(1) as count
    FROM input_enriched
    GROUP BY its_bluecard_claim_type
) as a
