SELECT
  first(client_key, true) as client_key
  ,first(client_name, true) as client_name
  ,sum(1) as claims_received
  ,count(distinct rendering_provider_key) as rendering_provider_key_unique_count
  ,count(distinct patient_key) as patient_key_unique_count
  ,min(claim_paid_date) as minimum_claim_paid_date
  ,max(claim_paid_date) as maximum_claim_paid_date
  ,min(claim_service_from_date) as minimum_claim_service_from_date
  ,max(claim_service_from_date) as maximum_claim_service_from_date
  ,'Header' as screen_type
FROM input_enriched