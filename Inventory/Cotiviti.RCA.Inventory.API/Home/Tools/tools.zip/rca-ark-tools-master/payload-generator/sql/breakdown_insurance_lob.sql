SELECT
  collect_list(struct(a.insurance_lob, a.count)) as breakdown_insurance_lob
FROM
(
    SELECT
      insurance_lob
      ,count(1) as count
    FROM input_enriched
    GROUP BY insurance_lob
) as a
