SELECT
  collect_list(struct(a.billing_provider_in_network_indicator, a.count)) as breakdown_billing_provider_in_network_indicator
FROM
(
    SELECT
      billing_provider_in_network_indicator
      ,count(1) as count
    FROM input_enriched
    GROUP BY billing_provider_in_network_indicator
) as a
