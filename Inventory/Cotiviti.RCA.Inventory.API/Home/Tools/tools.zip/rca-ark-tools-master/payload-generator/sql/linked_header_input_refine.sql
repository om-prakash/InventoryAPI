SELECT
  int(LinkId) AS LinkId,
  int(Batch) AS Batch,
  ClaimNum,
  ConceptName,
  int(ConceptKey) AS ConceptKey,
  bigint(LegacyClaimKey) AS LegacyClaimKey,
  LegacyMemKey,
  LegacyProvKey,
  int(SOR) AS SOR,
  ClaimAdjustment
FROM input
