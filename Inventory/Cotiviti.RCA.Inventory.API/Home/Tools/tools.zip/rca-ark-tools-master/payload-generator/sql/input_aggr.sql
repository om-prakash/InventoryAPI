SELECT
  first(Batch, true) as batch_key
  ,first(ConceptKey, true) as concept_key
  ,first(ConceptName, true) as concept_name
FROM input_refined