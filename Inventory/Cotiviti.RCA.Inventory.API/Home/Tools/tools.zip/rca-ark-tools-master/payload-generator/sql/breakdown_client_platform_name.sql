SELECT
  collect_list(struct(a.client_platform_name, a.count)) as breakdown_client_platform_name
FROM
(
    SELECT
      client_platform_name
      ,count(1) as count
    FROM input_enriched
    GROUP BY client_platform_name
) as a
