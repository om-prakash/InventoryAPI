SELECT
  i.LegacyClaimKey as claim_key
  ,a.client_key
  ,a.client_name
  ,a.client_platform_name
  ,a.insurance_lob
  ,a.billing_provider_in_network_indicator
  ,a.its_bluecard_claim_type
  ,0 as exclusion_international_approved
  ,a.client_claim_id
  ,a.claim_paid_amount as estimated_overpayment
  ,a.patient_member_id as patient_member_number
  ,i.LegacyMemKey as patient_key
  ,concat_ws(' ', a.patient_first_name, a.patient_last_name) as patient_full_name
  ,i.LegacyProvKey as rendering_provider_key
  ,a.rendering_provider_client_id
  ,a.rendering_provider_tax_id
  ,a.rendering_provider_npi
  ,a.rendering_provider_state
  ,a.rendering_provider_full_name
  ,date(a.claim_service_from_date) as claim_service_from_date
  ,date(a.claim_service_to_date) as claim_service_to_date
  ,date(a.claim_paid_date) as claim_paid_date
  ,date(a.client_received_date) as client_received_date
  ,a.type_of_bill_code
  ,a.diagnosis_codes
  ,a.claim_charge_amount
  ,a.claim_allowed_amount
  ,a.claim_paid_amount
  ,a.claim_patient_liability_amount
  ,a.claim_deductible_amount
  ,a.claim_copay_amount
  ,a.claim_coinsurance_amount
  ,date(d.line_service_from_date) as line_service_from_date
  ,date(d.line_service_to_date) as line_service_to_date
  ,d.line_place_of_service_code
  ,d.line_revenue_code
  ,d.line_cpt_hcpcs_code
  ,d.line_submitted_units
  ,d.line_paid_units
  ,d.line_cpt_hcpcs_modifier
  ,d.line_charge_amount
  ,d.line_allowed_amount
  ,d.line_paid_amount
  ,d.line_patient_liability_amount
  ,d.line_deductible_amount
  ,d.line_copay_amount
  ,d.line_coinsurance_amount
  ,d.line_number
  ,'Low' as complexity
FROM input_refined AS i
INNER JOIN claim_model AS a
  ON i.SOR = a.client_platform_id AND i.ClaimAdjustment = element_at(a.legacy_sys_ids, 'claimadjustmentind')
LATERAL VIEW inline(a.claim_detail) d
WHERE a.final_action_indicator = 1 AND i.LineNum = d.line_number