SELECT
  collect_list(struct(a.exclusion_international_approved, a.count)) as breakdown_exclusion_international_approved
FROM
(
    SELECT
      exclusion_international_approved
      ,count(1) as count
    FROM input_enriched
    GROUP BY exclusion_international_approved
) as a
