SELECT
  a.*
  ,b.*
  ,c.*
  ,d.*
  ,e.*
  ,f.*
  ,g.*
  ,h.*
FROM input_aggr as a
CROSS JOIN enrich_aggr as b
CROSS JOIN breakdown_exclusion as c
CROSS JOIN breakdown_insurance_lob as d
CROSS JOIN breakdown_client_platform_name as e
CROSS JOIN breakdown_billing_provider_indicator as f
CROSS JOIN breakdown_claim_type as g
CROSS JOIN header_claim_list as h