# This shell scripts contain shared functions that used in other shell scripts

function send_notification() {
  # send a notification to Microsoft Teams via a webhook
  url='https://cotiviti.webhook.office.com/webhookb2/caa0b75a-9926-447c-afa9-6bd0ceed18c5@7680316a-5e9e-4cc5-a52e-9ee89ee8c404/IncomingWebhook/12bd777ba6b74443aae9b1c429520480/b2067369-3c7a-4ccf-bab3-257b526b477d'
  msg=$1
  curl -H 'content-type: application/json' -d "{\"text\": \"${msg}\"}" $url
}

function check_command_result() {
  if [ "$1" -ne 0 ]; then
    echo "$2"
    exit "$1"
  fi
}

function delete_folder_if_exists() {
  set +e
  hdfs dfs -test -d "$1"
  if [ $? -eq 0 ]; then
    hdfs dfs -rm -r -skipTrash "$1"
  fi
  set -e
}