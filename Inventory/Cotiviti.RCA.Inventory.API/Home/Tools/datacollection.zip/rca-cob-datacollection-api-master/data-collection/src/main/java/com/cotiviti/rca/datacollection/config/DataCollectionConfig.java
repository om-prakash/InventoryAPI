package com.cotiviti.rca.datacollection.config;

import org.springframework.context.annotation.Bean;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

public class DataCollectionConfig {

    /**
     * Configure Swagger
     * <p>
     * The exposed swagger UI can be accessed from /swagger-ui/index.html
     *
     * @return An instance of {@link Docket}
     */
    @Bean
    public Docket api() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.cotiviti.rca.datacollection.controller"))
                .paths(PathSelectors.any())
                .build();
    }

}
