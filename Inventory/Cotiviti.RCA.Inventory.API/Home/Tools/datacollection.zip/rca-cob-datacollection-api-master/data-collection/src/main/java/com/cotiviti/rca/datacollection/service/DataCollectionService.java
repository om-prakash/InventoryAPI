package com.cotiviti.rca.datacollection.service;

import com.cotiviti.rca.datacollection.dto.GetWorkRequest;
import com.cotiviti.rca.datacollection.dto.GetWorkResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.sql.*;

@Service
public class DataCollectionService {
    private final Logger logger = LoggerFactory.getLogger(DataCollectionService.class);

    @Value("${spring.datasource.url}")
    private String url;

    @Value("${spring.datasource.username}")
    private String username;

    @Value("${spring.datasource.password}")
    private String password;

    /**
     * Get Work for Data Collection
     *
     * @param request An instance of {@link GetWorkRequest}
     * @return An instance of {@link GetWorkResponse}
     * @throws Throwable Unhandled exception
     */
    public GetWorkResponse getWork(GetWorkRequest request) throws Throwable {
        GetWorkResponse response = new GetWorkResponse();

        String retVal = "";
        System.out.println(this.url);

        try (Connection connection = DriverManager.getConnection(this.url, this.username, this.password); ) {

            System.out.println("Connected...");

            //Parameterize query
            String sql = "SELECT TOP 1 * FROM dbo.DataCollection_IPC WHERE MemberId = 'ABC11111' AND ClientName = ? ;" ;
            PreparedStatement p = connection.prepareStatement(sql);
            p.setString(1, request.getClientId());
            ResultSet rs = p.executeQuery();

            //Iterate recordset
            int rowCount = 0;
            while(rs.next()){
                response.setMemberId(rs.getString("MemberId"));
                response.setCoordinationType(rs.getString("CoordinationType"));
                response.setAllowedAmount(rs.getBigDecimal("AllowedAmount"));
                response.setPrAmount(rs.getBigDecimal("PrAmount"));
                rowCount++;
            }

            //If no records found
            if (rowCount == 0){
                retVal = "No records found";
                System.out.println("No records found");
            }

        } catch (Throwable ex) {
            logger.error(ex.toString());
        }

        return response;
    }
}
