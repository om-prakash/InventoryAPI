package com.cotiviti.rca.datacollection.controller;

import com.cotiviti.rca.datacollection.dto.GetWorkRequest;
import com.cotiviti.rca.datacollection.dto.GetWorkResponse;
import com.cotiviti.rca.datacollection.service.DataCollectionService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.math.BigDecimal;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.hamcrest.core.Is.is;

@SuppressWarnings("unused")
@RunWith(SpringRunner.class)
@WebMvcTest(DataCollectionController.class)
public class DataCollectionControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private DataCollectionService dataCollectionService;

    @Test
    public void getWorkShouldPass() throws Throwable {
        GetWorkRequest request = new GetWorkRequest();
        request.setClientId("Aetna");
        request.setUserId("some.user");

        // Mock response
        GetWorkResponse response = new GetWorkResponse();
        response.setMemberId("ABC11111");
        response.setCoordinationType("Something");
        response.setPrAmount(BigDecimal.valueOf(1233.29));
        response.setAllowedAmount(BigDecimal.valueOf(100.99));

        when(dataCollectionService.getWork(request)).thenReturn(response);

        MvcResult result = this.mvc.perform(post("/api/v1/datacollection")
                .contentType("application/json")
                .content(asJsonString(request)))
                .andExpect(status().isOk())
                .andDo(print())
//                .andExpect(jsonPath("$.memberId").value("ABC11111"))
                .andExpect(jsonPath("memberId", is(response.getMemberId())))
                .andExpect(jsonPath("$.coordinationType").value("Something"))
                .andExpect(jsonPath("$.prAmount").value(1233.29))
                .andExpect(jsonPath("$.allowedAmount").value(100.99))
                .andReturn();

        String actualJson = result.getResponse().getContentAsString();
        System.out.println("RESULT: " + actualJson);
    }



    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
