package com.cotiviti.rca.datacollection.controller;

import com.cotiviti.rca.datacollection.dto.GetWorkRequest;
import com.cotiviti.rca.datacollection.dto.GetWorkResponse;
import com.cotiviti.rca.datacollection.service.DataCollectionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * A REST controller to get and save work for Data Collection
 */
@RestController
@RequestMapping(value = "/api/v1/datacollection")
public class DataCollectionController {

    private final Logger logger = LoggerFactory.getLogger(DataCollectionController.class);

    @Autowired
    private final DataCollectionService dataCollectionService;

    public DataCollectionController(DataCollectionService dataCollectionService) {
        this.dataCollectionService = dataCollectionService;
    }

//    @RequestMapping("/test")
    @GetMapping("/test")
    public String getTest() {
        return "Test";
    }

    @PostMapping(consumes="application/json", produces="application/json")
    public GetWorkResponse post(@RequestBody GetWorkRequest request){

        logger.info("Received data collection ipc request to get work.");
        GetWorkResponse response = new GetWorkResponse();

        try {
            response = dataCollectionService.getWork(request);
        } catch (Throwable throwable) {
            logger.error(throwable.toString());
        }
        return response;
    }
}
