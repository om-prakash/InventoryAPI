package com.cotiviti.rca.datacollection.dto;

import lombok.Data;

@Data
public class GetWorkRequest {
    private String userId;
    private String clientId;
}
