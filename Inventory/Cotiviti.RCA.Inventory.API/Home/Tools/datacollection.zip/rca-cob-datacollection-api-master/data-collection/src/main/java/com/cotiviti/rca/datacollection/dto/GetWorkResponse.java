package com.cotiviti.rca.datacollection.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Currency;

@Data
public class GetWorkResponse {
    private String memberId;
    private String coordinationType;
    private BigDecimal prAmount;
    private BigDecimal allowedAmount;
}
