package com.cotiviti.poc.hbaseapi.dto;

import java.io.Serializable;

public class Exclusion implements Serializable {

    private String claimId;
    private boolean nt;

    public String getClaimId() {
        return claimId;
    }

    public void setClaimId(String claimId) {
        this.claimId = claimId;
    }

    public boolean isNt() {
        return nt;
    }

    public void setNt(boolean nt) {
        this.nt = nt;
    }
}
