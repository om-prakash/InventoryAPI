package com.cotiviti.poc.hbaseapi.dao;

import org.apache.hadoop.hbase.client.Mutation;
import org.apache.hadoop.hbase.client.Scan;

import java.util.List;

@SuppressWarnings("unused")
public interface HbaseOperations {

    <T> T execute(String tableName, TableCallback<T> action) throws Throwable;

    <T> List<T> find(String tableName, String family, final RowMapper<T> mapper) throws Throwable;

    <T> List<T> find(String tableName, String family, String qualifier, final RowMapper<T> mapper) throws Throwable;

    <T> List<T> find(String tableName, final Scan scan, final RowMapper<T> mapper) throws Throwable;

    <T> T get(String tableName, String rowName, final RowMapper<T> mapper) throws Throwable;

    <T> T get(String tableName, String rowName, String familyName, final RowMapper<T> mapper) throws Throwable;

    <T> T get(String tableName, final String rowName, final String familyName, final String qualifier, final RowMapper<T> mapper) throws Throwable;

    void execute(String tableName, MutatorCallback action) throws Throwable;

    void saveOrUpdate(String tableName, Mutation mutation) throws Throwable;

    void saveOrUpdates(String tableName, List<Mutation> mutations) throws Throwable;

}
