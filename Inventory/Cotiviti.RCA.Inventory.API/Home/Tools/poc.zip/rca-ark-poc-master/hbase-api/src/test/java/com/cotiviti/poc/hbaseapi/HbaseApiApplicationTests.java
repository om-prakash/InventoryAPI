package com.cotiviti.poc.hbaseapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HbaseApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
