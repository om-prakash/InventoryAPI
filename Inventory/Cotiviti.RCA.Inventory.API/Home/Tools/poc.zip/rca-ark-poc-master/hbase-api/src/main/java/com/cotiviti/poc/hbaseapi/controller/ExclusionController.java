package com.cotiviti.poc.hbaseapi.controller;

import com.cotiviti.poc.hbaseapi.dao.HbaseTemplate;
import com.cotiviti.poc.hbaseapi.dto.Exclusion;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * A sample controller to read / write HBase
 */
@SuppressWarnings("unused")
@RestController
@RequestMapping(value = "/exclusion")
public class ExclusionController {

    private final HbaseTemplate template;

    @Autowired
    public ExclusionController(HbaseTemplate template) {
        this.template = template;
    }

    /**
     * Get data from HBase table
     *
     * @return A list of {@link Exclusion}
     * @throws Throwable Unhandled exception
     */
    @GetMapping
    public List<Exclusion> get() throws Throwable {
        return template.find("anthem:exclusion", "data", "ntd", (result, rowNum) -> {
            Exclusion exclusion = new Exclusion();
            exclusion.setClaimId(Bytes.toString(result.getRow()));
            exclusion.setNt(Bytes.toBoolean(result.getValue(Bytes.toBytes("data"), Bytes.toBytes("ntd"))));
            return exclusion;
        });
    }

    @GetMapping(value = "{rowKey}")
    public Exclusion getByRowKey(@PathVariable String rowKey) throws Throwable {
        return template.get("anthem:exclusion", rowKey, "data", "ntd", ((result, rowNum) -> {
            Exclusion exclusion = new Exclusion();
            exclusion.setClaimId(rowKey);
            exclusion.setNt(Bytes.toBoolean(result.getValue(Bytes.toBytes("data"), Bytes.toBytes("ntd"))));
            return exclusion;
        }));
    }

    /**
     * Save data to HBase spring-test-write table
     *
     * @param exclusion An instance of {@link Exclusion}, de-serialized from request body
     * @throws Throwable Unhandled exception
     */
    @PostMapping
    public void create(@RequestBody() Exclusion exclusion) throws Throwable {
        Put put = new Put(Bytes.toBytes(exclusion.getClaimId()));
        put.addColumn(Bytes.toBytes("data"), Bytes.toBytes("ntd"), Bytes.toBytes(exclusion.isNt()));
        template.saveOrUpdate("anthem:exclusion", put);
    }
}
