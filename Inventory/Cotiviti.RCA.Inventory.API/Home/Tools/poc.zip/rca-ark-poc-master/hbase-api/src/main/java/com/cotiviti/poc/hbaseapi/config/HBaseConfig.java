package com.cotiviti.poc.hbaseapi.config;

import com.cotiviti.poc.hbaseapi.dao.HbaseTemplate;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.security.UserGroupInformation;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;


@SuppressWarnings("unused")
@Configuration
public class HBaseConfig {

    @Value(value = "${service.account.principal}")
    private String principal;

    @Value(value = "${service.account.keytab}")
    private String keytab;

    @Bean
    public HbaseTemplate hbaseTemplate() throws IOException {
        org.apache.hadoop.conf.Configuration configuration = HBaseConfiguration.create();
        // below two lines of code make kerberos authentication work as expected
        UserGroupInformation.setConfiguration(configuration);
        UserGroupInformation.loginUserFromKeytab(principal, keytab);
        return new HbaseTemplate(configuration);
    }

}
