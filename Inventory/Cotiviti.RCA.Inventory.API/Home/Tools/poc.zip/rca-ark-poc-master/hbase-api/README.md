# HBase with Spring Boot

This project demonstrates how to operate HBase inside a Spring Boot project. In ARK team, we're going
to create a few Spring Boot REST api which need to access HBase. This project works as a reference implementation.

## What Included

Use standard MVC design pattern, we expose below RESTful endpoints:

- an endpoint to get a list of exclusion from HBase
- an endpoint to get an exclusion from HBase via row key
- an endpoint to create a new exclusion in HBase

## Dependencies

```xml
<dependency>
    <groupId>org.apache.hbase</groupId>
    <artifactId>hbase-client</artifactId>
    <version>2.2.6</version>
</dependency>
```

## How to create Keytab

Please follow below steps to create keytab that required for HBase authentication:

* Step 1: on the edge node, use ktutil command to create keytab

  ```shell script
  # ktutil
  ktutil
    add_entry -password -p <first>.<last>@COTIVITI.COM -k 1 -e aes256-cts-hmac-sha1-96
    add_entry -password -p <first>.<last>@COTIVITI.COM -k 1 -e aes128-cts-hmac-sha1-96
    write_kt <path to keytab file>
    quit
  ```
  **Important**
  
  The principal is case-sensitive. Ensure the first name and last name match the user name in AD 
  exactly.
  
* Step 2: Download the generated keytab to your local machine

* Step 3: Configure the principal and keytab in application.properties

  ```properties
  service.account.principal=Spring.Zhou@COTIVITI.COM
  service.account.keytab=C:\\Research\\hbase-api\\kerberos\\spring.zhou.keytab
  ```
