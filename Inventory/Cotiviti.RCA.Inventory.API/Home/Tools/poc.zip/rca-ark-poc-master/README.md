# RCA ARK POC Repository

This repository is used to store all POC related projects that created by ARK team in RCA.

## HBase POC

Please refer to below folders:

- hbase-poc
- hbase-api

In above two folders, we include codes to demonstrate:

- Access HBase via HBaseContext in Spark
- Access HBase via DataSource V1 spec in Spark
- Access HBase via HBase Client API in any JVM based applications
- Access HBase via HBase Client API in Spring Boot REST application 

![HBase POC](images/hbase-poc.PNG)

## Kie Client

This project demonstrates how to use Kie Cient API to invoke remote Kie Server API to make a decision on the fly.

## Spark Cobol Reader

This project demonstrates how to use spark-cobol package to read mainframe data files in EBCDIC format.

## Spark Excel Reader

This project demonstrates how to use spark-excel package to read Excel files in Spark.