# Spark Excel POC

This POC project is to demonstrate how to read an Excel file from Spark. We use the NoTouch data
from Centene as test data.

## Highlights

The Spark community provides a package called [spark-excel](https://github.com/crealytics/spark-excel) and this package dedicated to read and write Excel files.

In pom.xml, add below dependency:

```xml
<dependency>
    <groupId>com.crealytics</groupId>
    <artifactId>spark-excel_2.11</artifactId>
    <version>0.13.7</version>
</dependency>
```

While submitting a Spark job or using Spark shell, we can add below package parameter to spark-submit command to use this package
in our Spark application:

```shell script
--packages com.crealytics:spark-excel_2.11:0.13.7
```


### New Spark Reader Format

The package provides an implementation of Spark DataSource API, so we can use it like below:

```java
spark.read().format("com.crealytics.spark.excel")
``` 

## Result

After reading Excel data into Spark DataFrame, we can use it as any other Spark DataFrames like filtering, 
transformation, etc. 

In our POC, We run below codes:

```java
public static void main(String[] args) {
    try (SparkSession spark = SparkSession.builder()
            .master("local[*]")
            .getOrCreate()) {
        StructType st = new StructType(new StructField[] {
           new StructField("claim_number", DataTypes.StringType, false, Metadata.empty()),
           new StructField("service_line", DataTypes.StringType, false, Metadata.empty()),
           new StructField("adjust_amount", DataTypes.DoubleType, false, Metadata.empty())
        });
        // spark-excel package provides an implementation of Spark DataSource API,
        // so we can use "com.crealytics.spark.excel" as format in below code
        // under the cover, this package uses apache POI to parse excel files
        // for more options, please refer to https://github.com/crealytics/spark-excel
        Dataset<Row> df = spark.read()
                .format("com.crealytics.spark.excel")
                .option("header", "true")
                // below option limits the usage of memory for a huge Excel file
                .option("maxRowsInMemory", 1000)
                .schema(st)
                .load("C:\\Data\\Centene\\Exclusion\\NoTouch\\Approved-claims-list-6-15-20.xlsx");
        df.printSchema();
        df.show(10, false);
    }
}
```

And then we got below Spark Dataframe:

![result](images/result.PNG)

