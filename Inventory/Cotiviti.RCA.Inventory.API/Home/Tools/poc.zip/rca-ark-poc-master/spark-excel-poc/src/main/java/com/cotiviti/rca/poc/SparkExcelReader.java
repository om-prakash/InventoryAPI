package com.cotiviti.rca.poc;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

/**
 * A class to demonstrate how to read excel files from Spark
 *
 * A few clients send us excel files. For instance: Centene NoTouch files
 */
public class SparkExcelReader {
    public static void main(String[] args) {
        try (SparkSession spark = SparkSession.builder()
                .master("local[*]")
                .getOrCreate()) {
            StructType st = new StructType(new StructField[] {
               new StructField("claim_number", DataTypes.StringType, false, Metadata.empty()),
               new StructField("service_line", DataTypes.StringType, false, Metadata.empty()),
               new StructField("adjust_amount", DataTypes.DoubleType, false, Metadata.empty())
            });
            // spark-excel package provides an implementation of Spark DataSource API,
            // so we can use "com.crealytics.spark.excel" as format in below code
            // under the cover, this package uses apache POI to parse excel files
            // for more options, please refer to https://github.com/crealytics/spark-excel
            Dataset<Row> df = spark.read()
                    .format("com.crealytics.spark.excel")
                    .option("header", "true")
                    .option("maxRowsInMemory", 1000)
                    .schema(st)
                    .load("C:\\Data\\Centene\\Exclusion\\NoTouch\\Approved-claims-list-6-15-20.xlsx");
            df.printSchema();
            df.show(10, false);
        }
    }
}
