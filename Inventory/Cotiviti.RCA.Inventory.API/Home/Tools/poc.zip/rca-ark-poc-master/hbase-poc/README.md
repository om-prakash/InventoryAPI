# HBase POC

This project includes Java classes that demonstrate multiple approaches to access HBase in ARK 
environment. It includes:

- Access HBase in Spark via HBaseContext
- Access HBase in Spark via DataSource V1 interface (PySpark uses this approach as well)
- Access HBase via HBase Client API
- Access HBase in Spring Boot Rest API (hbase-api project)

## Dependencies

The HBaseContext and DataSource V1 interface defined in the HBase-Spark connector. In the pom.xml of 
this project, we include the definition of this dependency:

```xml
<dependency>
    <groupId>org.apache.hbase</groupId>
    <artifactId>hbase-spark</artifactId>
    <version>2.1.0-cdh6.3.2</version>
    <scope>provided</scope>
</dependency>
```

## List of Classes

- **BulkGetDemo.java**

  This class uses the bulkGet method of HBaseContext to retrieve data from HBase and generate Spark RDD or DataFrame
  
  ![Bulk Get](images/bulk-get.PNG)
  
- **BulkPutDemo.java**

  This class uses the bulkPut method of HBaseContext to write a Spark DataFrame to HBase
  
  ![Bulk Put](images/bulk-put.PNG)
  
- **DataSourceReadDemo.java**

  This class uses the DataSource V1 interface to read HBase data as Spark DataFrame
  
  ![Data Source Read](images/data-source-read.PNG)
  
- **DataSourceWriteDemo.java**

  This class uses the DataSource V1 interface to write Spark DataFrame to HBase
  
  ![Data Source Write](images/data-source-write.PNG)
  
- **BasicOperatorDemo.java**

  This class uses the HBase Client API to get, put, scan and delete data in HBase
  
  ![HBase Client API](images/hbase-client-api.PNG)

## Tips

- We need to ensure the **hbase-site.xml** in the class path, HBaseContext needs this file to initialize.

- While using the DataSource interface, we need a catalog file to map the schema of DataFrame with the column qualify of HBase table

  ```json
  {
    "table": {
      "namespace": "default",
      "name": "spring-test",
      "tableCoder":"PrimitiveType"
    },
    "rowkey": "key",
    "columns": {
      "client_claim_id": {
        "cf": "rowkey",
        "col": "key",
        "type": "string"
      },
      "nt": {
        "cf": "cf1",
        "col": "nt",
        "type": "boolean"
      }
    }
  }
  ```