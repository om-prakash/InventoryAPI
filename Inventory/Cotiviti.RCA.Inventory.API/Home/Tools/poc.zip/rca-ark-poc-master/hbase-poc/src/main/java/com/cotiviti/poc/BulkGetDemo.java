package com.cotiviti.poc;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.spark.JavaHBaseContext;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

/**
 * A class to demo how to use the bulkGet method of HBaseContext
 */
public class BulkGetDemo {
    // name of hbase table
    private final static String TABLE_NAME = "spring-test";
    // name of column family of hbase table
    private final static String COL_FAMILY_NAME = "cf1";

    public static void main(String[] args) {
        try (SparkSession spark = SparkSession.builder().master("local[*]").getOrCreate()) {
            // read anthem model data
            // the data in this DataFrame works as row key in HBase
            Dataset<Row> df = spark.read().format("parquet")
                    .load("C:\\Data\\Anthem\\Model").select("client_claim_id").coalesce(1);
            // because HBaseContext is based on RDD, so we need to convert Spark DataFrame to RDD
            JavaRDD<Row> rdd = df.toJavaRDD();

            // create Hadoop Configuration and add HBase related configuration
            // ensure the hbase-site.xml file in the class path
            Configuration conf = HBaseConfiguration.create();

            // construct JavaHBaseContext
            JavaSparkContext sc = JavaSparkContext.fromSparkContext(spark.sparkContext());
            JavaHBaseContext ctx = new JavaHBaseContext(sc, conf);

            // bulk get
            // five parameters:
            //  1. name of hbase table
            //  2. batch size
            //  3. rdd with row keys
            //  4. function to convert row to HBase Get object
            //  5. function to convert HBase Result object to Spark Row object
            JavaRDD<Row> rddResult = ctx.bulkGet(TableName.valueOf(TABLE_NAME), 1000, rdd, row -> {
                Get get = new Get(Bytes.toBytes(row.getAs("client_claim_id").toString()));
                get.addColumn(Bytes.toBytes(COL_FAMILY_NAME), Bytes.toBytes("nt"));
                return get;
            }, res -> RowFactory.create(Bytes.toString(res.getRow()),
                    Bytes.toBoolean(res.getValue(Bytes.toBytes(COL_FAMILY_NAME), Bytes.toBytes("nt")))));

            // convert RDD to DataFrame
            StructType st = new StructType()
                    .add(new StructField("claim_id", DataTypes.StringType, true, Metadata.empty()))
                    .add(new StructField("nt_flag", DataTypes.BooleanType, false, Metadata.empty()));
            Dataset<Row> dfResult = spark.createDataFrame(rddResult, st);
            dfResult.printSchema();
            dfResult.show(10, false);
        }
    }
}
