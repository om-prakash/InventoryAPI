package com.cotiviti.poc;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.spark.JavaHBaseContext;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

/**
 * A class to demo how to use HBaseContext to bulk write to HBase
 */
public class BulkPutDemo {
    private final static String TABLE_NAME = "spring-test";
    private final static String COL_FAMILY_NAME = "cf1";

    public static void main(String[] args) {

        try (SparkSession spark = SparkSession.builder().master("local[*]").getOrCreate()) {
            // read anthem model data
            Dataset<Row> df = spark.read().format("parquet")
                    .load("C:\\Data\\Anthem\\Model").select("client_claim_id").coalesce(1);
            // because HBaseContext is based on RDD, so we need to convert Spark DataFrame to RDD
            JavaRDD<Row> rdd = df.toJavaRDD();

            // create Hadoop Configuration and add HBase related configuration
            // ensure the hbase-site.xml file in the class path
            Configuration conf = HBaseConfiguration.create();

            // construct JavaHBaseContext
            JavaSparkContext sc = JavaSparkContext.fromSparkContext(spark.sparkContext());
            JavaHBaseContext ctx = new JavaHBaseContext(sc, conf);

            // bulk put
            ctx.bulkPut(rdd, TableName.valueOf(TABLE_NAME), row -> {
                Put put = new Put(Bytes.toBytes(row.getAs("client_claim_id").toString()));
                put.addColumn(Bytes.toBytes(COL_FAMILY_NAME), Bytes.toBytes("nt"), Bytes.toBytes(false));
                return put;
            });
        }
    }
}
