package com.cotiviti.poc;

import com.cotiviti.poc.util.CatalogLoader;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

import java.io.IOException;

/**
 * A class to demo how to use Spark Data Source API to read data from HBase
 * The same approach can be used in PySpark as well
 */
public class DataSourceReadDemo {
    public static void main(String[] args) {
        boolean hasError = false;
        // get HBase table catalog JSON from class path, you can check
        // the catalog JSON in resources folder
        String catalog = null;
        try {
            catalog = CatalogLoader.getCatalog("catalog.json");
        } catch (IOException iex) {
            System.out.println(iex.getMessage());
            System.exit(-1);
        }

        try (SparkSession spark = SparkSession.builder()
                .appName("Spark HBase Reader")
                .master("local[*]")
                .getOrCreate()) {
            try {
                /*
                 the connector provides a new format based on Spark
                 Data Source API Version 1
                 Only three options need to be provided
                 1. table catalog JSON string
                 2. since we are using Data Source API, so do not use HBaseContext directly
                 3. resource (based on the source code, we should not need this option, but without it on my local, it throws an exception)
                */
                Dataset<Row> df = spark.read()
                        .format("org.apache.hadoop.hbase.spark")
                        .option("catalog", catalog)
                        .option("hbase.use.hbase.context", "false")
                        .option("hbase.config.resources", "hbase-site.xml")
                        .load();
                df.printSchema();
                df.show(10);
            } catch (Exception ex) {
                ex.printStackTrace();
                hasError = true;
            }
        }
        if (hasError) {
            System.exit(-1);
        }
    }
}
