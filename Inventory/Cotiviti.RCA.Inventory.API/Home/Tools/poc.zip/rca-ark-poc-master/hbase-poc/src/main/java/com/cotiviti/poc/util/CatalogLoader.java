package com.cotiviti.poc.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class CatalogLoader {

    /**
     * Read a catalog file (in json format) from class path and return its content string
     *
     * @param c file name of catalog
     * @return A string that represents the content of catalog.json
     * @throws IOException An exception that indicates an unhandled {@link IOException}
     */
    public static String getCatalog(String c) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (InputStream catalog =
                     CatalogLoader.class.getClassLoader().getResourceAsStream(c)) {
            if (catalog == null) {
                throw new IOException(String.format("Cannot open the catalog file: %s", c));
            }
            try (InputStreamReader reader = new InputStreamReader(catalog)) {
                try (BufferedReader br = new BufferedReader(reader)) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        sb.append(line);
                    }
                }
            }
        }
        return sb.toString();
    }
}
