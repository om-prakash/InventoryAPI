package com.cotiviti.poc;

import com.cotiviti.poc.util.CatalogLoader;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

/**
 * A class to demo how to use the DataSource API to write a DataFrame to HBase
 * The same approach can be used in PySpark as well
 */
public class DataSourceWriteDemo {
    public static void main(String[] args) {
        boolean hasError = false;
        // get HBase table catalog JSON from class path, you can check
        // the write-catalog.json in resources folder
        String catalog = null;
        try {
            catalog = CatalogLoader.getCatalog("write-catalog.json");
        } catch (IOException iex) {
            System.out.println(iex.getMessage());
            System.exit(-1);
        }

        try (SparkSession spark = SparkSession.builder()
                .appName("Spark HBase Writer")
                .master("local[*]")
                .getOrCreate()) {
            try {
                // prepare for the DataFrame
                StructType st = new StructType()
                        .add(new StructField("client_claim_id", DataTypes.StringType, false, Metadata.empty()))
                        .add(new StructField("nt", DataTypes.BooleanType, false, Metadata.empty()));
                List<Row> rows = Arrays.asList(
                        RowFactory.create("Z098765", false),
                        RowFactory.create("Z098766", true)
                );
                Dataset<Row> df = spark.createDataFrame(rows, st);

                // use the DataSource api to save to HBase
                /*
                 the connector provides a new format based on Spark
                 Data Source API Version 1
                 Only three options need to be provided
                 1. table catalog JSON string
                 2. since we are using Data Source API, so do not use HBaseContext directly
                 3. resource (based on the source code, we should not need this option, but without it on my local, it throws an exception)
                */
                df.write()
                        .format("org.apache.hadoop.hbase.spark")
                        .option("catalog", catalog)
                        .option("hbase.use.hbase.context", "false")
                        .option("hbase.config.resources", "hbase-site.xml")
                        .save();
              } catch (Exception ex) {
                ex.printStackTrace();
                hasError = true;
            }
        }
        if (hasError) {
            System.exit(-1);
        }
    }
}
