package com.cotiviti.poc;


import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.util.Bytes;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * A class to demo basic API of hbase client. It includes get, put, scan and delete
 */
public class BasicOperatorDemo {
    public static void main(String[] args) throws IOException {
        // create an instance of Hadoop configuration and add hbase-default.xml and
        // hbase-site.xml to the configuration object. Ensure the hbase-site.xml file is in classpath
        Configuration conf = HBaseConfiguration.create();
        // hbase 2.x api is different with hbase 1.x
        // the hbase connection is thread safe, so we can share the connection across threads
        try (Connection conn = ConnectionFactory.createConnection(conf)) {
            try (Table table = conn.getTable(TableName.valueOf("spring-test"))) {
                // get api
                Get get = new Get(Bytes.toBytes("Y4369873"));
                Result result = table.get(get);
                if (result != null) {
                    byte[] value = result.getValue(Bytes.toBytes("cf1"), Bytes.toBytes("nt"));
                    System.out.println(String.format("The result of get is: %s", Bytes.toBoolean(value)));
                }

                // put api
                List<String> keys = Arrays.asList("A09874", "B76532");
                List<Put> puts = new ArrayList<>();
                Put put;
                for (String key : keys) {
                    put = new Put(Bytes.toBytes(key));
                    put.addColumn(Bytes.toBytes("cf1"), Bytes.toBytes("nt"), Bytes.toBytes(false));
                    puts.add(put);
                }
                table.put(puts);

                // scan api
                Scan scan = new Scan();
                // add RowPrefix filter
                scan.setRowPrefixFilter(Bytes.toBytes("A"));
                ResultScanner scanner = table.getScanner(scan);
                scanner.forEach(res -> System.out.println(Bytes.toString(res.getRow())));
                scanner.close();

                // delete api
                Delete del;
                List<Delete> deletes = new ArrayList<>();
                for (String key : keys) {
                    del = new Delete(Bytes.toBytes(key));
                    deletes.add(del);
                }
                table.delete(deletes);
            }
        }
    }
}
