package com.cotiviti.rca.ark.poc.ec.config;

import org.kie.server.api.marshalling.MarshallingFormat;
import org.kie.server.client.KieServicesClient;
import org.kie.server.client.KieServicesConfiguration;
import org.kie.server.client.KieServicesFactory;
import org.kie.server.client.RuleServicesClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@SuppressWarnings("unused")
@Configuration
public class KieServiceClientConfig {

    private final KieServerProperties properties;

    @Autowired
    public KieServiceClientConfig(KieServerProperties properties) {
        this.properties = properties;
    }

    /**
     * register a bean with type as RuleServicesClient
     * @return an instance of {@link RuleServicesClient}
     */
    @Bean
    public RuleServicesClient ruleClient() {
        final KieServicesConfiguration config
                = KieServicesFactory.newRestConfiguration(properties.getUrl(), properties.getUser(),
                properties.getPassword(), properties.getTimeout());
        config.setMarshallingFormat(MarshallingFormat.JSON);
        // add extra classes
        // config.addExtraClasses(null);
        final KieServicesClient client = KieServicesFactory.newKieServicesClient(config);
        return client.getServicesClient(RuleServicesClient.class);
    }
}
