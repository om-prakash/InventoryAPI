package com.cotiviti.rca.ark.poc.ec.util;

import java.lang.reflect.Field;

/**
 * A utility class to get and set object value via Java reflection
 */
@SuppressWarnings("unused")
public class ReflectionUtil {

    /**
     * set the specified value to object's specified field
     * @param object an object that going to be revised
     * @param fieldName name of field
     * @param fieldValue value of field
     */
    public static void set(Object object, String fieldName, Object fieldValue) {
        Class<?> cls = object.getClass();
        while(cls != null) {
            try {
                Field field = cls.getDeclaredField(fieldName);
                field.setAccessible(true);
                field.set(object, fieldValue);
            } catch(NoSuchFieldException ne) {
                cls = cls.getSuperclass();
            }
            catch(Exception ex) {
                throw new IllegalStateException(ex);
            }
        }
    }

    /**
     * get the value of object's specified field
     * @param object an object
     * @param fieldName name of field
     * @param <V> generic type of field
     * @return value of field
     */
    @SuppressWarnings("unchecked")
    public static <V> V get(Object object, String fieldName) {
        Class<?> cls = object.getClass();
        while (cls != null) {
            try {
                Field field = cls.getDeclaredField(fieldName);
                field.setAccessible(true);
                return (V) field.get(object);
            } catch(NoSuchFieldException ne) {
                cls = cls.getSuperclass();
            } catch(Exception ex) {
                throw new IllegalStateException(ex);
            }
        }
        return null;
    }
}
