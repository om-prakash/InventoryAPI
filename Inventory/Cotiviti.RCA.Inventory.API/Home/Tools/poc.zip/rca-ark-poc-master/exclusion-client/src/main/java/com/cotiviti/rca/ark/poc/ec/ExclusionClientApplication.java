package com.cotiviti.rca.ark.poc.ec;

import com.cotiviti.rca.ark.poc.ec.util.ReflectionUtil;
import org.kie.api.KieServices;
import org.kie.api.command.Command;
import org.kie.api.command.KieCommands;
import org.kie.api.runtime.ExecutionResults;
import org.kie.server.api.model.KieServiceResponse;
import org.kie.server.api.model.ServiceResponse;
import org.kie.server.client.RuleServicesClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SpringBootApplication
public class ExclusionClientApplication implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(ExclusionClientApplication.class, args);
    }

    /**
     * inject from IOC, find how to register in {@link com.cotiviti.rca.ark.poc.ec.config.KieServiceClientConfig}
     */
    @Autowired
    private RuleServicesClient client;

    /**
     * this method demonstrates below functions:
     * 1. how to construct fact object dynamically via Java reflection
     * 2. how to construct required kie commands
     * 3. how to invoke remote kie server to apply rules against the fact object
     * 4. check the result of execution
     *
     * @param args command line arguments
     * @throws Exception unhandled exception
     */
    @Override
    public void run(String... args) throws Exception {
        // construct fact object
        String targetClass = "com.cotiviti.rca.anthem_exclusion_rules.Claim";
        Map<String, Object> data = getExclusionDataFromHBase();
        Object fact = buildFactObject(data, targetClass);

        // construct Kie commands
        KieCommands commands = KieServices.get().getCommands();
        // insert command to insert an object to rule engine working memory
        // the second parameter is the identifier (key) of returned object from rule engine
        Command<?> insert = commands.newInsert(fact, "claim");
        // fireAllRules command to apply all defined rules against the fact object
        Command<?> fire = commands.newFireAllRules();
        // batch command to group commands together
        // the second parameter is the stateless session that defined in BRMS, the value should be configurable
        Command<?> batch = commands.newBatchExecution(Arrays.asList(insert, fire), "exclusion-session");

        // send commands to remote kie server and get the response of execution
        // the first parameter is the id of kie container, it should be configurable
        ServiceResponse<ExecutionResults> executeResponse =
                client.executeCommandsWithResults("anthem-exclusion", batch);

        // check the result of execution
        if (executeResponse.getType() == KieServiceResponse.ResponseType.SUCCESS) {
            System.out.println("Succeed");
            ExecutionResults result = executeResponse.getResult();
            // get returned object
            fact = result.getValue("claim");
            // we assume the fact object has the excluded and reason properties
            Boolean excluded = ReflectionUtil.get(fact, "excluded");
            List<String> reasons = ReflectionUtil.get(fact, "reason");
            if (excluded != null && excluded && reasons != null) {
                for (String reason : reasons) {
                    System.out.println(reason);
                }
            }
        } else {
            System.out.println("Error executing rules. Message: ");
            System.out.println(executeResponse.getMsg());
        }
    }

    /**
     * build the fact object from a map that contains exclusion data and the class name of fact object
     *
     * @param map     a map that contains all required exclusion data
     * @param clsName a string represents the full qualified class name of fact object
     * @return fact object
     * @throws Exception unhandled exception
     */
    private Object buildFactObject(Map<String, Object> map, String clsName) throws Exception {
        Class<?> cls = Class.forName(clsName);
        Object o = cls.newInstance();
        for (Map.Entry<String, Object> kv : map.entrySet()) {
            ReflectionUtil.set(o, kv.getKey(), kv.getValue());
        }
        return o;
    }

    /**
     * simulate to get exclusion data points from HBase claim table
     *
     * @return a map that contains all required exclusion data points
     * @throws Exception unhandled exception
     */
    private Map<String, Object> getExclusionDataFromHBase() throws Exception {
        Map<String, Object> map = new HashMap<>();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        map.put("cnlyClmJoinKey", 123456789L);
        map.put("claimsPlusFlag", false);
        map.put("cnlyClmNum", "12345");
        map.put("expDate", format.parse("2020-10-10"));
        map.put("grpGWFInd", false);
        map.put("lagDate", format.parse("2020-09-12"));
        map.put("lobGWFInd", false);
        map.put("noTouchCOB", false);
        map.put("noTouchMCR", false);
        map.put("noTouchDM", true);
        return map;
    }
}
