package com.cotiviti.rca.ark.poc.ec.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * A configuration property class to bind to key value pairs that related to kie server in application.properties file
 */
@Configuration
@ConfigurationProperties(prefix = "kie.server")
@Data
public class KieServerProperties {
    private String url;
    private String user;
    private String password;
    private Integer timeout;
}
