# Kie Server Client

This project demonstrates how to invoke remote kie server from a Spring Boot application.

In this project, we demonstrate below functions:

- Construct fact object dynamically via Java reflection
- Construct kie commands
- Send kie commands to remote kie server to apply defined rules against the fact object
- Check the result of execution

## Tips

Because we construct fact object via reflection, so we do not need to define those client 
specific rule artifacts in the pom.xml as dependencies. we only need to ensure those artifacts
are in the classpath at runtime.

For Spring Boot based application, you can use below approach to specify a path to hold all external
client specific artifacts (jars).

[Spring Boot Additional ClassPath](https://stackoverflow.com/questions/40499548/how-to-configure-additional-classpath-in-springboot)

```shell script
# specify additional classpath for a Spring Boot application
java -cp app.jar -Dloader.path=./extension org.springframework.boot.loader.PropertiesLauncher
```