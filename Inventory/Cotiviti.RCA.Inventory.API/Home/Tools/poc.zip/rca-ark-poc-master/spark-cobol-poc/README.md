# Spark Cobol POC

This POC project is to demonstrate how to read a mainframe data file in EBCDIC format. We use the data
from Aetna RCE data as test data.

## Highlights

The Spark community provides a package called [spark-cobol](https://github.com/AbsaOSS/cobrix) and this package dedicated to read cobol data files.

In pom.xml, add below dependency:

```xml
<dependency>
    <groupId>za.co.absa.cobrix</groupId>
    <artifactId>spark-cobol_2.11</artifactId>
    <version>2.2.2</version>
</dependency>
```

While submitting a Spark job or using Spark shell, we can add below package parameter to spark-submit command to use this package
in our Spark application:

```shell script
--packages za.co.absa.cobrix:spark-cobol_2.11:2.2.2
```


### New Spark Reader Format

The package provides an implementation of Spark DataSource API, so we can use it like below:

```java
spark.read().format("cobol")
``` 

### Copybook

To read properly, this package requires an option called copybook or copybook_content. The copybook 
describes the layout of data file. You can find a reference of copybook [here](copybook/C1JTEC20.cpy).

Below code snippet shows how to specify a copybook:

```java
spark.read()
     .format("cobol")
     .option("copybook", "<path to copybook file>")
```

### Schema Retention Policy

In the copybook, we can have multiple level nested structures. To simplify the schema of Spark DataFrame, we 
can use the schema retention policy to collapse the nested levels.

Below code snippet shows how to specify a policy of schema retention:

```java
spark.read()
     .format("cobol")
     .option("copybook", "<path to copybook file>")
     .option("schema_retention_policy", "collapse_root")
```

## Result

After reading EBCDIC data into Spark DataFrame, we can use it as another other Spark DataFrames like filtering, 
transformation, etc. 

In our POC, the data in Spark DataFrame looks like below:

![result](images/result.PNG)

