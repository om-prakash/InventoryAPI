package com.cotiviti.rca.poc;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

/**
 * A class to demonstrate how to read mainframe files in EBCDIC format from Spark
 *
 * A few clients send us raw data in this format like Aetna
 */
public class CopybookReader {
    public static void main(String[] args) {
        try (SparkSession spark = SparkSession.builder()
                .master("local[*]")
                .getOrCreate()) {
            // spark-cobol package provides an implementation of Spark DataSource API,
            // so we can use "cobol" as format in below code
            // use a copybook to describe the layout of file, the copybook is key to parse the file properly
            Dataset<Row> df = spark.read()
                    .format("cobol")
                    .option("copybook", "C:\\Users\\spring.zhou\\Desktop\\C1JTEC20.cpy")
                    .option("schema_retention_policy", "collapse_root")
                    .load("Y:\\Split\\FS01-K\\Aetna\\RCE\\20210531\\VENDOR_DLY.RCECLMS.20210531222400.F116653238_C20.F116653238");
            df.printSchema();
            df.show(10, false);
        }
    }
}
