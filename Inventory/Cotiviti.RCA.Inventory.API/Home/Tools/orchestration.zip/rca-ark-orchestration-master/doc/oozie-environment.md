# Oozie Environment

## Oozie Server

https://usaphdpm04.cotiviti.com:11101/oozie

## Oozie CLI Client

Oozie CLI client installed on the edge node usaphdpe02.cotiviti.com. The version is **5.1.0-cdh6.3.4**

Use below command to validate if you can access the CLI command properly:

```shell script
# run below command on the edge node
oozie version 
```

You should get below output:

![CLI](images/oozie-cli-validation.PNG)

## Hue Oozie Web Console

We can use Hue web console to create and monitor Oozie jobs as well. 

Access below link:

https://usaphdpm03.cotiviti.com:8889/hue/jobbrowser#!workflows

![Hue Oozie](images/hue-oozie-job.PNG)

If you cannot access above page, then you need to contact system administrators to grant permissions.