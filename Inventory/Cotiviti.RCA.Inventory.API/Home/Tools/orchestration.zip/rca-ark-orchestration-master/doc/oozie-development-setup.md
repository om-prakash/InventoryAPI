# Oozie Development Setup

This document describes how to setup an Oozie development envrionment on your local. 

To simplify our setup, we assume you use Jetbrains IDEA community edition as IDE to develop Oozie jobs. 

## 1. Setup XSD schema

Oozie provides XSD schemas for workflow, action and coordinator to enable the validation. We utilize those schemas to validate if the workflow or coordinator that we created is valid or not. Also, those schemas can provide code completion in a modern IDE like Jetbrains IDEA. To setup the schema in Jetbrains IDEA, please follow below steps:

### Step 1: Download XSD schema files

Download the XSD schema of Oozie workflow, action, coordinator and bundle from [here](oozie-schema.zip). After download, unzip and save the downloaded files to local disk like below:

![schema](images/oozie-schema.PNG)

### Step 2: Configure XSD schema in Jetbrains IDEA

In the Settings dialog, select [Languages & Frameworks] / [ Schemas and DTDs], and then click the + button to add extra schemas:

![settings](images/idea-setting.PNG)

## 2. Create project

Because Oozie workflow uses xml as the definition language, so we don't need to create a Java based project in IDEA. So we only need to open a folder which will contain our Oozie workflows.

![open](images/open-folder.PNG)

## 3. Setup standard folder structure

Refer to [Standard Folder Structure](https://github.com/cotiviti/rca-ark-orchestration/tree/master/oozie/centene) to setup your new project:

![folder](images/folder-structure.PNG)