# Centene Control-M

## Background

**Control-M** is used by our data load team to load Centene raw data into the split folder. It's logical to use the same tool to load raw data from the split folder to HDFS. Because of this reason, we configure a few Control-M jobs to complete below functions:

- Watch the trigger files which indicate the raw data are ready in the split folder
- After a trigger file been detected, invoke a shell script on the edge node and pass the file name of dedected trigger file as argument. The shell script is responsible to upload raw data into HDFS and in turn submit the Cenene's Oozie job to start the data ingestion workflow of Centene on RCA new platform.

## Control-M Environment

We use Control-M DEV environment to configure our jobs. In the DEV environment, we have below Control-M components:

- **Control-M Client (usadcssctmcld01)**

  Development GUI tool. Use this tool to create workspaces, folders, jobs and etc. Also, use the tool to order and monitor. 

- **Control-M Enterprise Manager (usadctmapp01)**

  This is centralized services of Control-M and it provides GUI services to Control-M clients. 
  
- **Control-M Server (usadctmapp01)**

  This is the control machine of Control-M.

- **Control-M Host / Agent (usadctmagt02)**

  Those agent machines controlled by the Control-M server and the Control-M agent and utilizies installed on those machines. Most of jobs in Control-M will be scheduled to run on those machines.

- **Control-M Remote Host / Agentless (usaphdpe02)**
  
  Control-M remote host is a computer which does not have Control-M agent installed but Control-M can schedule and monitor jobs on it. This agentless approach can reduce the overhead of maintenance but it has some limitations as well. For instance, we cannot schedule a file watcher job on remote hosts because the file watcher job needs the agent file watcher utility installed. (Use the file transfer job with watch only mode to overcome this limitation) In our case, our edge node is a remote host of Control-M.

Below diagram shows how those components connected together to provide a reliable workflow automation envrionment.

![Control-M Architecture](../../doc/images/control-m-architecture.PNG)

## Job Setup

Currently we use two jobs in Control-M. One job is to detect the trigger file which indicates a new raw dataset is ready in split folder. The second job is to execute a [shell script](claim-prov-raw-ready.sh) on the edge node (usaphdpe02) of Hadoop cluster.

## Job Run

![Control-M Job Run](../../doc/images/control-m-result.PNG)

