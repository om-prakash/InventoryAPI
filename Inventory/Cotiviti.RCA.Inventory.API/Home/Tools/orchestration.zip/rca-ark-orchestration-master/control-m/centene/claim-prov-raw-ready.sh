#!/usr/bin/env bash

# This script will be invoked by a Control-M job when Centene's claim and provider
# raw data are ready in the split folder. This script contains below functions:
# 1. Upload ready raw data into HDFS
# 2. Submit and run Oozie job to start Centene's data ingestion pipeline

# Control-M will provide the name of matched completion file via the environment variable "CF"
# The value looks like Centene_Claim_ingestion_trigger_2018_04_07.txt (Need to work with data load team to decide the final format)
FC=${CF}

# Check if required environment variable supplied
if [ -z "$FC" ]; then
  echo "The required environment variable not supplied."
  exit 1
fi

# Try to get the load date from the name of trigger file
# Result should be a date string in yyyy-MM-dd format
FIND="Centene_Claim_ingestion_trigger_"
REPLACE=""
LDT=${FC//$FIND/$REPLACE}
LDT=${LDT//.txt/$REPLACE}
LDT=${LDT//_/-}
LY=$(date -d "${LDT}" +%Y)
LM=$(date -d "${LDT}" +%-m)
LD=$(date -d "${LDT}" +%-d)
# Source of raw claim and provider data
SOURCE=/windows-wellpoint-split/Centene/${LDT}
# Destination of raw claim data
CTARGET=/rca/dev/centene/raw/claim/${LDT}
# Destination of raw provider data
PTARGET=/rca/dev/centene/raw/provider/${LDT}

# Set destination folder for claim raw data
hdfs dfs -test -d ${CTARGET}
if [ $? -eq 0 ]; then
  # if claim raw target folder exists, then delete it first
  hdfs dfs -rm -r -skipTrash ${CTARGET}
  echo "${CTARGET} deleted."
fi
hdfs dfs -mkdir ${CTARGET}
if [ $? -eq 0 ]; then
  echo "${CTARGET} created."
else
  echo "${CTARGET} cannot be created."
  exit 1
fi

# Set destination folder for provider raw data
hdfs dfs -test -d ${PTARGET}
if [ $? -eq 0 ]; then
  # if provider raw target folder exists, then delete it first
  hdfs dfs -rm -r -skipTrash ${PTARGET}
  echo "${PTARGET} deleted."
fi
hdfs dfs -mkdir ${PTARGET}
if [ $? -eq 0 ]; then
  echo "${PTARGET} created."
else
  echo "${PTARGET} cannot be created."
  exit 1
fi

# Upload claim and provider raw data into HDFS
hdfs dfs -put ${SOURCE}/CNC_VENDOR_PROVIDER_*.txt ${PTARGET}
if [ $? -eq 0 ]; then
  echo "provider raw data uploaded successfully."
else
  echo "an error occurred while uploading provider raw data."
  exit 1
fi
hdfs dfs -put ${SOURCE}/Claims/Fixed_CNC_VENDOR_CLAIM_*.txt ${CTARGET}
if [ $? -eq 0 ]; then
  echo "claim raw data uploaded successfully."
else
  echo "an error occurred while uploading claim raw data."
  exit 1
fi

# Set ACL
hdfs dfs -chmod -R 770 ${CTARGET}
hdfs dfs -chmod -R 770 ${PTARGET}
echo "hdfs permissions applied successfully."

# Run Oozie job
oozie job -oozie https://usaphdpm04.cotiviti.com:11101/oozie \
-config /home/svcdrca/control-m/centene/job.properties \
-D load_date=${LDT} \
-D load_year=${LY} \
-D load_month=${LM} \
-D load_day=${LD} -run

echo "Oozie job submitted, you can use the returned job id to track its status."

# Move trigger file
# To use the wildcard in the file transfer job, we have to keep only one trigger file in
# the target folder. Otherwise the file transfer job will only match the first file.
mv -f /windows-wellpoint-split/Centene/${FC} /windows-wellpoint-split/Centene/trigger

exit 0
