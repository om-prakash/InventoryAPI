# RCA ARK Orchestration

This repo contains all workflow or automation definitions that related to orchestration of RCA new platform. We have below main artifacts in this repo:

- Oozie workflow definition (in xml format)
- Control-M automation API defintion (in json format)
- Documents

