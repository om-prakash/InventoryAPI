SELECT
    CnlyProviderId,
    array_sort(
        array_distinct(
            collect_list(
                struct(
                    CAST(CASE WHEN AddressType = 'D' THEN 1 ELSE 0 END as INT) AS address_key
                    ,AddressType AS address_reported_type
                    ,StreetAddress As address_street_1
                    ,StreetAddressLine2 As address_street_2
                    ,City AS address_city
                    ,State As address_state_code
                    ,CASE
                        WHEN Zipcode <> ''  THEN Zipcode
                        ELSE '' END As address_zip_code
                    ,to_timestamp(AddressEffectiveDate, 'yyyyMMdd') AS address_effective_date
                    ,to_timestamp(AddressEndDate, 'yyyyMMdd') AS address_termination_date
                    ,to_timestamp('', 'yyyy-MM-dd') AS address_original_load_date
                    ,LoadFileName as address_original_load_source
                )
            )
	    )
	) AS address,
	    array_remove(
        array_sort(
            array_distinct(
                    collect_list(ProviderPhoneNumber)
            )
        )
    , '') AS provider_phone, --change to provider_phone
    array_remove(
        array_sort(
            array_distinct(
                    collect_list(FederalTaxId)
            )
        )
    , '') AS TAX_ID,
    array_remove(
        array_sort(
            array_distinct(
                    collect_list(Npi)
            )
        )
    , '') AS Npi,
    array_sort(
        array_distinct(
            collect_list(
                struct(
                    '' as id,
                    '' as client_lob,
                    '' as provider_network,
                    '' as effective_date,
                    '' as termination_date,
                    '' as in_network_indicator
                )
            )
	    )
	) AS contract
FROM
    provider_raw
GROUP BY
    CnlyProviderId