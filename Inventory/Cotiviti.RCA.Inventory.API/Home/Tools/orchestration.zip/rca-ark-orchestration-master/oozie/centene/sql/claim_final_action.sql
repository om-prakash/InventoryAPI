SELECT
    l.claim_num as CnlyClaimNum,
    coalesce(d.legacy_sys_ids['FirstClaimNum'], l.first_num) as BaseClaimNum,
    coalesce(d.claim_paid_date, c.PaidDt) as OrigPaidDt,
    l.claim_level + ifnull(d.claim_sequence_rank,0) as ClaimSeq,
    l.FinalAction
FROM (
    SELECT claim_num,
           first_num,
           claim_level,
           (claim_level == (max(claim_level) over (PARTITION BY first_num))) as FinalAction
    FROM claim_link) l
LEFT JOIN claim_aggregate c on c.CnlyClaimNum = l.first_num
LEFT JOIN claim_model_dedup d on l.first_num = d.CnlyClaimNum
