SELECT
         ProviderNumber
		,InstitutionalProviderName
		,ProviderLastName
		,ProviderFirstName
		,ProviderType
		,AddressType
		,StreetAddress
        ,StreetAddressLine2
		,City
		,State
		,Zipcode
		,to_timestamp(AddressEffectiveDateCcyymmdd, 'yyyyMMdd') as AddressEffectiveDate
		,to_timestamp(AddressEndDateCcyymmdd, 'yyyyMMdd') as AddressEndDate
		,ProviderTitle
		,FederalTaxId
		,MedicareProviderNumber
		,CenteneProvNbr
		,CenteneAffNbr
		,ProviderLicenseNumber
		,to_timestamp(LicenseEffectiveDateCcyymmdd, 'yyyyMMdd') as LicenseEffectiveDate
		,to_timestamp(LicenseExpiredDateCcyymmdd, 'yyyyMMdd') as LicenseExpiredDate
		,CountyCode
		,ProviderPhoneNumber
		,GroupTaxId
		,ProviderSpecialty1
		,ProviderSpecialty2
		,to_timestamp(ProviderSpecialtyStartDateCcyymmdd, 'yyyyMMdd') as ProviderSpecialtyStartDate
		,to_timestamp(ProviderSpecialtyEndDateCcyymmdd, 'yyyyMMdd') as ProviderSpecialtyEndDate
		,ProviderDeaNumber
		,ParNonparIndicator
		,Npi
		,BusUnit
		,ProviderAltPhoneNbr
		,GroupAddress1
		,GroupAddress2
		,GroupCity
		,GroupState
		,GroupZip
		,to_timestamp(GroupAddressEffectiveDate, 'yyyyMMdd') as GroupAddressEffectiveDate
		,to_timestamp(GroupAddressEndDate, 'yyyyMMdd') as GroupAddressEndDate
		,GroupPhoneNbr
		,GroupAltPhoneNbr
		,PcpInd
		,PayClass
		,CONCAT(ifnull(CenteneProvNbr,''), ifnull(CenteneAffNbr,'')) as CnlyProviderId
		,PROV_BUS_PRACTICE_ADDR1 As ProvBusPracticeAddr1
		,PROV_BUS_PRACTICE_ADDR2 As ProvBusPracticeAddr2
		,PROV_BUS_PRACTICE_CITY As ProvBusPracticeCity
		,PROV_BUS_PRACTICE_STATE As ProvBusPracticeState
		,PROV_BUS_PRACTICE_ZIP As ProvBusPracticeZip
		,PROV_BUS_PRACTICE_CTRY As ProvBusPracticeCtry
		,SubProgramCode
		,HatCode
		,year(to_timestamp(regexp_extract(ARK_IFN, '_([0-9.]+).txt$'), 'yyyyMMdd')) as loadyear
        ,month(to_timestamp(regexp_extract(ARK_IFN, '_([0-9.]+).txt$'), 'yyyyMMdd')) as loadmonth
        ,day(to_timestamp(regexp_extract(ARK_IFN, '_([0-9.]+).txt$'), 'yyyyMMdd')) as loadday
        ,regexp_extract(ARK_IFN, '/([A-Za-z0-9_.]+)$', 1) AS LoadFileName
        ,to_timestamp(regexp_extract(ARK_IFN, '_([0-9.]+).txt$'), 'yyyyMMdd') AS LoadDate
FROM
    provider_raw