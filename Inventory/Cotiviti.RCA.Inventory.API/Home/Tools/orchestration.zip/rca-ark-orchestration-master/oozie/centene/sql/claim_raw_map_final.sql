SELECT
       BusUnit
      ,BusLine
      ,PlanCode
      ,IndividualIdNumber
      ,MedicaidIdNumber
      ,ServicingProvNumber
      ,ServicingProvNpi
      ,CenteneProvNbr
      ,CenteneAffNbr
      ,PlaceOfService
      ,BillType
      ,DrgCode
      ,ClaimFormInd
      ,PatLastName
      ,PatFirstName
      ,PatMidInit
      ,PatSex
      ,to_timestamp(PatDob,'yyyyMMdd') as PatDob
      ,TransactionType
      ,TransactionStatus
      ,to_timestamp(DateOfRemit,'yyyyMMdd') as DateOfRemit
      ,AdjustmentIndicator
      ,AdjReason
      ,Tcn
      ,FormerTcn
      ,PrimaryDiag
      ,SecondaryDiag
      ,Dx3
      ,Dx4
      ,Dx5
      ,ClaimUnitVistsDays
      ,to_timestamp(ClaimFromDos,'yyyyMMdd') as ClaimFromDos
      ,to_timestamp(ClaimThruDos,'yyyyMMdd') as ClaimThruDos
      ,to_timestamp(AdmitDate,'yyyyMMdd') as AdmitDate
      ,to_timestamp(DischargeDate,'yyyyMMdd') as DischargeDate
      ,NatureHspAdmission
      ,ProviderClaimNumber
      ,ProviderType
      ,ProviderSpecialty
      ,ReferringProviderNumber
      ,ReferringProviderNpi
      ,CenteneReferringProvNbr
      ,CenteneReferringAffNbr
      ,CAST(BilledAmountHeader as DECIMAL(18,2)) as BilledAmountHeader
      ,CAST(BilledAmountNetHeader as DECIMAL(18,2)) as BilledAmountNetHeader
      ,CAST(PaidAmountHeader as DECIMAL(18,2)) as PaidAmountHeader
      ,CAST(DrgAllowedAmountHeader as DECIMAL(18,2)) as DrgAllowedAmountHeader
      ,AdmittingDiagnosis
      ,PrincipalProcedureCode
      ,PrincipalProcType
      ,PrincipalProcedureCode2
      ,PrincipalProcType2
      ,SrcLineItemDtlCnt
      ,LineItemDtlNbr
      ,LineItemDtlNbrSeqNbr
      ,Resolution
      ,to_timestamp(LineItemFromDos,'yyyyMMdd') as LineItemFromDos
      ,to_timestamp(LineItemThruDos,'yyyyMMdd') as LineItemThruDos
      ,RevenueCode
      ,Cpt4ProcedureCode
      ,Cpt4ProcModifierOne
      ,Cpt4ProcModifierTwo
      ,LineItemUnits
      ,CAST(BilledAmountDetail as DECIMAL(18,2)) as BilledAmountDetail
      ,CAST(BilledAmountNetDetail as DECIMAL(18,2)) as BilledAmountNetDetail
      ,CAST(PaidAmountDetail as DECIMAL(18,2)) as PaidAmountDetail
      ,CAST(OtherInsPaidDetail as DECIMAL(18,2)) as OtherInsPaidDetail
      ,ClaimStatus
      ,ClaimType
      ,ClaimProc1
      ,ClaimProc2
      ,ClaimProc3
      ,ClaimProc4
      ,ClaimProc5
      ,FormType
      ,FacilityType
      ,BillClass
      ,Occurance
      ,SourceAdmission
      ,AdmitCode
      ,DischargeCode
      ,ProviderIrsNumber
      ,CAST(TppAmt as DECIMAL(18,2)) as TppAmt
      ,CAST(TppAllowAmt as DECIMAL(18,2)) as TppAllowAmt
      ,TpStat
      ,CAST(AllowBenefitAmt as DECIMAL(18,2)) as AllowBenefitAmt
      ,CentenePlanCode
      ,CenteneDivisionCode
      ,PlanStateCode
      ,PaytoCode
      ,to_timestamp(ReceivedDate, 'yyyyMMdd') as ReceivedDate
      ,PoaInd1
      ,PoaInd2
      ,PoaInd3
      ,PoaInd4
      ,PoaInd5
      ,OccuranceCode1
      ,to_timestamp(OccuranceDate1, 'yyyyMMdd') as OccuranceDate1
      ,ValueCode1
      ,CAST(ValueAmt1 as DECIMAL(18,2)) as ValueAmt1
      ,OccuranceCode2
      ,to_timestamp(OccuranceDate2, 'yyyyMMdd') as OccuranceDate2
      ,ValueCode2
      ,CAST(ValueAmt2 as DECIMAL(18,2)) as ValueAmt2
      ,OccuranceCode3
      ,to_timestamp(OccuranceDate3, 'yyyyMMdd') as OccuranceDate3
      ,ValueCode3
      ,CAST(ValueAmt3 as DECIMAL(18,2)) as ValueAmt3
      ,OccuranceCode4
      ,to_timestamp(OccuranceDate4, 'yyyyMMdd') as OccuranceDate4
      ,ValueCode4
      ,CAST(ValueAmt4 as DECIMAL(18,2)) as ValueAmt4
      ,OccuranceCode5
      ,to_timestamp(OccuranceDate5, 'yyyyMMdd') as OccuranceDate5
      ,ValueCode5
      ,CAST(ValueAmt5 as DECIMAL(18,2)) as ValueAmt5
      ,OccuranceCode6
      ,to_timestamp(OccuranceDate6, 'yyyyMMdd') as OccuranceDate6
      ,ValueCode6
      ,CAST(ValueAmt6 as DECIMAL(18,2)) as ValueAmt6
      ,OccuranceCode7
      ,to_timestamp(OccuranceDate7, 'yyyyMMdd') as OccuranceDate7
      ,ValueCode7
      ,CAST(ValueAmt7 as DECIMAL(18,2)) as ValueAmt7
      ,OccuranceCode8
      ,to_timestamp(OccuranceDate8, 'yyyyMMdd') as OccuranceDate8
      ,ValueCode8
      ,CAST(ValueAmt8 as DECIMAL(18,2)) as ValueAmt8
      ,Cpt4ProcModifier3
      ,Cpt4ProcModifier4
      ,IcdVersionIndicator
      ,ConditionCode1
      ,ConditionCode2
      ,ConditionCode3
      ,ConditionCode4
      ,ConditionCode5
      ,ConditionCode6
      ,ConditionCode7
      ,ConditionCode8
      ,ConditionCode9
      ,ConditionCode10
      ,ConditionCode11
      ,ConditionCode12
      ,ConditionCode13
      ,ConditionCode14
      ,ConditionCode15
      ,ConditionCode16
      ,ConditionCode17
      ,ConditionCode18
      ,ConditionCode19
      ,ConditionCode20
      ,ConditionCode21
      ,ConditionCode22
      ,ConditionCode23
      ,ConditionCode24
      ,Dx6
      ,Dx7
      ,Dx8
      ,Dx9
      ,Dx10
      ,Dx11
      ,Dx12
      ,Dx13
      ,Dx14
      ,Dx15
      ,Dx16
      ,Dx17
      ,Dx18
      ,Dx19
      ,Dx20
      ,Dx21
      ,Dx22
      ,Dx23
      ,Dx24
      ,Dx25
      ,OtherProcedure6
      ,OtherProcedure7
      ,OtherProcedure8
      ,OtherProcedure9
      ,OtherProcedure10
      ,OtherProcedure11
      ,OtherProcedure12
      ,OtherProcedure13
      ,OtherProcedure14
      ,OtherProcedure15
      ,OtherProcedure16
      ,OtherProcedure17
      ,OtherProcedure18
      ,OtherProcedure19
      ,OtherProcedure20
      ,OtherProcedure21
      ,OtherProcedure22
      ,OtherProcedure23
      ,OtherProcedure24
      ,OtherProcedure25
      ,ValueCode9
      ,CAST(ValueAmt9 as DECIMAL(18,2)) as ValueAmt9
      ,ValueCode10
      ,CAST(ValueAmt10 as DECIMAL(18,2)) as ValueAmt10
      ,ValueCode11
      ,CAST(ValueAmt11 as DECIMAL(18,2)) as ValueAmt11
      ,ValueCode12
      ,CAST(ValueAmt12 as DECIMAL(18,2)) as ValueAmt12
      ,ValueCode13
      ,CAST(ValueAmt13 as DECIMAL(18,2)) as ValueAmt13
      ,ValueCode14
      ,CAST(ValueAmt14 as DECIMAL(18,2)) as ValueAmt14
      ,ValueCode15
      ,CAST(ValueAmt15 as DECIMAL(18,2)) as ValueAmt15
      ,ValueCode16
      ,CAST(ValueAmt16 as DECIMAL(18,2)) as ValueAmt16
      ,ValueCode17
      ,CAST(ValueAmt17 as DECIMAL(18,2)) as ValueAmt17
      ,ValueCode18
      ,CAST(ValueAmt18 as DECIMAL(18,2)) as ValueAmt18
      ,ValueCode19
      ,CAST(ValueAmt19 as DECIMAL(18,2)) as ValueAmt19
      ,ValueCode20
      ,CAST(ValueAmt20 as DECIMAL(18,2)) as ValueAmt20
      ,ValueCode21
      ,CAST(ValueAmt21 as DECIMAL(18,2)) as ValueAmt21
      ,ValueCode22
      ,CAST(ValueAmt22 as DECIMAL(18,2)) as ValueAmt22
      ,ValueCode23
      ,CAST(ValueAmt23 as DECIMAL(18,2)) as ValueAmt23
      ,ValueCode24
      ,CAST(ValueAmt24 as DECIMAL(18,2)) as ValueAmt24
      ,PoaInd6
      ,PoaInd7
      ,PoaInd8
      ,PoaInd9
      ,PoaInd10
      ,PoaInd11
      ,PoaInd12
      ,PoaInd13
      ,PoaInd14
      ,PoaInd15
      ,PoaInd16
      ,PoaInd17
      ,PoaInd18
      ,PoaInd19
      ,PoaInd20
      ,PoaInd21
      ,PoaInd22
      ,PoaInd23
      ,PoaInd24
      ,RecoveryFlag
      ,AuthorizationNbr
      ,DualIndicator
      ,SubmittedDrgNbr
      ,TraumaIndicator
      ,ParNonParInd
      ,PoaInd25
      ,to_timestamp(ProcDate1, 'yyyyMMdd') as ProcDate1
      ,to_timestamp(ProcDate2, 'yyyyMMdd') as ProcDate2
      ,to_timestamp(ProcDate3, 'yyyyMMdd') as ProcDate3
      ,to_timestamp(ProcDate4, 'yyyyMMdd') as ProcDate4
      ,to_timestamp(ProcDate5, 'yyyyMMdd') as ProcDate5
      ,to_timestamp(ProcDate6, 'yyyyMMdd') as ProcDate6
      ,to_timestamp(ProcDate7, 'yyyyMMdd') as ProcDate7
      ,to_timestamp(ProcDate8, 'yyyyMMdd') as ProcDate8
      ,to_timestamp(ProcDate9, 'yyyyMMdd') as ProcDate9
      ,to_timestamp(ProcDate10, 'yyyyMMdd') as ProcDate10
      ,to_timestamp(ProcDate11, 'yyyyMMdd') as ProcDate11
      ,to_timestamp(ProcDate12, 'yyyyMMdd') as ProcDate12
      ,to_timestamp(ProcDate13, 'yyyyMMdd') as ProcDate13
      ,to_timestamp(ProcDate14, 'yyyyMMdd') as ProcDate14
      ,to_timestamp(ProcDate15, 'yyyyMMdd') as ProcDate15
      ,to_timestamp(ProcDate16, 'yyyyMMdd') as ProcDate16
      ,to_timestamp(ProcDate17, 'yyyyMMdd') as ProcDate17
      ,to_timestamp(ProcDate18, 'yyyyMMdd') as ProcDate18
      ,to_timestamp(ProcDate19, 'yyyyMMdd') as ProcDate19
      ,to_timestamp(ProcDate20, 'yyyyMMdd') as ProcDate20
      ,to_timestamp(ProcDate21, 'yyyyMMdd') as ProcDate21
      ,to_timestamp(ProcDate22, 'yyyyMMdd') as ProcDate22
      ,to_timestamp(ProcDate23, 'yyyyMMdd') as ProcDate23
      ,to_timestamp(ProcDate24, 'yyyyMMdd') as ProcDate24
      ,to_timestamp(ProcDate25, 'yyyyMMdd') as ProcDate25
      ,ExtCauseofInj1
      ,ExtCauseofInj2
      ,ExtCauseofInj3
      ,ExtCauseofInj4
      ,ExtCauseofInj5
      ,ExtCauseofInj6
      ,ExtCauseofInj7
      ,ExtCauseofInj8
      ,ExtCauseofInj9
      ,ExtCauseofInj10
      ,ExtCauseofInj11
      ,ExtCauseofInj12
      ,PoaExtCauseofInj1
      ,PoaExtCauseofInj2
      ,PoaExtCauseofInj3
      ,PoaExtCauseofInj4
      ,PoaExtCauseofInj5
      ,PoaExtCauseofInj6
      ,PoaExtCauseofInj7
      ,PoaExtCauseofInj8
      ,PoaExtCauseofInj9
      ,PoaExtCauseofInj10
      ,PoaExtCauseofInj11
      ,PoaExtCauseofInj12
      ,ClaimBillingDesc
      ,CAST(AltCarrierAmtCoins as DECIMAL(18,2)) as AltCarrierAmtCoins
      ,CAST(AltCarrierAmtCopay as DECIMAL(18,2)) as AltCarrierAmtCopay
      ,CAST(AltCarrierAmtDeduct as DECIMAL(18,2)) as AltCarrierAmtDeduct
      ,AltCarrierPHolderRelation
      ,to_timestamp(AltCarrierPolicyEffDate, 'yyyyMMdd') as AltCarrierPolicyEffDate
      ,to_timestamp(AltCarrierPolicyEndDate, 'yyyyMMdd') as AltCarrierPolicyEndDate
      ,TimeAdmit
      ,TimeDischarge
      ,BirthWeight
      ,BankCheckNbr
      ,MethodOfPayment
      ,LineItemPlusUnits
      ,LineItemUnitMinutes
      ,BusUnitDesc
      ,ProgramDesc
      ,CarrierDesc
      ,RegionDesc
      ,BusLineDesc
      ,ConsolidatedProductDesc
      ,MedicaidProductDesc
      ,MedicareProductDesc
      ,ClaimTypeDesc
      ,ProviderTypeDesc
      ,ResolutionDesc
      ,ClaimStatusDesc
      ,RiskPopulation
      ,PayClass
      ,BenefitPackage
      ,TPL_IND as TplInd
      ,WC_IND as WcInd
      ,MEMBER_RELATIONSHIP as MemberRelationship
      ,CAPITATION_IND as CapitationInd
      ,BENEFIT_PAY_CODE as BenefitPayCode
      ,to_timestamp(ACCIDENT_DATE, 'yyyyMMdd') as AccidentDate
      ,PmgId
      ,PatientAccountNumber
      ,DRG_IND as DrgInd
      ,CAST(Copay as DECIMAL(18,2)) as Copay
      ,CAST(Coinsurance as DECIMAL(18,2)) as Coinsurance
      ,CAST(Deductible as DECIMAL(18,2)) as Deductible
      ,MedicareAllowedAmtLine
      ,CategoryCode
      ,RmcCodeAtDateOfService
      ,MedicalRecordNumber
      ,ProcedureCodingMethod
      ,HospitalDays
      ,DaysCovered
      ,NDCNumber
      ,MemberReferralInd
      ,BankCode
      ,AdmittingProvider
      ,SubmitterID
      ,PayServiceCode
      ,FeeSchedule
      ,TreatmentType
      ,Rider
      ,Component
      ,CAST(TPLiabMedicareAllowedAmount as DECIMAL(18,2)) as TPLiabMedicareAllowedAmount
      ,CAST(TPLiabMedicarePaidAmount as DECIMAL(18,2)) as TPLiabMedicarePaidAmount
      ,CAST(TPLiabPrimaryInsurerAllowedAmount as DECIMAL(18,2)) as TPLiabPrimaryInsurerAllowedAmount
      ,CAST(TPLiabPrimaryInsurerPaidAmount as DECIMAL(18,2)) as TPLiabPrimaryInsurerPaidAmount
      ,to_timestamp(DateTimeofRequest, 'yyyyMMdd') as DateTimeofRequest
      ,to_timestamp(StateDate, 'yyyy-MM-dd') as StateDate
      ,OverallStatus
      ,OverallStatusDescription
      ,AdmissionTypeCodeDescription
      ,to_timestamp(TargetAdmissionDate, 'yyyyMMdd') as TargetAdmissionDate
      ,to_timestamp(TargetDischargeDate, 'yyyyMMdd') as TargetDischargeDate
      ,to_timestamp(ActualAdmissionDate, 'yyyyMMdd') as ActualAdmissionDate
      ,MPIID
      ,CONCAT(Tcn,BusUnit,BusLine) as CnlyClaimNum
      ,CONCAT(FormerTcn,BusUnit,BusLine) as CnlyFormerTcn
      ,CONCAT(ifnull(CenteneProvNbr,''), ifnull(CenteneAffNbr,'')) as CnlyProviderId
      ,CASE
        WHEN BusUnit = "AZ" and (LENGTH(PlanStateCode) - 2) > 0 THEN
            CONCAT(IndividualIdNumber,MedicaidIdNumber,BusLine,CenteneDivisionCode,LEFT(CONCAT("AZ", RIGHT(PlanstateCode,LENGTH(PlanStateCode) - 2)),6))
        WHEN BusUnit = "CN" and (LENGTH(PlanStateCode) - 2) > 0 THEN
            CONCAT(IndividualIdNumber,MedicaidIdNumber,BusLine,CenteneDivisionCode,LEFT(CONCAT("CN", RIGHT(PlanStateCode,LENGTH(PlanStateCode) - 2)),6))
        WHEN BusUnit = "CX" and (LENGTH(PlanStateCode) - 2) > 0 THEN
            CONCAT(IndividualIdNumber,MedicaidIdNumber,BusLine,CenteneDivisionCode,LEFT(CONCAT("CX", RIGHT(PlanStateCode,LENGTH(PlanStateCode) - 2)),6))
        WHEN BusUnit = "MA" and (LENGTH(PlanStateCode) - 2) > 0 THEN
            CONCAT(IndividualIdNumber,MedicaidIdNumber,BusLine,CenteneDivisionCode,LEFT(CONCAT("MA", RIGHT(PlanStateCode,LENGTH(PlanStateCode) - 2)),6))
        WHEN BusUnit = "MC" and (LENGTH(PlanStateCode) - 2) > 0 THEN
            CONCAT(IndividualIdNumber,MedicaidIdNumber,BusLine,CenteneDivisionCode,LEFT(CONCAT("MC", RIGHT(PlanStateCode,LENGTH(PlanStateCode) - 2)),6))
        WHEN BusUnit = "MP" and (LENGTH(PlanStateCode) - 2) > 0 THEN
            CONCAT(IndividualIdNumber,MedicaidIdNumber,BusLine,CenteneDivisionCode,LEFT(CONCAT("MP", RIGHT(PlanStateCode,LENGTH(PlanStateCode) - 2)),6))
        ELSE
            CONCAT(IndividualIdNumber,MedicaidIdNumber,BusLine,CenteneDivisionCode,LEFT(PlanStateCode,6))
      End as CnlyMemberId
      ,year(to_timestamp(regexp_extract(ARK_IFN, '_([0-9.]+).txt$'), 'yyyyMMdd')) as loadyear
      ,month(to_timestamp(regexp_extract(ARK_IFN, '_([0-9.]+).txt$'), 'yyyyMMdd')) as loadmonth
      ,day(to_timestamp(regexp_extract(ARK_IFN, '_([0-9.]+).txt$'), 'yyyyMMdd')) as loadday
      ,regexp_extract(ARK_IFN, '/([A-Za-z0-9_.]+)$', 1) AS LoadFileName
      ,to_timestamp(regexp_extract(ARK_IFN, '_([0-9.]+).txt$'), 'yyyyMMdd') AS LoadDate
 FROM claim_raw