SELECT
    CONCAT(p.cnlyProviderId,'_',p.ProviderNumber) as provider_key
    ,p.LoadDate as provider_load_date
	,p.LoadFileName as provider_load_source
	,array('') as provider_legacy_sys_ids
	,p.ProviderNumber as provider_client_id
	,CAST('' as string) as provider_client_platform_id
	,'Centene' as provider_client_name
	,p.ProviderType as provider_type
    ,CASE WHEN length(p.InstitutionalProviderName) >= 1 THEN p.InstitutionalProviderName ELSE '' END as provider_org_name
	,p.ProviderFirstName as provider_first_name
	,'' as provider_middle_name
	,p.ProviderLastName as provider_last_name
	,CASE WHEN length(p.InstitutionalProviderName) >=1  THEN p.InstitutionalProviderName
	      WHEN  length(p.ProviderFirstName)>=1 OR length(p.ProviderLastName)>=1
	        THEN concat(p.ProviderFirstName,' ',p.ProviderLastName) END as provider_full_name
	,'' as provider_SSN
	,a.TAX_ID as provider_tax_id
	,a.Npi as provider_NPI
	,a.address
	,a.provider_phone
	,a.contract
	,p.PcpInd as provider_pcp_indicator
	,p.GroupTaxId as provider_group_tax_id
	,p.ProviderDeaNumber as provider_dea_number
	,'' as provider_email
	,'' as provider_taxonomy_code
	,COALESCE(ProviderSpecialty1,ProviderSpecialty2) as provider_specialty_code
	,MedicareProviderNumber as provider_medicare_id
	,'' as provider_medicaid_id
	,'' as provider_its_host_plan_code
	,to_timestamp('', 'yyyyMMdd') as provider_record_start_date
	,to_timestamp('', 'yyyyMMdd') as provider_record_end_date

FROM provider_dedup p
INNER JOIN
    provider_aggregate a
ON
    p.CnlyProviderId = a.CnlyProviderId