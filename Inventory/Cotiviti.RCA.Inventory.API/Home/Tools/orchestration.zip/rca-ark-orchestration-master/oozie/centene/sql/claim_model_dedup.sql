SELECT legacy_sys_ids['CnlyClaimNum'] as CnlyClaimNum, m.*
FROM prev_claim_model m
LEFT JOIN claim_dedup d on m.legacy_sys_ids['CnlyClaimNum'] = d.CnlyClaimNum
WHERE d.CnlyCLaimNum IS NULL