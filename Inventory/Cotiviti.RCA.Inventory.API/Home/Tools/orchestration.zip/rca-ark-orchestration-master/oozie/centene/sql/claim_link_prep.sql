SELECT
    concat(BusLine,BusUnit) as repartition_field,
    CnlyClaimNum,
    MIN( CASE
        WHEN length(CnlyFormerTcn) < 7 THEN	''	--Valid ClaimNumbers are at least 7 in length
        WHEN CnlyClaimNum = CnlyFormerTcn THEN	''	--We may have the CNLYClaimnum here, so we need reprocess
        ELSE ifnull(CnlyFormerTcn,'')
        END ) as  CnlyClaimNumFrom
FROM claim_raw
WHERE CnlyClaimNum is not null
GROUP BY BusLine, BusUnit, CnlyClaimNum