# Centene Oozie Workflow

Centene Oozie workflow defines control nodes and action nodes that required for the orchestration of Centene Hadoop jobs on RCA new platform. 

## Standard Folder Structure

We follow below standard folder structure:

- **workflow.xml**

  This is the main workflow definition xml file. Inside this file, we define all required control nodes and action nodes. Oozie provides multiple versions of schema xsd files to ensure the workflow xml file is valid.

- **job.properties**

  This file is the main configuration file. We put all variables that used in above workflow.xml in this configuration file. It uses the key=value format. All variables that defined in this file can be referred as ${var} in the workflow.xml.

- **lib**

  This folder contains all third-party libraries (jar, so and etc.) that used by actions that defined in the workflow.xml file. The files under this folder will be included into classpath automatically at runtime. 

## How to use

**P.S.** The URL of Oozie Server in our cluster is https://usaphdpm04.cotiviti.com:11101/oozie It is needed when we submit an oozie job later on.

### Step 1: Upload to HDFS

Oozie uses HDFS as the path of workflow application. Before we submit an oozie job, we need to upload its content to 
a folder in HDFS. (**job.properties excluded because the job.properties file only used when submitting an oozie job.**)

For this sample Oozie workflow, the folder in HDFS looks like below:

![hdfs folder](../../doc/images/hdfs-folder.PNG)

### Step 2: Submit an Oozie Job

On the edge node, run below command to submit:

```shell script
oozie job -oozie https://usaphdpm04.cotiviti.com:11101/oozie -config <path to job.property> -run
```

When submitting the job, all variables that defined in the workflow.xml will be replaced by the values that defined in job.properties.

```properties
name_node=hdfs://atlanta-prod
rm=usaphdpm02.cotiviti.com:8032
oozie.use.system.libpath=true
oozie.wf.application.path=/user/spring.zhou/oozie/centene
load_year=2021
load_month=5
load_day=8
load_date=2021-05-08
client=Centene
job=claim_prov_raw_builder
```

Also, the value in above job.properties can be override by command line parameters "-D". For instance, if we need to change the value of load_date from command line, we can use below syntax:

```shell script
# use -D parameter to override the value in job.properties
oozie job -oozie https://usaphdpm04.cotiviti.com:11101/oozie -config <path to job.property> -D load_date=2021-05-10 -run
```

The above "oozie job -run" command will return a job id and we can use it to monitor the status of the job.

### Step 3: Operate an Oozie Job

After submitting a job, we can use below command to query the status of the job:

```shell script
# monitor the status of a job
oozie job -oozie https://usaphdpm04.cotiviti.com:11101/oozie -info <id of job>
```

The output of above command looks like below:

![Oozie CLI Info](../../doc/images/oozie-cli-info.PNG)

Please refer to [Oozie Job Operation Commands](https://oozie.apache.org/docs/5.1.0/DG_CommandLineTool.html#Oozie_job_operation_commands) to suspend, resume and kill an Oozie job if needed.

Except using those CLI commands, we can use Hue to query the status of an oozie job as well.

Access to [Hue Oozie Jobs](https://usaphdpm03.cotiviti.com:8889/hue/jobbrowser#!jobs) and we can see all jobs that submitted from the oozie command line.

![Oozie Jobs in Hue](../../doc/images/oozie-result.PNG)

