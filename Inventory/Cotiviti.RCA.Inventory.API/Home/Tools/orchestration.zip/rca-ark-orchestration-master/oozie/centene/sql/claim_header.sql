SELECT
    concat_ws('_',
        reverse(string(CnlyMemberId)),
        '2',
        year(ClaimBegDOS),
        Tcn,
        PlanStateCode,
        f.ClaimSeq
    )  AS claim_key
    ,concat_ws('_',
        reverse(CnlyMemberId),
        '2',
        year(ClaimBegDOS),
         f.BaseClaimNum
    ) AS claim_root_key
    ,cast(2 AS string) AS internal_client_key
    ,'Centene' AS client_name
    ,cast(right(a.CnlyClaimNum,4) as string) AS client_platform_id
    ,'Centene' AS client_platform_name
    ,a.ReceiveDt AS client_received_date
    ,claim_load_date
    ,claim_load_source
    ,ifnull(Tcn,'')	 AS client_claim_id
    ,map('CnlyClaimNum', h.CnlyClaimNum,
         'ClaimAdjustInd', ifnull(if(AdjustmentIndicator = 'Y', 1, 0) ,''),
         'ClaimFormInd', ClaimFormInd,
         'ClmRemarks', concat(ClaimStatus, ' - ', RecoveryFlag),
         'PatCtlNum', ProviderClaimNumber,
         'TAC', AuthorizationNbr,
         'FirstClaimNum', f.BaseClaimNum) AS legacy_sys_ids
    ,'' AS its_bluecard_claim_type
    ,'' AS document_control_number
    ,ifnull(CASE WHEN ClaimFormInd = 'U' THEN 'F' ELSE 'P' END, '') AS claim_type
    ,'' AS claim_service_rendering_type
    ,ifnull(
        CASE WHEN BusUnit = 'MC' THEN 'MCR'
            WHEN BusUnit = 'MP' OR 'TP' IN (BusUnit, BusLine) THEN 'COM'
            ELSE 'MCD' END, '')  AS insurance_lob_code
    ,BusLine AS client_lob_code
    ,'UKN' AS funding_type_code
    ,'U' AS claim_submission_type
    ,CASE
        WHEN '#' IN (FacilityType, BillClass, Occurance) THEN cast(null as string)
        ELSE if(length(concat(FacilityType, BillClass, Occurance)) = 3, concat('0', FacilityType, BillClass, Occurance), concat(FacilityType, BillClass, Occurance))
    END AS type_of_bill_code
    ,occurance AS type_of_bill_frequency_code
    ,a.ClaimBegDOS AS claim_service_from_date
    ,a.ClaimEndDOS AS claim_service_to_date
    ,ifnull(CASE WHEN ClaimFormInd = 'U' THEN
                CASE WHEN BillClass in ('2','1') THEN 'INPATIENT'
                     WHEN BillClass = '3' THEN 'OUTPATIENT'
                END
            ELSE
                if(PlaceOfService in ('21','51','61'), 'INPATIENT', 'OUTPATIENT')
            END,'') as claim_facility_setting_type
    ,a.AdmitDt as admission_date
    ,if(TimeAdmit < 24, CAST(TimeAdmit as integer), null) AS admission_hour
    ,int(null) as admission_minute
    ,cast(null as string) AS admission_type_code
    ,nullif(regexp_replace(SourceAdmission,'[^A-Za-z0-9]', ''), '') as admission_source_code
    ,a.DischargeDt AS discharge_date
    ,if(TimeDischarge < 24, CAST(TimeDischarge as integer), null) AS discharge_hour
    ,int(null) AS discharge_minute
    ,ifnull(CASE WHEN length(regexp_replace(DischargeCode,'DS','')) = 1 THEN RIGHT(concat('00', regexp_replace(DischargeCode,'DS','')),2)
                WHEN length(regexp_replace(DischargeCode,'DS','')) = 2 THEN regexp_replace(DischargeCode,'DS','')
                ELSE ''
            END , '') AS discharge_status_code
    ,a.LOS AS length_of_stay
    ,CASE WHEN BusUnit = 'MC' THEN 'MCR'
        WHEN BusUnit = 'MP' OR 'TP' IN (BusUnit, BusLine) THEN 'COM'
        ELSE 'MCD' END as product_type
    ,cast(null as boolean) AS capitation_indicator
    ,cast(null as boolean) AS cob_indicator
    ,'UNKNOWN'  AS other_insurance_type_description
    ,cast(null as boolean) AS paid_by_drg_indicator
    ,'' AS prior_authorization_number
    ,cast(null AS DECIMAL(18,2)) AS claim_prior_payment_amount
    ,CASE WHEN ParNonParInd = 'Y' THEN True
        WHEN ParNonParInd = 'N' THEN False
        ELSE null
    END AS claim_participation_indicator
    ,CnlyProviderId as billing_provider_key
    --,ifnull(case when pnpi.NPI is not null then pnpi.BillProvNum	else p.BillProvNum		end, '')
    ,'' AS billing_provider_client_id
    --,ifnull(case when pnpi.NPI is not null then pnpi.ProvTin else p.ProvTin end,'')D
    ,'' AS billing_provider_tax_id
    --,ifnull(case when pnpi.NPI is not null then pnpi.NPI			else  p.BillProvNPI		end, '')
    ,'' AS billing_provider_npi
    --,coalesce(nullif(pnpi.BillProvName,''), p.BillProvName)
    ,'' AS billing_provider_full_name
    --,ifnull(case when pnpi.NPI is not null then pnpi.BillProvAdr1	else p.BillProvAdr1		end, '') AS billing_provider_address_01
    --,ifnull(case when pnpi.NPI is not null then pnpi.BillProvAdr2	else p.BillProvAdr2		end, '') AS billing_provider_address_02
    --,ifnull(case when pnpi.NPI is not null then pnpi.BillProvCity	else p.BillProvCity		end, '') AS billing_provider_city
    --,ifnull(case when pnpi.NPI is not null then pnpi.BillProvST	else p.BillProvST		end, '') AS billing_provider_state
    --,ifnull(case when pnpi.NPI is not null then pnpi.BillProvZip	else p.BillProvZip		end, '') AS billing_provider_zip
    ,'' AS billing_provider_contract_id
    ,'' AS billing_provider_negotiated_service_term_id
    ,'' AS billing_provider_phone
    ,CnlyProviderId as rendering_provider_key
    ,ServicingProvNumber AS rendering_provider_client_id
    ,'' AS rendering_provider_medicare_id
    ,'' AS rendering_provider_tax_id
    ,ServicingProvNpi AS rendering_provider_npi
    --,coalesce(nullif(pnpi.SvcProvName,''), p.SvcProvName )
    ,'' AS rendering_provider_full_name
    --,ifnull(case when pnpi.NPI is not null then pnpi.SvcProvAdr1 else p.SvcProvAdr1 end,'')
    ,'' AS rendering_provider_address_01
    --,ifnull(case when pnpi.NPI is not null then pnpi.SvcProvAdr2 else p.SvcProvAdr2 end,'')
    ,'' AS rendering_provider_address_02
    --,ifnull(case when pnpi.NPI is not null then pnpi.SvcProvCity else p.SvcProvCity end,'')
    ,'' AS rendering_provider_city
    --,isnull(case when pnpi.NPI is not null then  pnpi.SvcProvStCd	else p.SvcProvStCd end, '')
    ,'' AS rendering_provider_state
    --,isnull(case when pnpi.NPI is not null then  pnpi.SvcProvZip	else p.SvcProvZip end, '')
    ,'' AS rendering_provider_zip
    ,ifnull(
        CASE WHEN length(ProviderSpecialty) = 1 AND cast(ProviderSpecialty as int) IS NOT NULL THEN RIGHT(concat('0', ProviderSpecialty),2)
            ELSE ProviderSpecialty END, '') AS rendering_provider_specialty_code
    ,'' AS rendering_provider_taxonomy_code
    ,CnlyMemberId as patient_key
    ,IndividualIdNumber AS patient_member_id
    ,'' AS patient_dependent_id
    --,isnull(m.relCd,'')
    ,'' AS patient_relationship_to_subscriber
    ,MedicalRecordNumber AS patient_medical_record_number
    ,MedicaidIdNumber AS patient_medicaid_id
    ,'' AS patient_medicare_id
    --,ISNULL(m.PatSSN,'')
    ,'' AS patient_ssn
    ,PatFirstName AS patient_first_name
    ,PatLastName AS patient_last_name
    --,ISNULL(m.PatAdr1,'')
    ,'' AS patient_address_01
    --,ISNULL(m.PatAdr1,'')
    ,'' AS patient_address_02
    --,ISNULL(m.PatCity,'')
    ,'' AS patient_city
    --,ISNULL(m.PatSt,'')
    ,'' AS patient_state
    --,ISNULL(m.PatZip,'')
    ,'' AS patient_zip
    ,PatDob AS patient_birth_date
    ,if(upper(PatSex) in ('M','F'), upper(PatSex), 'U') AS patient_gender
    ,CAST(BirthWeight as int) AS patient_birth_weight
    ,IndividualIdNumber AS subscriber_client_id
    ,ifnull(PatFirstName,'') as subscriber_first_name
    ,ifnull(PatMidInit,'') as subscriber_middle_name
    ,ifnull(PatLastName,'') as subscriber_last_name
    --,ifnull(m.SubAdr1,'')
    ,'' as subscriber_address_01
    --,ifnull(m.SubAdr2,'')
    ,'' as subscriber_address_02
    --,ifnull(m.SubCity,'')
    ,'' as subscriber_city
    --,ISNULL(m.SubST,'')
    ,'' as subscriber_state
    --,ISNULL(m.SubZip,'')
    ,'' as subscriber_zip
    ,PatSex	as subscriber_gender
    ,ifnull(PmgId,'') AS group_number
    ,'' AS group_name
    ,'' AS employer_sub_group_number
    ,'' AS employer_sub_group_name
    ,PlanStateCode AS benefit_plan_code
    ,'' AS benefit_product_code
    ,'' AS benefit_class_code
    ,LEFT(SubmittedDrgNbr,3) AS submitted_drg_code
    ,CASE WHEN length(DrgCode) > 3 THEN RIGHT(DrgCode, 1) ELSE '' END AS submitted_drg_severity_of_illness
    ,LEFT(RIGHT(DrgCode, 4), 3) AS allowed_drg_code
    ,'' AS allowed_drg_grouper_id
    ,CAST(null as INT) AS allowed_drg_grouper_version
    ,upper(if(length(regexp_replace(AdmittingDiagnosis, '[^A-Za-z0-9]', '')) > 3, concat(left(regexp_replace(AdmittingDiagnosis, '[^A-Za-z0-9]', ''), 3),'.',substring(regexp_replace(AdmittingDiagnosis, '[^A-Za-z0-9]', ''), 4)), regexp_replace(AdmittingDiagnosis, '[^A-Za-z0-9]', ''))) AS admitting_diagnosis_code
    ,CAST(IcdVersionIndicator as string) AS icd_version_code
    ,upper(if(length(regexp_replace(DxCodes[0], '[^A-Za-z0-9]', '')) > 3, concat(left(regexp_replace(DxCodes[0], '[^A-Za-z0-9]', ''),3),'.',substring(regexp_replace(DxCodes[0], '[^A-Za-z0-9]', ''),4)), regexp_replace(DxCodes[0], '[^A-Za-z0-9]', ''))) AS primary_diagnosis_code
    ,transform(
        DxCodes, x ->
            if(length(x) > 3, concat(left(x, 3), '.', substring(x, 4)), x)
    ) AS diagnosis_codes
    ,transform(
        DxCodes, x -> ifnull(element_at(DiagPoaMaps,x), 'U')
    ) AS diagnosis_poa_codes
    ,transform(
        ECodes, x ->
            if(length(x) > 3, concat(left(x, 3), '.', substring(x, 4)), x)
    ) AS external_cause_of_injury_codes
    ,PxCodes AS procedure_codes
    ,occurrence_code
    ,a.value_code
    ,CAST(null as timestamp) AS adjudicated_date
    ,a.PaidDT AS claim_paid_date
    ,f.OrigPaidDt AS claim_original_paid_date
    ,cast('' as timestamp) AS check_date
    ,ifnull(
        CASE WHEN TransactionStatus = 'A' THEN ''--'Open'
            WHEN TransactionStatus = 'B' THEN 'P'--'Paid'
            WHEN TransactionStatus = 'C' THEN ''--'Pend'
            WHEN TransactionStatus = 'D' THEN 'R'--'Denied'
            WHEN TransactionStatus = 'E' THEN 'R'--'Adjusted'
            WHEN TransactionStatus = 'F' THEN ''--'Other'
            ELSE '' END , '') AS payment_status
    ,'UNKNOWN' AS payment_method
    ,'' AS paid_to_code
    ,BankCheckNbr AS check_number
    ,CAST(a.ClmTotalChgs AS DECIMAL(18,2)) AS claim_charge_amount
    ,CAST(a.ClmAllowedAmt AS DECIMAL(18,2)) AS claim_allowed_amount
    ,CAST(0 AS DECIMAL(18,2)) AS claim_cob_allowed_amount
    ,CAST(a.ClmCoInsAmt AS DECIMAL(18,2)) AS claim_coinsurance_amount
    ,CAST(0 AS DECIMAL(18,2)) AS claim_cob_coinsurance_amount
    ,CAST(a.ClmCOBAmt AS DECIMAL(18,2)) AS claim_cob_paid_amount
    ,CAST(a.ClmCoPayAmt AS DECIMAL(18,2)) AS claim_copay_amount
    ,CAST(a.ClmDeductAmt AS DECIMAL(18,2)) AS claim_deductible_amount
    ,CAST((a.ClmDeductAmt + a.ClmCoPayAmt + a.ClmCoInsAmt) AS DECIMAL(20,2)) AS claim_patient_liability_amount
    ,CAST(a.ClmPaidAmt AS DECIMAL(18,2)) AS claim_paid_amount
    ,CAST(0 AS DECIMAL(18,2)) AS claim_non_covered_amount
    ,CAST(0 AS DECIMAL(18,2)) AS claim_fee_schedule_amount
    ,CAST(0 AS DECIMAL(18,2)) AS claim_patient_responsibility_amount
    ,CAST(0 AS DECIMAL(18,2)) AS claim_per_case_rate_amount
    ,CAST(0 AS DECIMAL(18,2)) AS claim_per_diem_rate_amount
    ,CAST(0 AS DECIMAL(18,2)) AS claim_per_diem_weighted_amount
    ,CAST(0 AS DECIMAL(18,2)) AS claim_sequestration_amount
    ,CAST(0 AS DECIMAL(18,2)) AS claim_disallowed_amount
    ,f.ClaimSeq AS claim_sequence_rank
    ,f.FinalAction AS final_action_indicator
    ,array_min(claim_detail.line_place_of_service_code) AS claim_place_of_service_code
    ,True as new_claim_indicator
    ,claim_detail
FROM (
    SELECT  *,
            row_number() over (PARTITION BY CnlyClaimNum ORDER BY CAST(LineItemDtlNbr AS INT) DESC) as rnk

    FROM claim_dedup
) h
INNER JOIN claim_aggregate a on h.CnlyClaimNum = a.CnlyClaimNum
INNER JOIN claim_final_action f on h.CnlyClaimNum = f.CnlyClaimNum
WHERE rnk = 1