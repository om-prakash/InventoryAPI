from pyspark.sql.functions import lit
from util import load_df


def exclude(context):
    """
    A function to exclude medical claims based on specified notouch dataframe
    :param context: An instance of ExclusionContext
    :return: An instance of ExclusionContext
    """
    spark = context.spark
    config = context.config
    included = context.included
    excluded = context.included
    source_path = config['input']['path']
    notouch_path = config['exclusions']['notouch']['path']
    input_join_column = config['input']['join_column']
    notouch_join_column = config['exclusions']['notouch']['join_column']
    target = config['exclusions']['notouch']['target'].upper()
    # a flag to identify if the exclusion is the first one in the exclusion pipeline
    # this flag will drive if we need to cache dataframe to avoid unnecessary computation
    is_first_exclusion = False
    if included is None:
        # for test purpose, we project columns to minimum to save testing time
        # for production, we should not use any projections
        included = load_df(spark, source_path).select(input_join_column, 'CnlySor')
        is_first_exclusion = True
    # load notouch dataframe
    df_notouch = load_df(spark, notouch_path)
    # create temp views from above dataframe
    included.createOrReplaceTempView('source')
    df_notouch.createOrReplaceTempView('notouch')
    # pickup column from notouch dataframe based on the target configuration
    if target == 'DM':
        flag = 'nt.NoTouchDM AS nt_flag'
    elif target == 'COB':
        flag = 'nt.NoTouchCOB AS nt_flag'
    else:
        flag = 'nt.NoTouchMCR AS nt_flag'
    # construct spark SQL statement to left outer join source and notouch
    sql = """
        SELECT
          s.*, {flag} 
        FROM source AS s 
        LEFT OUTER JOIN notouch AS nt
          ON s.{input_join_key} = nt.{notouch_join_key}
        """.format(input_join_key=input_join_column, notouch_join_key=notouch_join_column, flag=flag)
    df_joined = spark.sql(sql)
    # if this is the first middleware of exclusion in the pipeline, then we
    # can cache the joined dataframe
    if is_first_exclusion:
        df_joined = df_joined.cache()
    included = df_joined.where('nt_flag = 0 or nt_flag IS NULL').drop('nt_flag')
    if excluded is not None:
        excluded = excluded\
            .union(df_joined.where('nt_flag = 1').select(input_join_column).withColumn('Reason', lit('No Touch')))
    else:
        excluded = df_joined.where('nt_flag = 1').select(input_join_column).withColumn('Reason', lit('No Touch'))
    context.included = included
    context.excluded = excluded
    return context
