from datetime import datetime


def pprint(output):
    """
    Output message with timestamp
    :param output: message
    :return: None
    """
    print('======== %s =========' % str(datetime.now()))
    print(output)
    print('=============================================\n')


def load_df(spark, path):
    """
    Load source dataframe based on extension
    Currently only support avro and parquet formats
    :param spark Spark session
    :param path: path to source files
    :return: spark dataframe
    """
    input_format = 'avro' if path.lower().endswith('avro') else 'parquet'
    return spark.read.format(input_format).load(path)


def validate_input(conf_input):
    """
    Validate the input section in config JSON and return a list of validation error
    If no validation errors found, then return an empty list
    :param conf_input: A dict that represents input section in config JSON
    :return: A list of validation error
    """
    errors = []
    join_column = conf_input.get('join_column', None)
    path = conf_input.get('path', None)
    # ensure the join_column of input is not None or empty spaces
    if join_column is None or len(join_column.strip()) == 0:
        errors.append('The join_column of input is missing.')
    # ensure the path of input is not None or empty spaces
    if path is None or len(path.strip()) == 0:
        errors.append('The path of input is missing.')
    else:
        # check the extensions, only avro and parquet supported
        extension = path.lower().endswith('avro') or path.lower().endswith('parquet')
        if not extension:
            errors.append('Invalid input file format. Only avro and parquet supported.')
    return errors


def validate_included(conf_included):
    """
    Validate the included section in config JSON and return a list of validation error
    If no validation errors found, then return an empty list
    :param conf_included: A dict that represents included section in config JSON
    :return: A list of validation error
    """
    errors = []
    path = conf_included.get('path', None)
    # ensure the path of included is not None or empty spaces
    if path is None or len(path.strip()) == 0:
        errors.append('The path of included is missing.')
    return errors


def validate_excluded(conf_excluded):
    """
    Validate the excluded section in config JSON and return a list of validation error
    If no validation errors found, then return an empty list
    :param conf_excluded: A dict that represents excluded section in config JSON
    :return: A list of validation error
    """
    errors = []
    path = conf_excluded.get('path', None)
    # ensure the path of excluded is not None or empty spaces
    if path is None or len(path.strip()) == 0:
        errors.append('The path of excluded is missing.')
    return errors


def validate_output(conf_output):
    """
    Validate the output section in config JSON and return a list of validation error
    If no validation errors found, then return an empty list
    :param conf_output: A dict that represents output section in config JSON
    :return: A list of validation error
    """
    errors = []
    # validate output format to ensure only avro and parquet supported
    output_format = conf_output.get('format', None)
    if output_format is None or len(output_format.strip()) == 0:
        errors.append('The format of output is missing.')
    else:
        # validate the format of output, only avro and parquet supported
        output_format = output_format.lower()
        if output_format not in ['avro', 'parquet']:
            errors.append('Invalid output file format. Only avro and parquet supported.')
    # validate output compress to ensure it is a boolean value
    output_compress = conf_output.get('compress', None)
    if not output_compress:
        errors.append('The compress of output is missing.')
    else:
        if type(output_compress).__name__ != 'bool':
            errors.append('The type of compress must be boolean.')
    # validate output included
    output_included = conf_output.get('included', None)
    if not output_included:
        errors.append('The included of output is missing')
    else:
        errors = errors + validate_included(output_included)
    # validate output excluded
    output_excluded = conf_output.get('excluded', None)
    if not output_excluded:
        errors.append('The excluded of output is missing.')
    else:
        errors = errors + validate_excluded(output_excluded)
    return errors


def validate_notouch(conf_notouch):
    """
    Validate the notouch section in config JSON and return a list of validation error
    If no validation errors found, then return an empty list
    :param conf_notouch: A dict that represents notouch section in config JSON
    :return: A list of validation error
    """
    errors = []
    path = conf_notouch.get('path', None)
    # ensure the path of notouch is not None or empty spaces
    if path is None or len(path.strip()) == 0:
        errors.append('The path of notouch is missing.')
    else:
        # check the extensions, only avro and parquet supported
        extension = path.lower().endswith('avro') or path.lower().endswith('parquet')
        if not extension:
            errors.append('Invalid notouch file format. Only avro and parquet supported.')
    # validate join_column
    join_column = conf_notouch.get('join_column', None)
    if join_column is None or len(join_column.strip()) == 0:
        errors.append('The join_column of notouch is missing.')
    # validate target
    target = conf_notouch.get('target', None)
    if target is None or len(target.strip()) == 0:
        errors.append('The target of notouch is missing.')
    else:
        # ensure the target is one of supported values.
        target = target.lower()
        if target not in ['dm', 'cob', 'mcr']:
            errors.append('Invalid target. only DM, COB and MCR supported.')
    return errors


def validate_expiration(conf_expiration):
    """
    Validate the expiration section in config JSON and return a list of validation error
    If no validation errors found, then return an empty list
    :param conf_expiration: A dict that represents expiration section in config JSON
    :return: A list of validation error
    """
    errors = []
    path = conf_expiration.get('path', None)
    # ensure the path of notouch is not None or empty spaces
    if path is None or len(path.strip()) == 0:
        errors.append('The path of expiration is missing.')
    else:
        # check the extensions, only avro and parquet supported
        extension = path.lower().endswith('avro') or path.lower().endswith('parquet')
        if not extension:
            errors.append('Invalid expiration file format. Only avro and parquet supported.')
    # validate join_column
    join_column = conf_expiration.get('join_column', None)
    if join_column is None or len(join_column.strip()) == 0:
        errors.append('The join_column of expiration is missing.')
    # validate check_column
    check_column = conf_expiration.get('check_column', None)
    if check_column is None or len(check_column.strip()) == 0:
        errors.append('The check_column of expiration is missing.')
    return errors


def validate_exclusions(conf_exclusions):
    """
    Validate the exclusions section in config JSON and return a list of validation error
    If no validation errors found, then return an empty list
    :param conf_exclusions: A dict that represents exclusions section in config JSON
    :return: A list of validation error
    """
    errors = []
    pipelines = conf_exclusions.get('pipeline', None)
    # validate pipelines configuration
    if not pipelines:
        errors.append('The pipeline of exclusions is missing.')
    else:
        if type(pipelines).__name__ != 'list':
            errors.append('The pipelines must be an array.')
        else:
            if len(pipelines) == 0:
                errors.append('The pipelines cannot be empty.')
    # validate notouch configuration if presented
    notouch = conf_exclusions.get('notouch', None)
    if notouch is not None:
        errors = errors + validate_notouch(notouch)
    # validate expiration configuration if presented
    expiration = conf_exclusions.get('expiration', None)
    if expiration is not None:
        errors = errors + validate_expiration(expiration)
    return errors


def validate(conf):
    """
    Validation configuration JSON and return a list of validation error
    :param conf: A dict that represents configuration
    :return: A list of validation error
    """
    errors = []
    input_conf = conf.get('input', None)
    # validate input configuration
    if not input_conf:
        errors.append('The input configuration is missing.')
    else:
        errors = errors + validate_input(input_conf)
    output_conf = conf.get('output', None)
    # validate output configuration
    if not output_conf:
        errors.append('The output configuration is missing.')
    else:
        errors = errors + validate_output(output_conf)
    # validate exclusions configuration
    exclusions_conf = conf.get('exclusions', None)
    if not exclusions_conf:
        errors.append('The exclusions configuration is missing.')
    else:
        errors = errors + validate_exclusions(exclusions_conf)
    return errors
