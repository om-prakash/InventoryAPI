from datetime import date

from pyspark.sql.functions import lit
from util import load_df


def exclude(context):
    """
    A function to exclude expired medical claims
    :param context: An instance of ExclusionContext
    :return: An instance of ExclusionContext
    """
    spark = context.spark
    config = context.config
    included = context.included
    excluded = context.excluded
    source_path = config['input']['path']
    expiration_path = config['exclusions']['expiration']['path']
    input_join_column = config['input']['join_column']
    expiration_join_column = config['exclusions']['expiration']['join_column']
    expiration_check_column = config['exclusions']['expiration']['check_column']
    # a flag to identify if the exclusion is the first one in the exclusion pipeline
    # this flag will drive if we need to cache dataframe to avoid unnecessary computation
    is_first_exclusion = False
    if included is None:
        # for test purpose, we project columns to minimum to save testing time
        # for production, we should not use any projections
        included = load_df(spark, source_path).select(input_join_column, 'CnlySor')
        is_first_exclusion = True
    # Compare the value of ExpDate column in claim header with today's date
    # to check if a claim is expired or not
    today = date.today().strftime('%Y-%m-%d')
    # Join with fact claim header data to check its expiration
    # Filter expired claims in fact claim header first to reduce the size of shuffle data
    df_claim_header = load_df(spark, expiration_path).select(expiration_join_column, expiration_check_column)\
        .where("{check_column} > '{check_date}'".format(check_column=expiration_check_column, check_date=today))
    included.createOrReplaceTempView('included')
    df_claim_header.createOrReplaceTempView('header')
    sql = """
      SELECT i.*,
        CASE 
          WHEN h.{expiration_join_key} IS NULL THEN 1
          ELSE 0
        END AS expired
      FROM included AS i 
      LEFT OUTER JOIN header AS h 
        ON i.{input_join_key} = h.{expiration_join_key}
    """.format(input_join_key=input_join_column,
               expiration_join_key=expiration_join_column)
    df_joined = spark.sql(sql)
    # if this is the first middleware of exclusion in the pipeline, then we
    # can cache the joined dataframe
    if is_first_exclusion:
        df_joined = df_joined.cache()
    context.included = df_joined.where('expired = 0').drop('expired')
    if excluded is not None:
        excluded = excluded\
            .union(df_joined.where('expired = 1').select(input_join_column).withColumn('Reason', lit('Expired')))
    else:
        excluded = df_joined.where('expired = 1').select(input_join_column).withColumn('Reason', lit('Expired'))
    context.excluded = excluded
    return context
