from exclusion_context import ExclusionContext
from util import pprint


def load_pipeline(pipes):
    """
    Load exclusion middleware into exclusion pipeline
    :param pipes: A list of full name of exclusion middleware
    :return: list of exclusion function
    """
    pipelines = []
    for pipe in pipes:
        mod_name, func_name = pipe.split('.')
        mod = __import__(mod_name)
        func = getattr(mod, func_name)
        pipelines.append(func)
    return pipelines


def write(config, df_included, df_excluded):
    """
    Write output files based on the output configuration
    This method writes two output files, one file has the same data structure
    as the source file, but only contains non-excluded claims; other file contains excluded claims
    :param config: global configuration
    :param df_included: dataframe which contains valid claims
    :param df_excluded: dataframe which contains excluded claims
    :return: None
    """
    included_path = config['output']['included']['path']
    excluded_path = config['output']['excluded']['path']
    output_format = config['output']['format']
    compress = config['output']['compress']

    # write dataframe based on output configuration (format, compress and path)
    df_included_writer = df_included.write.format(output_format.lower())  \
        .mode('overwrite')
    df_excluded_writer = df_excluded.write.format(output_format.lower()) \
        .mode('overwrite')
    if compress:
        df_included_writer.option('compression', 'snappy')
        df_excluded_writer.option('compression', 'snappy')
    df_included_writer.save(included_path)
    df_excluded_writer.save(excluded_path)


def run(spark, config):
    """
    Entry point for exclusion pipeline
    This function constructs an exclusion pipeline based on global configuration
    and then trigger the execution of exclusion middleware in the pipeline to get
    final included and excluded dataframe and eventually write to specified output paths
    :param spark: an instance of SparkSession
    :param config: global configuration
    :return: None
    """
    pprint('Anthem exclusion process started.')
    # step 1: Construct exclusion context
    context = ExclusionContext(spark, config)
    # step 2: Build exclusion pipeline by composing middleware of exclusion
    # the order of middleware matters, the first middleware will be executed first
    pipes = config['exclusions']['pipeline']
    pipelines = load_pipeline(pipes)
    # step 3: Trigger exclusion middleware in pipeline
    for func in pipelines:
        context = func(context)
    # step 4: Write final included and excluded dataframe based on the output configuration
    write(config, context.included, context.excluded)
    pprint('Anthem exclusion process completed successfully.')
