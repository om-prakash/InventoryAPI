class ExclusionContext:
    """
    A class that represents the context of exclusion. This context includes:
    1. an instance of SparkSession
    2. a global configuration
    3. a dataframe that includes valid claims (the default value is None, this value revised
    via middleware of exclusion)
    4. a dataframe that includes excluded claims (the default value is None, this value revised via middleware of
    exclusion)
    """
    def __init__(self, spark, config, included=None, excluded=None):
        if spark is None:
            raise ValueError('Invalid SparkSession.')
        if config is None:
            raise ValueError('Invalid global configuration.')
        self.spark = spark
        self.config = config
        self.included = included
        self.excluded = excluded
