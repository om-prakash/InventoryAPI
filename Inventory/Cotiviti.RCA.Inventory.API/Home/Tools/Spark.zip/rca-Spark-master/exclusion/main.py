from pyspark.sql import SparkSession
import argparse
import json
import traceback


# load config from JSON config file
# we can put our configuration in the JSON
# config file and then pass it via --files parameter
# while calling spark-submit command
def load_config(path):
    with open(path) as f:
        return json.load(f)


def run(session, arg):
    import exclusion
    from util import validate
    # load global configuration
    conf = load_config(arg.config)
    # validate global configuration
    errors = validate(conf)
    if len(errors) > 0:
        raise ValueError("Invalid configuration found. \n {}".format('\n'.join(errors)))
    # run exclusion pyspark job
    exclusion.run(session, conf)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description='Anthem exclusion processor')
    # below line can be commented out in local development
    # parser.add_argument('--src', required=True, help='source files zip path')
    parser.add_argument('-c', '--config', help='a json file on the config setting')
    args = parser.parse_args()
    parser.
    spark = None
    has_error = False
    try:
        # spark = SparkSession.builder.appName("Word Count PySpark Demo").master("local[*]") \
        #     .config('spark.driver.memory', '4g') \
        #     .config("spark.memory.offHeap.enabled", True) \
        #     .config("spark.memory.offHeap.size", "2g") \
        #     .config("spark.sql.objectHashAggregate.sortBased.fallbackThreshold", 50000) \
        #     .config("spark.sql.autoBroadcastJoinThreshold", 100 * 1024 * 1024) \
        #     .config("spark.sql.shuffle.partitions", 200) \
        #     .getOrCreate()

        spark = SparkSession.builder\
            .appName('Anthem exclusion processor')\
            .master('local[*]')\
            .config('spark.jars.packages', 'org.apache.spark:spark-avro_2.11:2.4.5')\
            .getOrCreate()

        sc = spark.sparkContext
        # below line can be commented out in local development
        # sc.addPyFile(args.src)
        sc.setLogLevel('INFO')

        # run jobs
        run(spark, args)
    except IOError as ie:
        has_error = True
        print('An IO error occurred. exit with error code.')
        traceback.print_exc()
        traceback.format_exc()
    except Exception as e:
        has_error = True
        print(e)
        traceback.print_exc()

    # stop spark session to release resources
    if spark is None:
        pass
    else:
        spark.stop()
    # if an error occurred, we need to mark the exit code to an non-zero value
    # in airflow, an non-zero exit code identifies a task failed, otherwise airflow
    # will keep running and never end
    if has_error:
        exit(1)


import psycopg2
import psycopg2.extras


# establish connection to Postgres
def connect_db():
    try:
        connection = psycopg2.connect(
            user = pg_dict['connect']['user'],
            password = pg_dict['connect']['password'],
            host = pg_dict['connect']['host'],
            port = pg_dict['connect']['port'],
            database = pg_dict['connect']['database']
        )
    except (Exception, psycopg2.Error) as error:
        print ("Error while connecting to PostgreSQL", error)
    else:
        logg("Connected!")
        return connection



logg('pysopg2 loaded')

pg_dict = {u'connect': {u'user': u'svc_zera', u'host': u'Usapgres10.cotiviti.com', u'password': u'Z3r@_T3am', u'port': u'5432', u'database': u'rca'}}

logg(str(pg_dict))

try:
    cur = connection.cursor(cursor_factory = psycopg2.extras.RealDictCursor)
    cur.execute('select * from config.client')
    res = cur.fetchall()

    logg(str(res))

except:
    err = traceback.format_exc()
    logg(err)
