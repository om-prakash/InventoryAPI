#!/bin/sh

# This script is used to zip the src folder to generate src.jar file
# The generated src.jar will be provided as an argument for spark-submit command

jar -cvf src.jar -C ./src .
