#!/usr/bin/env bash

HDIR="/rca/Anthem/data/raw/FactClaimHeader/"
MAXPATH=$(hdfs dfs -ls -R ${HDIR} | grep "^d" | tail -1 | tr "[:alpha:][:punct:]" ' ' | tr -s ' ' | cut -d' ' -f8 |tr -d ' ')

spark2-submit \
--master yarn \
--deploy-mode cluster \
--name "Anthem Claim Final Action" \
--packages org.apache.spark:spark-avro_2.11:2.4.0 \
--queue root.rcaengdev \
--executor-memory 20G \
--executor-cores 5 \
--driver-memory 10G \
--conf spark.locality.wait.rack=60s \
AnthemFinalAction.py --filepart ${MAXPATH} ;
