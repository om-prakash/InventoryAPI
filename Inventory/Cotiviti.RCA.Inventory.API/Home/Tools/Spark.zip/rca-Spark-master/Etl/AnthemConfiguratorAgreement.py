import os
import sys

import argparse

from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *

sc = SparkContext.getOrCreate()
spark = SparkSession.builder.getOrCreate()

spark.conf.set("spark.sql.avro.compression.codec", "snappy")

inputpath = "/rca/Anthem/data/raw/sqoop/contract/"
outputpath = "/rca/Anthem/data/raw/"
poutputpath = "/rca/Anthem/data/raw/parquet/contract/"
refinedpath = "/rca/Anthem/data/refined/"

in_agreepath = inputpath + "vConfiguratorClaimAgreements/*"
in_contrpath = inputpath + "vConfiguratorClaimContracts/*"
out_agreepath = outputpath + "ClaimAgreements"
out_contrpath = outputpath + "ClaimContracts"
pout_agreepath = poutputpath + "ClaimAgreements"
pout_contrpath = poutputpath + "ClaimContracts"

scAgree = StructType(
    [StructField("CnlyClmJoinKey", LongType(), True), StructField("ClmNum", StringType(), True), StructField("Agreement_ID", StringType(), True), StructField("Agreement_Desc", StringType(), True), StructField("Agreement_Eff_Dt", DateType(), True), StructField("Agreement_Term_Dt", DateType(), True), StructField("EffectiveDt", DateType(), True), StructField("TerminationDt", DateType(), True),
     StructField("PCPInd", StringType(), True), StructField("Network_Prov_Prefix", StringType(), True), StructField("Term_Reason", StringType(), True), StructField("SFileName", StringType(), True), StructField("LoadDate", DateType(), True)])
scContr = StructType(
    [StructField("CnlyClmJoinKey", LongType(), False), StructField("CnlyLnID", IntegerType(), False), StructField("ClmNum", StringType(), True), StructField("LineNum", StringType(), True), StructField("Contract_Terms", StringType(), True), StructField("Contract_Term_Dt", DateType(), True), StructField("Contract_Eff_Dt", DateType(), True), StructField("RevProcDiag_Code", StringType(), True),
     StructField("Contract_Price", DecimalType(18, 2), True), StructField("Contract_Rate", StringType(), True), StructField("Fee_Schedule", StringType(), True), StructField("Facility_ID", StringType(), True), StructField("NPI", StringType(), True), StructField("Network_ID", StringType(), True), StructField("Network_Name", StringType(), True), StructField("Based_On", StringType(), True),
     StructField("SFileName", StringType(), True), StructField("LoadDate", DateType(), True)])

dfcontr = spark.read.schema(scContr).csv(path = in_contrpath, header = "false", sep = "|")
dfcontr.coalesce(150).write.mode("overwrite").format("avro").save(out_contrpath)

dfagree = spark.read.schema(scAgree).csv(path = in_agreepath, header = "false", sep = "|")
dfagree.coalesce(100).write.mode("overwrite").format("avro").save(out_agreepath)

blockMB = 512
dictMB = 3
paddMB = 8
block_size = str(blockMB * 1024 * 1024)
dict_size = str(dictMB * 1024 * 1024)
padd_size = str(paddMB * 1024 * 1024)

sc._jsc.hadoopConfiguration().set("dfs.block.size", block_size)
sc._jsc.hadoopConfiguration().set("parquet.block.size", block_size)
sc._jsc.hadoopConfiguration().set("parquet.dictionary.page.size", dict_size)
sc._jsc.hadoopConfiguration().set("parquet.writer.max-padding", padd_size)

dfcontr = spark.read.format("avro").load(out_contrpath)
dfagree = spark.read.format("avro").load(out_agreepath)

dfcontr.repartition(45).write.mode("overwrite").parquet(pout_contrpath)
dfagree.repartition(40).write.mode("overwrite").parquet(pout_agreepath)

spark.stop()
