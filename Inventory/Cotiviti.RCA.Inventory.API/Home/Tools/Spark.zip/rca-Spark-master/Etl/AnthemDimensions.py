from pyspark.sql.session import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *

spark = SparkSession.builder.getOrCreate()

raw_path = "/rca/Anthem/data/raw/sqoop/dimensions/"
output_path = "/rca/Anthem/data/raw/parquet/dimensions/"

sc_dxcd = StructType(
    [StructField("DxCdID", IntegerType(), False),
     StructField("DxCd", StringType(), True),
     StructField("UB04Ind", IntegerType(), True),
     StructField("Description", StringType(), True),
     StructField("ICDVersionCd", ShortType(), False),
     StructField("UnKnownCd", IntegerType(), True),
     StructField("CdSource", StringType(), True),
     StructField("CreateDt", DateType(), True),
     StructField("WLP_EffectiveDt", DateType(), True),
     StructField("WLP_TermDt", DateType(), True),
     StructField("WLP_MinAge", ShortType(), True),
     StructField("WLP_MaxAge", ShortType(), True),
     StructField("WLP_SSB_ER_Lvl", ShortType(), True),
     StructField("WLP_CodeFirst", IntegerType(), True),
     StructField("WLP_LgGrp", IntegerType(), True),
     StructField("WLP_SmGrp", IntegerType(), True),
     StructField("WLP_Indiv", IntegerType(), True),
     StructField("WLP_LimitCls", StringType(), True),
     StructField("WLP_LimitClsDef", StringType(), True)]
)

current_dim = "vDimDxCd"
in_path = raw_path + current_dim
out_path = output_path + current_dim

spark.read\
    .schema(sc_dxcd)\
    .csv(in_path, header="false", sep="|")\
    .repartition(1)\
    .write.mode("overwrite")\
    .parquet(out_path)

sc_svccd = StructType(
    [StructField("SvcCdID", IntegerType(), False),
     StructField("SvcCd", StringType(), True),
     StructField("Description", StringType(), True),
     StructField("CodeType", StringType(), True),
     StructField("UnknownCd", IntegerType(), True),
     StructField("CdSource", StringType(), True),
     StructField("CreateDt", DateType(), True)]
)

current_dim = "vDimSvcCd"
in_path = raw_path + current_dim
out_path = output_path + current_dim

spark.read\
    .schema(sc_svccd)\
    .csv(in_path, header="false", sep="|")\
    .repartition(1)\
    .write.mode("overwrite")\
    .parquet(out_path)

sc_sorcd = StructType(
    [StructField("SORID", ShortType(), False),
     StructField("ClmSOR", ShortType(), False),
     StructField("Description", StringType(), True),
     StructField("UnknownCd", IntegerType(), True),
     StructField("CdSource", StringType(), True),
     StructField("CreateDt", DateType(), True)]
)

current_dim = "vDimClmSORCd"
in_path = raw_path + current_dim
out_path = output_path + current_dim

spark.read\
    .schema(sc_sorcd)\
    .csv(in_path, header="false", sep="|")\
    .repartition(1)\
    .write.mode("overwrite")\
    .parquet(out_path)

sc_dl = StructType(
    [StructField("LoadID", IntegerType(), False),
     StructField("LoadLOB", StringType(), True),
     StructField("LoadScheduled", IntegerType(), True),
     StructField("LoadMonth", StringType(), True),
     StructField("LoadStartDt", DateType(), True),
     StructField("LoadCompleteDt", DateType(), True),
     StructField("LoadUser", StringType(), True),
     StructField("Notes", StringType(), True),
     StructField("MinPaidDt", DateType(), True),
     StructField("MaxPaidDt", DateType(), True),
     StructField("GlobalLoggingID", LongType(), True)]
)

current_dim = "vDataLoads"
in_path = raw_path + current_dim
out_path = output_path + current_dim

spark.read\
    .schema(sc_dl)\
    .csv(in_path, header="false", sep="|")\
    .repartition(1)\
    .write.mode("overwrite")\
    .parquet(out_path)

sc_memrelcd = StructType(
    [StructField("MemReltnID", ShortType(), False),
     StructField("MemReltnCd", StringType(), True),
     StructField("CnlyMemType", StringType(), True),
     StructField("Description", StringType(), True),
     StructField("UnKnownCd", IntegerType(), True),
     StructField("CdSource", StringType(), True),
     StructField("CreateDt", DateType(), True)]
)

current_dim = "vDimMemReltnCd"
in_path = raw_path + current_dim
out_path = output_path + current_dim

spark.read\
    .schema(sc_memrelcd)\
    .csv(in_path, header="false", sep="|")\
    .repartition(1)\
    .write.mode("overwrite")\
    .parquet(out_path)

sc_adjrsncd = StructType(
    [StructField("AdjstRsnID", ShortType(), False),
     StructField("AdjstRsnCd", StringType(), True),
     StructField("Description", StringType(), True),
     StructField("UnknownCd", IntegerType(), True),
     StructField("CdSource", StringType(), True),
     StructField("CreateDt", DateType(), True)]
)

current_dim = "vDimAdjstRsnCd"
in_path = raw_path + current_dim
out_path = output_path + current_dim

spark.read\
    .schema(sc_adjrsncd)\
    .csv(in_path, header="false", sep="|")\
    .repartition(1)\
    .write.mode("overwrite")\
    .parquet(out_path)

spark.stop()
