PART=49

until [  $PART -lt 25 ]; do echo PARTITION $PART;

spark2-submit \
--master yarn \
--deploy-mode cluster \
--name "Anthem Header Raw" \
--packages org.apache.spark:spark-avro_2.11:2.4.0 \
--queue root.rcaengdev \
--executor-memory 20G \
--executor-cores 5 \
--driver-memory 15G \
AnthemHeader.py --filepart $PART

let PART-=1; done
