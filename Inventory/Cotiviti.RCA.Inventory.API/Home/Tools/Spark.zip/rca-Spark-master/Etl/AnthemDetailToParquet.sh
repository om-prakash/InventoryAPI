spark2-submit \
--master yarn \
--deploy-mode cluster \
--name "Anthem Detail to Parquet" \
--packages org.apache.spark:spark-avro_2.11:2.4.0 \
--queue root.rcaengdev \
--executor-memory 40G \
--executor-cores 5 \
--driver-memory 15G \
--conf "spark.yarn.submit.waitAppCompletion=false" \
AnthemDetailToParquet.py
