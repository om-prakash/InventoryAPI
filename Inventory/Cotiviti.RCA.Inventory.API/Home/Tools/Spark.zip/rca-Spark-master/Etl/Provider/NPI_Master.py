import subprocess
import argparse

from pyspark.sql.session import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *

spark = SparkSession.builder.getOrCreate()

path = '/rca/codelibrary/npi/'
parquet_path = path + 'parquet/'
npidata_latest = parquet_path + 'latest/npidata'
othername_latest = parquet_path + 'latest/othername'
pl_latest = parquet_path + 'latest/practice_location'

npi = spark.read.parquet(npidata_latest)
npi.createOrReplaceTempView("npi")
othername = spark.read.parquet(othername_latest)
othername.createOrReplaceTempView("othr")
pl = spark.read.parquet(pl_latest)
pl.createOrReplaceTempView("pl")

npi_othernames = spark.sql("""
select
    N.NPI as provider_npi
    ,collect_list(
        struct(
            upper(O.Provider_Other_Organization_Name) as provider_name,
            string(null) as provider_credential,
            case O.Provider_Other_Organization_Name_Type_Code
                when '5' then 'N'
                when O.Provider_Other_Organization_Name_Type_Code is not null
                    then 'Y' 
            end as provider_matching_eligibile,
            case O.Provider_Other_Organization_Name_Type_Code
                when '1' then 'FORMER NAME'
                when '2' then 'PROFESSIONAL NAME'
                when '3' then 'DOING BUSINESS AS'
                when '4' then 'FORMER LEGAL BUSINESS NAME'
                when '5' then 'UNKNOWN'
            end as name_type
            )
        ) as provider_other_names
from 
    npi N
    left join othr O on N.NPI = O.NPI
group by
    N.NPI
""")
npi_othernames.createOrReplaceTempView("vnpi_othernames")

npi_address = spark.sql("""
select
    N.NPI as provider_npi
    ,collect_list(
        struct(
            'SECONDARY PRACTICE ADDRESS' as provider_address_type,
            upper(Provider_Secondary_Practice_Location_First_Line_Address) 
                as provider_address_line_1,
            upper(Provider_Secondary_Practice_Location_Second_Line_Address)
                as provider_address_line_2,
            upper(Provider_Secondary_Practice_Location_Address_City_Name)
                as provider_city,
            upper(Provider_Secondary_Practice_Location_Address_State_Name)
                as provider_state,
            left(Provider_Secondary_Practice_Location_Address_Postal_Code,5)
                as provider_zip,
            case when 
            length(Provider_Secondary_Practice_Location_Address_Postal_Code) >5
            then right(Provider_Secondary_Practice_Location_Address_Postal_Code,4)
                end as provider_zip_4,
            upper(Provider_Secondary_Practice_Location_Address_Country_Code_If_outside_US)
                as provider_country_code,
            Provider_Secondary_Practice_Location_Address_Telephone_Number
                as provider_phone,
            upper(Provider_Secondary_Practice_Location_Address_Telephone_Extension)
                as provider_phone_extension,
            Provider_Secondary_Practice_Location_Address_Fax_Number 
                as provider_fax
            )
        ) as provider_address
from
    npi N
    left join pl P on N.NPI = P.NPI
group by 
    N.NPI
""")
npi_address.createOrReplaceTempView("vnpi_address")

npi_new = spark.sql("""
select
    N.NPI as provider_npi,
    case 
        when Entity_Type_Code = 1 then 'INDIVIDUAL'
        when Entity_Type_Code = 2 then 'ORGANIZATION'
        else "UKNOWN"
    end as provider_entity_type,
    Replacement_NPI as provider_replacement_npi,
    coalesce(
        upper(Provider_Organization_Name_Legal_Business_Name),
        upper(regexp_replace(nullif(trim(concat_ws(' ', 
            ifnull(Provider_First_Name,''), 
            ifnull(Provider_Middle_Name,''), 
            ifnull(Provider_Last_Name_Legal_Name,''),
            ifnull(
                replace(Provider_Name_Suffix_Text, '.', '')
                ,''))),''), ' +', ' ')))
    as provider_name,
    Provider_Credential_Text as provider_credential,
    'Y' as provider_matching_eligibile,
    filter(array_union(array(struct(
    coalesce(
        upper(Provider_Other_Organization_Name),
        upper(regexp_replace(nullif(trim(concat_ws(' ', 
            ifnull(Provider_Other_First_Name,''), 
            ifnull(Provider_Other_Middle_Name,''), 
            ifnull(Provider_Other_Last_Name,''),
            ifnull(
                replace(Provider_Other_Name_Suffix_Text, '.', '')
                ,''))),''), ' +', ' ')))
    as provider_name,
    Provider_other_Credential_Text as provider_credential,
    'Y' as provider_matching_eligibile,
    coalesce(
        case 
            when Provider_Other_Organization_Name is not null and
            Provider_Other_Organization_Name_Type_Code = '1' 
                then 'FORMER NAME'
            when Provider_Other_Organization_Name is not null and
            Provider_Other_Organization_Name_Type_Code =  '2'  
                then 'PROFESSIONAL NAME'
            when Provider_Other_Organization_Name is not null and
            Provider_Other_Organization_Name_Type_Code =  '3'  
                then 'DOING BUSINESS AS'
            when Provider_Other_Organization_Name is not null and
            Provider_Other_Organization_Name_Type_Code =  '4'  
                then 'FORMER LEGAL BUSINESS NAME'
            when Provider_Other_Organization_Name is not null
                then 'UNKNOWN'
        end,
        case 
            when coalesce(Provider_Other_First_Name, Provider_Other_Last_Name)
            is not null and Provider_Other_Last_Name_Type_Code = '1' 
                then 'FORMER NAME'
            when coalesce(Provider_Other_First_Name, Provider_Other_Last_Name)
            is not null and Provider_Other_Last_Name_Type_Code = '2' 
                then 'PROFESSIONAL NAME'
            when coalesce(Provider_Other_First_Name, Provider_Other_Last_Name)
            is not null and Provider_Other_Last_Name_Type_Code = '3' 
                then 'DOING BUSINESS AS'
            when coalesce(Provider_Other_First_Name, Provider_Other_Last_Name)
            is not null and Provider_Other_Last_Name_Type_Code = '4' 
                then 'FORMER LEGAL BUSINESS NAME'
            when coalesce(Provider_Other_First_Name, Provider_Other_Last_Name) 
                is not null then 'UNKNOWN'
        end)     
     as name_type),
    struct(upper(trim(Parent_Organization_LBN)) as provider_name,
    string(null) as provider_credential,
    'N' as provider_matching_eligibile,
     case when Parent_Organization_LBN is not null 
        then 'PARENT ORGANIZATION NAME' end as name_type),
     struct(
     upper(regexp_replace(nullif(trim(concat_ws(' ', 
            ifnull(Authorized_Official_First_Name,''), 
            ifnull(Authorized_Official_Middle_Name,''), 
            ifnull(Authorized_Official_Last_Name,''),
            ifnull(
                replace(Authorized_Official_Name_Suffix_Text, '.', '')
                ,''))),''), ' +', ' '))
    as provider_name,
    Authorized_Official_Credential_Text as provider_credential,
    'N' as provider_matching_eligibile,
    case when coalesce(Authorized_Official_First_Name,
        Authorized_Official_Last_Name) is not null
        then concat('AUTHORIZED OFFICIAL',  
            upper(ifnull(concat(' - ', 
                Authorized_Official_Title_or_Position),'')))
    end as name_type)), O.provider_other_names), 
    x -> x.name_type is not null) as provider_other_names,
    case Provider_Gender_Code
        when 'M' then 'M'
        when 'F' then 'F'
    end as provider_gender,
    filter(array_union(case     
    when 
        ifnull(Provider_First_Line_Business_Mailing_Address,'') =
        ifnull(Provider_First_Line_Business_Practice_Location_Address,'')
    and ifnull(Provider_Second_Line_Business_Mailing_Address,'') =
        ifnull(Provider_Second_Line_Business_Practice_Location_Address,'')
    and ifnull(Provider_Business_Mailing_Address_City_Name,'') =
        ifnull(Provider_Business_Practice_Location_Address_City_Name,'')
    and ifnull(Provider_Business_Mailing_Address_State_Name,'') =
        ifnull(Provider_Business_Practice_Location_Address_State_Name,'')
    and ifnull(Provider_Business_Mailing_Address_Telephone_Number,'') =
        ifnull(Provider_Business_Practice_Location_Address_Telephone_Number,'')
    and ifnull(Provider_Business_Mailing_Address_Fax_Number,'') =
        ifnull(Provider_Business_Practice_Location_Address_Fax_Number,'')
    then
    array(struct(
        'MAILING / PRIMARY PRACTICE ADDRESS' as provider_address_type,
        upper(Provider_First_Line_Business_Mailing_Address) 
            as provider_address_line_1,
        upper(Provider_Second_Line_Business_Mailing_Address)
            as provider_address_line_2,
        upper(Provider_Business_Mailing_Address_City_Name)
            as provider_city,
        upper(Provider_Business_Mailing_Address_State_Name)
            as provider_state,
        left(Provider_Business_Mailing_Address_Postal_Code, 5)
            as provider_zip,
        case when 
        length(Provider_Business_Mailing_Address_Postal_Code) > 5
        then right(Provider_Business_Mailing_Address_Postal_Code, 4)
            end as provider_zip_4,
        upper(Provider_Business_Mailing_Address_Country_Code_If_outside_US)
            as provider_country_code,
        Provider_Business_Mailing_Address_Telephone_Number
            as provider_phone,
        string(null) as provider_phone_extension,
        Provider_Business_Mailing_Address_Fax_Number 
            as provider_fax
        )) 
    else
    array(struct(
        'MAILING ADDRESS' as provider_address_type,
        upper(Provider_First_Line_Business_Mailing_Address) 
            as provider_address_line_1,
        upper(Provider_Second_Line_Business_Mailing_Address)
            as provider_address_line_2,
        upper(Provider_Business_Mailing_Address_City_Name)
            as provider_city,
        upper(Provider_Business_Mailing_Address_State_Name)
            as provider_state,
        left(Provider_Business_Mailing_Address_Postal_Code, 5)
            as provider_zip,
        case when 
        length(Provider_Business_Mailing_Address_Postal_Code) > 5
        then right(Provider_Business_Mailing_Address_Postal_Code, 4)
            end as provider_zip_4,
        upper(Provider_Business_Mailing_Address_Country_Code_If_outside_US)
            as provider_country_code,
        Provider_Business_Mailing_Address_Telephone_Number
            as provider_phone,
        string(null) as provider_phone_extension,
        Provider_Business_Mailing_Address_Fax_Number 
            as provider_fax
        ),
        struct(
        'PRIMARY PRACTICE ADDRESS' as provider_address_type,
        upper(Provider_First_Line_Business_Practice_Location_Address) 
            as provider_address_line_1,
        upper(Provider_Second_Line_Business_Practice_Location_Address)
            as provider_address_line_2,
        upper(Provider_Business_Practice_Location_Address_City_Name)
            as provider_city,
        upper(Provider_Business_Practice_Location_Address_State_Name)
            as provider_state,
        left(Provider_Business_Mailing_Address_Postal_Code, 5)
            as provider_zip,
        case when 
        length(Provider_Business_Practice_Location_Address_Postal_Code) > 5
        then right(Provider_Business_Practice_Location_Address_Postal_Code, 4)
            end as provider_zip_4,
        upper(Provider_Business_Practice_Location_Address_Country_Code_If_outside_US)
            as provider_country_code,
        Provider_Business_Practice_Location_Address_Telephone_Number
            as provider_phone,
        string(null) as provider_phone_extension,
        Provider_Business_Practice_Location_Address_Fax_Number 
            as provider_fax
        )) end, A.provider_address), 
        x -> coalesce(x.provider_address_line_1,
            x.provider_address_line_2,
            x.provider_state,
            x.provider_zip,
            x.provider_phone) is not null
        ) as provider_address,
    filter(array(
        struct(
            Healthcare_Provider_Taxonomy_Code_1 as taxonomy_code,
            Provider_License_Number_1 as license_nummber,
            Provider_License_Number_State_Code_1 as license_state,
            Healthcare_Provider_Primary_Taxonomy_Switch_1 as primary,
            Healthcare_Provider_Taxonomy_Group_1 as taxonomy_group_type),
        struct(
            Healthcare_Provider_Taxonomy_Code_2 as taxonomy_code,
            Provider_License_Number_2 as license_nummber,
            Provider_License_Number_State_Code_2 as license_state,
            Healthcare_Provider_Primary_Taxonomy_Switch_2 as primary,
            Healthcare_Provider_Taxonomy_Group_2 as taxonomy_group_type),
        struct(
            Healthcare_Provider_Taxonomy_Code_3 as taxonomy_code,
            Provider_License_Number_3 as license_nummber,
            Provider_License_Number_State_Code_3 as license_state,
            Healthcare_Provider_Primary_Taxonomy_Switch_3 as primary,
            Healthcare_Provider_Taxonomy_Group_3 as taxonomy_group_type),
        struct(
            Healthcare_Provider_Taxonomy_Code_4 as taxonomy_code,
            Provider_License_Number_4 as license_nummber,
            Provider_License_Number_State_Code_4 as license_state,
            Healthcare_Provider_Primary_Taxonomy_Switch_4 as primary,
            Healthcare_Provider_Taxonomy_Group_4 as taxonomy_group_type),
        struct(
            Healthcare_Provider_Taxonomy_Code_5 as taxonomy_code,
            Provider_License_Number_5 as license_nummber,
            Provider_License_Number_State_Code_5 as license_state,
            Healthcare_Provider_Primary_Taxonomy_Switch_5 as primary,
            Healthcare_Provider_Taxonomy_Group_5 as taxonomy_group_type),
        struct(
            Healthcare_Provider_Taxonomy_Code_6 as taxonomy_code,
            Provider_License_Number_6 as license_nummber,
            Provider_License_Number_State_Code_6 as license_state,
            Healthcare_Provider_Primary_Taxonomy_Switch_6 as primary,
            Healthcare_Provider_Taxonomy_Group_6 as taxonomy_group_type),
        struct(
            Healthcare_Provider_Taxonomy_Code_7 as taxonomy_code,
            Provider_License_Number_7 as license_nummber,
            Provider_License_Number_State_Code_7 as license_state,
            Healthcare_Provider_Primary_Taxonomy_Switch_7 as primary,
            Healthcare_Provider_Taxonomy_Group_7 as taxonomy_group_type),
        struct(
            Healthcare_Provider_Taxonomy_Code_8 as taxonomy_code,
            Provider_License_Number_8 as license_nummber,
            Provider_License_Number_State_Code_8 as license_state,
            Healthcare_Provider_Primary_Taxonomy_Switch_8 as primary,
            Healthcare_Provider_Taxonomy_Group_8 as taxonomy_group_type),
        struct(
            Healthcare_Provider_Taxonomy_Code_9 as taxonomy_code,
            Provider_License_Number_9 as license_nummber,
            Provider_License_Number_State_Code_9 as license_state,
            Healthcare_Provider_Primary_Taxonomy_Switch_9 as primary,
            Healthcare_Provider_Taxonomy_Group_9 as taxonomy_group_type),
        struct(
            Healthcare_Provider_Taxonomy_Code_10 as taxonomy_code,
            Provider_License_Number_10 as license_nummber,
            Provider_License_Number_State_Code_10 as license_state,
            Healthcare_Provider_Primary_Taxonomy_Switch_10 as primary,
            Healthcare_Provider_Taxonomy_Group_10 as taxonomy_group_type),
        struct(
            Healthcare_Provider_Taxonomy_Code_11 as taxonomy_code,
            Provider_License_Number_11 as license_nummber,
            Provider_License_Number_State_Code_11 as license_state,
            Healthcare_Provider_Primary_Taxonomy_Switch_11 as primary,
            Healthcare_Provider_Taxonomy_Group_11 as taxonomy_group_type),
        struct(
            Healthcare_Provider_Taxonomy_Code_12 as taxonomy_code,
            Provider_License_Number_12 as license_nummber,
            Provider_License_Number_State_Code_12 as license_state,
            Healthcare_Provider_Primary_Taxonomy_Switch_12 as primary,
            Healthcare_Provider_Taxonomy_Group_12 as taxonomy_group_type),
        struct(
            Healthcare_Provider_Taxonomy_Code_13 as taxonomy_code,
            Provider_License_Number_13 as license_nummber,
            Provider_License_Number_State_Code_13 as license_state,
            Healthcare_Provider_Primary_Taxonomy_Switch_13 as primary,
            Healthcare_Provider_Taxonomy_Group_13 as taxonomy_group_type),
        struct(
            Healthcare_Provider_Taxonomy_Code_14 as taxonomy_code,
            Provider_License_Number_14 as license_nummber,
            Provider_License_Number_State_Code_14 as license_state,
            Healthcare_Provider_Primary_Taxonomy_Switch_14 as primary,
            Healthcare_Provider_Taxonomy_Group_14 as taxonomy_group_type),
        struct(
            Healthcare_Provider_Taxonomy_Code_15 as taxonomy_code,
            Provider_License_Number_15 as license_nummber,
            Provider_License_Number_State_Code_15 as license_state,
            Healthcare_Provider_Primary_Taxonomy_Switch_15 as primary,
            Healthcare_Provider_Taxonomy_Group_15 as taxonomy_group_type)
        ), x -> x.taxonomy_code is not null) as taxonomy_codes,
    filter(array(
        struct(
            Other_Provider_Identifier_1 as provider_id,
            case Other_Provider_Identifier_Type_Code_1 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_1 as issuing_state,
            Other_Provider_Identifier_Issuer_1 as issuing_entity),
        struct(
            Other_Provider_Identifier_2 as provider_id,
            case Other_Provider_Identifier_Type_Code_2 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_2 as issuing_state,
            Other_Provider_Identifier_Issuer_2 as issuing_entity),
        struct(
            Other_Provider_Identifier_3 as provider_id,
            case Other_Provider_Identifier_Type_Code_3 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_3 as issuing_state,
            Other_Provider_Identifier_Issuer_3 as issuing_entity),
        struct(
            Other_Provider_Identifier_4 as provider_id,
            case Other_Provider_Identifier_Type_Code_4 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_4 as issuing_state,
            Other_Provider_Identifier_Issuer_4 as issuing_entity),
        struct(
            Other_Provider_Identifier_5 as provider_id,
            case Other_Provider_Identifier_Type_Code_5 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_5 as issuing_state,
            Other_Provider_Identifier_Issuer_5 as issuing_entity),
        struct(
            Other_Provider_Identifier_6 as provider_id,
            case Other_Provider_Identifier_Type_Code_6 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_6 as issuing_state,
            Other_Provider_Identifier_Issuer_6 as issuing_entity),
        struct(
            Other_Provider_Identifier_7 as provider_id,
            case Other_Provider_Identifier_Type_Code_7 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_7 as issuing_state,
            Other_Provider_Identifier_Issuer_7 as issuing_entity),
        struct(
            Other_Provider_Identifier_8 as provider_id,
            case Other_Provider_Identifier_Type_Code_8 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_8 as issuing_state,
            Other_Provider_Identifier_Issuer_8 as issuing_entity),
        struct(
            Other_Provider_Identifier_9 as provider_id,
            case Other_Provider_Identifier_Type_Code_9 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_9 as issuing_state,
            Other_Provider_Identifier_Issuer_9 as issuing_entity),
        struct(
            Other_Provider_Identifier_10 as provider_id,
            case Other_Provider_Identifier_Type_Code_10 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_10 as issuing_state,
            Other_Provider_Identifier_Issuer_10 as issuing_entity),
        struct(
            Other_Provider_Identifier_11 as provider_id,
            case Other_Provider_Identifier_Type_Code_11 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_11 as issuing_state,
            Other_Provider_Identifier_Issuer_11 as issuing_entity),
        struct(
            Other_Provider_Identifier_12 as provider_id,
            case Other_Provider_Identifier_Type_Code_12 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_12 as issuing_state,
            Other_Provider_Identifier_Issuer_12 as issuing_entity),
        struct(
            Other_Provider_Identifier_13 as provider_id,
            case Other_Provider_Identifier_Type_Code_13 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_13 as issuing_state,
            Other_Provider_Identifier_Issuer_13 as issuing_entity),
        struct(
            Other_Provider_Identifier_14 as provider_id,
            case Other_Provider_Identifier_Type_Code_14 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_14 as issuing_state,
            Other_Provider_Identifier_Issuer_14 as issuing_entity),
        struct(
            Other_Provider_Identifier_15 as provider_id,
            case Other_Provider_Identifier_Type_Code_15 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_15 as issuing_state,
            Other_Provider_Identifier_Issuer_15 as issuing_entity),
        struct(
            Other_Provider_Identifier_16 as provider_id,
            case Other_Provider_Identifier_Type_Code_16 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_16 as issuing_state,
            Other_Provider_Identifier_Issuer_16 as issuing_entity),
        struct(
            Other_Provider_Identifier_17 as provider_id,
            case Other_Provider_Identifier_Type_Code_17 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_17 as issuing_state,
            Other_Provider_Identifier_Issuer_17 as issuing_entity),
        struct(
            Other_Provider_Identifier_18 as provider_id,
            case Other_Provider_Identifier_Type_Code_18 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_18 as issuing_state,
            Other_Provider_Identifier_Issuer_18 as issuing_entity),
        struct(
            Other_Provider_Identifier_19 as provider_id,
            case Other_Provider_Identifier_Type_Code_19 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_19 as issuing_state,
            Other_Provider_Identifier_Issuer_19 as issuing_entity),
        struct(
            Other_Provider_Identifier_20 as provider_id,
            case Other_Provider_Identifier_Type_Code_20 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_20 as issuing_state,
            Other_Provider_Identifier_Issuer_20 as issuing_entity),
        struct(
            Other_Provider_Identifier_21 as provider_id,
            case Other_Provider_Identifier_Type_Code_21 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_21 as issuing_state,
            Other_Provider_Identifier_Issuer_21 as issuing_entity),
        struct(
            Other_Provider_Identifier_22 as provider_id,
            case Other_Provider_Identifier_Type_Code_22 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_22 as issuing_state,
            Other_Provider_Identifier_Issuer_22 as issuing_entity),
        struct(
            Other_Provider_Identifier_23 as provider_id,
            case Other_Provider_Identifier_Type_Code_23 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_23 as issuing_state,
            Other_Provider_Identifier_Issuer_23 as issuing_entity),
        struct(
            Other_Provider_Identifier_24 as provider_id,
            case Other_Provider_Identifier_Type_Code_24 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_24 as issuing_state,
            Other_Provider_Identifier_Issuer_24 as issuing_entity),
        struct(
            Other_Provider_Identifier_25 as provider_id,
            case Other_Provider_Identifier_Type_Code_25 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_25 as issuing_state,
            Other_Provider_Identifier_Issuer_25 as issuing_entity),
        struct(
            Other_Provider_Identifier_26 as provider_id,
            case Other_Provider_Identifier_Type_Code_26 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_26 as issuing_state,
            Other_Provider_Identifier_Issuer_26 as issuing_entity),
        struct(
            Other_Provider_Identifier_27 as provider_id,
            case Other_Provider_Identifier_Type_Code_27 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_27 as issuing_state,
            Other_Provider_Identifier_Issuer_27 as issuing_entity),
        struct(
            Other_Provider_Identifier_28 as provider_id,
            case Other_Provider_Identifier_Type_Code_28 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_28 as issuing_state,
            Other_Provider_Identifier_Issuer_28 as issuing_entity),
        struct(
            Other_Provider_Identifier_29 as provider_id,
            case Other_Provider_Identifier_Type_Code_29 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_29 as issuing_state,
            Other_Provider_Identifier_Issuer_29 as issuing_entity),
        struct(
            Other_Provider_Identifier_30 as provider_id,
            case Other_Provider_Identifier_Type_Code_30 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_30 as issuing_state,
            Other_Provider_Identifier_Issuer_30 as issuing_entity),
        struct(
            Other_Provider_Identifier_31 as provider_id,
            case Other_Provider_Identifier_Type_Code_31 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_31 as issuing_state,
            Other_Provider_Identifier_Issuer_31 as issuing_entity),
        struct(
            Other_Provider_Identifier_32 as provider_id,
            case Other_Provider_Identifier_Type_Code_32 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_32 as issuing_state,
            Other_Provider_Identifier_Issuer_32 as issuing_entity),
        struct(
            Other_Provider_Identifier_33 as provider_id,
            case Other_Provider_Identifier_Type_Code_33 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_33 as issuing_state,
            Other_Provider_Identifier_Issuer_33 as issuing_entity),
        struct(
            Other_Provider_Identifier_34 as provider_id,
            case Other_Provider_Identifier_Type_Code_34 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_34 as issuing_state,
            Other_Provider_Identifier_Issuer_34 as issuing_entity),
        struct(
            Other_Provider_Identifier_35 as provider_id,
            case Other_Provider_Identifier_Type_Code_35 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_35 as issuing_state,
            Other_Provider_Identifier_Issuer_35 as issuing_entity),
        struct(
            Other_Provider_Identifier_36 as provider_id,
            case Other_Provider_Identifier_Type_Code_36 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_36 as issuing_state,
            Other_Provider_Identifier_Issuer_36 as issuing_entity),
        struct(
            Other_Provider_Identifier_37 as provider_id,
            case Other_Provider_Identifier_Type_Code_37 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_37 as issuing_state,
            Other_Provider_Identifier_Issuer_37 as issuing_entity),
        struct(
            Other_Provider_Identifier_38 as provider_id,
            case Other_Provider_Identifier_Type_Code_38 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_38 as issuing_state,
            Other_Provider_Identifier_Issuer_38 as issuing_entity),
        struct(
            Other_Provider_Identifier_39 as provider_id,
            case Other_Provider_Identifier_Type_Code_39 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_39 as issuing_state,
            Other_Provider_Identifier_Issuer_39 as issuing_entity),
        struct(
            Other_Provider_Identifier_40 as provider_id,
            case Other_Provider_Identifier_Type_Code_40 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_40 as issuing_state,
            Other_Provider_Identifier_Issuer_40 as issuing_entity),
        struct(
            Other_Provider_Identifier_41 as provider_id,
            case Other_Provider_Identifier_Type_Code_41 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_41 as issuing_state,
            Other_Provider_Identifier_Issuer_41 as issuing_entity),
        struct(
            Other_Provider_Identifier_42 as provider_id,
            case Other_Provider_Identifier_Type_Code_42 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_42 as issuing_state,
            Other_Provider_Identifier_Issuer_42 as issuing_entity),
        struct(
            Other_Provider_Identifier_43 as provider_id,
            case Other_Provider_Identifier_Type_Code_43 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_43 as issuing_state,
            Other_Provider_Identifier_Issuer_43 as issuing_entity),
        struct(
            Other_Provider_Identifier_44 as provider_id,
            case Other_Provider_Identifier_Type_Code_44 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_44 as issuing_state,
            Other_Provider_Identifier_Issuer_44 as issuing_entity),
        struct(
            Other_Provider_Identifier_45 as provider_id,
            case Other_Provider_Identifier_Type_Code_45 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_45 as issuing_state,
            Other_Provider_Identifier_Issuer_45 as issuing_entity),
        struct(
            Other_Provider_Identifier_46 as provider_id,
            case Other_Provider_Identifier_Type_Code_46 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_46 as issuing_state,
            Other_Provider_Identifier_Issuer_46 as issuing_entity),
        struct(
            Other_Provider_Identifier_47 as provider_id,
            case Other_Provider_Identifier_Type_Code_47 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_47 as issuing_state,
            Other_Provider_Identifier_Issuer_47 as issuing_entity),
        struct(
            Other_Provider_Identifier_48 as provider_id,
            case Other_Provider_Identifier_Type_Code_48 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_48 as issuing_state,
            Other_Provider_Identifier_Issuer_48 as issuing_entity),
        struct(
            Other_Provider_Identifier_49 as provider_id,
            case Other_Provider_Identifier_Type_Code_49 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_49 as issuing_state,
            Other_Provider_Identifier_Issuer_49 as issuing_entity),
        struct(
            Other_Provider_Identifier_50 as provider_id,
            case Other_Provider_Identifier_Type_Code_50 
            when '05' then 1 else 0 end as medicaid,
            Other_Provider_Identifier_State_50 as issuing_state,
            Other_Provider_Identifier_Issuer_50 as issuing_entity)
    ), x -> x.provider_id is not null) as other_provider_identifiers,
    case Is_Sole_Proprietor
        when 'Y' then 'Y'
        when 'N' then 'N'
    end as sole_proprietor_indicator,
    Provider_Enumeration_Date as npi_activation_date,
    Last_Update_Date as last_update_date,
    NPI_Deactivation_Date as npi_deactivation_date,
    NPI_Deactivation_Reason_Code as npi_deactivation_reason,
    NPI_Reactivation_Date as npi_reactivation_date,
    Certification_Date as npi_certification_date,
    cast(current_date() as DATE) as last_build_date 

from
    npi N
    inner join vnpi_othernames O on N.NPI = O.provider_npi
    inner join vnpi_address A on N.NPI = A.provider_npi
""")

npi_new\
    .withColumn("primary_taxonomy_code",
                expr(
                     "element_at(filter("
                     "taxonomy_codes, "
                     "x -> x.primary = 'Y'), 1).taxonomy_code"
                    )
                )\
    .repartition(5)\
    .write.mode("overwrite")\
    .parquet("/rca/codelibrary/npi/provider_npi_refined")

spark.stop()
