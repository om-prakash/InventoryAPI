import subprocess
import argparse

from pyspark.sql.session import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *

spark = SparkSession.builder.getOrCreate()

parser = argparse.ArgumentParser()
parser.add_argument("--MonthNum", type = str)
args = parser.parse_args()
if args.MonthNum:
    MonthNum = args.MonthNum

# HDFS filesystem commands
testCmd = 'hdfs dfs -test -e '
removeCmd = 'hdfs dfs -rm -r '
moveCmd = 'hdfs dfs -mv '
makedircmd = 'hdfs dfs -mkdir -p '
copycmd = 'hdfs dfs -cp '

path = '/rca/codelibrary/npi/'

# MonthNum = "202006"
raw_path = path + 'raw/' + MonthNum
parquet_path = path + 'parquet/'
npidata_raw = raw_path + '/npidata*[0-9].csv'
npidata_pq_mth = parquet_path + MonthNum + '/npidata'
npidata_latest = parquet_path + 'latest/npidata'
othername_raw = raw_path + '/othername*[0-9].csv'
othername_pq_mth = parquet_path + MonthNum + '/othername'
othername_latest = parquet_path + 'latest/othername'
pl_raw = raw_path + '/pl_*[0-9].csv'
pl_pq_mth = parquet_path + MonthNum + '/practice_location'
pl_latest = parquet_path + 'latest/practice_location'

subprocess.call(makedircmd + parquet_path + MonthNum, shell=True)

npidata_schema = spark.read.parquet(npidata_latest).schema
othername_schema = spark.read.parquet(othername_latest).schema
pl_schema = spark.read.parquet(pl_latest).schema

npidata = spark\
    .read\
    .schema(npidata_schema)\
    .csv(npidata_raw,
         header = "true",
         dateFormat = "MM/dd/yyyy",
         escape = "|")\
    .withColumn("rnk",
                expr(
                     "row_number() over (partition by NPI order by "
                     "Last_Update_Date desc)"
                    )
                )\
    .filter("rnk = 1")\
    .drop("rnk")\
    .write\
    .mode("overwrite")\
    .parquet(npidata_pq_mth)

othername = spark\
    .read\
    .schema(othername_schema)\
    .csv(othername_raw,
         header = "true",
         dateFormat = "MM/dd/yyyy",
         escape = "|")\
    .distinct()\
    .write\
    .mode("overwrite")\
    .parquet(othername_pq_mth)

pl = spark\
    .read\
    .schema(pl_schema)\
    .csv(pl_raw,
         header = "true",
         dateFormat = "MM/dd/yyyy",
         escape = "|")\
    .distinct()\
    .write\
    .mode("overwrite")\
    .parquet(pl_pq_mth)

chkNPI = subprocess.call(testCmd + npidata_pq_mth + '/_SUCCESS', shell=True)
chkOTHR = subprocess.call(testCmd + othername_pq_mth + '/_SUCCESS', shell=True)
chkPL = subprocess.call(testCmd + pl_pq_mth + '/_SUCCESS', shell=True)
chkR = chkNPI + chkOTHR + chkPL

if chkR == 0:
    print('rebuild created successfully')
    chkC = subprocess.call(testCmd + parquet_path + 'latest', shell=True)
    if chkC == 0:
        subprocess.call(removeCmd + parquet_path + 'latest', shell=True)
    subprocess.call(
        copycmd + parquet_path + MonthNum + ' ' + parquet_path + 'latest',
        shell = True)

spark.stop()
