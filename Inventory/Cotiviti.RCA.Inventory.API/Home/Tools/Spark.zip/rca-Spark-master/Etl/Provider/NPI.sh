#!/usr/bin/env bash

SFX=".zip"
URL="https://download.cms.gov/nppes/"
WEEKLYBEG=`date -d "monday-14 days" '+%m%d%y'`
WEEKLYEND=`date -d "sunday-7 days" '+%m%d%y'`
WEEKLYMONTHNUM=`date -d "monday-14 days" '+%Y%m'`
WEEKLYFILE="NPPES_Data_Dissemination_${WEEKLYBEG}_${WEEKLYEND}_Weekly"
WEEKLYURL=${URL}${WEEKLYFILE}${SFX}
MONTH=`date '+%B'`
YEAR=`date '+%Y'`
MONTHNUM=`date '+%Y%m'`
MONTHLYFILE="NPPES_Data_Dissemination_${MONTH}_${YEAR}"
MONTHLYURL=${URL}${MONTHLYFILE}${SFX}
RUNLOAD=0

TEMPPATH="/tempspace/${MONTHLYFILE}"
ARCHIVEPATH="/rca/codelibrary/npi/archive/${MONTHLYFILE}${SFX}"
UNZIPPATH="/rca/codelibrary/npi/raw/${MONTHNUM}/"

# check for monthly file
MFILECOUNT=`hdfs dfs -ls ${ARCHIVEPATH} 2> /dev/null | wc -l`

if [[ "${MFILECOUNT}" == "0" ]];
    then
        if wget -q --spider ${MONTHLYURL};
            then
                BUILDMONTH=${MONTHNUM}
                wget -O ${TEMPPATH}${SFX} ${MONTHLYURL}
                hdfs dfs -put -f ${TEMPPATH}${SFX} ${ARCHIVEPATH}  2> /dev/null
                hdfs dfs -mkdir -p ${UNZIPPATH}
                unzip ${TEMPPATH}${SFX} -d ${TEMPPATH}
                for f in ${TEMPPATH}/*.csv;
                    do hdfs dfs -put -f ${f} ${UNZIPPATH} 2> /dev/null ;
                    echo "${f} copied to HDFS";
                done
                rm ${TEMPPATH}${SFX}
                rm -r ${TEMPPATH}
                RUNLOAD=1
        else
            BUILDMONTH=${WEEKLYMONTHNUM}
            echo "monthly file not present"
        fi
fi

TEMPPATH="/tempspace/${WEEKLYFILE}"
ARCHIVEPATH="/rca/codelibrary/npi/archive/${WEEKLYFILE}${SFX}"
UNZIPPATH="/rca/codelibrary/npi/raw/${WEEKLYMONTHNUM}/"

# check for weekly file
WFILECOUNT=`hdfs dfs -ls ${ARCHIVEPATH} 2> /dev/null | wc -l`

if [[ "${WFILECOUNT}" == "0" ]];
    then
        if wget -q --spider ${WEEKLYURL};
            then
                wget -O ${TEMPPATH}${SFX} ${WEEKLYURL}
                hdfs dfs -put -f ${TEMPPATH}${SFX} ${ARCHIVEPATH} 2> /dev/null
                hdfs dfs -mkdir -p ${UNZIPPATH}
                unzip ${TEMPPATH}${SFX} -d ${TEMPPATH}
                for f in ${TEMPPATH}/*.csv;
                    do hdfs dfs -put -f ${f} ${UNZIPPATH} 2> /dev/null ;
                    echo "${f} copied to HDFS";
                done
                rm ${TEMPPATH}${SFX}
                rm -r ${TEMPPATH}
                RUNLOAD=1
        else
            echo "weekly file not present"
        fi
fi

if [[ "${RUNLOAD}" == "1" ]];
    then
        spark2-submit \
        --master yarn \
        --deploy-mode cluster \
        --name "NPPES Provider raw" \
        --executor-memory 15G \
        --executor-cores 5 \
        --driver-memory 10G \
        --conf spark.locality.wait.rack=60s \
        NPI.py  --MonthNum ${BUILDMONTH} ;

        spark2-submit \
        --master yarn \
        --deploy-mode cluster \
        --name "NPPES Provider refined" \
        --executor-memory 15G \
        --executor-cores 5 \
        --driver-memory 10G \
        --conf spark.locality.wait.rack=60s \
        NPI_Master.py ;
    else
        echo "no new files present"
fi