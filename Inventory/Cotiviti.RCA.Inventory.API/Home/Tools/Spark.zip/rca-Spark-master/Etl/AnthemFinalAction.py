import argparse

from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.storagelevel import *

sc = SparkContext.getOrCreate()
spark = SparkSession.builder.getOrCreate()

parser = argparse.ArgumentParser()
parser.add_argument("--filepart")
args = parser.parse_args()
if args.filepart:
    filepart = args.filepart

# filepart = 51
new_file = "/rca/Anthem/data/raw/FactClaimHeader/" + str(filepart)

spark.conf.set("spark.sql.avro.compression.codec", "snappy")

dfh = spark.read.parquet("/rca/Anthem/data/raw/parquet/FactClaimHeader")
dfa = dfh.select(
    "CnlyClmJoinKey",
    "ClmAdjstNum",
    "ClmDispCd",
    "ClmRoot",
    "CnlySor",
    to_date("CnlyPaidDt").alias("CnlyPaidDt"),
    "ClmNum"
)
dfan = spark.read\
    .format("avro").load(new_file)
dfAction = dfan.select(
    "CnlyClmJoinKey",
    "ClmAdjstNum",
    "ClmDispCd",
    "ClmRoot",
    "CnlySor",
    "CnlyPaidDt",
    "ClmNum"
).union(dfa).distinct()
dfAction.createOrReplaceTempView("action")

dfActionFinal = spark.sql("""
select
     CnlyClmJoinKey
    ,ClmAdjstNum
    ,ClmDispCd
    ,ClmRoot
    ,CnlySor
    ,CnlyPaidDt
    ,ClmNum
    ,CnlyFinal
    ,CalcAdjstNum - 1 as CalcAdjstNum
    ,claim_original_paid_date
from (
    select
        a.*
        ,case 
            when row_number() over (
                partition by CnlySor, ClmRoot 
                order by 
                    ClmAdjstNum desc
                    ,CnlyPaidDt desc
                    ,case 
                        when ClmDispCd = 'ORGNL' then 1 
                        when ClmDispCd = 'RVRSL' then 2 
                        when ClmDispCd = 'ADJD' then 3 
                        else 4 
                    end desc
                    ,ClmNum desc
                    ,CnlyClmJoinKey desc
            ) = 1 then 1 else 0 end as CnlyFinal
        ,row_number() over (
            partition by CnlySor, ClmRoot 
            order by 
                ClmAdjstNum
                ,CnlyPaidDt
                ,case 
                    when ClmDispCd = 'ORGNL' then 1 
                    when ClmDispCd = 'RVRSL' then 2 
                    when ClmDispCd = 'ADJD' then 3 
                    else 4 
                end
                ,CnlyClmJoinKey
            ) 
            + min(ClmAdjstNum) over (
                partition by CnlySor, ClmRoot) 
        as CalcAdjstNum
        ,first_value(CnlyPaidDt) over (
            partition by CnlySor, ClmRoot
            order by 
                    ClmAdjstNum 
                    ,CnlyPaidDt 
        ) as claim_original_paid_date
    from
        action a
    ) pre
""")

dfActionFinal\
    .repartitionByRange("CnlyClmJoinKey")\
    .write.mode("overwrite")\
    .format("avro").save("/rca/Anthem/data/raw/FactClaimAction/")

spark.stop()
