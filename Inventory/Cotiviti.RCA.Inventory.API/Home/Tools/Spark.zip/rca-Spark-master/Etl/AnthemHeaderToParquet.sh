spark2-submit \
--master yarn \
--deploy-mode cluster \
--name "Anthem Header to Parquet" \
--packages org.apache.spark:spark-avro_2.11:2.4.0 \
--queue root.rcaengdev \
--executor-memory 30G \
--executor-cores 5 \
--driver-memory 10G \
--conf spark.locality.wait.rack=60s \
--conf spark.speculation=true \
--conf spark.speculation.quantile=0.7 \
--conf "spark.yarn.submit.waitAppCompletion=false" \
AnthemHeadertoParquet.py
