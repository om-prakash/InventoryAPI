import subprocess

from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession

sc = SparkContext.getOrCreate()
spark = SparkSession.builder.getOrCreate()

path = "/rca/Anthem/data/raw/parquet/FactClaimHeader"
rebuild_path = path + '_rebuild'
testCmd = "hdfs dfs -test -e "
removeCmd = "hdfs dfs -rm -r "
moveCmd = "hdfs dfs -mv "

blockMB = 512
dictMB = 3
paddMB = 8
block_size = str(blockMB * 1024 * 1024)
dict_size = str(dictMB * 1024 * 1024)
padd_size = str(paddMB * 1024 * 1024)

sc._jsc.hadoopConfiguration().set("dfs.block.size", block_size)
sc._jsc.hadoopConfiguration().set("parquet.block.size", block_size)
sc._jsc.hadoopConfiguration().set("parquet.dictionary.page.size", dict_size)
sc._jsc.hadoopConfiguration().set("parquet.writer.max-padding", padd_size)

df = spark.read.format("avro").load("/rca/Anthem/data/raw/FactClaimHeader/*")
df.createOrReplaceTempView("header")
dfa = spark.read.format("avro").load("/rca/Anthem/data/raw/FactClaimAction/*")
dfa.createOrReplaceTempView("action")

dff = spark.sql("""
SELECT 
    h.CnlyClmJoinKey,a.CnlySor,a.CnlyPaidDt,CnlyClmID,CnlyClmNum,a.ClmNum,a.ClmRoot,ClmAltNum,AdjctDt,ClmSysEntryDt,ClmRecvDt,ClmStmtBegDt,ClmStmtEndDt,ClmSvcBegDt,ClmSvcEndDt,ClmLOS,ClmFormType,
    ClmBillAmtInt,ClmBillAmtOrig,ClmBillAmt,ClmAllowAmtInt,ClmAllowAmtOrig,ClmAllowAmt,CnlyClmAllowAmt,ClmCOBAmtInt,ClmCOBAmtOrig,ClmCOBAmt,ClmCoinsAmtInt,ClmCoinsAmtOrig,ClmCoInsAmt,
    ClmCopayAmtInt,ClmCopayAmtOrig,ClmCoPayAmt,ClmDedAmtInt,ClmDedAmtOrig,ClmDedAmt,ClmNonCovAmtInt,ClmNonCovAmtOrig,ClmNonCovAmt,ClmPaidAmtInt,ClmPaidAmtOrig,ClmPaidAmt,ClmMdcrAllowAmt,
    ClmMdcrDedAmt,ClmMdcrPaidAmt,ClmPayRatio,ClmAllowedRatio,ClmAllowedRatioTrunc,ClmAllowedPerDiem,ClmCheckDt,CapitCd,SrcClmReimbMthdCd,EnrEffDt,EnrTermDt,CnlyPaidTH,ProdExcl,PaidToInd,
    ICDVersionCd,PxCd1,PxCd2,PxCd3,PxCd4,PxCd5,PxCd6,PxCd7,PxCd8,PxCd9,PxCd10,POACd1,POACd2,POACd3,POACd4,POACd5,POACd6,POACd7,POACd8,POACd9,POACd10,AdmitDxCd,ECIDxCd1,ECIDxCd2,ECIDxCd3,
    DxCd1,DxCd2,DxCd3,DxCd4,DxCd5,DxCd6,DxCd7,DxCd8,DxCd9,DxCd10,DxCd11,DxCd12,DxCd13,DxCd14,DxCd15,DxCd16,DxCd17,DxCd18,DxCd19,DxCd20,DxCd21,DxCd22,DxCd23,DxCd24,DxCd25,DxCd26,DxCd27,
    DxCd28,DxCd29,DxCd30,SvrtyOfIlnsCd,DrgCodeVrsnNbr,FnlDRGCd,DRGTypeCd,SbmDRGCd,DRGCd,ExpRuleTypeID,ExpRuleID,ExceptionID,LagDate,ExpDate,GrpNum,GrpName,SubGrpNum,SubGrpName,PurchOrgNum,
    EnrProdCd,EnrCompCd,EnrMBUCd,EnrFundCd,FundType,ProductCd,ProductState,MarketCd,GWFInd_Grp,AdmitDt,AdmitHr,AdmitTypeCd,AdmitSrc,DischDt,DischHr,DischStatCd,LoadID,a.CnlyFinal,a.ClmAdjstNum,
    a.ClmDispCd,CnlyClmNumFrom,ClmAdjstKey,MedRecNum,DocCtlNum,CheckNum,PriorAuthNum,OIIndCd,CnlyLOB,BlueCardCd,CCVLOB,CnlyFEP,GWFInd_LOB,ProvContrCd,ReimbTypeCd,ContrStatCd,ReimbMthdCd,
    NetworkCd,CnlyPar,BillTypeCd,BillClassCd,SvcLocCd,SvcProvRoleCd,CnlyClmType,ClmTypeCd,CnlyClmSetting,CnlyAmbulance,CnlyPsych,CnlySNF,CnlyRehab,CnlyDialysis,CnlyHHA,CnlyCAH,CnlyASC,
    CnlyAIP,CnlySwingBed,CnlyLTC,CnlyMemSor,CnlyMemID,CnlyPersNum,CnlyMemNum,SubNum,SubSeqNum,MemFirstName,MemLastName,MemSex,MemDOB,MemBirthWght,MemZip,MemAltCd,MemSSN,AltMemNum,
    MemMdcrNum,MemReltnID,MemReltnCd,CnlyMemType,MemAddLine1,MemAddLine2,MemCity,MemState,MemPhone,MemKey,CnlyProvSOR,CnlyProvID,CnlyProvNum,ProvTypeCd,SvcCnlyProvID,SvcProvNum,
    SvcProvTaxID,SvcProvNPI,SvcProvName,SvcProvSt,SvcProvTaxonomyCd,BillCnlyProvID,BillProvNum,BillProvTaxID,BillProvNPI,BillProvName,SvcProvZip,ProvMdcrNum 
FROM header h inner join action a on h.CnlyClmJoinKey = a.CnlyClmJoinKey 
""")

dff.repartitionByRange(200, "CnlySor", "CnlyMemID", "CnlyClmJoinKey") \
    .sortWithinPartitions("CnlySor", "CnlyMemID", "CnlyClmJoinKey") \
    .write.mode("overwrite") \
    .parquet(rebuild_path)

chkR = subprocess.call(testCmd + rebuild_path + "/_SUCCESS", shell=True)
if chkR == 0:
    print("rebuild created successfully")
    chkC = subprocess.call(testCmd + path, shell=True)
    if chkC == 0:
        subprocess.call(removeCmd + path, shell=True)
    subprocess.call(moveCmd + rebuild_path + " " + path, shell = True)

spark.stop()
