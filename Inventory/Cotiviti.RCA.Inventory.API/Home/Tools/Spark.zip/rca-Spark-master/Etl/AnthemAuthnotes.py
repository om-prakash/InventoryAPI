import os
import sys

import argparse

from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *

sc = SparkContext.getOrCreate()
spark = SparkSession.builder.getOrCreate()

spark.conf.set("spark.sql.avro.compression.codec", "snappy")

inputpath = "/rca/Anthem/data/raw/sqoop/authnotes/"
outputpath = "/rca/Anthem/data/raw/"
poutputpath = "/rca/Anthem/data/raw/parquet/authnotes/"
refinedpath = "/rca/Anthem/data/refined/"

in_notespath = inputpath + "vAuthNotes/"
in_clmnotespath = inputpath + "vAuthNoteClaims/*"
out_notespath = outputpath + "AuthNotes/"
out_clmnotespath = outputpath + "AuthNoteClaims/"
pout_notespath = poutputpath + "AuthNotes"
pout_clmnotespath = poutputpath + "AuthNoteClaims"

scAuthClms = StructType([StructField("AuthClmID", LongType(), False), StructField("CnlyClmJoinKey", LongType(), False), StructField("ClmNum", StringType(), True),
                         StructField("AuthNum", StringType(), True), StructField("NoteID", LongType(), False), StructField("CnlySOR", ShortType(), False)])

scAuthNotes = StructType([StructField("NoteID", LongType(), False), StructField("CnlySOR", ShortType(), False), StructField("AuthNum", StringType(), True),
                          StructField("AuthSummary", StringType(), True), StructField("AuthNote", StringType(), True), StructField("NoteInputDate", DateType(), True)])

dfNotes = spark.read.schema(scAuthNotes).csv(path=in_notespath, header="false", sep="|")
dfNotes.write.mode("overwrite").format("avro").save(out_notespath)

dfNoteClms = spark.read.schema(scAuthClms).csv(path=in_clmnotespath, header= "false", sep="|")
dfNoteClms.write.mode("overwrite").format("avro").save(out_clmnotespath)

dfNotes = spark.read.format("avro").load(out_clmnotespath)
dfNotes.createOrReplaceTempView("nts")

stopwords = spark.read.csv(path="/rca/Anthem/data/raw/stopwords", header="true")\
    .agg(array_sort(collect_set("stopword")).alias("stopwords"))
stopwords.createOrReplaceTempView("st")

dfNotesScrb = spark.sql("""
select 
     nts.*
    ,ifnull(
        array_remove(
            filter(
                transform(
                    concat(split(lower(AuthNote), ' '), split(lower(AuthSummary), ' ')), 
                x -> regexp_replace(x, '[^a-z0-9]', '')), 
            x -> not array_contains(stopwords, x) and length(x) > 2),
        ''),
    array(null)) as AuthToken
from
    nts
    cross join st
""")


blockMB = 512
dictMB = 3
paddMB = 8
block_size = str(blockMB * 1024 * 1024)
dict_size = str(dictMB * 1024 * 1024)
padd_size = str(paddMB * 1024 * 1024)

sc._jsc.hadoopConfiguration().set("dfs.block.size", block_size)
sc._jsc.hadoopConfiguration().set("parquet.block.size", block_size)
sc._jsc.hadoopConfiguration().set("parquet.dictionary.page.size", dict_size)
sc._jsc.hadoopConfiguration().set("parquet.writer.max-padding", padd_size)

dfNoteClms = spark.read.format("avro").load(out_clmnotespath)

dfNotes.repartition(40).write.mode("overwrite").parquet(pout_notespath)
dfNoteClms.repartition(20).write.mode("overwrite").parquet(pout_clmnotespath)

spark.stop()
