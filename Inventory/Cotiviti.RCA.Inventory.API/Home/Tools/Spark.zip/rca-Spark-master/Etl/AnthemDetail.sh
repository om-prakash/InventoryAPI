
HDIR="/rca/Anthem/data/raw/sqoop/claims/vFactClaimLine"
MAXPATH=$(hdfs dfs -ls -R ${HDIR} | grep "^d" | tail -1 | tr "[:alpha:][:punct:]" ' ' | tr -s ' ' | cut -d' ' -f8 |tr -d ' ')
NEWPATH="$(($MAXPATH + 1))"
UNAME="adam.andrus"
DATASRC="vFactClaimLine"
DEST="$HDIR/$NEWPATH"
SPLIT="CnlyClmJoinKey"
DELIM='|'
CLNT="Wellpoint"
SERV="etl"
DBPART="CnlyClaims"
DB="$CLNT$DBPART"
THREADS="5"
FILTER=" partition = 49 and "
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  --username ${UNAME} --password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} --target-dir ${DEST} \
--null-string '' --null-non-string '' --fetch-size 100000 -m ${THREADS} --split-by ${SPLIT} -- --schema dbo ;

spark2-submit \
--master yarn \
--deploy-mode cluster \
--name "Anthem Detail Raw" \
--packages org.apache.spark:spark-avro_2.11:2.4.0 \
--queue root.rcaengdev \
--executor-memory 20G \
--executor-cores 5 \
--driver-memory 10G \
--conf spark.locality.wait.rack=60s \
--conf spark.speculation=true \
--conf spark.speculation.quantile=0.7 \
--conf "spark.yarn.submit.waitAppCompletion=false" \
AnthemDetail.py --filepart ${NEWPATH}
