import os
import sys

from pyspark.sql.session import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *

spark = SparkSession.builder.getOrCreate()

scAction = StructType([StructField("CnlyClmJoinKey", LongType(), False), StructField("CnlyFinal", IntegerType(), True), StructField("ClmAdjstNum", ShortType(), True), StructField("ClmDispCd", StringType(), True)])

dfAction = spark.read.schema(scAction).csv(path="./Wellpoint/stg/vFactClaimAction", header="false", sep="|")

dfAction.repartition(60).write.mode("overwrite").format("avro").save("./Wellpoint/stg/Claims/vFactClaimAction")

spark.stop()
