spark2-submit \
--master yarn \
--deploy-mode cluster \
--name "Anthem Detail Raw" \
--packages org.apache.spark:spark-avro_2.11:2.4.0 \
--queue root.rcaengdev \
--executor-memory 20G \
--executor-cores 4 \
--driver-memory 15G \
--conf "spark.yarn.submit.waitAppCompletion=false" \
AnthemDetail.py --filepart 44



spark2-submit \
--master yarn \
--deploy-mode cluster \
--name "Anthem Header to Parquet" \
--packages org.apache.spark:spark-avro_2.11:2.4.0 \
--queue root.rcaengdev \
--executor-memory 25G \
--executor-cores 3 \
--driver-memory 15G \
--conf "spark.yarn.submit.waitAppCompletion=false" \
AnthemHeadertoParquet.py



spark2-submit \
--master yarn \
--deploy-mode cluster \
--name "Anthem Detail to Parquet" \
--packages org.apache.spark:spark-avro_2.11:2.4.0 \
--queue root.rcaengdev \
--executor-memory 28G \
--executor-cores 3 \
--driver-memory 15G \
--conf "spark.yarn.submit.waitAppCompletion=false" \
AnthemDetailToParquet.py