import subprocess

from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession
from pyspark.sql.functions import *

sc = SparkContext.getOrCreate()
spark = SparkSession.builder.getOrCreate()

path = '/rca/refined/adjusted_claim/anthem/'
rebuild_path = path + '_rebuild'
testCmd = 'hdfs dfs -test -e '
removeCmd = 'hdfs dfs -rm -r '
moveCmd = 'hdfs dfs -mv '

blockMB = 128
block_size = str(blockMB * 1024 * 1024)

sc._jsc.hadoopConfiguration()\
    .set("dfs.block.size", block_size)\
    .set("parquet.block.size", block_size)

dfh = spark.read.parquet("/rca/refined/claim/anthem/")
dfh.createOrReplaceTempView("hdr")

dfAdjust = spark.sql("""
select
    claim_root_key
from
    hdr
where 
    payment_status != 'R'
group by
    claim_root_key
having 
    count(1) > 1 and sum(final_action_indicator) = 1
""")


dfAdjust.createOrReplaceTempView("adjroot")

df_headermod = spark.sql("""
select
    claim_key
    ,claim_charge_amount
    ,claim_allowed_amount
    ,claim_paid_amount
    ,diagnosis_codes
    ,other_insurance_type
from
    hdr h
    inner join adjroot a
        on h.claim_root_key = a.claim_root_key

""")



dfhMod = spark.sql("select h.CnlySor, a.ClmRootKey, h.CnlyMemID, h.ClmAdjstNum, h.ClmDispCd, h.CnlyFinal, \
                         h.CnlyClmJoinKey, lag(CnlyClmJoinKey) over (partition by a.ClmRootKey order by ClmAdjstNum, CnlyPaidDt, ClmDispCd, CnlyClmJoinKey) as CnlyClmJoinKeyFrom, \
                         first_value(CnlyClmJoinKey) over (partition by a.ClmRootKey order by ClmAdjstNum, CnlyPaidDt, ClmDispCd, CnlyClmJoinKey) as CnlyClmJoinKeyOrig, \
                         h.ClmPaidAmt, lag(ClmPaidAmt) over (partition by a.ClmRootKey order by ClmAdjstNum, CnlyPaidDt, ClmDispCd, CnlyClmJoinKey) as ClmPaidAmtFrom, \
                         first_value(ClmPaidAmt) over (partition by a.ClmRootKey order by ClmAdjstNum, CnlyPaidDt, ClmDispCd, CnlyClmJoinKey) as CnlyPaidAmtOrig, \
                         h.CnlyPaidDt, lag(CnlyPaidDt) over (partition by a.ClmRootKey order by ClmAdjstNum, CnlyPaidDt, ClmDispCd, CnlyClmJoinKey) as CnlyPaidDtFrom,\
                         first_value(CnlyPaidDt) over (partition by a.ClmRootKey order by ClmAdjstNum, CnlyPaidDt, ClmDispCd, CnlyClmJoinKey) as CnlyPaidDtOrig \
                         from hdr h \
                         inner join adjroot a on a.ClmRootKey = sha2(concat_ws('|', h.CnlySor, h.ClmRoot),256) \
                         where ClmDispCd != 'RVRSL' ")

dfhMod.filter("ClmDispCd == 'ADJD' and ClmPaidAmt < ClmPaidAmtFrom") \
    .repartition(8, "ClmRootKey") \
    .sortWithinPartitions("CnlySor", "ClmRootKey", "CnlyPaidDt") \
    .write.mode("overwrite") \
    .parquet("/rca/Anthem/data/raw/parquet/HeaderAdjustmentHistory")

dfhAdj = spark.read.parquet("/rca/Anthem/data/raw/parquet/HeaderAdjustmentHistory")
dfhAdj.createOrReplaceTempView("adjHeader")

dfLine = spark.read.parquet("/rca/Anthem/data/raw/parquet/FactClaimLine")
dfLine.createOrReplaceTempView("line")

dflAdj = spark.sql("select h.CnlySor, h.ClmRootKey, h.CnlyClmJoinKey, h.CnlyClmJoinKeyFrom , count(distinct l.CnlyLnID) as Lns, count(distinct ll.CnlyLnID) as LnsFrom, \
                   count(distinct sha2(concat_ws('|', l.CnlyLnID, l.SvcCd, l.RevCd ),256)) as lnHshCnt, \
                   count(distinct sha2(concat_ws('|', ll.CnlyLnID, ll.SvcCd, ll.RevCd ),256)) as lnHshCntFrom \
                   from adjHeader h \
                   inner join line ll on h.cnlyClmJoinKeyfrom = ll.cnlyclmjoinkey \
                   inner join line l on h.cnlyClmJoinKey = l.cnlyclmjoinkey  \
                   group by h.CnlySor, h.ClmRootKey, h.CnlyClmJoinKey, h.CnlyClmJoinKeyFrom ")

dflAdj.filter("lnHshCnt != lnHshCntFrom or Lns != LnsFrom").repartition(8, "ClmRootKey").write.mode("overwrite") \
    .parquet("./tmpadj")

chkR = subprocess.call(testCmd + rebuild_path + '/_SUCCESS', shell=True)
if chkR == 0:
    print('rebuild created successfully')
    chkC = subprocess.call(testCmd + path, shell=True)
    if chkC == 0:
        subprocess.call(removeCmd + path + 'part*', shell=True)
    subprocess.call(moveCmd + rebuild_path + '/* ' + path, shell = True)
    subprocess.call(removeCmd + rebuild_path, shell = True)

spark.stop()
