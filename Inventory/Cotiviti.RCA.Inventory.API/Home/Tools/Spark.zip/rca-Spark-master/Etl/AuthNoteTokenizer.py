from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.ml.feature import HashingTF, IDF, Tokenizer, CountVectorizer
from pyspark.ml.linalg import Vectors, SparseVector
from pyspark.ml.clustering import LDA, BisectingKMeans

sc = SparkContext.getOrCreate()
spark = SparkSession.builder.getOrCreate()

# stopwords are now maintained in a CSV that can be loaded and modified in the following path
stopwords = spark.read.csv(path = "/rca/Anthem/data/raw/stopwords", header = "true") \
    .agg(array_sort(collect_set("stopword")).alias("stopwords"))
stopwords.createOrReplaceTempView("st")

input_path = "/rca/Anthem/data/raw/AuthNotes/*"
parquet_path = "/rca/Anthem/data/raw/parquet/authnotes/"
notes_path = input_path + "AuthNotes"
claims_path = input_path + "AuthNoteClaims"
notestkn_path = parquet_path = "AuthNotesToken"
cp_path = ""

# Dont run from here unless rebuilding, skip to ML below
dfNotes = spark.read.format("avro").load(input_path)
dfNotes.createOrReplaceTempView("nts")

dfNotesScrb = spark.sql("""
select 
     nts.*
    ,ifnull(
        array_remove(
            filter(
                transform(
                    concat(split(lower(AuthNote), ' '), split(lower(AuthSummary), ' ')), 
                x -> regexp_replace(x, '[^a-z0-9]', '')), 
            x -> not array_contains(stopwords, x) and length(x) > 2),
        ''),
    array(null)) as AuthToken
from
    nts
    cross join st
""")

dfNotesScrb.repartition(40).write.mode("overwrite").parquet(notestkn_path)

# Start here for ML
dfTkn = spark.read.parquet(notestkn_path)

cv = CountVectorizer(inputCol = 'AuthToken', outputCol = 'rawFeatures', vocabSize = 100)
cvmodel = cv.fit(dfTkn)
featurizedData = cvmodel.transform(dfTkn)

vocab = cvmodel.vocabulary
vocab_broadcast = sc.broadcast(vocab)

idf = IDF(inputCol = 'rawFeatures', outputCol = 'features')
idfModel = idf.fit(featurizedData)
rescaledData = idfModel.transform(featurizedData)

# Generate 25 Data-Driven Topics:
lda = LDA(k = 25, seed = 123, optimizer = 'em', featuresCol = 'features')
ldamodel = lda.fit(rescaledData)
ldatopics = ldamodel.describeTopics()

dfTopics = spark.createDataFrame(ldatopics)
