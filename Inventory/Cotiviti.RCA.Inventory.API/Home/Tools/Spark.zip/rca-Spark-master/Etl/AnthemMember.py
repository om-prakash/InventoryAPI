import subprocess

from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

sc = SparkContext.getOrCreate()
spark = SparkSession.builder.getOrCreate()

path = '/rca/Anthem/data/raw/parquet/member/Member'
rebuild_path = path + '_rebuild'
testCmd = 'hdfs dfs -test -e '
removeCmd = 'hdfs dfs -rm -r '
moveCmd = 'hdfs dfs -mv '
temp_raw_path = "./temp_mem_raw_"

blockMB = 256
block_size = str(blockMB * 1024 * 1024)

sc._jsc.hadoopConfiguration().set("dfs.block.size", block_size)
sc._jsc.hadoopConfiguration().set("parquet.block.size", block_size)

scmem = StructType(
    [StructField("CnlyMemSOR", ShortType(), False),
     StructField("CnlyMemID", IntegerType(), False),
     StructField("CnlyMemNum", StringType(), True),
     StructField("MemKey", StringType(), True),
     StructField("SSN", StringType(), True),
     StructField("DOB", DateType(), True),
     StructField("Sex", StringType(), True),
     StructField("FName", StringType(), True),
     StructField("MName", StringType(), True),
     StructField("LName", StringType(), True),
     StructField("SubNum", StringType(), True),
     StructField("SubSeqNum", StringType(), True),
     StructField("RelCd", StringType(), True),
     StructField("RelCdText", StringType(), True),
     StructField("MarStatus", StringType(), True),
     StructField("MarStatusText", StringType(), True),
     StructField("MdcrNum", StringType(), True),
     StructField("MdcdNum", StringType(), True),
     StructField("MCID", LongType(), True),
     StructField("OrigEffDt", DateType(), True),
     StructField("AddType", StringType(), True),
     StructField("AddTypeDesc", StringType(), True),
     StructField("AddrEffDt", DateType(), True),
     StructField("AddrTermDt", DateType(), True),
     StructField("AddLine1", StringType(), True),
     StructField("AddLine2", StringType(), True),
     StructField("City", StringType(), True),
     StructField("State", StringType(), True),
     StructField("ZipCd", StringType(), True),
     StructField("PhoneNum", StringType(), True),
     StructField("PhoneNum2", StringType(), True),
     StructField("EMail", StringType(), True),
     StructField("GrpNum", StringType(), True),
     StructField("SubGrpNum", StringType(), True),
     StructField("PurchOrgNum", StringType(), True),
     StructField("GrpName", StringType(), True),
     StructField("SubGrpName", StringType(), True),
     StructField("HCPrefix", StringType(), True),
     StructField("HCNum", StringType(), True),
     StructField("RecStatus", StringType(), True),
     StructField("ContractType", StringType(), True),
     StructField("UndrWrtRiskCd", StringType(), True),
     StructField("MedCovInd", StringType(), True),
     StructField("RxCovInd", StringType(), True),
     StructField("ProdCd", StringType(), True),
     StructField("ProdDtlCd", StringType(), True),
     StructField("CompCd", StringType(), True),
     StructField("CompSt", StringType(), True),
     StructField("MBUCd", StringType(), True),
     StructField("FundCd", StringType(), True),
     StructField("EnrollmentEffDt", DateType(), True),
     StructField("EnrollmentTermDt", DateType(), True)]
)

sc_memaddress = StructType(
    [StructField("ID", IntegerType(), False),
     StructField("Mem_ID", IntegerType(), False),
     StructField("AddType", StringType(), True),
     StructField("AddLine1", StringType(), True),
     StructField("AddLine2", StringType(), True),
     StructField("City", StringType(), True),
     StructField("State", StringType(), True),
     StructField("ZipCd", StringType(), True),
     StructField("ZipCdPlus4", StringType(), True),
     StructField("PhoneNum", StringType(), True),
     StructField("EMail", StringType(), True)]
)

title_regxp = '^mr |^mrs |^miss |^ms |^mx |^rev |^dr |^sir |^sr |^st |^fr ' \
              '|msgr |[^a-z ]| md$| phd$| dds$| esq$| mba$| cpa$| dc$| ' \
              'od$| ob$'

ssn_validation = "" \
                 "when int(SSN) is null then 1 " \
                 "when length(trim(ifnull(SSN,''))) < 9 then 1 " \
                 "when left(trim(ifnull(SSN,'')),3) in ('000','666') then 1 " \
                 "when int(left(trim(ifnull(SSN,'')),3)) > 899 then 1 " \
                 "when left(trim(ifnull(SSN,'')),5) = '12345' then 1 " \
                 "when right(trim(ifnull(SSN,'')),6) = '000000' then 1 " \
                 "when trim(ifnull(SSN,'')) in (" \
                 "'111223333', '123121234', '222334444', '001010002', " \
                 "'333445555', '444556666', '555667777', '777889999') then 1 "

dfraw = spark.read \
    .schema(scmem) \
    .csv("/rca/Anthem/data/raw/sqoop/member/veMember", header = "false",
         sep = "|"
         )
dfraw.createOrReplaceTempView("raw")
rawsql = """
select 
    *
    ,case 
        when upper(sex) = 'M' then 'M' 
        when upper(sex) = 'F' then 'F' 
        else 'U' 
    end as Sex_Scrubbed
    ,ifnull(MCID,0) as MCID_Scrubbed
    ,case 
        when trim(ifnull(SSN,'')) = '' 
            and length(regexp_replace(mdcrnum, '[^0-9]', '')) = 9
            then regexp_replace(mdcrnum, '[^0-9]', '')
        else trim(ifnull(SSN,''))
    end as SSN_Scrubbed
    ,ifnull(DOB, to_date('01/01/1900','mm/dd/yyyy')) AS DOB_Scrubbed
    ,upper(fname) as FName_Scrubbed
    ,upper(ifnull(mname,'')) as MName_Scrubbed
    ,upper(lname) as LName_Scrubbed
    ,upper(
        regexp_replace(
            regexp_replace(
                concat_ws(' ', 
                    lower(replace(ifnull(FName,''),'.',' ')), 
                    lower(ifnull(MName,' ')), 
                    lower(rtrim(replace(
                        replace(ifnull(LName,''),'.',' '),',',' '
                    )))
                )
                ,'{0}', ' '
            )
            , ' +',' '
        )
    ) as MemName_with_Mid
    ,upper(
        regexp_replace(
            regexp_replace(
                concat_ws(' ', 
                    lower(replace(ifnull(FName,''),'.',' ')), 
                    lower(rtrim(
                        replace(replace(ifnull(LName,''),'.',' '),',',' '
                    )))
                )
                ,'{1}', ' '
            )
            , ' +',' '
        )
    ) as MemName
    ,case 
        when ifnull(DOB, to_date('01/01/1900', 'mm/dd/yyyy'))
            < date_sub(current_date(), (365 * 115)) then 1 
        when DOB >= current_date() then 1 
        else 0 
     end as DOB_Invalid
from
    raw 
""".format(title_regxp, title_regxp)

spark.sql(rawsql) \
    .drop("MCID", "DOB", "Sex", "SSN", "FName", "Lname", "MName") \
    .withColumnRenamed("MCID_Scrubbed", "MCID") \
    .withColumnRenamed("DOB_Scrubbed", "DOB") \
    .withColumnRenamed("Sex_Scrubbed", "Sex") \
    .withColumnRenamed("SSN_Scrubbed", "SSN") \
    .withColumnRenamed("FName_Scrubbed", "FName") \
    .withColumnRenamed("LName_Scrubbed", "LName") \
    .withColumnRenamed("MName_Scrubbed", "MName") \
    .repartition(20, "CnlyMemID") \
    .write \
    .mode("overwrite") \
    .parquet(temp_raw_path)

dfmem = spark.read.parquet(temp_raw_path)
dfmem.createOrReplaceTempView("mem")

agg_sql = """
select
    *
    ,size(array_distinct(array_remove(split(
        ssn_key,''
    ),''))) as ssn_unique_digits
    ,count(ssn_key) over (partition by ssn_key) as ssn_count
    ,approx_count_distinct(mcid_key) 
        over (partition by ssn_key) as ssn_mcid_count
    ,approx_count_distinct(dob_key) 
        over (partition by ssn_key) as ssn_dob_count
    ,approx_count_distinct(memname_key) 
        over (partition by ssn_key) as ssn_memname_count
    ,approx_count_distinct(sex_key) 
        over (partition by ssn_key) as ssn_sex_count
    ,count(mcid_key) over (partition by mcid_key) as mcid_count
    ,approx_count_distinct(ssn_key) 
        over (partition by mcid_key) as mcid_ssn_count
    ,approx_count_distinct(dob_key) 
        over (partition by mcid_key) as mcid_dob_count
    ,approx_count_distinct(memname_key) 
        over (partition by mcid_key) as mcid_memname_count
    ,approx_count_distinct(sex_key) 
        over (partition by mcid_key) as mcid_sex_count
from
    (select
         *
        ,case when case {0} else 0 end = 0 then ssn end as ssn_key
        ,case when mcid > 0 then mcid end as mcid_key
        ,case when DOB_Invalid = 0 then dob end as dob_key
        ,case when memname != '' then memname end as memname_key
        ,case when Sex != 'U' then Sex end as sex_key
        ,concat(case when memname != '' then memname end,
            case when DOB_Invalid = 0 then dob end
        ) as memname_dob_key
    from
        mem ) m
""".format(ssn_validation)

df_agg = spark.sql(agg_sql)
df_agg.createOrReplaceTempView("agg")

dfMemSQL = """
select 
    a.*
    ,case 
        {0}
        when ssn_unique_digits <= 2 then 1
        when ssn_unique_digits in (3, 8, 9) and 
            (ssn_mcid_count = 1 or ssn_dob_count = 1 or ssn_memname_count = 1)
            then 0
        else 0
     end as SSN_Invalid
from 
    agg a
""".format(ssn_validation)

dfMemRaw = spark.sql(dfMemSQL)
dfMemRaw \
    .createOrReplaceTempView("member_raw")

dfMemRaw_Final = spark.sql("""
select
    *
    ,MName as M
    ,case when MCID > 0 then MCIDrnk_p END as MCIDrnk
    ,case when MCID > 0 then MCIDct_p END as MCIDct
    ,case when SSN_Invalid = 0 then SSN end as SSNgrp
    ,case when SSN_Invalid = 0 then SSNRnk_p end as SSNrnk
    ,case when SSN_Invalid = 0 then SSNct_p end as SSNct
    ,case
        when MCID = 0 and DOB_Invalid = 0 then DOBSXgrp_p
        when DOB_Invalid = 0 and MCIDsxct = 1 then DOBgrp_p
        when DOB_Invalid = 0 and MCIDsxct = 2 then DOBSXgrp_p 
    end as DOBgrp
    ,case
        when MCID = 0 and DOB_Invalid = 0 then DOBSXrnk_p
        when DOB_Invalid = 0 and MCIDsxct = 1 then DOBrnk_p
        when DOB_Invalid = 0 and MCIDsxct = 2 then DOBSXrnk_p 
    end as DOBrnk
    ,case
        when MCID = 0 and DOB_Invalid = 0 then DOBSXct_p
        when DOB_Invalid = 0 and MCIDsxct = 1 then DOBct_p
        when DOB_Invalid = 0 and MCIDsxct = 2 then DOBSXct_p
    end as DOBct
from
    (select
         *
        ,row_number() over (
            partition by MCID
            order by SSN_Invalid, DOB_Invalid, length(MemName) desc,
            case when Sex = 'U' then 1 else 0 end, CnlyMemID desc
        ) as MCIDrnk_p
        ,count(1) over (partition by MCID) as MCIDct_p
        ,row_number() over (partition by SSN order by SSN_Invalid,
            DOB_Invalid, case when MCID > 0 then 1 else 0 end desc, 
            length(MemName) desc, case when Sex = 'U' then 1 else 0 end, 
            CnlyMemID desc
        ) as SSNRnk_p
        ,count(1) over (partition by SSN) AS SSNct_p
        ,hash(DOB, array_sort(array(
            left(MemName, 1), left(LName, 1)
        ))) as DOBgrp_p
        ,row_number() over (partition by DOB, array_sort(array(
            left(MemName, 1), left(LName, 1)
        )) order by SSN_Invalid, DOB_Invalid, 
        case when MCID > 0 then 1 else 0 end desc, 
        length(MemName) desc, CnlyMemID desc
        ) as DOBrnk_p
        ,count(*) over (partition by DOB, array_sort(array(
            left(MemName, 1), left(LName, 1)
        ))) as DOBct_p
        ,hash(sex, DOB, array_sort(array(
            left(MemName, 1), left(LName, 1)
        ))) as DOBSXgrp_p
        ,row_number() over (partition by sex, DOB, array_sort(array(
            left(MemName, 1), left(LName, 1)
        )) order by SSN_Invalid, DOB_Invalid, 
        case when MCID > 0 then 1 else 0 end desc, 
        length(MemName) desc, CnlyMemID desc
        ) as DOBSXrnk_p
        ,count(*) over (partition by sex, DOB, array_sort(array(
            left(MemName, 1), left(LName, 1)
        ))) as DOBSXct_p
        ,max(case when Sex = 'M' then 1 else 0 end) over (partition by MCID) 
        + max(case when Sex = 'F' then 1 else 0 end) over (partition by MCID)
        as MCIDsxct
    FROM
        member_raw) m
""")

dfMemRaw_Final \
    .drop("MCIDct_p", "MCIDrnk_p", "SSNrnk_p", "SSNct_p", "DOBgrp_p",
          "DOBrnk_p", "DOBct_p", "DOBSXgrp_p", "DOBSXrnk_p", "DOBSXct_p",
          "SCC", "SCCL"
          ) \
    .repartition(15, "MCID", "DOB") \
    .write.mode("overwrite") \
    .parquet(rebuild_path)

chkR = subprocess.call(testCmd + rebuild_path + "/_SUCCESS", shell = True)
if chkR == 0:
    print("rebuild created successfully")
    chkC = subprocess.call(testCmd + path, shell = True)
    if chkC == 0:
        subprocess.call(removeCmd + path, shell = True)
    subprocess.call(moveCmd + rebuild_path + " " + path, shell = True)

dfmem_base = spark.read.parquet(path)
dfmem_base.createOrReplaceTempView("base")

dfmem_master = spark.sql("""
select 
    MCID
from
    base
where 
    MCIDct > 1
group by
    MCID
having
    (
        (count(distinct SSNgrp) <= 1  and count(distinct MemName) = 1) 
        or (count(distinct SSNgrp) <= 1  and count(distinct MemName) >= 1)
    )
    and 
    and max(MCIDsxct) = 1
    and count(distinct DOBgrp) <= 1
""")
dfmem_master.createOrReplaceTempView("master")

patient_base = spark.sql("""
select 
     max(case 
        when b.MCIDrnk = 1 then b.CnlyMemID 
        else 0 
    end) over (partition by b.MCID) as patient_key
    ,b.CnlyMemID as member_key
    ,b.MemName as patient_name
    ,b.SSN as member_submitted_ssn
    ,case when ssn_dob_count <= 1 and ssn_memname_count <= 1 
        and MCIDrnk = 1 then b.SSNgrp end as patient_ssn
    ,case 
        when b.DOBgrp is not null then b.DOB 
    end as patient_birth_date
    ,MCIDrnk as sequence_id
    ,1 as parent_sequence_id
from 
    base b 
where 
    MCIDct > 1 and mcid_sex_count <= 1 and 
        (mcid_ssn_count <= 1 
        or (mcid_dob_count <= 1 
        and mcid_memname_count <= 1))

    """)

spark.stop()
