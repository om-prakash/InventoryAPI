import os
import sys

import argparse

from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *

sc = SparkContext.getOrCreate()
spark = SparkSession.builder.getOrCreate()

parser = argparse.ArgumentParser()
parser.add_argument("--filepart")
args = parser.parse_args()
if args.filepart:
    filepart = args.filepart

spark.conf.set("spark.sql.avro.compression.codec", "snappy")

inputclmpath = "/rca/Anthem/data/raw/sqoop/claims/"
outputpath = "/rca/Anthem/data/raw/"
refinedpath = "/rca/Anthem/data/refined"

linepath = inputclmpath + "vFactClaimLine/" + str(filepart)
lineout = outputpath + "factclaimline/" + str(filepart)

scline = StructType(
                   [StructField("CnlyClmJoinKey", LongType(), False),
                    StructField("CnlyLnID", IntegerType(), False),
                    StructField("CnlyLnNum", StringType(), True),
                    StructField("LnSvcBegDt", DateType(), True),
                    StructField("LnSvcEndDt", DateType(), True),
                    StructField("LnLOS", IntegerType(), True),
                    StructField("PgybkClmCd", IntegerType(), False),
                    StructField("SvcAltCdID", IntegerType(), True),
                    StructField("AdjctDocLvlCd", IntegerType(), False),
                    StructField("BillUnits", IntegerType(), True),
                    StructField("PaidUnits", IntegerType(), True),
                    StructField("CnlyUnits", IntegerType(), True),
                    StructField("BillAmtInt", DecimalType(18, 2), True),
                    StructField("CnlyAllowPerUnit", DecimalType(38, 20), True),
                    StructField("CnlyBillPerUnit", DecimalType(38, 21), True),
                    StructField("BillAmtOrig", DecimalType(18, 2), True),
                    StructField("BillAmt", DecimalType(18, 2), True),
                    StructField("AllowAmtInt", DecimalType(18, 2), True),
                    StructField("AllowAmtOrig", DecimalType(18, 2), True),
                    StructField("AllowAmt", DecimalType(18, 2), True),
                    StructField("CnlyAllowAmt", DecimalType(18, 2), True),
                    StructField("PaidAmtInt", DecimalType(18, 2), True),
                    StructField("PaidAmtOrig", DecimalType(18, 2), True),
                    StructField("PaidAmt", DecimalType(18, 2), True),
                    StructField("CnlyPaidAmt", DecimalType(18, 2), True),
                    StructField("COBAmtInt", DecimalType(18, 2), True),
                    StructField("COBAmtOrig", DecimalType(18, 2), True),
                    StructField("COBAmt", DecimalType(18, 2), True),
                    StructField("CoInsAmtInt", DecimalType(18, 2), True),
                    StructField("CoInsAmtOrig", DecimalType(18, 2), True),
                    StructField("CoInsAmt", DecimalType(18, 2), True),
                    StructField("CopayAmtInt", DecimalType(18, 2), True),
                    StructField("CopayAmtOrig", DecimalType(18, 2), True),
                    StructField("CoPayAmt", DecimalType(18, 2), True),
                    StructField("DedAmtInt", DecimalType(18, 2), True),
                    StructField("DedAmtOrig", DecimalType(18, 2), True),
                    StructField("DedAmt", DecimalType(18, 2), True),
                    StructField("NonCovAmtInt", DecimalType(18, 2), True),
                    StructField("NonCovAmtOrig", DecimalType(18, 2), True),
                    StructField("NonCovAmt", DecimalType(18, 2), True),
                    StructField("PayRatio", DecimalType(18, 2), True),
                    StructField("MdcrAllowAmt", DecimalType(18, 2), True),
                    StructField("MdcrDedAmt", DecimalType(18, 2), True),
                    StructField("MdcrPaidAmt", DecimalType(18, 2), True),
                    StructField("FFSEquivAmt", DecimalType(18, 2), True),
                    StructField("ContrEffDt", DateType(), True),
                    StructField("ContrEndDt", DateType(), True),
                    StructField("CnlyLnPaidTH", IntegerType(), False),
                    StructField("AdjctType", StringType(), True),
                    StructField("AdjctStat", StringType(), True),
                    StructField("CnlyAdjstNum", ShortType(), False),
                    StructField("ClmAdjstNum", ShortType(), False),
                    StructField("ClmDispCd", StringType(), True),
                    StructField("LnStatCd", StringType(), True),
                    StructField("AdjstRsnCd", StringType(), True),
                    StructField("SvcTypeCd", StringType(), True),
                    StructField("SvcLocCd", StringType(), True),
                    StructField("SvcCd", StringType(), True),
                    StructField("ModifierCd1", StringType(), True),
                    StructField("ModifierCd2", StringType(), True),
                    StructField("ModifierCd3", StringType(), True),
                    StructField("ModifierCd4", StringType(), True),
                    StructField("RevCd", StringType(), True),
                    StructField("RevCdGrp", StringType(), True),
                    StructField("NDCCd", StringType(), True),
                    StructField("ProvContrCd", StringType(), True),
                    StructField("ReimbTypeCd", StringType(), True),
                    StructField("ContrStatCd", StringType(), True),
                    StructField("ReimbMthdCd", StringType(), True),
                    StructField("NetworkCd", StringType(), True),
                    StructField("CnlyPar", StringType(), True),
                    StructField("LineFeeSchedCd", StringType(), True),
                    StructField("FeeSchedCd", StringType(), True),
                    StructField("Partition", IntegerType(), False)])

spark.read\
    .schema(scline)\
    .csv(path=linepath, header="false", sep="|")\
    .write.mode("overwrite")\
    .format("avro")\
    .save(lineout)

spark.stop()
