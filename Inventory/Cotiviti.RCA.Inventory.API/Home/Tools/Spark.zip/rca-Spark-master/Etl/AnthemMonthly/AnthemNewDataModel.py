import subprocess

from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *

sc = SparkContext.getOrCreate()
spark = SparkSession.builder.getOrCreate()

path = '/rca/refined/claim/anthem/'
rebuild_path = path + '_rebuild'
testCmd = 'hdfs dfs -test -e '
removeCmd = 'hdfs dfs -rm -r '
moveCmd = 'hdfs dfs -mv '

blockMB = 512
dictMB = 3
paddMB = 8
block_size = str(blockMB * 1024 * 1024)
dict_size = str(dictMB * 1024 * 1024)
padd_size = str(paddMB * 1024 * 1024)

sc._jsc.hadoopConfiguration().set('dfs.block.size', block_size)
sc._jsc.hadoopConfiguration().set('parquet.block.size', block_size)
sc._jsc.hadoopConfiguration().set('parquet.dictionary.page.size', dict_size)
sc._jsc.hadoopConfiguration().set('parquet.writer.max-padding', padd_size)

spark.conf.set('spark.sql.shuffle.partitions', 300)

df = spark.read.format('avro').load('/rca/Anthem/data/raw/FactClaimHeader/*')
dfh = df.withColumn("dxcds", expr("""
    upper(concat_ws(' ',
        regexp_replace(DxCd1,  '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd2,  '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd3,  '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd4,  '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd5,  '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd6,  '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd7,  '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd8,  '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd9,  '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd10, '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd11, '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd12, '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd13, '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd14, '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd15, '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd16, '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd17, '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd18, '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd19, '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd20, '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd21, '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd22, '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd23, '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd24, '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd25, '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd26, '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd27, '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd28, '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd29, '[^A-Za-z0-9]', ''),
        regexp_replace(DxCd30, '[^A-Za-z0-9]', '')))
    """)).withColumn("poacds", expr("""
        upper(concat_ws(' ',
            regexp_replace(ifnull(POACd1, 'U'), '[^YyNnUuWw1]', 'U'),
            regexp_replace(ifnull(POACd2, 'U'), '[^YyNnUuWw1]', 'U'),
            regexp_replace(ifnull(POACd3, 'U'), '[^YyNnUuWw1]', 'U'),
            regexp_replace(ifnull(POACd4, 'U'), '[^YyNnUuWw1]', 'U'),
            regexp_replace(ifnull(POACd5, 'U'), '[^YyNnUuWw1]', 'U'),
            regexp_replace(ifnull(POACd6, 'U'), '[^YyNnUuWw1]', 'U'),
            regexp_replace(ifnull(POACd7, 'U'), '[^YyNnUuWw1]', 'U'),
            regexp_replace(ifnull(POACd8, 'U'), '[^YyNnUuWw1]', 'U'),
            regexp_replace(ifnull(POACd9, 'U'), '[^YyNnUuWw1]', 'U'),
            regexp_replace(ifnull(POACd10,'U'), '[^YyNnUuWw1]', 'U'),
        'U','U','U','U','U','U','U','U','U','U',
        'U','U','U','U','U','U','U','U','U','U'))
    """)).withColumn("pxcds", expr("""
        upper(concat_ws(' ',
            regexp_replace(PxCd1, '[^A-Za-z0-9]', ''),
            regexp_replace(PxCd2, '[^A-Za-z0-9]', ''),
            regexp_replace(PxCd3, '[^A-Za-z0-9]', ''),
            regexp_replace(PxCd4, '[^A-Za-z0-9]', ''),
            regexp_replace(PxCd5, '[^A-Za-z0-9]', ''),
            regexp_replace(PxCd6, '[^A-Za-z0-9]', ''),
            regexp_replace(PxCd7, '[^A-Za-z0-9]', ''),
            regexp_replace(PxCd8, '[^A-Za-z0-9]', ''),
            regexp_replace(PxCd9, '[^A-Za-z0-9]', ''),
            regexp_replace(PxCd10, '[^A-Za-z0-9]', '')))
    """)).withColumn("edxcds", expr("""
        upper(concat_ws(' ',
            regexp_replace(ECIDxCd1, '[^A-Za-z0-9]', ''),
            regexp_replace(ECIDxCd2, '[^A-Za-z0-9]', ''),
            regexp_replace(ECIDxCd3, '[^A-Za-z0-9]', '')))
    """))
dfh.createOrReplaceTempView('header')
dfa = spark.read.format('avro')\
    .load('/rca/Anthem/data/raw/FactClaimAction/*')
dfa.createOrReplaceTempView('action')
df = spark.read.format('avro')\
    .load('/rca/Anthem/data/raw/factclaimline/*')
df.createOrReplaceTempView('line')
dfSor = spark.read\
    .parquet('/rca/Anthem/data/raw/parquet/dimensions/vDimClmSORCd')
dfSor.createOrReplaceTempView('platform')
dfloads = spark.read\
    .parquet('/rca/Anthem/data/raw/parquet/dimensions/vDataLoads')
dfloads.createOrReplaceTempView('dl')
dfmemrel = spark.read\
    .parquet("/rca/Anthem/data/raw/parquet/dimensions/vDimMemReltnCd")
dfmemrel.createOrReplaceTempView('mr')
dfadj = spark.read\
    .parquet("/rca/Anthem/data/raw/parquet/dimensions/vDimAdjstRsnCd")
dfadj.createOrReplaceTempView("adjr")

dfheader = spark.sql("""
SELECT
    concat_ws('_', 
        reverse(string(CnlyMemID)), 
        '1', 
        a.CnlySor, 
        year(ClmSvcBegDt), 
        case 
            when a.CnlySor in (822,824) then a.ClmNum 
            else a.Clmroot 
        end, 
        CalcAdjstNum
    ) as claim_key
    ,concat_ws('_', 
        reverse(string(CnlyMemID)), 
        '1', a.CnlySor, 
        year(ClmSvcBegDt), 
        case 
            when a.CnlySor in (822,824) then a.ClmNum 
            else a.Clmroot 
        end
    ) as claim_root_key
    ,1 as client_key
    ,'ANTHEM' as client_name
    ,a.CnlySor as client_platform_id
    ,upper(trim(p.description)) as client_platform_name
    ,ClmRecvDt as client_received_date
    ,ifnull(dl.LoadStartDt,date(current_date())) as claim_load_date
    ,a.ClmNum as client_claim_id
    ,map(
        'cnlyclaimnum', cnlyclmnum, 
        'cnlyclaimnumfrom', cnlyclmnumfrom, 
        'cnlyclmid', cnlyclmid, 
        'cnlyclmjoinkey', a.cnlyclmjoinkey, 
        'claimadjustmentind', clmadjstkey
    ) as legacy_sys_ids
    ,upper(BlueCardCd) as its_bluecard_claim_type
    ,DocCtlNum as document_control_number
    ,case when CnlyClmType = 1 then 'F' else 'P' end as claim_type
    ,case SvcProvRoleCd 
        when 'DENTL' then 'DENTAL' 
        when 'FANCL' then 'FACILITY ANCILLARY'
        when 'HOSP'  then 'HOSPITAL'
        when 'PANCL' then 'PROFESSIONAL ANCILLARY'
        when 'PHYSN' then 'PHYSICIAN'
        when 'VISON' then 'VISION'
        when 'PHMCY' then 'PHARMACY'
        else 'UNKNOWN'
     end as claim_service_rendering_type
    ,case 
        when CnlyFEP = 1 then 'FEP' 
        when CCVLOB = 'MMP' then 'DUAL' 
        else upper(CnlyLOB) 
    end as insurance_lob
    ,EnrMBUCd as client_lob
    ,case 
        when EnrFundCd = '60' then 'NR' 
        when EnrFundCd in ('45','90','91','92') then 'ASO' 
        when FundType in ('FI','SI') then FundType 
        else 'UKN' 
    end as funding_type
    ,case 
        when ClmFormType = 'PA' then 'P' 
        WHEN ClmFormType = 'EL' then 'E' 
        else 'U' 
    end claim_submission_type
    ,right(
        concat(
            '0000', 
            case 
                when BillTypeCd not in ('000') 
                and length(regexp_replace(BillTypeCd,'[^A-Za-z0-9]', '')) > 2 
                    then upper(BillTypeCd) 
            end
        ), 4
    ) as type_of_bill_code
    ,right(
        case 
            when BillTypeCd not in ('000') 
            and length(regexp_replace(BillTypeCd,'[^A-Za-z0-9]', '')) > 2 
                then upper(BillTypeCd) 
        end, 1
    ) as type_of_bill_frequency_code
    ,ClmSvcBegDt as claim_service_from_date
    ,ClmSvcEndDt as claim_service_to_date
    ,case 
        when CnlyClmSetting = 1 then 'INPATIENT' 
        ELSE 'OUTPATIENT' 
    end as claim_setting_type
    ,case 
        when AdmitDt > '2000-01-01' and AdmitDt < ClmRecvDt then AdmitDt 
    end as admission_date
    ,case when AdmitHr < 24 then AdmitHr end as admission_hour
    ,int(null) as admission_minute
    ,case 
        when AdmitTypeCd in ('1','2','3','4','5','6','7','8','9') 
            then smallint(AdmitTypeCd) 
    end as admission_type_code
    ,nullif(
        regexp_replace(AdmitSrc,'[^A-Za-z0-9]', ''), ''
    ) as admission_source_code
    ,case 
        when DischDt > '2000-01-01' and DischDt < current_date() 
            then DischDt 
    end discharge_date
    ,case when DischHr < 24 then DischHr end as discharge_hour
    ,int(null) as discharge_minute
    ,DischStatCd as discharge_status_code
    ,ClmLOS as length_of_stay
    ,case when CapitCd is not null then 0 else 1 end as capitation_indicator
    ,case 
        when OIIndCd in ('OTHIN', 'OTHNW', 'MDCR') then 1
        when ClmCOBAmt > 0.0 then 1  
        else 0 
    end as cob_indicator
    ,case OIIndCd 
        when 'AUTO' then 'AUTO'
        when 'GLIAB' then 'GENERAL LIABILITY'
        when 'HMOWN' then 'HOME OWNERS'
        when 'MDCR' then 'MEDICARE PRIMARY'
        when 'NOFLT' then 'NO FAULT'
        when 'OTHIN' then 'OTHER INSURANCE PRIMARY'
        when 'OTHNW' then 'OTHER INSURANCE PRIMARY'
        when 'SUBRO' then 'SUBROGATION'
        when 'WCOMP' then 'WORKERS COMPENSATION'
        when 'WLP' then 'CLIENT PRIMARY'
        else 'UNKNOWN'
    end as other_insurance_type
    ,case when ReimbMthdCd = 'BDRG' then 1 else 0 end as paid_by_drg_indicator
    ,PriorAuthNum as prior_authorization_number
    ,case 
        when CnlyPar = 'P' then 1 
        else 0 
    end as billing_provider_in_network_indicator
    ,BillCnlyProvID as billing_provider_key
    ,BillProvNum as billing_provider_client_id
    ,BillProvTaxID as billing_provider_tax_id
    ,BillProvNPI as billing_provider_npi
    ,BillProvName as billing_provider_full_name
    ,ProvContrCd as billing_provider_contract_id
    ,ReimbTypeCd as billing_provider_negotiated_service_term_id
    ,SvcCnlyProvID as rendering_provider_key
    ,SvcProvNum as rendering_provider_client_id
    ,ProvMdcrNum as rendering_provider_medicare_id
    ,SvcProvTaxID as rendering_provider_tax_id
    ,SvcProvNPI as rendering_provider_npi
    ,SvcProvName as rendering_provider_full_name
    ,SvcProvSt as rendering_provider_state
    ,SvcProvZip as rendering_provider_zip
    ,SvcProvTaxonomyCd as rendering_provider_taxonomy_code
    ,CnlyMemID as patient_key
    ,CnlyMemNum as patient_member_id
    ,SubSeqNum as patient_dependent_id
    ,ifnull(mr.MemReltnCd, 'UNKNOWN') as patient_relationship_to_subscriber   
    ,case         
        when MedRecNum like concat('%', 
            regexp_replace(MemFirstName, '[^A-Za-z0-9]', ''), '%') 
            then MedRecNum
        when MedRecNum like concat('%',
            regexp_replace(MemLastName, '[^A-Za-z0-9]', ''), '%') 
            then MedRecNum 
        when replace(MedRecNum,' ','') like 'ITSHOSTCMF%' then null
        when regexp_replace(MedRecNum, '[0]', '') = '' then null
        when regexp_replace(MedRecNum, '[9]', '') = '' then null
        when regexp_replace(MedRecNum, '[1]', '') = '' then null
        when regexp_replace(MedRecNum, '[123]', '') = '' then null
        when length(MedRecNum) < 5 then null
        when regexp_replace(MedRecNum, '[^0-9]','') = '' then null
        else MedRecNum
    end as patient_medical_record_number
    ,MemMdcrNum as patient_medicare_id
    ,MemSSN as patient_ssn
    ,MemFirstName as patient_first_name
    ,MemLastName as patient_last_name
    ,MemAddLine1 as patient_address_01
    ,MemAddLine2 as patient_address_02
    ,MemCity as patient_city
    ,MemState as patient_state
    ,MemZip as patient_zip
    ,MemDOB as patient_birth_date
    ,case 
        when upper(MemSex) in ('M','F') then upper(MemSex) 
        else 'U' 
    end as patient_gender
    ,MemBirthWght as patient_birth_weight
    ,SubNum as subscriber_client_id
    ,GrpNum as employer_group_number
    ,GrpName as employer_group_name
    ,PurchOrgNum as employer_sub_group_number
    ,SubGrpName as employer_sub_group_name
    ,EnrProdCd as benefit_plan_code
    ,ProductCd as benefit_product_code
    ,MarketCd as benefit_class_code
    ,SbmDRGCd as submitted_drg_code
    ,SvrtyOfIlnsCd as submitted_drg_severity_of_illness
    ,FnlDRGCd as allowed_drg_code
    ,DRGTypeCd as allowed_drg_grouper_id
    ,DrgCodeVrsnNbr as allowed_drg_grouper_version 
    ,upper(
        case 
            when length(regexp_replace(AdmitDxCd, '[^A-Za-z0-9]', '')) > 3 
                then concat(
                    left(regexp_replace(AdmitDxCd, '[^A-Za-z0-9]', ''), 3),
                    '.',
                    substring(regexp_replace(AdmitDxCd, '[^A-Za-z0-9]', ''), 4)
                ) 
            else regexp_replace(AdmitDxCd , '[^A-Za-z0-9]', '') 
        end
    ) as admitting_diagnosis_code
    ,ICDVersionCd as icd_version_code
    ,upper(
        case when length(regexp_replace(DxCd1, '[^A-Za-z0-9]', '')) > 3 
            then concat(
                left(regexp_replace(DxCd1 , '[^A-Za-z0-9]', ''),3),
                '.',
                substring(regexp_replace(DxCd1 , '[^A-Za-z0-9]', ''),4)
            ) 
            else regexp_replace(DxCd1 , '[^A-Za-z0-9]', '')
        end
    ) as primary_diagnosis_code
    ,transform(
        split(dxcds, ' '), x -> 
            case 
                when length(x) > 3 
                    then concat(left(x, 3), '.', substring(x, 4)) 
                else x 
            end    
    ) as diagnosis_codes
    ,case 
        when element_at(split(dxcds, ' '), 1) = '' then array(null) 
        else slice(split(poacds, ' '), 1, size(split(dxcds, ' '))
    ) end as poa_codes
    ,transform(
        split(edxcds, ' '), x -> 
            case 
                when length(x) > 3 
                    then concat(left(x, 3), '.', substring(x, 4)) 
                else x 
            end 
    ) as external_cause_of_injury_codes
    ,split(pxcds, ' ') as pcs_procedure_codes
    ,AdjctDt as adjudicated_date
    ,a.CnlyPaidDt as claim_paid_date
    ,a.claim_original_paid_date as claim_original_paid_date
    ,ClmCheckDt as check_date
    ,case when a.ClmDispCd = 'RVRSL' then 'R' else 'P' end as payment_status
    ,case ReimbMthdCd
        when 'CASE' then 'CASE RATE'
        when 'DISC' then 'DISCOUNT'
        when 'BDRG' then 'DRG'
        when 'FEE' then 'FEE FOR SERVICE'
        when 'PDIEM' then 'PER DIEM'
        when 'STRGT' then 'STRAIGHT CHARGES'
        else 'UNKNOWN'
     end as payment_method
    ,case 
        when PaidToInd = 1 then 'PROVIDER' 
        else 'SUBSCRIBER' 
    end as paid_to_code
    ,CheckNum as check_number
    ,ClmBillAmt as claim_charge_amount
    ,CnlyClmAllowAmt as claim_allowed_amount
    ,ClmMdcrAllowAmt as claim_cob_allowed_amount
    ,ClmCoInsAmt as claim_coinsurance_amount
    ,ClmCoInsAmt as claim_cob_coinsurance_amount
    ,ClmCOBAmt as claim_cob_paid_amount
    ,ClmCoPayAmt as claim_copay_amount
    ,ClmDedAmt as claim_deductible_amount
    ,ClmDedAmt + ClmCoPayAmt + ClmCoInsAmt as claim_patient_liability_amount
    ,ClmPaidAmtInt as claim_paid_amount
    ,ClmNonCovAmt as claim_non_covered_amount
    ,CalcAdjstNum as claim_sequence_rank
    ,CnlyFinal as final_action_indicator
    
    ,h.CnlyClmJoinKey   
FROM 
    header h 
    inner join action a on h.CnlyClmJoinKey = a.CnlyClmJoinKey
    inner join platform p on h.CnlySor = p.ClmSOR
    left join dl on h.loadid = dl.loadid
    left join mr on h.MemReltnCd = mr.MemReltnCd
""")
dfheader.createOrReplaceTempView("h")

dfline = spark.sql("""
SELECT
     array_sort(
        collect_list(
            struct(
                CnlyLnID as line_number
                ,LnSvcBegDt as line_service_from_date
                ,LnSvcEndDt as line_service_to_date
                ,LnLOS as line_length_of_service
                ,case
                    when CnlyPar = 'P' then 1
                    else 0
                end as line_in_network_indicator
                ,ReimbTypeCd as line_negotiated_service_term_id
                ,case
                    when length(SvcLocCd) = 2
                    and length(regexp_replace(SvcLocCd, '[^0-9]', '')) = 2
                        then SvcLocCd
                    else 'UNK'
                end as line_place_of_service_code
                ,upper(nullif(SvcCd,'UNK')) as line_cpt_hcpcs_code
                ,array_remove(array_remove(split(concat_ws(' ',
                    ModifierCd1, ModifierCd2, ModifierCd3, ModifierCd4
                ),' '),''),'UNK') as line_cpt_hcpcs_modifier
                ,RevCd as line_revenue_code
                ,case
                    when ad.AdjstRsnCd is not null
                        then upper(trim(ad.description))
                    else 'UNKNOWN'
                end as line_adjustment_reason
                ,case
                    when trim(LnStatCd) = 'VOID' then 'VOIDED'
                    when trim(LnStatCd) = 'DND' then 'DENIED'
                    when trim(LnStatCd) = 'WARN' then 'WARN'
                    when trim(LnStatCd) = 'PND' then 'PENDED'
                    when trim(LnStatCd) = 'PD' then 'PAID'
                    when trim(LnStatCd) = 'PEND' then 'PENDED'
                    when trim(LnStatCd) = 'APRVD' then 'APPROVED'
                    when trim(LnStatCd) = 'APRZB' then 'APPROVED ZERO BALANCE'
                    when trim(LnStatCd) = 'DNDZB' then 'DENIED ZERO BALANCE'
                    else 'UNKNOWN'
                 end as line_payment_status
                ,case ReimbMthdCd
                    when 'CASE' then 'CASE RATE'
                    when 'DISC' then 'DISCOUNT'
                    when 'BDRG' then 'DRG'
                    when 'FEE' then 'FEE FOR SERVICE'
                    when 'PDIEM' then 'PER DIEM'
                    when 'STRGT' then 'STRAIGHT CHARGES'
                    else 'UNKNOWN'
                 end as line_payment_method
                ,LineFeeSchedCd as line_fee_schedule_code
                ,BillAmt as line_charge_amount
                ,CnlyAllowAmt as line_allowed_amount
                ,MdcrAllowAmt as line_cob_allowed_amount
                ,CoInsAmt as line_coinsurance_amount
                ,CoInsAmt as line_cob_coinsurance_amount
                ,COBAmt as line_cob_paid_amount
                ,CoPayAmt as line_copay_amount
                ,DedAmt as line_deductible_amount
                ,DedAmt + CoPayAmt + CoInsAmt as line_patient_liability_amount
                ,CnlyPaidAmt as line_paid_amount
                ,NonCovAmt as line_non_covered_amount
                ,FFSEquivAmt as line_fee_service_amount
                ,BillUnits as line_submitted_units
                ,CnlyUnits as line_paid_units
                ,NDCCd as line_submitted_ndc
            )
        )
    ) as claim_detail

    ,CnlyClmJoinKey

from
    line l
    left join adjr ad on l.AdjstRsnCd = ad.AdjstRsnCd
group by
    CnlyClmJoinKey
    """)
dfline.createOrReplaceTempView("l")

dff = spark.sql("""
select
     h.*
    ,array_min(
        claim_detail.line_place_of_service_code
    ) as claim_place_of_service_code
    ,l.claim_detail
from
    h inner join l on h.CnlyClmJoinKey = l.CnlyClmJoinKey
""")

dff.drop("CnlyClmJoinKey")\
    .repartition(300, "client_platform_id", "patient_key")\
    .sortWithinPartitions("claim_root_key")\
    .write.mode('overwrite')\
    .parquet(rebuild_path)

chkR = subprocess.call(testCmd + rebuild_path + '/_SUCCESS', shell=True)
if chkR == 0:
    print('rebuild created successfully')
    chkC = subprocess.call(testCmd + path, shell=True)
    if chkC == 0:
        subprocess.call(removeCmd + path + 'part*', shell=True)
    subprocess.call(moveCmd + rebuild_path + '/* ' + path, shell = True)
    subprocess.call(removeCmd + rebuild_path, shell = True)

spark.stop()
