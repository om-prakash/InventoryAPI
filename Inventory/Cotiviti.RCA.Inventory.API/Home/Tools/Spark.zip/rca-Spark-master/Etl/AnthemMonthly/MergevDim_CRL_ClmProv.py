import subprocess

from pyspark.sql.session import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *

spark = SparkSession.builder.getOrCreate()

spark.conf.set("spark.sql.avro.compression.codec", "snappy")
input_dim_path = "/rca/Anthem/data/raw/sqoop/dimensions/vDim_CRL_ClmProv"
temp_path = input_dim_path + "_temp"
rebuild_path = input_dim_path + "_rebuild"
old_path = input_dim_path + "_old"
testCmd = "hdfs dfs -test -e "
removeCmd = "hdfs dfs -rm -r "
moveCmd = "hdfs dfs -mv "

scCPrv = StructType(
    [StructField("CRL_ClmProv_ID", IntegerType(), False),
     StructField("CnlyProvSOR", ShortType(), False),
     StructField("CnlyProvID", IntegerType(), False),
     StructField("CnlyProvNum", StringType(), False),
     StructField("ProvTypeCd", StringType(), False),
     StructField("SvcProvClmID", IntegerType(), False),
     StructField("SvcCnlyProvID", IntegerType(), False),
     StructField("SvcProvNum", StringType(), False),
     StructField("SvcProvTaxID", StringType(), False),
     StructField("SvcProvNPI", StringType(), False),
     StructField("SvcProvName", StringType(), False),
     StructField("SvcProvStID", ShortType(), False),
     StructField("SvcProvSt", StringType(), True),
     StructField("SvcProvTaxonomyCd", StringType(), False),
     StructField("BillProvClmID", IntegerType(), False),
     StructField("BillCnlyProvID", IntegerType(), False),
     StructField("BillProvNum", StringType(), False),
     StructField("BillProvTaxID", StringType(), False),
     StructField("BillProvNPI", StringType(), False),
     StructField("BillProvName", StringType(), False),
     StructField("SvcProvZip", StringType(), True),
     StructField("ProvMdcrNum", StringType(), False)])
    
dfcPrvTemp = spark.read.schema(scCPrv)\
    .csv(path=temp_path, header="false", sep="|")
dfcPrv = spark.read.format("avro").load(path=input_dim_path)

dfcPrvCombined = dfcPrvTemp\
    .withColumn("priority_rnk",lit(1))\
    .union(dfcPrv.withColumn("priority_rnk",lit(2)))
dfcPrvCombined.createOrReplaceTempView("clmprv")

dfcPrvFinal = spark.sql("""
select 
    *
    ,row_number() 
        over (partition by CRL_ClmProv_ID order by priority_rnk) as rnk
from
    clmprv
""")

dfcPrvFinal\
    .filter(" rnk = 1 ")\
    .drop("rnk", "priority_rnk")\
    .repartition("CRL_ClmProv_ID")\
    .write.mode("overwrite")\
    .format("avro").save(rebuild_path)

chkR = subprocess.call(testCmd + rebuild_path + "/_SUCCESS", shell=True)
if chkR == 0:
    print("rebuild created successfully")
    chkO = subprocess.call(testCmd + old_path, shell=True)
    if chkO == 0:
        subprocess.call(removeCmd + old_path, shell=True)
    chkC = subprocess.call(testCmd + input_dim_path, shell=True)
    if chkC == 0:
        subprocess.call(moveCmd + input_dim_path + " " + old_path, shell=True)
    subprocess.call(moveCmd + rebuild_path + " " + input_dim_path, shell=True)

spark.stop()
