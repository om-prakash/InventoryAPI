import subprocess

from pyspark.sql.session import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *

spark = SparkSession.builder.getOrCreate()

spark.conf.set("spark.sql.avro.compression.codec", "snappy")
input_dim_path = "/rca/Anthem/data/raw/sqoop/dimensions/vDim_CRL_ClmMem"
temp_path = input_dim_path + '_temp'
rebuild_path = input_dim_path + '_rebuild'
old_path = input_dim_path + '_old'
testCmd = "hdfs dfs -test -e "
removeCmd = "hdfs dfs -rm -r "
moveCmd = "hdfs dfs -mv "

scCMem = StructType(
    [StructField("CRL_ClmMem_ID", IntegerType(), False),
     StructField("CnlyMemSor", ShortType(), False),
     StructField("CnlyMemID", IntegerType(), False),
     StructField("CnlyPersNum", StringType(), True),
     StructField("CnlyMemNum", StringType(), True),
     StructField("SubNum", StringType(), True),
     StructField("SubSeqNum", StringType(), True),
     StructField("MemFirstName", StringType(), True),
     StructField("MemLastName", StringType(), True),
     StructField("MemSex", StringType(), True),
     StructField("MemDOB", DateType(), True),
     StructField("MemBirthWght", IntegerType(), False),
     StructField("MemZip", StringType(), True),
     StructField("MemAltCd", StringType(), True),
     StructField("MemSSN", StringType(), True),
     StructField("AltMemNum", StringType(), True),
     StructField("MemMdcrNum", StringType(), True),
     StructField("MemReltnID", ShortType(), False),
     StructField("MemReltnCd", StringType(), True),
     StructField("CnlyMemType", StringType(), True),
     StructField("AddLine1", StringType(), True),
     StructField("AddLine2", StringType(), True),
     StructField("City", StringType(), True),
     StructField("State", StringType(), True),
     StructField("PhoneNum", StringType(), True),
     StructField("MemKey", StringType(), True)]
)

dfcMemTemp = spark.read\
    .schema(scCMem).csv(path=temp_path, header="false", sep="|")
dfcMem = spark.read.format("avro").load(path=input_dim_path)

dfcMemCombined = dfcMemTemp\
    .withColumn("priority_rnk", lit(1))\
    .union(dfcMem.withColumn("priority_rnk", lit(2)))
dfcMemCombined.createOrReplaceTempView("clmmems")

dfcMemFinal = spark.sql("""
select 
    *
    ,row_number() 
        over (partition by CRL_ClmMem_ID order by priority_rnk) as rnk
from
    clmmems
""")

dfcMemFinal\
    .filter(" rnk = 1 ")\
    .drop("rnk", "priority_rnk")\
    .repartition("CRL_ClmMem_ID")\
    .write.mode("overwrite")\
    .format("avro").save(rebuild_path)

chkR = subprocess.call(testCmd + rebuild_path + "/_SUCCESS", shell=True)
if chkR == 0:
    print("rebuild created successfully")
    chkO = subprocess.call(testCmd + old_path, shell=True)
    if chkO == 0:
        subprocess.call(removeCmd + old_path, shell=True)
    chkC = subprocess.call(testCmd + input_dim_path, shell=True)
    if chkC == 0:
        subprocess.call(moveCmd + input_dim_path + " " + old_path, shell=True)
    subprocess.call(moveCmd + rebuild_path + " " + input_dim_path, shell=True)

spark.stop()
