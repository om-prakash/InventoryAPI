HDIR="/rca/Anthem/data/raw/sqoop/claims/vFactClaimHeader"
MAXPATH=$(hdfs dfs -ls -R ${HDIR} | grep "^d" | tail -1 | tr "[:alpha:][:punct:]" ' ' | tr -s ' ' | cut -d' ' -f8 |tr -d ' ')
NEWPATH="$(($MAXPATH + 1))"
UNAME=${USER}
CLNT="Wellpoint"

DATASRC="vFactClaimHeader"
DEST="$HDIR/$NEWPATH"
SPLIT="CnlyClmJoinKey"
DELIM='|'
SERV="etl"
DBPART="CnlyClaims"
DB="$CLNT$DBPART"
THREADS="5"
FILTER=" partition = 49 and "
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  --username ${UNAME} --password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} --target-dir ${DEST} \
--null-string '' --null-non-string '' --fetch-size 100000 -m ${THREADS} --split-by ${SPLIT} -- --schema dbo ;

HDIR="/rca/Anthem/data/raw/sqoop/claims/vFactClaimKeys"
DATASRC="vFactClaimKeys"
DEST="$HDIR/$NEWPATH"
SPLIT="CnlyClmJoinKey"
DELIM='|'
CLNT="Wellpoint"
SERV="etl"
DBPART="CnlyClaims"
DB="$CLNT$DBPART"
THREADS="5"
FILTER=" \$PARTITION.PF_FactCnlyClmJoinKey(CnlyClmJoinKey)  = 49 and "
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  --username ${UNAME} --password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} --target-dir ${DEST} \
--null-string '' --null-non-string '' --fetch-size 100000 -m ${THREADS} --split-by ${SPLIT} -- --schema dbo ;

HDIR="/rca/Anthem/data/raw/sqoop/claims/vFactClaimAction"
DATASRC="vFactClaimAction"
DEST="$HDIR/$NEWPATH"
SPLIT="CnlyClmJoinKey"
DELIM='|'
CLNT="Wellpoint"
SERV="etl"
DBPART="CnlyClaims"
DB="$CLNT$DBPART"
THREADS="4"
FILTER=" \$PARTITION.PF_FactCnlyClmJoinKey(CnlyClmJoinKey) = 49 and "
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  --username ${UNAME} --password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} --target-dir ${DEST} \
--null-string '' --null-non-string '' --fetch-size 100000 -m $THREADS --split-by $SPLIT -- --schema dbo ;

HDIR="/rca/Anthem/data/raw/sqoop/claims/vFactClaimLine"
DATASRC="vFactClaimLine"
DEST="$HDIR/$NEWPATH"
SPLIT="CnlyClmJoinKey"
DELIM='|'
CLNT="Wellpoint"
SERV="etl"
DBPART="CnlyClaims"
DB="$CLNT$DBPART"
THREADS="5"
FILTER=" partition = 49 and "
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  --username ${UNAME} --password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} --target-dir ${DEST} \
--null-string '' --null-non-string '' --fetch-size 100000 -m ${THREADS} --split-by ${SPLIT} -- --schema dbo ;

DATASRC="vDim_CRL_LOBS"
DEST="/rca/Anthem/data/raw/sqoop/dimensions/vDim_CRL_LOBS"
DELIM='|'
CLNT="Wellpoint"
SERV="etl"
DBPART="CnlyClaims"
DB="$CLNT$DBPART"
THREADS="1"
FILTER=""
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  \
--username ${UNAME} --password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} --target-dir ${DEST} \
--null-string '' --null-non-string '' --fetch-size 100000 -m ${THREADS}  -- --schema dbo ;

DATASRC="vDim_CRL_ClmType"
DEST="/rca/Anthem/data/raw/sqoop/dimensions/vDim_CRL_ClmType"
DELIM='|'
CLNT="Wellpoint"
SERV="etl"
DBPART="CnlyClaims"
DB="$CLNT$DBPART"
THREADS="1"
FILTER=""
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  \
--username ${UNAME} --password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} --target-dir ${DEST} \
--null-string '' --null-non-string '' --fetch-size 100000 -m ${THREADS}  -- --schema dbo ;

DATASRC="vDim_CRL_CntrctJNK"
DEST="/rca/Anthem/data/raw/sqoop/dimensions/vDim_CRL_CntrctJNK"
DELIM='|'
CLNT="Wellpoint"
SERV="etl"
DBPART="CnlyClaims"
DB="$CLNT$DBPART"
THREADS="1"
FILTER=""
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  \
--username ${UNAME} --password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} --target-dir ${DEST} \
--null-string '' --null-non-string '' --fetch-size 100000 -m ${THREADS}  -- --schema dbo ;

DATASRC="vDim_CRL_ClmMem"
DEST="/rca/Anthem/data/raw/sqoop/dimensions/vDim_CRL_ClmMem_temp"
SPLIT="CRL_ClmMem_ID"
DELIM='|'
CLNT="Wellpoint"
SERV="etl"
DBPART="CnlyClaims"
DB="$CLNT$DBPART"
THREADS="5"
FILTER=""
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  \
--username ${UNAME} --password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} --target-dir ${DEST} \
--null-string '' --null-non-string '' --fetch-size 100000 -m ${THREADS} --split-by ${SPLIT} -- --schema dbo ;

DATASRC="vDim_CRL_ClmProv"
DEST="/rca/Anthem/data/raw/sqoop/dimensions/vDim_CRL_ClmProv_temp"
SPLIT="CRL_ClmProv_ID"
DELIM='|'
CLNT="Wellpoint"
SERV="etl"
DBPART="CnlyClaims"
DB="$CLNT$DBPART"
THREADS="5"
FILTER=""
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  \
--username ${UNAME} --password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} --target-dir ${DEST} \
--null-string '' --null-non-string '' --fetch-size 100000 -m ${THREADS} --split-by ${SPLIT} -- --schema dbo ;

DATASRC="vDimDxCd"
DEST="/rca/Anthem/data/raw/sqoop/dimensions/$DATASRC"
DELIM='|'
CLNT="Wellpoint"
SERV="etl"
DBPART="CnlyClaims"
DB="$CLNT$DBPART"
THREADS="1"
FILTER=" DxCdID > 0 and "
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  --username ${UNAME} --password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} --target-dir ${DEST} \
--null-string '' --null-non-string '' --fetch-size 100000 -m ${THREADS} -- --schema dbo ;

DATASRC="vDimSvcCd"
DEST="/rca/Anthem/data/raw/sqoop/dimensions/$DATASRC"
DELIM='|'
CLNT="Wellpoint"
SERV="etl"
DBPART="CnlyClaims"
DB="$CLNT$DBPART"
THREADS="1"
FILTER=" SvcCdID > 0 and "
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  --username ${UNAME} --password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} --target-dir ${DEST} \
--null-string '' --null-non-string '' --fetch-size 100000 -m ${THREADS} -- --schema dbo ;

DATASRC="vDimClmSORCd"
DEST="/rca/Anthem/data/raw/sqoop/dimensions/$DATASRC"
DELIM='|'
CLNT="Wellpoint"
SERV="etl"
DBPART="CnlyClaims"
DB="$CLNT$DBPART"
THREADS="1"
FILTER=" SORID > 0 and "
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  --username ${UNAME} --password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} --target-dir ${DEST} \
--null-string '' --null-non-string '' --fetch-size 100000 -m ${THREADS} -- --schema dbo ;

DATASRC="vDataLoads"
DEST="/rca/Anthem/data/raw/sqoop/dimensions/$DATASRC"
DELIM='|'
CLNT="Wellpoint"
SERV="etl"
DBPART=""
DB="$CLNT$DBPART"
THREADS="1"
FILTER=" "
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  --username ${UNAME} --password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} --target-dir ${DEST} \
--null-string '' --null-non-string '' --fetch-size 100000 -m ${THREADS} -- --schema dbo ;

DATASRC="vDimMemReltnCd"
DEST="/rca/Anthem/data/raw/sqoop/dimensions/$DATASRC"
DELIM='|'
CLNT="Wellpoint"
SERV="etl"
DBPART="CnlyClaims"
DB="$CLNT$DBPART"
THREADS="1"
FILTER=" MemReltnID > 0 and "
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  --username ${UNAME} --password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} --target-dir ${DEST} \
--null-string '' --null-non-string '' --fetch-size 100000 -m ${THREADS} -- --schema dbo ;

DATASRC="vDimAdjstRsnCd"
DEST="/rca/Anthem/data/raw/sqoop/dimensions/$DATASRC"
DELIM='|'
CLNT="Wellpoint"
SERV="etl"
DBPART="CnlyClaims"
DB="$CLNT$DBPART"
THREADS="1"
FILTER=" AdjstRsnID > 0 and "
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  --username ${UNAME} --password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} --target-dir ${DEST} \
--null-string '' --null-non-string '' --fetch-size 100000 -m ${THREADS} -- --schema dbo ;

spark2-submit \
--master yarn \
--deploy-mode cluster \
--name "Anthem Support Dimension Build" \
--conf "spark.yarn.submit.waitAppCompletion=false" \
AnthemDimensions.py

spark2-submit \
--master yarn \
--deploy-mode cluster \
--name "Anthem Member Dim Merge" \
--packages org.apache.spark:spark-avro_2.11:2.4.0 \
--executor-memory 15G \
--executor-cores 5 \
--driver-memory 10G \
--conf spark.locality.wait.rack=60s \
--conf "spark.yarn.submit.waitAppCompletion=false" \
MergevDim_CRL_ClmMem.py ;

spark2-submit \
--master yarn \
--deploy-mode cluster \
--name "Anthem Provider Dim Merge" \
--packages org.apache.spark:spark-avro_2.11:2.4.0 \
--executor-memory 15G \
--executor-cores 5 \
--driver-memory 10G \
--conf spark.locality.wait.rack=60s \
MergevDim_CRL_ClmProv.py ;

spark2-submit \
--master yarn \
--deploy-mode cluster \
--name "Anthem Header Raw" \
--packages org.apache.spark:spark-avro_2.11:2.4.0 \
--executor-memory 15G \
--executor-cores 5 \
--driver-memory 10G \
--conf spark.locality.wait.rack=60s \
AnthemHeader.py --filepart ${NEWPATH}

spark2-submit \
--master yarn \
--deploy-mode cluster \
--name "Anthem Claim Final Action" \
--packages org.apache.spark:spark-avro_2.11:2.4.0 \
--executor-memory 20G \
--executor-cores 5 \
--driver-memory 10G \
--conf spark.locality.wait.rack=60s \
--conf "spark.yarn.submit.waitAppCompletion=false" \
AnthemFinalAction.py --filepart ${NEWPATH}

