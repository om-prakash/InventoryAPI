import os
import sys

import argparse

from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *

sc = SparkContext.getOrCreate()
spark = SparkSession.builder.getOrCreate()

parser = argparse.ArgumentParser()
parser.add_argument("--filepart")
args = parser.parse_args()
if args.filepart:
    filepart = args.filepart

path = "/rca/Anthem/data/raw/parquet/FactClaimLine"
rebuild_path = path + '_rebuild'
testCmd = "hdfs dfs -test -e "
removeCmd = "hdfs dfs -rm -r "
moveCmd = "hdfs dfs -mv "

blockMB = 512
dictMB = 3
paddMB = 8
block_size = str(blockMB * 1024 * 1024)
dict_size = str(dictMB * 1024 * 1024)
padd_size = str(paddMB * 1024 * 1024)

inputclmpath = "/rca/Anthem/data/raw/sqoop/claims/"
outputpath = "/rca/Anthem/data/raw/"
refinedpath = "/rca/Anthem/data/refined"

headerpath = outputpath + "FactClaimHeader/" + str(filepart)
linepath = inputclmpath + "vFactClaimLine/" + str(filepart)
lineout = outputpath + "FactClaimLine/" + str(filepart)

scline = StructType([StructField("CnlyClmJoinKey", LongType(), False), StructField("CnlyLnID", IntegerType(), False), StructField("CnlyLnNum", StringType(), True), StructField("LnSvcBegDt", DateType(), True), StructField("LnSvcEndDt", DateType(), True), StructField("LnLOS", IntegerType(), True), StructField("PgybkClmCd", IntegerType(), False), StructField("SvcAltCdID", IntegerType(), True),
                     StructField("AdjctDocLvlCd", IntegerType(), False), StructField("BillUnits", IntegerType(), True), StructField("PaidUnits", IntegerType(), True), StructField("CnlyUnits", IntegerType(), True), StructField("BillAmtInt", DecimalType(18, 2), True), StructField("CnlyAllowPerUnit", DecimalType(38, 20), True), StructField("CnlyBillPerUnit", DecimalType(38, 21), True),
                     StructField("BillAmtOrig", DecimalType(18, 2), True), StructField("BillAmt", DecimalType(18, 2), True), StructField("AllowAmtInt", DecimalType(18, 2), True), StructField("AllowAmtOrig", DecimalType(18, 2), True), StructField("AllowAmt", DecimalType(18, 2), True), StructField("CnlyAllowAmt", DecimalType(18, 2), True), StructField("PaidAmtInt", DecimalType(18, 2), True),
                     StructField("PaidAmtOrig", DecimalType(18, 2), True), StructField("PaidAmt", DecimalType(18, 2), True), StructField("CnlyPaidAmt", DecimalType(18, 2), True), StructField("COBAmtInt", DecimalType(18, 2), True), StructField("COBAmtOrig", DecimalType(18, 2), True), StructField("COBAmt", DecimalType(18, 2), True), StructField("CoInsAmtInt", DecimalType(18, 2), True),
                     StructField("CoInsAmtOrig", DecimalType(18, 2), True), StructField("CoInsAmt", DecimalType(18, 2), True), StructField("CopayAmtInt", DecimalType(18, 2), True), StructField("CopayAmtOrig", DecimalType(18, 2), True), StructField("CoPayAmt", DecimalType(18, 2), True), StructField("DedAmtInt", DecimalType(18, 2), True), StructField("DedAmtOrig", DecimalType(18, 2), True),
                     StructField("DedAmt", DecimalType(18, 2), True), StructField("NonCovAmtInt", DecimalType(18, 2), True), StructField("NonCovAmtOrig", DecimalType(18, 2), True), StructField("NonCovAmt", DecimalType(18, 2), True), StructField("PayRatio", DecimalType(18, 2), True), StructField("MdcrAllowAmt", DecimalType(18, 2), True), StructField("MdcrDedAmt", DecimalType(18, 2), True),
                     StructField("MdcrPaidAmt", DecimalType(18, 2), True), StructField("FFSEquivAmt", DecimalType(18, 2), True), StructField("ContrEffDt", DateType(), True), StructField("ContrEndDt", DateType(), True), StructField("CnlyLnPaidTH", IntegerType(), False), StructField("AdjctType", StringType(), True), StructField("AdjctStat", StringType(), True),
                     StructField("CnlyAdjstNum", ShortType(), False), StructField("ClmAdjstNum", ShortType(), False), StructField("ClmDispCd", StringType(), True), StructField("LnStatCd", StringType(), True), StructField("AdjstRsnCd", StringType(), True), StructField("SvcTypeCd", StringType(), True), StructField("SvcLocCd", StringType(), True), StructField("SvcCd", StringType(), True),
                     StructField("ModifierCd1", StringType(), True), StructField("ModifierCd2", StringType(), True), StructField("ModifierCd3", StringType(), True), StructField("ModifierCd4", StringType(), True), StructField("RevCd", StringType(), True), StructField("RevCdGrp", StringType(), True), StructField("NDCCd", StringType(), True), StructField("ProvContrCd", StringType(), True),
                     StructField("ReimbTypeCd", StringType(), True), StructField("ContrStatCd", StringType(), True), StructField("ReimbMthdCd", StringType(), True), StructField("NetworkCd", StringType(), True), StructField("CnlyPar", StringType(), True), StructField("LineFeeSchedCd", StringType(), True), StructField("FeeSchedCd", StringType(), True),
                     StructField("Partition", IntegerType(), False)])

dfHeader = spark.read.format("avro").load(path=headerpath)
dfHeader.drop("ClmAdjstNum", "ClmDispCd").createOrReplaceTempView("clmHeader")
dfLine = spark.read.schema(scline).csv(path=linepath, header="false", sep="|")
dfLine.createOrReplaceTempView("clmLine")

line = spark.sql("""
select 
    h.*, 
    l.CnlyLnID, l.CnlyLnNum, l.LnSvcBegDt, l.LnSvcEndDt, l.LnLOS, l.PgybkClmCd, l.SvcAltCdID, 
    l.AdjctDocLvlCd, l.BillUnits, l.PaidUnits, l.CnlyUnits, l.BillAmtInt, l.CnlyAllowPerUnit, 
    l.CnlyBillPerUnit, l.BillAmtOrig, l.BillAmt, l.AllowAmtInt, l.AllowAmtOrig, l.AllowAmt, l.CnlyAllowAmt, 
    l.PaidAmtInt, l.PaidAmtOrig, l.PaidAmt, l.CnlyPaidAmt, l.COBAmtInt, l.COBAmtOrig, l.COBAmt, l.CoInsAmtInt, 
    l.CoInsAmtOrig, l.CoInsAmt, l.CopayAmtInt, l.CopayAmtOrig, l.CoPayAmt, l.DedAmtInt, l.DedAmtOrig, 
    l.DedAmt, l.NonCovAmtInt, l.NonCovAmtOrig, l.NonCovAmt, l.PayRatio, l.MdcrAllowAmt, l.MdcrDedAmt, 
    l.MdcrPaidAmt, l.FFSEquivAmt, l.ContrEffDt, l.ContrEndDt, l.CnlyLnPaidTH, l.AdjctType, l.AdjctStat, 
    l.CnlyAdjstNum, l.ClmAdjstNum, l.ClmDispCd, l.LnStatCd, l.AdjstRsnCd, l.SvcTypeCd, l.SvcLocCd as LineSvcLocCd, 
    l.SvcCd, l.ModifierCd1, l.ModifierCd2, l.ModifierCd3, l.ModifierCd4, l.RevCd, l.RevCdGrp, l.NDCCd, 
    l.ProvContrCd as LieProvContrCd, l.ReimbTypeCd as LineReimbTypeCd, l.ContrStatCd as LineContrStatCd, 
    l.ReimbMthdCd as LineReimbMthCd, l.NetworkCd as LineNetworkCd, l.CnlyPar as LineCnlyPar, l.LineFeeSchedCd, 
    l.FeeSchedCd 
from clmHeader h 
inner join clmLine l on h.CnlyClmJoinKey = l.CnlyClmJoinKey 
""")

line.coalesce(50).write.mode("overwrite").format("avro").save(lineout)

spark.stop()
"""
pyspark2 \
--packages org.apache.spark:spark-avro_2.11:2.4.0 \
--driver-class-path /share/spring/ \
--executor-memory 10G \
--queue "root.rcaengdev" \
--executor-cores 4 \
--jars /share/spring/mssql-jdbc-8.2.2.jre8.jar,/share/spring/kerberos-sql-driver-1.0-SNAPSHOT.jar \
--files /home/adam.andrus/adam.andrus.keytab
"""


dfjdbc = spark.read.format("jdbc").\
    option("driver", "com.cotiviti.jdbc.Krb5SqlServerDriver").\
    option("url", "jdbc:krb5ss://DS-FLD-105.ccaintranet.com;databaseName=WellpointCnlyData;integratedSecurity=true;authenticationSchema=JavaKerberos;krb5Principal=adam.andrus@CCAINTRANET.COM;krb5Keytab=adam.andrus.keytab;").\
    option("dbtable", "dbo.vConfiguratorClaimContracts").\
    option("partitionColumn","CnlyClmJoinKey").\
    option("lowerBound", 10600000001).\
    option("upperBound", 10652433071).\
    option("numPartitions", 6).\
    option("fetchSize", 100000).\
    load()
