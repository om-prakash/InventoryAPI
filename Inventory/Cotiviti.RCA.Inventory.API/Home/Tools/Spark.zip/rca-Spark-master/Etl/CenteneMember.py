import subprocess
import argparse

from pyspark.sql.session import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *

spark = SparkSession.builder.getOrCreate()

memdf = spark.read\
    .text("/rca/centene/data/raw/member/eligibility/*")\
    .selectExpr(
                "upper(trim(substring(value, 1, 12))) as MemberID",
                "upper(trim(substring(value, 13, 18))) as AlternateID",
                "upper(trim(substring(value, 31, 36))) as LastName",
                "upper(trim(substring(value, 67, 26))) as FirstName",
                "upper(trim(substring(value, 93, 26))) as MiddleName",
                "upper(trim(substring(value, 119, 1))) as Gender",
                "to_date(upper(trim(substring(value, 120, 8))),"
                "'yyyymmdd') as DOB",
                "upper(trim(substring(value, 128, 9))) as AlternateID2",
                "upper(trim(substring(value, 147, 36))) as Address",
                "upper(trim(substring(value, 183, 24))) as City",
                "upper(trim(substring(value, 207, 2))) as State",
                "upper(trim(substring(value, 209, 9))) as Zip",
                "to_date(upper(trim(substring(value, 218, 8))),"
                "'yyyymmdd') as EffectiveDate",
                "to_date(upper(trim(substring(value, 226, 8))),"
                "'yyyymmdd')  as EndDate",
                "upper(trim(substring(value, 246, 2))) as Employment",
                "upper(trim(substring(value, 248, 10))) as Division",
                "upper(trim(substring(value, 258, 8))) as PlanID",
                "upper(trim(substring(value, 266, 2))) as OtherIns",
                "upper(trim(substring(value, 444, 2))) as BusLine",
                "int(trim(substring(value, 448, 3))) as "
                "MemberHomePhoneAreaCode",
                "int(trim(substring(value, 451, 27))) as "
                "MemberHomePhoneNumber",
                "int(trim(substring(value, 478, 3))) as "
                "MemberWorkPhoneAreaCode",
                "int(trim(substring(value, 481, 27))) as "
                "MemberWorkPhoneNumber",
                "upper(trim(substring(value, 508, 55))) as MemberAddress2",
                "to_date(upper(trim(substring(value, 563, 8))),"
                "'yyyymmdd')  as DateofDeath",
                "upper(trim(substring(value, 580, 11))) as "
                "MedicareMemberIdentificationNumber",
                "upper(trim(substring(value, 591, 256))) as EmailAddress",
                "upper(trim(substring(value, 847, 11))) as "
                "MedicareBeneficiaryIdentifier",
                "upper(trim(substring(value, 858, 2))) as MemberClassCode"
                )\
    .drop("value")\
    .withColumn("row_hash",
                expr(
                    "sha2(concat_ws('|', *), 256)"
                    )
                )\
    .withColumn("src_file",
                expr(
                    "regexp_extract(input_file_name(), '[^\/]*$',0)"
                    )
                )\
    .repartition("row_hash")\
    .write.mode("append")\
    .format("avro").save("/rca/centene/data/avro/member/eligibility/")

memdf = spark.read\
    .format("avro").load("/rca/centene/data/avro/member/eligibility/")\
    .withColumn("MemberID",
                expr(
                     "coalesce(nullif(BusLine,''),"
                     "")
                )\
    .repartition("MemberID", "row_hash")\
    .withColumn("rnk",
                expr(
                    "row_number() over "
                    "(partition by MemberID, row_hash order by src_file)"
                    )
                )\
    .filter("rnk = 1")\
    .drop("rnk")

mem_cob = spark\
    .read.text("/rca/centene/data/raw/member/cob/*")\
    .selectExpr(
                "upper(trim(substring(value, 4, 8))) as Date",
                "upper(trim(substring(value, 12, 12))) as MemberID",
                "upper(trim(substring(value, 24, 9))) as UniqueID1",
                "upper(trim(substring(value, 33, 36))) as MemberLastName",
                "upper(trim(substring(value, 69, 26))) as MemberFirstName",
                "upper(trim(substring(value, 95, 26))) as MemberMiddleName",
                "upper(trim(substring(value, 121, 1))) as MemberGender",
                "upper(trim(substring(value, 122, 8))) as MemberDOB",
                "upper(trim(substring(value, 132, 16))) as PolicySSN",
                "upper(trim(substring(value, 148, 9))) as MemberSSN",
                "upper(trim(substring(value, 157, 14))) as PolicyLastName",
                "upper(trim(substring(value, 171, 14))) as PolicyFirstName",
                "upper(trim(substring(value, 186, 8))) as PolicyDOB",
                "upper(trim(substring(value, 326, 4))) as UniqueIDInsCo",
                "upper(trim(substring(value, 334, 6))) as AltCarrierGroupNumber",
                "upper(trim(substring(value, 385, 8))) as AltCarrierEffectiveDate",
                "upper(trim(substring(value, 393, 8))) as AltCarrierEndDate",
                "upper(trim(substring(value, 401, 8))) as DateLastVerified",
                "upper(trim(substring(value, 425, 18))) as UniqueID2",
                "upper(trim(substring(value, 443, 2))) as Void")\
    .drop("value")
