#!/usr/bin/env bash

UNAME="adam.andrus"
DATASRC="vDimDxCd"
DEST="/rca/Anthem/data/raw/sqoop/dimensions/$DATASRC"
DELIM='|'
CLNT="Wellpoint"
SERV="etl"
DBPART="CnlyClaims"
DB="$CLNT$DBPART"
THREADS="1"
FILTER=" DxCdID > 0 and "
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  --username ${UNAME} --password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} --target-dir ${DEST} \
--null-string '' --null-non-string '' --fetch-size 100000 -m ${THREADS} -- --schema dbo ;

UNAME="adam.andrus"
DATASRC="vDimSvcCd"
DEST="/rca/Anthem/data/raw/sqoop/dimensions/$DATASRC"
DELIM='|'
CLNT="Wellpoint"
SERV="etl"
DBPART="CnlyClaims"
DB="$CLNT$DBPART"
THREADS="1"
FILTER=" SvcCdID > 0 and "
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  --username ${UNAME} --password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} --target-dir ${DEST} \
--null-string '' --null-non-string '' --fetch-size 100000 -m ${THREADS} -- --schema dbo ;

UNAME="adam.andrus"
DATASRC="vDimClmSORCd"
DEST="/rca/Anthem/data/raw/sqoop/dimensions/$DATASRC"
DELIM='|'
CLNT="Wellpoint"
SERV="etl"
DBPART="CnlyClaims"
DB="$CLNT$DBPART"
THREADS="1"
FILTER=" SORID > 0 and "
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  --username ${UNAME} --password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} --target-dir ${DEST} \
--null-string '' --null-non-string '' --fetch-size 100000 -m ${THREADS} -- --schema dbo ;

UNAME="adam.andrus"
DATASRC="vDataLoads"
DEST="/rca/Anthem/data/raw/sqoop/dimensions/$DATASRC"
DELIM='|'
CLNT="Wellpoint"
SERV="etl"
DBPART=""
DB="$CLNT$DBPART"
THREADS="1"
FILTER=" "
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  --username ${UNAME} --password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} --target-dir ${DEST} \
--null-string '' --null-non-string '' --fetch-size 100000 -m ${THREADS} -- --schema dbo ;

UNAME="adam.andrus"
DATASRC="vDimMemReltnCd"
DEST="/rca/Anthem/data/raw/sqoop/dimensions/$DATASRC"
DELIM='|'
CLNT="Wellpoint"
SERV="etl"
DBPART="CnlyClaims"
DB="$CLNT$DBPART"
THREADS="1"
FILTER=" MemReltnID > 0 and "
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  --username ${UNAME} --password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} --target-dir ${DEST} \
--null-string '' --null-non-string '' --fetch-size 100000 -m ${THREADS} -- --schema dbo ;

UNAME="adam.andrus"
DATASRC="vDimAdjstRsnCd"
DEST="/rca/Anthem/data/raw/sqoop/dimensions/$DATASRC"
DELIM='|'
CLNT="Wellpoint"
SERV="etl"
DBPART="CnlyClaims"
DB="$CLNT$DBPART"
THREADS="1"
FILTER=" AdjstRsnID > 0 and "
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  --username ${UNAME} --password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} --target-dir ${DEST} \
--null-string '' --null-non-string '' --fetch-size 100000 -m ${THREADS} -- --schema dbo ;

spark2-submit \
--master yarn \
--deploy-mode cluster \
--name "Anthem Support Dimension Build" \
--queue root.rcaengdev \
--conf "spark.yarn.submit.waitAppCompletion=false" \
AnthemDimensions.py
