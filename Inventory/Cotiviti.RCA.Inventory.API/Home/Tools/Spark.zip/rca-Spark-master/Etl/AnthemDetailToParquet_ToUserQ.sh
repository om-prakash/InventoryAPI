spark2-submit \
--master yarn \
--deploy-mode cluster \
--name "Anthem Detail to Parquet" \
--packages org.apache.spark:spark-avro_2.11:2.4.0 \
--executor-memory 40G \
--executor-cores 5 \
--driver-memory 20G \
--conf spark.locality.wait.rack=60s \
--conf spark.speculation=true \
--conf spark.speculation.quantile=0.7 \
--conf "spark.yarn.submit.waitAppCompletion=false" \
AnthemDetailToParquet.py
