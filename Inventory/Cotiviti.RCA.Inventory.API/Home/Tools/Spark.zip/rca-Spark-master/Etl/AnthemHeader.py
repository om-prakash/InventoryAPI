import os
import sys

import argparse

from pyspark.sql.session import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *

spark = SparkSession.builder.getOrCreate()

spark.conf.set("spark.sql.avro.compression.codec", "snappy")

parser = argparse.ArgumentParser()
parser.add_argument("--filepart")
args = parser.parse_args()
if args.filepart:
    filepart = args.filepart

inputclmpath = "/rca/Anthem/data/raw/sqoop/claims/"
inputdimpath = "/rca/Anthem/data/raw/sqoop/dimensions/"
outputpath = "/rca/Anthem/data/raw/"
refinedpath = "/rca/Anthem/data/refined"

headerPath = inputclmpath + "vFactClaimHeader/" + str(filepart)
keysPath = inputclmpath + "vFactClaimKeys/" + str(filepart)
actionPath = inputclmpath + "vFactClaimAction/" + str(filepart)
lobspath = inputdimpath + "vDim_CRL_LOBS"
cntrctpath = inputdimpath + "vDim_CRL_CntrctJNK"
clmtppath = inputdimpath + "vDim_CRL_ClmType"
cmempath = inputdimpath + "vDim_CRL_ClmMem"
cprvpath = inputdimpath + "vDim_CRL_ClmProv"
headerout = outputpath + "FactClaimHeader/" + str(filepart)

scHeader = StructType(
    [StructField("CnlyClmJoinKey", LongType(), False), StructField("CnlySor", ShortType(), False), StructField("CnlyPaidDt", DateType(), True), StructField("CnlyClmID", LongType(), False), StructField("CnlyClmNum", StringType(), True), StructField("ClmNum", StringType(), True), StructField("ClmRoot", StringType(), True), StructField("ClmAltNum", StringType(), True),
     StructField("AdjctDt", DateType(), True), StructField("ClmSysEntryDt", DateType(), True), StructField("ClmRecvDt", DateType(), True), StructField("ClmStmtBegDt", DateType(), True), StructField("ClmStmtEndDt", DateType(), True), StructField("ClmSvcBegDt", DateType(), True), StructField("ClmSvcEndDt", DateType(), True), StructField("ClmLOS", IntegerType(), True),
     StructField("ClmFormType", StringType(), True), StructField("ClmBillAmtInt", DecimalType(18, 2), True), StructField("ClmBillAmtOrig", DecimalType(18, 2), True), StructField("ClmBillAmt", DecimalType(18, 2), True), StructField("ClmAllowAmtInt", DecimalType(18, 2), True), StructField("ClmAllowAmtOrig", DecimalType(18, 2), True),
     StructField("ClmAllowAmt", DecimalType(18, 2), True), StructField("CnlyClmAllowAmt", DecimalType(18, 2), True), StructField("ClmCOBAmtInt", DecimalType(18, 2), True), StructField("ClmCOBAmtOrig", DecimalType(18, 2), True), StructField("ClmCOBAmt", DecimalType(18, 2), True), StructField("ClmCoinsAmtInt", DecimalType(18, 2), True),
     StructField("ClmCoinsAmtOrig", DecimalType(18, 2), True), StructField("ClmCoInsAmt", DecimalType(18, 2), True), StructField("ClmCopayAmtInt", DecimalType(18, 2), True), StructField("ClmCopayAmtOrig", DecimalType(18, 2), True), StructField("ClmCoPayAmt", DecimalType(18, 2), True), StructField("ClmDedAmtInt", DecimalType(18, 2), True),
     StructField("ClmDedAmtOrig", DecimalType(18, 2), True), StructField("ClmDedAmt", DecimalType(18, 2), True), StructField("ClmNonCovAmtInt", DecimalType(18, 2), True), StructField("ClmNonCovAmtOrig", DecimalType(18, 2), True), StructField("ClmNonCovAmt", DecimalType(18, 2), True), StructField("ClmPaidAmtInt", DecimalType(18, 2), True),
     StructField("ClmPaidAmtOrig", DecimalType(18, 2), True), StructField("ClmPaidAmt", DecimalType(18, 2), True), StructField("ClmMdcrAllowAmt", DecimalType(18, 2), True), StructField("ClmMdcrDedAmt", DecimalType(18, 2), True), StructField("ClmMdcrPaidAmt", DecimalType(18, 2), True), StructField("ClmPayRatio", DecimalType(18, 2), True),
     StructField("ClmAllowedRatio", DecimalType(18, 2), True), StructField("ClmAllowedRatioTrunc", DecimalType(18, 2), True), StructField("ClmAllowedPerDiem", DecimalType(18, 2), True), StructField("ClmCheckDt", DateType(), True), StructField("CapitCd", StringType(), True), StructField("SrcClmReimbMthdCd", StringType(), True), StructField("EnrEffDt", DateType(), True),
     StructField("EnrTermDt", DateType(), True), StructField("CnlyPaidTH", IntegerType(), True), StructField("ProdExcl", IntegerType(), True), StructField("PaidToInd", ShortType(), False), StructField("ICDVersionCd", ShortType(), False), StructField("CRL_ClmProv_ID", IntegerType(), False), StructField("CRL_ClmMem_ID", IntegerType(), False),
     StructField("CRL_ClmType_ID", ShortType(), False), StructField("CRL_CntrctJNK_ID", IntegerType(), False), StructField("CRL_LOBS_ID", ShortType(), False), StructField("PxCd1", StringType(), True), StructField("PxCd2", StringType(), True), StructField("PxCd3", StringType(), True), StructField("PxCd4", StringType(), True), StructField("PxCd5", StringType(), True),
     StructField("PxCd6", StringType(), True), StructField("PxCd7", StringType(), True), StructField("PxCd8", StringType(), True), StructField("PxCd9", StringType(), True), StructField("PxCd10", StringType(), True), StructField("POACd1", StringType(), True), StructField("POACd2", StringType(), True), StructField("POACd3", StringType(), True),
     StructField("POACd4", StringType(), True), StructField("POACd5", StringType(), True), StructField("POACd6", StringType(), True), StructField("POACd7", StringType(), True), StructField("POACd8", StringType(), True), StructField("POACd9", StringType(), True), StructField("POACd10", StringType(), True), StructField("AdmitDxCd", StringType(), True),
     StructField("ECIDxCd1", StringType(), True), StructField("ECIDxCd2", StringType(), True), StructField("ECIDxCd3", StringType(), True), StructField("DxCd1", StringType(), True), StructField("DxCd2", StringType(), True), StructField("DxCd3", StringType(), True), StructField("DxCd4", StringType(), True), StructField("DxCd5", StringType(), True),
     StructField("DxCd6", StringType(), True), StructField("DxCd7", StringType(), True), StructField("DxCd8", StringType(), True), StructField("DxCd9", StringType(), True), StructField("DxCd10", StringType(), True), StructField("DxCd11", StringType(), True), StructField("DxCd12", StringType(), True), StructField("DxCd13", StringType(), True),
     StructField("DxCd14", StringType(), True), StructField("DxCd15", StringType(), True), StructField("DxCd16", StringType(), True), StructField("DxCd17", StringType(), True), StructField("DxCd18", StringType(), True), StructField("DxCd19", StringType(), True), StructField("DxCd20", StringType(), True), StructField("DxCd21", StringType(), True),
     StructField("DxCd22", StringType(), True), StructField("DxCd23", StringType(), True), StructField("DxCd24", StringType(), True), StructField("DxCd25", StringType(), True), StructField("DxCd26", StringType(), True), StructField("DxCd27", StringType(), True), StructField("DxCd28", StringType(), True), StructField("DxCd29", StringType(), True),
     StructField("DxCd30", StringType(), True), StructField("SvrtyOfIlnsCd", StringType(), True), StructField("DrgCodeVrsnNbr", IntegerType(), False), StructField("FnlDRGCd", StringType(), True), StructField("DRGTypeCd", StringType(), True), StructField("SbmDRGCd", StringType(), True), StructField("DRGCd", StringType(), True), StructField("ExpRuleTypeID", ShortType(), False),
     StructField("ExpRuleID", IntegerType(), False), StructField("ExceptionID", IntegerType(), True), StructField("LagDate", DateType(), True), StructField("ExpDate", DateType(), True), StructField("GrpNum", StringType(), True), StructField("GrpName", StringType(), True), StructField("SubGrpNum", StringType(), True), StructField("SubGrpName", StringType(), True),
     StructField("PurchOrgNum", StringType(), True), StructField("EnrProdCd", StringType(), True), StructField("EnrCompCd", StringType(), True), StructField("EnrMBUCd", StringType(), True), StructField("EnrFundCd", StringType(), True), StructField("FundType", StringType(), True), StructField("ProductCd", StringType(), True), StructField("ProductState", StringType(), True),
     StructField("MarketCd", StringType(), True), StructField("GWFInd_Grp", ShortType(), False), StructField("AdmitDt", DateType(), True), StructField("AdmitHr", IntegerType(), False), StructField("AdmitTypeCd", StringType(), True), StructField("AdmitSrc", StringType(), True), StructField("DischDt", DateType(), True), StructField("DischHr", IntegerType(), False),
     StructField("DischStatCd", StringType(), True), StructField("LoadID", IntegerType(), False), StructField("Partition", IntegerType(), False)])

scLobs = StructType(
    [StructField("CRL_LOBS_ID", ShortType(), False), StructField("CnlySor", ShortType(), False), StructField("OIIndID", ShortType(), False), StructField("OIIndCd", StringType(), True), StructField("CnlyLOBRuleID", ShortType(), True), StructField("CnlyLOB", StringType(), True), StructField("CnlyBlueCard", ShortType(), False), StructField("BlueCardCd", StringType(), True),
     StructField("CCVLOBID", ShortType(), False), StructField("CCVLOB", StringType(), True), StructField("CnlyFEP", IntegerType(), True), StructField("GWFInd", ShortType(), False)])

scCntrct = StructType(
    [StructField("CRL_CntrctJNK_ID", IntegerType(), False), StructField("CnlySor", ShortType(), False), StructField("ProvContrID", IntegerType(), True), StructField("ProvContrCd", StringType(), True), StructField("ReimbTypeID", IntegerType(), False), StructField("ReimbTypeCd", StringType(), True), StructField("ContrStatID", ShortType(), False), StructField("ContrStatCd", StringType(), True),
     StructField("ReimbMthdID", ShortType(), False), StructField("ReimbMthdCd", StringType(), True), StructField("NetworkID", ShortType(), False), StructField("NetworkCd", StringType(), True), StructField("CnlyPar", StringType(), True)])

scClmTp = StructType(
    [StructField("CRL_ClmType_ID", ShortType(), False), StructField("BillTypeID", ShortType(), False), StructField("BillTypeCd", StringType(), True), StructField("BillClassID", ShortType(), False), StructField("BillClassCd", StringType(), True), StructField("SvcLocID", ShortType(), False), StructField("SvcLocCd", StringType(), True), StructField("SvcProvRoleID", ShortType(), False),
     StructField("SvcProvRoleCd", StringType(), True), StructField("CnlyClmType", IntegerType(), True), StructField("ClmTypeCd", StringType(), True), StructField("ClmTypeCdNumString", StringType(), True), StructField("CnlyClmSetting", IntegerType(), True), StructField("CnlyAmbulance", IntegerType(), True), StructField("CnlyPsych", IntegerType(), True), StructField("CnlySNF", IntegerType(), True),
     StructField("CnlyRehab", IntegerType(), True), StructField("CnlyDialysis", IntegerType(), True), StructField("CnlyHHA", IntegerType(), True), StructField("CnlyCAH", IntegerType(), True), StructField("CnlyASC", IntegerType(), True), StructField("CnlyAIP", IntegerType(), True), StructField("CnlySwingBed", IntegerType(), True), StructField("CnlyLTC", IntegerType(), True)])

scCKeys = StructType([StructField("CnlyClmJoinKey", LongType(), False), StructField("CnlyClmNumFrom", StringType(), True), StructField("ClmAdjstKey", StringType(), True), StructField("MedRecNum", StringType(), True), StructField("DocCtlNum", StringType(), True), StructField("CheckNum", StringType(), True), StructField("PriorAuthNum", StringType(), True)])

scAction = StructType([StructField("CnlyClmJoinKey", LongType(), False), StructField("CnlyFinal", IntegerType(), True), StructField("ClmAdjstNum", ShortType(), True), StructField("ClmDispCd", StringType(), True)])

dfHeader = spark.read.schema(scHeader).csv(path = headerPath, header = "false", sep = "|")
dfHeader.createOrReplaceTempView("clmHeader")
dfAction = spark.read.schema(scAction).csv(path = actionPath, header = "false", sep = "|")
dfAction.createOrReplaceTempView("clmAction")
dfKeys = spark.read.schema(scCKeys).csv(path = keysPath, header = "false", sep = "|")
dfKeys.createOrReplaceTempView("clmKeys")
dfLobs = spark.read.schema(scLobs).csv(path = lobspath, header = "false", sep = "|")
dfLobs.createOrReplaceTempView("lobs")
dfCtp = spark.read.schema(scClmTp).csv(path = clmtppath, header = "false", sep = "|")
dfCtp.createOrReplaceTempView("clmtypes")
dfCntrct = spark.read.schema(scCntrct).csv(path = cntrctpath, header = "false", sep = "|")
dfCntrct.createOrReplaceTempView("cntrct")
dfcMem = spark.read.format("avro").load(path = cmempath)
dfcMem.createOrReplaceTempView("clmmems")
dfcPrv = spark.read.format("avro").load(path = cprvpath)
dfcPrv.createOrReplaceTempView("clmprovs")

header = spark.sql("select \
                    h.*, a.ClmAdjstNum, a.ClmDispCd, k.CnlyClmNumFrom, k.ClmAdjstKey, k.MedRecNum, k.DocCtlNum, k.CheckNum, k.PriorAuthNum, \
                    l.OIIndCd, l.CnlyLOB, l.BlueCardCd, l.CCVLOB, l.CnlyFEP, l.GWFInd as GWFInd_LOB, \
                    crt.ProvContrCd, crt.ReimbTypeCd, crt.ContrStatCd, crt.ReimbMthdCd, crt.NetworkCd, crt.CnlyPar, \
                    ct.BillTypeCd, ct.BillClassCd, ct.SvcLocCd, ct.SvcProvRoleCd, ct.CnlyClmType, ct.ClmTypeCd, \
                    ct.CnlyClmSetting, ct.CnlyAmbulance, ct.CnlyPsych, ct.CnlySNF, ct.CnlyRehab, ct.CnlyDialysis, ct.CnlyHHA, \
                    ct.CnlyCAH, ct.CnlyASC, ct.CnlyAIP, ct.CnlySwingBed, ct.CnlyLTC, \
                    m.CnlyMemSor, m.CnlyMemID, m.CnlyPersNum, m.CnlyMemNum, m.SubNum, m.SubSeqNum, m.MemFirstName, \
                    m.MemLastName, m.MemSex, m.MemDOB, m.MemBirthWght, m.MemZip, m.MemAltCd, m.MemSSN, m.AltMemNum, m.MemMdcrNum, \
                    m.MemReltnID, m.MemReltnCd, m.CnlyMemType, m.AddLine1 as MemAddLine1, m.AddLine2 as MemAddLine2, m.City as MemCity, \
                    m.State as MemState, m.PhoneNum as MemPhone, m.MemKey, \
                    p.CnlyProvSOR, p.CnlyProvID, p.CnlyProvNum, p.ProvTypeCd, p.SvcCnlyProvID, p.SvcProvNum, p.SvcProvTaxID, p.SvcProvNPI, \
                    p.SvcProvName, p.SvcProvSt, p.SvcProvTaxonomyCd, p.BillCnlyProvID, p.BillProvNum, p.BillProvTaxID, p.BillProvNPI, \
                    p.BillProvName, p.SvcProvZip, p.ProvMdcrNum \
                    from clmHeader h \
                    inner join clmKeys k on h.CnlyClmJoinKey = k.CnlyClmJoinKey \
                    inner join clmAction a on h.CnlyClmJoinKey = a.CnlyClmJoinKey \
                    inner join lobs l on h.CRL_LOBS_ID = l.CRL_LOBS_ID \
                    inner join cntrct crt on h.CRL_CntrctJNK_ID = crt.CRL_CntrctJNK_ID \
                    inner join clmtypes ct on h.CRL_ClmType_ID = ct.CRL_ClmType_ID \
                    inner join clmmems m on h.CRL_ClmMem_ID = m.CRL_ClmMem_ID \
                    inner join clmprovs p on h.CRL_ClmProv_ID = p.CRL_ClmProv_ID ")

dfHeaderfnl = header.drop("CRL_LOBS_ID", "CRL_CntrctJNK_ID", "CRL_ClmType_ID", "partition")
dfHeaderfnl.repartition(25, "CnlyMemID").write.mode("overwrite").format("avro").save(headerout)

spark.stop()
