# Office to HDFS

The data from our clients can be in excel or access 
format. Those office formats are not natively supported 
by Apache Spark. Because of this reason, we need to 
figure out an approach to convert excel or access files 
to a format which Spark can consume effectively. 

Inside this project, we demonstrate an approach to convert 
data in Microsoft Access database to parquet or avro.

## Highlights

- Use a pure JDBC drive to access Microsoft Access database
across platforms
- Convert standard java ResultSet to parquet or avro
- How to access system tables in Microsfot Access database
- How to use Hadoop Client API to access a kerberos enabled HDFS across platform

## References

[UCanAccess JDBC Drive](http://ucanaccess.sourceforge.net/site.html)

