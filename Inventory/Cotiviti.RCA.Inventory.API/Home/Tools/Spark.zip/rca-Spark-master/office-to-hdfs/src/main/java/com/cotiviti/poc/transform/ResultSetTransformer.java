package com.cotiviti.poc.transform;

import java.io.IOException;
import java.io.InputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

/**
 * Transforms an SQL ResultSet into another format.
 */
public interface ResultSetTransformer {
    /**
     * @param resultSet  The ResultSet to transform.
     * @param schemaName Schema name.
     * @param namespace  Schema namespace.
     * @param listeners  A list of TransformerListener
     * @return InputStream containing the transformed data.
     * @throws IOException  An exception that represents an IO exception
     * @throws SQLException An exception that represents a SQL related exception
     */
    InputStream transform(ResultSet resultSet, String schemaName, String namespace,
                          List<TransformerListener> listeners) throws IOException, SQLException;


    /**
     * Extracts the appropriate value from the ResultSet using the given SchemaSqlMapping.
     *
     * @param mapping An instance of {@link SchemaSqlMapping}
     * @param resultSet java.sql.ResultSet
     * @return A value of a row and column
     * @throws SQLException An exception that represents a sql related exception
     */
    static Object extractResult(SchemaSqlMapping mapping, ResultSet resultSet) throws SQLException {

        switch (mapping.getSqlType()) {
            case Types.BOOLEAN:
                return resultSet.getBoolean(mapping.getSqlColumnName());
            case Types.TINYINT:
            case Types.SMALLINT:
            case Types.INTEGER:
            case Types.BIGINT:
            case Types.ROWID:
                return resultSet.getInt(mapping.getSqlColumnName());
            case Types.REAL:
            case Types.FLOAT:
                return resultSet.getFloat(mapping.getSqlColumnName());
            case Types.DOUBLE:
                return resultSet.getDouble(mapping.getSqlColumnName());
            case Types.NUMERIC:
            case Types.DECIMAL:
                return resultSet.getBigDecimal(mapping.getSqlColumnName());
            case Types.DATE:
                return resultSet.getDate(mapping.getSqlColumnName()).getTime();
            case Types.TIME:
            case Types.TIME_WITH_TIMEZONE:
                return resultSet.getTime(mapping.getSqlColumnName()).getTime();
            case Types.TIMESTAMP:
            case Types.TIMESTAMP_WITH_TIMEZONE:
                return resultSet.getTimestamp(mapping.getSqlColumnName()).getTime();
            case Types.BINARY:
            case Types.VARBINARY:
            case Types.LONGVARBINARY:
            case Types.NULL:
            case Types.OTHER:
            case Types.JAVA_OBJECT:
            case Types.DISTINCT:
            case Types.STRUCT:
            case Types.ARRAY:
            case Types.BLOB:
            case Types.CLOB:
            case Types.REF:
            case Types.DATALINK:
            case Types.NCLOB:
            case Types.REF_CURSOR:
                return resultSet.getByte(mapping.getSqlColumnName());
            default:
                return resultSet.getString(mapping.getSqlColumnName());
        }
    }
}
