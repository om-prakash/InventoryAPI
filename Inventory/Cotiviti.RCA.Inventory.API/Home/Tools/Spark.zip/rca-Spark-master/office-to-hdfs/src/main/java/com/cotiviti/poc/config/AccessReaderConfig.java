package com.cotiviti.poc.config;

public class AccessReaderConfig {

    public static AccessReaderConfig parse(String[] args) {
        if (args == null || args.length != 3) {
            System.out.println("You need to specify three arguments.");
            throw new IllegalArgumentException("Invalid arguments.");
        }
        String accessPath = args[0];
        String tableName = args[1];
        String outputPath = args[2];
        if (accessPath.trim().length() == 0 || tableName.trim().length() == 0
                || outputPath.trim().length() == 0) {
            throw new IllegalArgumentException("Argument cannot be empty.");
        }
        return new AccessReaderConfig(accessPath, tableName, outputPath);
    }

    private final String accessPath;
    private final String tableName;
    private final String outputPath;

    private AccessReaderConfig(String accessPath, String tableName, String outputPath) {
        this.accessPath = accessPath;
        this.tableName = tableName;
        this.outputPath = outputPath;
    }

    public String getAccessPath() {
        return accessPath;
    }

    public String getTableName() {
        return tableName;
    }

    public String getOutputPath() {
        return outputPath;
    }

}
