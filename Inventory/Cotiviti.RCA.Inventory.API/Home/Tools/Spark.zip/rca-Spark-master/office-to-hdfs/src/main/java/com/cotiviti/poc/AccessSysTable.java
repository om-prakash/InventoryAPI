package com.cotiviti.poc;

import java.sql.*;

/**
 * A class to demonstrate how to access system tables to
 * get the metadata of Microsoft Access database
 *
 * In this example, we get all user defined tables via a system
 * table called MSysObjects in Access database
 */
public class AccessSysTable {
    public static void main(String[] args) throws SQLException {
        // in the connection string, sysSchema=true will allow us
        // to access system tables or views in Microsoft Access database
        // otherwise, we will get an exception when we try to access system objects
        try (Connection conn = DriverManager
                .getConnection("jdbc:ucanaccess://C:/Projects/office-to-hdfs/data/SpringTest.accdb;memory=true;sysSchema=true;")) {
            Statement stat = conn.createStatement();
            // access system table MSysObjects to get all user defined tables
            ResultSet rs = stat.executeQuery("SELECT Name FROM sys.MSysObjects WHERE Flags = 0 AND Type = 1");
            while (rs.next()) {
                System.out.println(rs.getString("Name"));
            }
        }
    }
}
