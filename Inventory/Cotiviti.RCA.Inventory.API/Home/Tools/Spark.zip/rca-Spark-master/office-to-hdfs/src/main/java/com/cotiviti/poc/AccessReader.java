package com.cotiviti.poc;

import com.cotiviti.poc.config.AccessReaderConfig;
import com.cotiviti.poc.transform.ResultSetTransformer;
import com.cotiviti.poc.transform.SchemaResults;
import com.cotiviti.poc.transform.TransformerListener;
import com.cotiviti.poc.transform.impl.ResultSetParquetTransformer;
import org.apache.avro.generic.GenericRecord;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AccessReader {
    public static void main(String[] args) throws SQLException, IOException {
        AccessReaderConfig config = null;
        try {
            config = AccessReaderConfig.parse(args);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            System.exit(-1);
        }
        // use ucanaccess JDBC drive to access Microsoft Access database across platform
        String url = String.format("jdbc:ucanaccess://%s;memory=true", config.getAccessPath());
        String statement = String.format("SELECT * FROM %s", config.getTableName());
        try (Connection conn = DriverManager
                .getConnection(url)) {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(statement);
            // convert ResultSet to Parquet or Avro
            String namespace = "com.cotiviti.poc";
            String schemaName = "entity";
            List<TransformerListener> listeners = new ArrayList<>();
            listeners.add(new TransformerListener() {
                @Override
                public void onRecordParsed(GenericRecord record) {
                    System.out.println("Avro generic record been parsed.");
                }

                @Override
                public void onSchemaParsed(SchemaResults schemaResults) {
                    System.out.println("Avro schema retrieved.");
                }
            });
            // convert java.sql.ResultSet to parquet or avro InputStream and then
            // write to the specified output path. If we run this application on windows
            // platform, then ensure the Hadoop winutils tool is presented
            ResultSetTransformer transformer = new ResultSetParquetTransformer();
            try (InputStream is = transformer.transform(rs, schemaName, namespace, listeners)) {
                try (OutputStream os = new FileOutputStream(config.getOutputPath())) {
                    byte[] buffer = new byte[8 * 1024];
                    int bytesRead;
                    while((bytesRead = is.read(buffer)) != -1) {
                        os.write(buffer, 0, bytesRead);
                    }
                }
            }
            rs.close();
            st.close();
        }
    }
}
