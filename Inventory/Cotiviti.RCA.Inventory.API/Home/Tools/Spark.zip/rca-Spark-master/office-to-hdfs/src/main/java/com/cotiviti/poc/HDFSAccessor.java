package com.cotiviti.poc;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.security.UserGroupInformation;

import java.io.IOException;

/**
 * A class to demonstrate how to access a kerberos enabled HDFS system from
 * windows platform
 *
 * In this example, we use keytab file to pass kerberos token
 */
public class HDFSAccessor {
    public static void main(String[] args) throws IOException {
        Configuration conf = new Configuration();
        conf.set("fs.defaultFS", "hdfs://norcrphdpprd11.ccaintranet.com:8020");
        conf.set("hadoop.security.authentication", "kerberos");
        conf.set("hadoop.security.authorization", "true");
        conf.set("dfs.namenode.kerberos.principal.pattern", "hdfs/*@CCAINTRANET.COM");
        UserGroupInformation.setConfiguration(conf);
        UserGroupInformation.loginUserFromKeytab("spring.zhou@CCAINTRANET.COM",
                "C:\\Temp\\spring.zhou.keytab");
        try (FileSystem fs = FileSystem.get(conf)) {
            FileStatus[] fsStatus = fs.listStatus(new Path("/user/spring.zhou"));
            for(FileStatus fstat : fsStatus) {
                System.out.println(fstat.getPath());
            }
        }
    }
}
