# Spark Rule Engine

This POC is to validate the integration between Apache Spark and JBoss Drools.

An important benefit for this approach is we bring business rules to data not opposite. 
For big data scenarios, it's especially helpful because 
the rules are much smaller compare to data itself. This approach 
can dramatically reduce the data transfer over wire.

# Highlights

- A generic data model to apply rules
- An external configuration to generalize
- Use static helper functions in rule definitions
- Use global variables in rule definitions
- Optimize the session usage of Drools

# Usage

This application developed in [JetBrains IDEA](https://www.jetbrains.com/idea/). 
You can download the community version from its official site. 
Although we suggest to use JetBrains IDEA, but you can use any IDEs that
support Maven, like Eclipse.

After you open the project in JetBrains IDEA, the 
dependencies that declared in the pom.xml should be resolved automatically.
Before you can run this application, please ensure:

- The settings in the config.json are valid
- You specify the correct argument (This application needs an 
argument to specify the path of config.json)

# Configuration

Below is a sample configuration:

```json
{
  "source": [
    {
      "format": "avro",
      "select_column": "CnlyClmJoinKey,CnlySor",
      "where_clause": "",
      "temp_view": "header",
      "path": "C:\\Projects\\spark-rule-engine\\data\\input\\header\\*.avro"
    },
    {
      "format": "parquet",
      "select_column": "CnlyClmJoinKey,NoTouchDM",
      "where_clause": "",
      "temp_view": "notouch",
      "path": "C:\\Projects\\spark-rule-engine\\data\\input\\notouch\\*.parquet"
    },
    {
      "format": "jdbc",
      "select_column": "clm_id,data_srce",
      "where_clause": "",
      "temp_view": "csv_import",
      "url": "jdbc:sqlserver://claims.sql.dev.ccaintranet.com;databaseName=SpringDev;",
      "table": "dbo.CsvImport",
      "user": "svc_appian_dev",
      "password": "***"
    }
  ],
  "sink": {
    "format": "parquet",
    "compress": true,
    "included_path": "C:\\Projects\\spark-rule-engine\\data\\output\\included",
    "excluded_path": "C:\\Projects\\spark-rule-engine\\data\\output\\excluded"
  },
  "rule": {
    "definition_path": "",
    "globals": {
      "ADURN_1": ["DURN", "AURN"],
      "CORE_1": ["63"],
      "SOR": [808]
    }
  },
  "enrich": {
    "sql": "SELECT h.*, ifnull(n.NoTouchDM, 0) AS NoTouchDM FROM header AS h LEFT OUTER JOIN notouch AS n ON h.CnlyClmJoinKey = n.CnlyClmJoinKey",
    "key": "CnlyClmJoinKey"
  }
}
```