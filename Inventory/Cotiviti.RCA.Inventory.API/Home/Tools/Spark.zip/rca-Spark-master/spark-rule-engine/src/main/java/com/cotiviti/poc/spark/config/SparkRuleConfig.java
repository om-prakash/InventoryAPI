package com.cotiviti.poc.spark.config;

/**
 * A class that represents the command line argument
 */
public class SparkRuleConfig {

    public static SparkRuleConfig parse(String[] args) {
        if (args == null || args.length == 0) {
            throw new IllegalArgumentException("Invalid arguments found.");
        }
        String input = args[0];
        if (input.trim().length() == 0) {
            throw new IllegalArgumentException("Invalid arguments found.");
        }
        return new SparkRuleConfig(input);
    }

    private String input;
    private SparkRuleConfig(String input) {
        this.input = input;
    }

    public String getInput() {
        return input;
    }
}
