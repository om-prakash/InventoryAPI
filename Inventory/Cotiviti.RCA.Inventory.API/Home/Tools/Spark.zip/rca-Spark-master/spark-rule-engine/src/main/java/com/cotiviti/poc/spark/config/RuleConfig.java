package com.cotiviti.poc.spark.config;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.Map;

/**
 * A class that represents the rule section in
 * the external configuration json file
 */
public class RuleConfig implements Serializable {
    @JsonProperty("definition_path")
    private String definitionPath;
    private Map<String, Object> globals;

    public String getDefinitionPath() {
        return definitionPath;
    }

    public void setDefinitionPath(String definitionPath) {
        this.definitionPath = definitionPath;
    }

    public Map<String, Object> getGlobals() {
        return globals;
    }

    public void setGlobals(Map<String, Object> globals) {
        this.globals = globals;
    }
}
