package com.cotiviti.poc.spark.util;

import com.cotiviti.poc.spark.model.Claim;
import org.kie.api.KieBase;
import org.kie.api.KieServices;
import org.kie.api.runtime.StatelessKieSession;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class KnowledgeSessionHelper {

    /**
     * Load defined rules and return an instance of KieBase
     * @return An instance of {@link KieBase}
     */
    public static KieBase loadRules() {
        // KieBase is heavy, so initialize once and reuse it
        KieServices ks = KieServices.Factory.get();
        return ks.getKieClasspathContainer().getKieBase("rules");
    }

    /**
     * Apply rules against a list of fact object
     *
     * We apply business rules against all fact objects in a partition
     *
     * @param base An instance of {@link KieBase}
     * @param claims A list of instance of {@link Claim}
     * @param globals A map to hold all possible global variables for the Kie Session
     * @return A list of modified instance of {@link Claim}
     */
    public static Iterator<Claim> applyRules(KieBase base, Iterator<Claim> claims, Map<String, Object> globals) {
        // Session is relatively light, so we can create a session per partition
        StatelessKieSession session = base.newStatelessKieSession();
        // if globals map is not null and empty, then set globals on session object
        if (globals != null && !globals.isEmpty()) {
            session.setGlobal("config", globals);
        }
        List<Claim> result = new ArrayList<>();
        Claim item;
        while(claims.hasNext()) {
            item = claims.next();
            // fire all rules that we defined
            session.execute(item);
            result.add(item);
        }
        return result.iterator();
    }

}
