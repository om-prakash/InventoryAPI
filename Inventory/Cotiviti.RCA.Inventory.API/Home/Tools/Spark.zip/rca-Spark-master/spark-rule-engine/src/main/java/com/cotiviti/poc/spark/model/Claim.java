package com.cotiviti.poc.spark.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * A class that represents fact data object that passed into
 * Drools rule engine
 */
public class Claim implements Serializable {
    // primary key that identifies a medical claim
    private long clmJoinKey;
    // boolean flag that indicates if a medical claim
    // should be excluded. This flag updated by rule engine
    private boolean excluded = false;
    // reason of exclusion. It updated by rule engine
    private String reason = "";
    // a hashmap to contain all facts that required by rule definitions
    private Map<String, Object> pairs = new HashMap<>();

    public Claim() {

    }

    public Claim(long clmJoinKey, Map<String, Object> pairs) {
        this.clmJoinKey = clmJoinKey;
        if (pairs != null) {
            this.pairs = pairs;
        }
    }

    public long getClmJoinKey() {
        return clmJoinKey;
    }

    public void setClmJoinKey(long clmJoinKey) {
        this.clmJoinKey = clmJoinKey;
    }

    public boolean isExcluded() {
        return excluded;
    }

    public void setExcluded(boolean excluded) {
        this.excluded = excluded;
    }

    public Map<String, Object> getPairs() {
        return pairs;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}
