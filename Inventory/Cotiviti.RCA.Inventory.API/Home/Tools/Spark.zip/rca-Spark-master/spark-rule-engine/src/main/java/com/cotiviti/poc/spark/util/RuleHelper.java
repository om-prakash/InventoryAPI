package com.cotiviti.poc.spark.util;

import java.util.Map;

/**
 * A class that defines helper static methods that can be used
 * in rule definitions
 *
 * If we need to reuse a piece of codes in rule definitions, we can extract
 * the piece of codes and define a function in this class and then use the import
 * function statement in rule definitions to import those functions
 */
public class RuleHelper {
    /**
     * Return a string from a hashmap based on a specified key
     *
     * If the key does not exist, then return empty string instead
     *
     * @param map An instance of {@link java.util.HashMap}
     * @param key A string that represents the key of map entry
     * @return A string that represents the value of map entry
     */
    public static String getAsString(Map<String, Object> map, String key) {
        return map.getOrDefault(key, "").toString();
    }

    /**
     * Return an integer from a hashmap based on a specified key
     *
     * If the key does not exist, then return 0 instead
     *
     * @param map An instance of {@link java.util.HashMap}
     * @param key A string that represents the key of map entry
     * @return An integer that represents the value of map entry
     */
    public static int getAsInteger(Map<String, Object> map, String key) {
        return (int)map.getOrDefault(key, 0);
    }
}
