package com.cotiviti.poc.spark;

import com.cotiviti.poc.spark.config.EngineConfig;
import com.cotiviti.poc.spark.config.SourceConfig;
import com.cotiviti.poc.spark.config.SparkRuleConfig;
import com.cotiviti.poc.spark.model.Claim;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.kie.api.KieBase;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.cotiviti.poc.spark.util.KnowledgeSessionHelper.applyRules;
import static com.cotiviti.poc.spark.util.KnowledgeSessionHelper.loadRules;

public class SparkRuleDemo {

    public static void main(String[] args) {
        EngineConfig engineConfig = null;
        try {
            SparkRuleConfig config = SparkRuleConfig.parse(args);
            // load global configuration JSON and
            // deserialize to an instance of EngineConfig
            engineConfig = new ObjectMapper()
                    .readValue(new File(config.getInput()), EngineConfig.class);
        } catch(Exception ex) {
            System.out.println(ex.getMessage());
            System.exit(-1);
        }
        boolean hasError = false;
        // load rule engine
        // this operation is expensive, so we load it on drive node
        // and then broadcast to all worker nodes
        final KieBase rules = loadRules();
        // load global configuration of rule engine
        // we can use this global configuration in rule definitions
        final Map<String, Object> globals = engineConfig.getRule().getGlobals();
        try (SparkSession spark = SparkSession.builder()
                .master("local[*]")
                .appName("Spark Rule Demo")
                .getOrCreate()) {
            try {
                JavaSparkContext sc = JavaSparkContext.fromSparkContext(spark.sparkContext());
                // broadcast rules to executors
                Broadcast<KieBase> bcRules = sc.broadcast(rules);
                // broadcast Drools global variable to executors
                Broadcast<Map<String, Object>> bcGlobals = sc.broadcast(globals);
                // load sources based on the configuration
                // we can load all kinds of data sources (parquet, avro, jdbc, etc.) dynamically
                loadSources(spark, engineConfig);
                // enrich based on loaded sources
                // the purpose of enrichment is to gather data elements that
                // required by our rule definitions. Because those data elements
                // can exist across different data sources, so we use the enrichment to gather data
                Dataset<Row> dfEnriched = spark.sql(engineConfig.getEnrich().getSql());
                // convert enriched data into our data model
                final String key = engineConfig.getEnrich().getKey();
                Dataset<Claim> dfClaim = dfEnriched.map(row -> buildClaim(row, key), Encoders.bean(Claim.class));
                // apply rules against fact data
                dfClaim = dfClaim.mapPartitions(claims -> applyRules(bcRules.getValue(), claims, bcGlobals.getValue()), Encoders.bean(Claim.class));
                // currently we only show result on the screen, you
                // can write this result to HDFS
                dfClaim.show(20, false);
                // release broadcast variables
                bcRules.destroy();
                bcGlobals.destroy();
            } catch(Exception inx) {
                System.out.println(inx.getMessage());
                hasError = true;
            }
        }
        if (hasError) {
            System.exit(-1);
        }
    }

    /**
     * Convert Spark SQL Row object to Claim object
     * @param row An object of {@link Row}
     * @param key A string that represents primary key of a claim
     * @return An instance of {@link Claim}
     */
    private static Claim buildClaim(Row row, String key) {
        String[] fields = row.schema().fieldNames();
        Map<String, Object> pairs = new HashMap<>();
        for(String field : fields) {
            // exclude the primary key because we do not need to
            // put the primary key into pairs hashmap
            if (field.toLowerCase().equals(key.toLowerCase())) continue;
            pairs.put(field, row.getAs(field));
        }
        return new Claim(row.getAs(key), pairs);
    }

    /**
     * Load configured data sources and create temp views in Hive meta store
     * @param spark An instance of {@link SparkSession}
     * @param config An instance of {@link EngineConfig}
     * @throws Exception An exception
     */
    private static void loadSources(SparkSession spark,EngineConfig config) throws Exception {
        List<SourceConfig> sources = config.getSource();
        if (sources == null || sources.size() == 0) {
            throw new Exception("The configuration of source is invalid.");
        }
        String format;
        for(SourceConfig sc : sources) {
            format = sc.getFormat().toLowerCase();
            switch (format) {
                case "avro":
                case "parquet":
                    loadFileSource(spark, sc);
                    break;
                case "jdbc":
                    loadDBSource(spark, sc);
                    break;
                default:
                    throw new Exception(String.format("The format of %s is not supported", format));
            }
        }
    }

    /**
     * Load file based data sources and create temp views in Hive meta store
     * the possible formats can be parquet, avro, etc.
     * @param spark An instance of {@link SparkSession}
     * @param sc An instance of {@link SourceConfig}
     * @throws Exception An exception
     */
    private static void loadFileSource(SparkSession spark, SourceConfig sc) throws Exception {
        String path = sc.getOption().getOrDefault("path", "");
        if (path.trim().length() == 0) {
            throw new Exception("The path of source is invalid.");
        }
        String view = sc.getTempView();
        Dataset<Row> dfSource = spark
                .read()
                .format(sc.getFormat())
                .load(path);
        dfSource = applyFilterAndProject(dfSource, sc);
        dfSource.createOrReplaceTempView(view);
    }

    /**
     * Load database based data sources and create temp views in Hive meta store
     * @param spark An instance of {@link SparkSession}
     * @param sc An instance of {@link SourceConfig}
     */
    private static void loadDBSource(SparkSession spark, SourceConfig sc) {
        String url = sc.getOption().get("url");
        String table = sc.getOption().get("table");
        String user = sc.getOption().get("user");
        String password = sc.getOption().get("password");
        String view = sc.getTempView();
        Dataset<Row> dfSource = spark
                .read()
                .format(sc.getFormat())
                .option("url", url)
                .option("dbtable", table)
                .option("user", user)
                .option("password", password)
                .load();
        dfSource = applyFilterAndProject(dfSource, sc);
        dfSource.createOrReplaceTempView(view);
    }

    /**
     * Apply filters and projections against a dataframe and return
     * the revised dataframe
     * @param origin An instance of {@link Dataset<Row>}
     * @param sc An instance of {@link SourceConfig}
     * @return A revised dataframe
     */
    private static Dataset<Row> applyFilterAndProject(Dataset<Row> origin, SourceConfig sc) {
        String columns = sc.getSelectColumn();
        String where = sc.getWhereClause();
        if (where.trim().length() > 0) {
            origin = origin.where(where);
        }
        if (!columns.trim().equals("*")) {
            String[] cols = Arrays.stream(columns.split(","))
                    .map(String::trim)
                    .toArray(String[]::new);
            String firstColumn = cols[0];
            String[] restColumns = Arrays.copyOfRange(cols, 1, cols.length);
            origin = origin.select(firstColumn, restColumns);
        }
        return origin;
    }
}
