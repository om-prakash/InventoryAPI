package com.cotiviti.poc.spark.config;

import java.io.Serializable;
import java.util.List;

/**
 * A class that represents configuration of rule engine
 * Use Jackson library to deserialize from the external configuration
 * json file
 */
public class EngineConfig implements Serializable {
    private List<SourceConfig> source;
    private SinkConfig sink;
    private RuleConfig rule;
    private EnrichConfig enrich;

    public List<SourceConfig> getSource() {
        return source;
    }

    public void setSource(List<SourceConfig> source) {
        this.source = source;
    }

    public SinkConfig getSink() {
        return sink;
    }

    public void setSink(SinkConfig sink) {
        this.sink = sink;
    }

    public RuleConfig getRule() {
        return rule;
    }

    public void setRule(RuleConfig rule) {
        this.rule = rule;
    }

    public EnrichConfig getEnrich() {
        return enrich;
    }

    public void setEnrich(EnrichConfig enrich) {
        this.enrich = enrich;
    }
}
