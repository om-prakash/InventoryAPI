package com.cotiviti.poc.spark.config;

import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * A class that represents the source section in
 * the external configuration json file
 *
 * Use @JsonAnySetter annotation to allow arbitrary key value
 * pairs in the source section. Those arbitrary key value pairs
 * will be added into the option hashmap after deserialization
 */
public class SourceConfig implements Serializable {
    private String format;
    @JsonProperty("select_column")
    private String selectColumn;
    @JsonProperty("where_clause")
    private String whereClause;
    @JsonProperty("temp_view")
    private String tempView;
    private Map<String, String> option = new HashMap<>();

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getSelectColumn() {
        return selectColumn;
    }

    public void setSelectColumn(String selectColumn) {
        this.selectColumn = selectColumn;
    }

    public String getWhereClause() {
        return whereClause;
    }

    public void setWhereClause(String whereClause) {
        this.whereClause = whereClause;
    }

    public String getTempView() {
        return tempView;
    }

    public void setTempView(String tempView) {
        this.tempView = tempView;
    }

    public Map<String, String> getOption() {
        return option;
    }

    @JsonAnySetter
    public void addOption(String key, String value) {
        option.put(key, value);
    }
}
