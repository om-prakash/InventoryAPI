package com.cotiviti.poc.spark.config;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

/**
 * A class that represents the sink section in
 * the external configuration json file
 */
public class SinkConfig implements Serializable {
    private String format;
    private boolean compress;
    @JsonProperty("included_path")
    private String includedPath;
    @JsonProperty("excluded_path")
    private String excludedPath;

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public boolean isCompress() {
        return compress;
    }

    public void setCompress(boolean compress) {
        this.compress = compress;
    }

    public String getIncludedPath() {
        return includedPath;
    }

    public void setIncludedPath(String includedPath) {
        this.includedPath = includedPath;
    }

    public String getExcludedPath() {
        return excludedPath;
    }

    public void setExcludedPath(String excludedPath) {
        this.excludedPath = excludedPath;
    }
}
