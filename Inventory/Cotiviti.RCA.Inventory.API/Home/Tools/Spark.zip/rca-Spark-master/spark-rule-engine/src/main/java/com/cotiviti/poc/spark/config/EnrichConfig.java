package com.cotiviti.poc.spark.config;

import java.io.Serializable;

/**
 * A class that represents the enrich section in
 * the external configuration json file
 */
public class EnrichConfig implements Serializable {
    private String sql;
    private String key;

    public String getSql() {
        return sql;
    }

    public void setSql(String sql) {
        this.sql = sql;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
