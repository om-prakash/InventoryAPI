import subprocess
import argparse

from pyspark.sql.session import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *

spark = SparkSession.builder.getOrCreate()

parser = argparse.ArgumentParser()
parser.add_argument("--ClientName")
args = parser.parse_args()
if args.ClientName:
    ClientName = args.ClientName.lower()

ClientName = 'Anthem'
raw_path = "/rca/" + ClientName + "/data/raw/"
ClientName = 'anthem'
transformed_path = "/rca/refined/claimsplus/" + ClientName + "/"

cp_schema = StructType(
    [StructField("AuditID", IntegerType(), False),
     StructField("AuditPass", ShortType(), True),
     StructField("CheckNum", StringType(), True),
     StructField("ClaimAuditPass", ShortType(), True),
     StructField("ClaimAuthor", StringType(), True),
     StructField("ClaimCode", StringType(), True),
     StructField("ClaimCodeClient", StringType(), True),
     StructField("ClaimCodeClientText", StringType(), False),
     StructField("ClaimCodeText", StringType(), False),
     StructField("ClaimDate", TimestampType(), False),
     StructField("ClaimDays", IntegerType(), True),
     StructField("ClaimDesc", StringType(), True),
     StructField("ClaimID", StringType(), False),
     StructField("ClaimMonths", IntegerType(), True),
     StructField("ClaimNum", StringType(), False),
     StructField("ClaimPrefix", StringType(), True),
     StructField("ClaimSrc", StringType(), True),
     StructField("ClaimSrcRootTxt", StringType(), True),
     StructField("ClaimSrcTxt", StringType(), True),
     StructField("ClaimSuffix", StringType(), True),
     StructField("ClientDiv", StringType(), True),
     StructField("ConnollyAuditPass", ShortType(), True),
     StructField("DedAmt", DecimalType(18, 2), False),
     StructField("DedCT", IntegerType(), True),
     StructField("GrossAmt", DecimalType(18, 2), False),
     StructField("LastDedDate", TimestampType(), True),
     StructField("LastTranDate", TimestampType(), True),
     StructField("LastUserName", StringType(), True),
     StructField("LedgerCT", IntegerType(), True),
     StructField("LocationCode", StringType(), True),
     StructField("NetAmt", DecimalType(18, 2), False),
     StructField("PayBackAmt", DecimalType(18, 2), False),
     StructField("PaybackCode", StringType(), True),
     StructField("PaybackCodeClient", StringType(), True),
     StructField("PaybackCodeClientText", StringType(), False),
     StructField("PaybackCodeText", StringType(), False),
     StructField("ProjectID", StringType(), True),
     StructField("ProjectName", StringType(), False),
     StructField("RecoveryAmt", DecimalType(18, 2), False),
     StructField("RootCause", StringType(), True),
     StructField("StatusDesc", StringType(), True),
     StructField("StatusID", ShortType(), False),
     StructField("TranCT", IntegerType(), True),
     StructField("User001", StringType(), True),
     StructField("User002", StringType(), True),
     StructField("User003", StringType(), True),
     StructField("User004", StringType(), True),
     StructField("User005", StringType(), True),
     StructField("User006", StringType(), True),
     StructField("User007", StringType(), True),
     StructField("User008", StringType(), True),
     StructField("User009", StringType(), True),
     StructField("User010", StringType(), True),
     StructField("User011", StringType(), True),
     StructField("User012", StringType(), True),
     StructField("User013", StringType(), True),
     StructField("User014", StringType(), True),
     StructField("User015", StringType(), True),
     StructField("User016", StringType(), True),
     StructField("User017", StringType(), True),
     StructField("User018", StringType(), True),
     StructField("User019", StringType(), True),
     StructField("User020", StringType(), True),
     StructField("User021", StringType(), True),
     StructField("User022", StringType(), True),
     StructField("User023", StringType(), True),
     StructField("User024", StringType(), True),
     StructField("User025", StringType(), True),
     StructField("User026", StringType(), True),
     StructField("User027", StringType(), True),
     StructField("User028", StringType(), True),
     StructField("User029", StringType(), True),
     StructField("User030", StringType(), True),
     StructField("User031", StringType(), True),
     StructField("User032", StringType(), True),
     StructField("User033", StringType(), True),
     StructField("User034", StringType(), True),
     StructField("User035", StringType(), True),
     StructField("User036", StringType(), True),
     StructField("User037", StringType(), True),
     StructField("User038", StringType(), True),
     StructField("User039", StringType(), True),
     StructField("User040", StringType(), True),
     StructField("User041", StringType(), True),
     StructField("User042", StringType(), True),
     StructField("User043", StringType(), True),
     StructField("User044", StringType(), True),
     StructField("User045", StringType(), True),
     StructField("User046", StringType(), True),
     StructField("User047", StringType(), True),
     StructField("User048", StringType(), True),
     StructField("User049", StringType(), True),
     StructField("User050", StringType(), True),
     StructField("User051", StringType(), True),
     StructField("User052", StringType(), True),
     StructField("User053", StringType(), True),
     StructField("User054", StringType(), True),
     StructField("User055", StringType(), True),
     StructField("User056", StringType(), True),
     StructField("User057", StringType(), True),
     StructField("User058", StringType(), True),
     StructField("User059", StringType(), True),
     StructField("User060", StringType(), True),
     StructField("User061", StringType(), True),
     StructField("User062", StringType(), True),
     StructField("User063", StringType(), True),
     StructField("User064", StringType(), True),
     StructField("User065", StringType(), True),
     StructField("User066", StringType(), True),
     StructField("User067", StringType(), True),
     StructField("User068", StringType(), True),
     StructField("User069", StringType(), True),
     StructField("User070", StringType(), True),
     StructField("User071", StringType(), True),
     StructField("User072", StringType(), True),
     StructField("User073", StringType(), True),
     StructField("User074", StringType(), True),
     StructField("User075", StringType(), True),
     StructField("User076", StringType(), True),
     StructField("User077", StringType(), True),
     StructField("User078", StringType(), True),
     StructField("User079", StringType(), True),
     StructField("User080", StringType(), True),
     StructField("User081", StringType(), True),
     StructField("User082", StringType(), True),
     StructField("User083", StringType(), True),
     StructField("User084", StringType(), True),
     StructField("User085", StringType(), True),
     StructField("User086", StringType(), True),
     StructField("User087", StringType(), True),
     StructField("User088", StringType(), True),
     StructField("User089", StringType(), True),
     StructField("User090", StringType(), True),
     StructField("User091", StringType(), True),
     StructField("User092", StringType(), True),
     StructField("User093", StringType(), True),
     StructField("User094", StringType(), True),
     StructField("User095", StringType(), True),
     StructField("User096", StringType(), True),
     StructField("User097", StringType(), True),
     StructField("User098", StringType(), True),
     StructField("User099", StringType(), True),
     StructField("User100", StringType(), True),
     StructField("ValID", StringType(), True),
     StructField("Validated", ShortType(), True),
     StructField("ValName", StringType(), True),
     StructField("VenAdd1", StringType(), True),
     StructField("VenAdd2", StringType(), True),
     StructField("VenAdd3", StringType(), True),
     StructField("VenCity", StringType(), True),
     StructField("VenID1", StringType(), True),
     StructField("VenID2", StringType(), True),
     StructField("VenName", StringType(), True),
     StructField("VenSt", StringType(), True),
     StructField("VenZip", StringType(), True),
     StructField("VoidAmt", DecimalType(18, 2), False),
     StructField("VoidCode", StringType(), True),
     StructField("VoidCodeClient", StringType(), True),
     StructField("VoidCodeClientText", StringType(), False),
     StructField("VoidCodeText", StringType(), False),
     StructField("CreatedDate", TimestampType(), True),
     StructField("CreatedHost", StringType(), True),
     StructField("CreatedUser", StringType(), True),
     StructField("UpdatedDate", TimestampType(), True),
     StructField("UpdatedHost", StringType(), True),
     StructField("UpdatedUser", StringType(), True),
     StructField("RecoveredAmt", DecimalType(18, 2), False),
     StructField("CompanyID", IntegerType(), True),
     StructField("CompanyName", StringType(), True),
     StructField("CnlyClaimID", StringType(), True),
     StructField("CnlyLineID", IntegerType(), True),
     StructField("MedClaimID", StringType(), True),
     StructField("MedClaimLineID", StringType(), True),
     StructField("AssociatedClaimID", StringType(), True),
     StructField("PlatformCode", StringType(), True),
     StructField("BillingProviderID", StringType(), True),
     StructField("BillingProviderName", StringType(), True),
     StructField("TaxIDNumber", StringType(), True),
     StructField("TaxIDProviderName", StringType(), True),
     StructField("ServicingProviderID", StringType(), True),
     StructField("ServicingProviderName", StringType(), True),
     StructField("ServicingProviderState", StringType(), True),
     StructField("NPI", StringType(), True),
     StructField("MemberID", StringType(), True),
     StructField("RelationshipCode", StringType(), True),
     StructField("RelationshipDescription", StringType(), True),
     StructField("BeginDOS", TimestampType(), True),
     StructField("EndDOS", TimestampType(), True),
     StructField("PaidDate", TimestampType(), True),
     StructField("InvoicedDate", TimestampType(), True),
     StructField("InvoiceNumber", StringType(), True),
     StructField("PaidAmt", DecimalType(18, 2), True),
     StructField("ChargeAmt", DecimalType(18, 2), True),
     StructField("CheckNumber", StringType(), True),
     StructField("ClientDivision", StringType(), True),
     StructField("ClientLOB", StringType(), True),
     StructField("LOBID", ShortType(), True),
     StructField("LOBName", StringType(), True),
     StructField("PlanTypeID", ShortType(), True),
     StructField("PlanType", StringType(), True),
     StructField("FundingTypeID", ShortType(), True),
     StructField("FundingType", StringType(), True),
     StructField("PARIndicator", ShortType(), True),
     StructField("ProviderTypeID", ShortType(), True),
     StructField("ProviderType", StringType(), True),
     StructField("PlaceOfService", StringType(), True),
     StructField("MedicareFacilityID", StringType(), True),
     StructField("MedicaidFacilityID", StringType(), True),
     StructField("ScreenName", StringType(), True),
     StructField("ReportNumber", StringType(), True),
     StructField("RevenueCode", StringType(), True),
     StructField("CPTCode", StringType(), True),
     StructField("HCPCSCode", StringType(), True),
     StructField("Modifier1", StringType(), True),
     StructField("Modifier2", StringType(), True),
     StructField("Modifier3", StringType(), True),
     StructField("DRGBilled", StringType(), True),
     StructField("CorrectedDRG", StringType(), True),
     StructField("DRGTypeCode", StringType(), True),
     StructField("DRGTypeName", StringType(), True),
     StructField("UnitsBilled", IntegerType(), True),
     StructField("CorrectedUnits", IntegerType(), True),
     StructField("BillTypeCode", StringType(), True),
     StructField("TotalClaimCharges", DecimalType(18, 2), True),
     StructField("OutlierPaymentCalc", DecimalType(18, 2), True),
     StructField("LengthOfStay", IntegerType(), True),
     StructField("AdmitTypeID", ShortType(), True),
     StructField("AdmitType", StringType(), True),
     StructField("DischargeStatusCode", StringType(), True),
     StructField("Diagnosis", StringType(), True),
     StructField("AdmitDiagnosis", StringType(), True),
     StructField("PrimaryDiagnosis", StringType(), True),
     StructField("ICDProcedureCodes", StringType(), True),
     StructField("AllowedAmt", DecimalType(18, 2), True),
     StructField("CopayAmt", DecimalType(18, 2), True),
     StructField("CoinsuranceAmt", DecimalType(18, 2), True),
     StructField("AuditStatusCode", StringType(), True),
     StructField("HCCOMFieldCreatedDate", TimestampType(), True),
     StructField("HCCOMFieldCreatedHost", StringType(), True),
     StructField("HCCOMFieldCreatedUser", StringType(), True),
     StructField("HCCOMFieldUpdatedDate", TimestampType(), True),
     StructField("HCCOMFieldUpdatedHost", StringType(), True),
     StructField("HCCOMFieldUpdatedUser", StringType(), True),
     StructField("FirstTranDate", TimestampType(), True),
     StructField("FirstDedDate", TimestampType(), True),
     StructField("DaysToDeduct", IntegerType(), True),
     StructField("OutstandingClaimDedAmt", DecimalType(18, 2), True),
     StructField("DaysToDeductAging", StringType(), True),
     StructField("IsConnollyClaim", IntegerType(), False),
     StructField("NetClaimDedAmt", DecimalType(18, 2), False),
     StructField("NetClaimIDAmt", DecimalType(18, 2), True),
     StructField("OICARRID", ShortType(), True),
     StructField("OICARRNM", StringType(), True),
     StructField("OICARRNBR", StringType(), True),
     StructField("MEDAEFFDT", TimestampType(), True),
     StructField("MEDBEFFDT", TimestampType(), True),
     StructField("COMOIEFFDT", TimestampType(), True),
     StructField("PrimeDt", TimestampType(), True),
     StructField("LastMirrorDate", TimestampType(), False),
     StructField("IsArchived", ShortType(), True),
     StructField("ClaimValue", DecimalType(18, 2), True)]
)

ledger_schema = StructType(
    [StructField("AuditID", IntegerType(), False),
     StructField("ClaimID", StringType(), False),
     StructField("ClaimNum", StringType(), False),
     StructField("LedgerID", StringType(), False),
     StructField("ParentLedgerID", StringType(), True),
     StructField("Reference", StringType(), True),
     StructField("TranAmt", DecimalType(18, 2), False),
     StructField("TranClientCode", StringType(), True),
     StructField("TranClientCodeText", StringType(), True),
     StructField("TranCode", StringType(), False),
     StructField("TranCodeText", StringType(), True),
     StructField("TranComment", StringType(), True),
     StructField("TranDate", TimestampType(), False),
     StructField("TranType", ShortType(), False),
     StructField("TranTypeName", StringType(), True),
     StructField("CreatedDate", TimestampType(), False),
     StructField("CreatedHost", StringType(), True),
     StructField("CreatedUser", StringType(), True),
     StructField("LastUserName", StringType(), True),
     StructField("UpdatedDate", TimestampType(), False),
     StructField("UpdatedHost", StringType(), True),
     StructField("UpdatedUser", StringType(), True),
     StructField("LastMirrorDate", TimestampType(), True)]
)

deductions_schema = StructType(
    [StructField("AuditID", IntegerType(), False),
     StructField("CheckNum", StringType(), True),
     StructField("ClaimID", StringType(), False),
     StructField("ClaimNum", StringType(), False),
     StructField("DedAmt", DecimalType(18, 2), False),
     StructField("DedDate", TimestampType(), True),
     StructField("DedNotes", StringType(), True),
     StructField("DeductionID", StringType(), False),
     StructField("RefNum", StringType(), True),
     StructField("CreatedDate", TimestampType(), False),
     StructField("CreatedHost", StringType(), True),
     StructField("CreatedUser", StringType(), True),
     StructField("LastUserName", StringType(), True),
     StructField("UpdatedDate", TimestampType(), False),
     StructField("UpdatedHost", StringType(), True),
     StructField("UpdatedUser", StringType(), True),
     StructField("LastMirrorDate", TimestampType(), True)]
)

cp_flag_schema = StructType(
    [StructField("CPFlagID", IntegerType(), False),
     StructField("CompanyID", ShortType(), False),
     StructField("AuditID", ShortType(), False),
     StructField("ClaimNum", StringType(), False),
     StructField("CnlyClmJoinKey", LongType(), False),
     StructField("CPFlag", StringType(), False),
     StructField("LastUpdate", TimestampType(), True)]
)

audits_schema = StructType(
    [StructField("AgeToDeduct", ShortType(), False),
     StructField("AuditDesc", StringType(), True),
     StructField("AuditEndDte", TimestampType(), True),
     StructField("AuditEndYR", ShortType(), False),
     StructField("AuditID", IntegerType(), False),
     StructField("AuditPass", ShortType(), False),
     StructField("AuditPctCompleted", ShortType(), True),
     StructField("AuditPropEndDte", TimestampType(), True),
     StructField("AuditPropStartDte", TimestampType(), True),
     StructField("AuditStartDte", TimestampType(), True),
     StructField("AuditStartYR", ShortType(), False),
     StructField("AuditYear", StringType(), True),
     StructField("BillingReserveDuration", ShortType(), False),
     StructField("BillingReservePct", DecimalType(2, 2), False),
     StructField("CcaDivName", StringType(), True),
     StructField("CCALobID", IntegerType(), True),
     StructField("CcaLOBName", StringType(), True),
     StructField("ClaimComments", StringType(), True),
     StructField("ClaimImagePathOverride", StringType(), True),
     StructField("ClaimNextNumber", LongType(), False),
     StructField("ClaimPrefix", StringType(), True),
     StructField("ClaimSuffix", StringType(), True),
     StructField("ClientDiv", StringType(), True),
     StructField("CommentsFinancial", StringType(), True),
     StructField("CommentsReservePct", StringType(), True),
     StructField("CommentsStatus", StringType(), True),
     StructField("CommentsToDo", StringType(), True),
     StructField("CompanyID", IntegerType(), False),
     StructField("CompanyName", StringType(), True),
     StructField("DebitBalAmt", DecimalType(18, 2), False),
     StructField("EstimatedManWeeks", DecimalType(6, 2), False),
     StructField("EstimatedRecoveries", DecimalType(18, 2), False),
     StructField("FixedFee", IntegerType(), False),
     StructField("FlgStatClientRelations", ShortType(), False),
     StructField("GPLOB", StringType(), True),
     StructField("GrossRecoverAmt", DecimalType(18, 2), False),
     StructField("JobAmt1", IntegerType(), False),
     StructField("JobAmt2", IntegerType(), False),
     StructField("JobAmt3", IntegerType(), False),
     StructField("JobAmt4", IntegerType(), False),
     StructField("JobRate1", DecimalType(18, 4), False),
     StructField("JobRate2", DecimalType(18, 4), False),
     StructField("JobRate3", DecimalType(18, 4), False),
     StructField("JobRate4", DecimalType(18, 4), False),
     StructField("ManWeeks", DecimalType(18, 4), False),
     StructField("PaybackAmt", DecimalType(18, 2), False),
     StructField("PctOtt", DecimalType(18, 4), False),
     StructField("ToDoDataRequestDte", TimestampType(), True),
     StructField("ToDoIssueMLDte", TimestampType(), True),
     StructField("ToDoMLDueDte", TimestampType(), True),
     StructField("ToDoReviewMLDte", TimestampType(), True),
     StructField("ToDoSecurePaperDte", TimestampType(), True),
     StructField("ToDoWriteMLDte", TimestampType(), True),
     StructField("Unprocessed", DecimalType(18, 2), False),
     StructField("UnrecoverableAmt", DecimalType(18, 2), False),
     StructField("Voids", DecimalType(18, 2), False),
     StructField("CreatedDate", TimestampType(), False),
     StructField("CreatedHost", StringType(), True),
     StructField("CreatedUser", StringType(), True),
     StructField("LastUserName", StringType(), True),
     StructField("UpdatedDate", TimestampType(), False),
     StructField("UpdatedHost", StringType(), True),
     StructField("UpdatedUser", StringType(), True),
     StructField("CannotEditOthersTimeBitmask", IntegerType(), False),
     StructField("ShortName", StringType(), False),
     StructField("PreviousAuditID", IntegerType(), True),
     StructField("PreviousAuditDesc", StringType(), True),
     StructField("TranCodeClientMappingDirectionID", ShortType(), False),
     StructField("TranCodeClientMappingDirection", StringType(), True),
     StructField("TimeEntriesReadOnlyAfterDays", ShortType(), True),
     StructField("AccountStandardsOptInStartDate", DateType(), True),
     StructField("AuditsFunction", StringType(), True),
     StructField("CompanyOrganization", StringType(), True),
     StructField("CompanyPayerType", StringType(), True),
     StructField("DefaultCurrencyCode", StringType(), False),
     StructField("DefaultCurrencyCodeDesc", StringType(), True),
     StructField("CurrencyRequired", ShortType(), False),
     StructField("LastMirrorDate", TimestampType(), True)]
)

rawfilename = "vCnlyClaimsPlusHCCOM_Mirror_Audits"

sqoop_path = raw_path + "/sqoop/claimsplus/" + rawfilename
avro_path = raw_path + "/claimsplus/" + rawfilename
parquet_path = raw_path + "/parquet/claimsplus/" + rawfilename

audits = spark.read.schema(audits_schema)\
    .csv(
    path = sqoop_path,
    header = "false",
    sep = "|")\
    .repartition(1)\
    .write.mode("overwrite")\
    .format("avro")\
    .save(avro_path)

audits_df = spark.read.format("avro")\
    .load(avro_path)\
    .repartition(1)\
    .write.mode("overwrite")\
    .parquet(parquet_path)

rawfilename = "vCnlyClaimsPlusHCCOM_Mirror"

sqoop_path = raw_path + "/sqoop/claimsplus/" + rawfilename
avro_path = raw_path + "/claimsplus/" + rawfilename
parquet_path = raw_path + "/parquet/claimsplus/" + rawfilename

cp = spark.read.schema(cp_schema)\
    .csv(
    path = sqoop_path,
    header = "false",
    sep = "|")\
    .write.mode("overwrite")\
    .format("avro")\
    .save(avro_path)

cp_df = spark.read.format("avro")\
    .load(avro_path)\
    .repartition(4)\
    .write.mode("overwrite")\
    .parquet(parquet_path)

rawfilename = "vCnlyClaimsPlusHCCOM_Mirror_Ledger"

sqoop_path = raw_path + "/sqoop/claimsplus/" + rawfilename
avro_path = raw_path + "/claimsplus/" + rawfilename
parquet_path = raw_path + "/parquet/claimsplus/" + rawfilename

ledger = spark.read.schema(ledger_schema)\
    .csv(
    path = sqoop_path,
    header = "false",
    sep = "|")\
    .write.mode("overwrite")\
    .format("avro")\
    .save(avro_path)

ledger_df = spark.read.format("avro")\
    .load(avro_path)\
    .repartition(4)\
    .write.mode("overwrite")\
    .parquet(parquet_path)

rawfilename = "vCnlyClaimsPlusHCCOM_Mirror_Deductions"

sqoop_path = raw_path + "/sqoop/claimsplus/" + rawfilename
avro_path = raw_path + "/claimsplus/" + rawfilename
parquet_path = raw_path + "/parquet/claimsplus/" + rawfilename

deductions = spark.read.schema(deductions_schema)\
    .csv(
    path = sqoop_path,
    header = "false",
    sep = "|")\
    .write.mode("overwrite")\
    .format("avro")\
    .save(avro_path)

deductions_df = spark.read.format("avro")\
    .load(avro_path)\
    .repartition(4)\
    .write.mode("overwrite")\
    .parquet(parquet_path)

rawfilename = "ClaimsWHSE_CPFlag"

sqoop_path = raw_path + "/sqoop/claimsplus/" + rawfilename
avro_path = raw_path + "/claimsplus/" + rawfilename
parquet_path = raw_path + "/parquet/claimsplus/" + rawfilename

cp_flag = spark.read.schema(cp_flag_schema)\
    .csv(
    path = sqoop_path,
    header = "false",
    sep = "|")\
    .write.mode("overwrite")\
    .format("avro")\
    .save(avro_path)

cp_flag_df = spark.read.format("avro")\
    .load(avro_path)\
    .repartition(4)\
    .write.mode("overwrite")\
    .parquet(parquet_path)

spark.stop()
