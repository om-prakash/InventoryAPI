#!/usr/bin/env bash

UNAME="adam.andrus"
BATCH="2004"
DATASRC="AppianExport"
DEST="/rca/Anthem/appian_export/Batch$BATCH/Batch$BATCH.csv"
#SPLIT="CnlyMemID"
DELIM=','
CLNT="Wellpoint"
SERV="etl"
DBPART=""
DB="$CLNT$DBPART"
THREADS="1"
FILTER=""
hdfs dfs -rm -r $DEST;

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  --username $UNAME --password-file /user/$UNAME/pass.txt \
--fields-terminated-by $DELIM --target-dir $DEST \
--null-string '' --null-non-string '' --fetch-size 100000 -m $THREADS -- --schema dbo ;

UNAME="adam.andrus"
BATCH="2004"
DATASRC="AppianExportHeader"
FNAME="Header"
DEST="/rca/Anthem/appian_export/Batch$BATCH/Batch$BATCH$FNAME.csv"
#SPLIT="CnlyMemID"
DELIM=','
CLNT="Wellpoint"
SERV="etl"
DBPART=""
DB="$CLNT$DBPART"
THREADS="1"
FILTER=""
hdfs dfs -rm -r $DEST;

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  --username $UNAME --password-file /user/$UNAME/pass.txt \
--fields-terminated-by $DELIM --target-dir $DEST \
--null-string '' --null-non-string '' --fetch-size 100000 -m $THREADS -- --schema dbo ;
