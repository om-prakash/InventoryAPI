PART=44

until [  $PART -lt 2 ]; do echo PARTITION $PART;
UNAME="adam.andrus"
DATASRC="vDim_CRL_ClmMem"
DEST="/rca/Anthem/data/raw/sqoop/dimensions/vDim_CRL_ClmMem_temp"
SPLIT="CRL_ClmMem_ID"
DELIM='|'
CLNT="Wellpoint"
SERV="etl"
DBPART="CnlyClaims"
DB="$CLNT$DBPART"
THREADS="5"
FILTER=""
hdfs dfs -rm -r $DEST;

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  \
--username $UNAME --password-file /user/$UNAME/pass.txt \
--fields-terminated-by $DELIM --target-dir $DEST \
--null-string '' --null-non-string '' --fetch-size 100000 -m $THREADS --split-by $SPLIT -- --schema dbo ;

let PART-=1; done



UNAME="adam.andrus"
DATASRC="veMember_test"
DEST="./Wellpoint/stg/Member/$DATASRC"
SPLIT="CnlyMemID"
DELIM='|'
CLNT="Wellpoint"
SERV="etl"
DBPART="CnlyData"
DB="$CLNT$DBPART"
THREADS="1"
FILTER=""
hdfs dfs -rm -r $DEST;

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  --username $UNAME --password-file /user/$UNAME/pass.txt \
--fields-terminated-by $DELIM --target-dir $DEST \
--null-string '' --null-non-string '' --fetch-size 100000 -m $THREADS -- --schema dbo ;


PART=49

until [  $PART -lt 2 ]; do echo PARTITION $PART;

PPATH=$PART
let PPATH+=1
UNAME="adam.andrus"
DATASRC="vConfiguratorClaimAgreements"
DEST="/rca/Anthem/data/raw/sqoop/contract/$UNAME/$PPATH"
SPLIT="CnlyClmJoinKey"
DELIM='|'
CLNT="Wellpoint"
SERV="etl"
DBPART="CnlyData"
DB="$CLNT$DBPART"
THREADS="5"
FILTER="  WellpointCnlyClaims.\$PARTITION.PF_FactCnlyClmJoinKey(CnlyClmJoinKey) = $PART and "
hdfs dfs -rm -r $DEST;

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  --username $UNAME --password-file /user/$UNAME/pass.txt \
--fields-terminated-by $DELIM --target-dir $DEST \
--null-string '' --null-non-string '' --fetch-size 100000 -m $THREADS --split-by $SPLIT -- --schema dbo ;

let PART-=1; done


UNAME="adam.andrus"
DATASRC="tf_review"
DEST="./tf_review"
SPLIT="CnlyClmJoinKey"
DELIM='|'
CLNT="Wellpoint"
SERV="prd"
DBPART="ClaimsPlusMirror"
DB="$CLNT$DBPART"
THREADS="1"
FILTER=""
hdfs dfs -rm -r $DEST;

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  --username $UNAME --password-file /user/$UNAME/pass.txt \
--fields-terminated-by $DELIM --target-dir $DEST \
--null-string '' --null-non-string '' --fetch-size 100000 -m $THREADS  -- --schema dbo ;

UNAME="adam.andrus"
DATASRC="v_extract_FLAG_Data_Active"
DEST="/rca/Anthem/data/raw/sqoop/dimensions/$DATASRC"
SPLIT="CnlyClmJoinKey"
DELIM='|'
CLNT="Wellpoint"
SERV="prd"
DBPART="AuditorsScreens"
DB="$CLNT$DBPART"
THREADS="1"
FILTER=""
hdfs dfs -rm -r $DEST;

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  --username $UNAME --password-file /user/$UNAME/pass.txt \
--fields-terminated-by $DELIM --target-dir $DEST \
--null-string '' --null-non-string '' --fetch-size 100000 -m $THREADS  -- --schema dbo ;

UNAME="adam.andrus"
DATASRC="vMasterProviderInfo"
DEST="/rca/Anthem/data/raw/sqoop/dimensions/$DATASRC"
SPLIT="CnlyClmJoinKey"
DELIM='|'
CLNT="Wellpoint"
SERV="prd"
DBPART="AuditorsScreens"
DB="$CLNT$DBPART"
THREADS="1"
FILTER=""
hdfs dfs -rm -r $DEST;

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  --username $UNAME --password-file /user/$UNAME/pass.txt \
--fields-terminated-by $DELIM --target-dir $DEST \
--null-string '' --null-non-string '' --fetch-size 100000 -m $THREADS  -- --schema dbo ;
