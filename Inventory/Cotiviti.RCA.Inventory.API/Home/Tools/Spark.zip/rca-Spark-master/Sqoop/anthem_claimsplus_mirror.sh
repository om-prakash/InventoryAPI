#!/usr/bin/env bash

UNAME=${USER}
BASEPATH="/rca/Anthem/data/raw/sqoop/claimsplus/"
DELIM='|'
CLNT="Wellpoint"
SERV="prd"
DBPART="ClaimsPlusMirror"
DB="${CLNT}${DBPART}"

DATASRC="vCnlyClaimsPlusHCCOM_Mirror_Audits"
DEST="${BASEPATH}${DATASRC}"
THREADS="1"
FILTER=""
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev \
--query "select * from ${DATASRC} where ${FILTER} \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://${CLNT}.${SERV}.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=${DB};integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager \
--driver net.sourceforge.jtds.jdbc.Driver  \
--username ${UNAME} \
--password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} \
--target-dir ${DEST} \
--null-string '' \
--null-non-string '' \
--fetch-size 100000 \
-m ${THREADS}  \
-- --schema dbo ;

DATASRC="vCnlyClaimsPlusHCCOM_Mirror_Ledger"
DEST="${BASEPATH}${DATASRC}"
THREADS="1"
FILTER=""
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev \
--query "select * from ${DATASRC} where ${FILTER} \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://${CLNT}.${SERV}.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=${DB};integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager \
--driver net.sourceforge.jtds.jdbc.Driver  \
--username ${UNAME} \
--password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} \
--target-dir ${DEST} \
--null-string '' \
--null-non-string '' \
--fetch-size 100000 \
-m ${THREADS}  \
-- --schema dbo ;

DATASRC="vCnlyClaimsPlusHCCOM_Mirror_Deductions"
DEST="${BASEPATH}${DATASRC}"
THREADS="1"
FILTER=""
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev \
--query "select * from ${DATASRC} where ${FILTER} \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://${CLNT}.${SERV}.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=${DB};integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager \
--driver net.sourceforge.jtds.jdbc.Driver  \
--username ${UNAME} \
--password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} \
--target-dir ${DEST} \
--null-string '' \
--null-non-string '' \
--fetch-size 100000 \
-m ${THREADS}  \
-- --schema dbo ;

DATASRC="vCnlyClaimsPlusHCCOM_Mirror"
DEST="${BASEPATH}${DATASRC}"
THREADS="1"
FILTER=""
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev \
--query "select * from ${DATASRC} where ${FILTER} \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://${CLNT}.${SERV}.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=${DB};integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager \
--driver net.sourceforge.jtds.jdbc.Driver  \
--username ${UNAME} \
--password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} \
--target-dir ${DEST} \
--null-string '' \
--null-non-string '' \
--fetch-size 100000 \
-m ${THREADS}  \
-- --schema dbo ;

DATASRC="ClaimsWHSE_CPFlag"
DEST="${BASEPATH}${DATASRC}"
THREADS="1"
FILTER=""
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev \
--query "select * from ${DATASRC} where ${FILTER} \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://${CLNT}.${SERV}.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=${DB};integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager \
--driver net.sourceforge.jtds.jdbc.Driver  \
--username ${UNAME} \
--password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} \
--target-dir ${DEST} \
--null-string '' \
--null-non-string '' \
--fetch-size 100000 \
-m ${THREADS}  \
-- --schema dbo ;

spark2-submit \
--master yarn \
--deploy-mode cluster \
--name "Anthem Claims Plus" \
--packages org.apache.spark:spark-avro_2.11:2.4.0 \
--queue root.rcaengdev \
--executor-memory 15G \
--executor-cores 5 \
--driver-memory 10G \
--conf spark.locality.wait.rack=60s \
anthem_claimsplus_mirror.py
