
HDIR="/rca/Anthem/data/raw/sqoop/claims/vFactClaimKeys"
MAXPATH=$(hdfs dfs -ls -R ${HDIR} | grep "^d" | tail -1 | tr "[:alpha:][:punct:]" ' ' | tr -s ' ' | cut -d' ' -f8 |tr -d ' ')
NEWPATH="$(($MAXPATH + 1))"
UNAME="adam.andrus"
DATASRC="vFactClaimKeys"
DEST="$HDIR/$NEWPATH"
SPLIT="CnlyClmJoinKey"
DELIM='|'
CLNT="Wellpoint"
SERV="etl"
DBPART="CnlyClaims"
DB="$CLNT$DBPART"
THREADS="6"
FILTER=" \$PARTITION.PF_FactCnlyClmJoinKey(CnlyClmJoinKey)  = 49 and "
hdfs dfs -rm -r ${DEST};

sqoop import -Dmapreduce.job.queuename=root.rcaengdev --query "select * from $DATASRC where $FILTER \$CONDITIONS "  \
--connect "jdbc:jtds:sqlserver://$CLNT.$SERV.sql.ccaintranet.com:1433;useNTLMv2=true;domain=ccaintranet.com;databaseName=$DB;integratedSecurity=true" \
--connection-manager org.apache.sqoop.manager.SQLServerManager --driver net.sourceforge.jtds.jdbc.Driver  --username ${UNAME} --password-file /user/${UNAME}/pass.txt \
--fields-terminated-by ${DELIM} --target-dir ${DEST} \
--null-string '' --null-non-string '' --fetch-size 100000 -m ${THREADS} --split-by ${SPLIT} -- --schema dbo ;
