# Excel to Parquet

This minor utility tool can read data from a specified sheet of an excel file and generate a parquet file 
on the fly.

## What we use

- Use Pandas to read data from Excel
- Use PyArrow and PyArrow.Parquet to write Pandas DataFrame to Parquet file

Because of using Python, this tool can work across platforms.

## Arguments

This tool accepts 4 arguments:

| Argument Name | Argument Type | Description                     |
|---------------|---------------|---------------------------------|
| src           | string        | The path of source excel file   |
| out           | string        | The path of output parquet file |
| sheet         | int           | index of sheet (0 based)        |
| header        | int           | row index of header (0 based)   |