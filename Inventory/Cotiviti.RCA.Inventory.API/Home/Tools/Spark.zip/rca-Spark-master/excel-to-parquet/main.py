import argparse
import traceback

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq


def clean_column_name(col):
    """
    Replace characters in column to clean column name of pandas DataFrame
    :param col: the original column name
    :return: the cleaned column name
    """
    return col.strip().replace(' ', '_').replace(',', '').replace(';', '') \
        .replace('{', '').replace('}', '').replace('(', '').replace(')', '') \
        .replace('\n', '').replace('\t', '').replace('=', '').replace(':', '')


def excel_to_parquet(config):
    """
    Read data from the specified sheet of an Excel and write to the specified parquet
    output file
    :param config: A dictionary that contains command line arguments
    :return: None
    """
    # read excel file
    df = pd.read_excel(config.src, sheet_name=config.sheet, header=config.header)

    # we should remove some chars from column names, otherwise it will
    # throw exceptions when we read the generated parquet files from spark
    # spark does not like " ,;{}()\n\t=" in column name
    df.columns = df.columns.map(lambda s: clean_column_name(s))

    # convert pandas dataframe to pyarrow table
    table = pa.Table.from_pandas(df)

    # write pyarrow table to parquet file
    pq.write_table(table, config.out)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Excel to Parquet')
    parser.add_argument('--src', required=True, help='The path of source excel file', type=str)
    parser.add_argument('--out', required=True, help='The path of output parquet file', type=str)
    parser.add_argument('--sheet', required=True, help='index of sheet (0 based)', default=0, type=int)
    parser.add_argument('--header', required=True, help='index of header (0 based)', default=0, type=int)
    args = parser.parse_args()

    has_error = False
    try:
        excel_to_parquet(args)
    except Exception as e:
        has_error = True
        print(e)
        traceback.print_exc()

    if has_error:
        exit(-1)
