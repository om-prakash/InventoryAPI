# used with python 2.7.5

import psycopg2
import json

configFile = 'postgres_user.json'


# Get DB Connection
def connect_db():
    # get connection details
    with open(configFile, 'r') as config_file:
        config_dict = json.load(config_file)

    try:
        connection = psycopg2.connect(
            user = config_dict['postgres']['connect']['host'],
            password = config_dict['postgres']['connect']['password'],
            host = config_dict['postgres']['connect']['host'],
            port = config_dict['postgres']['connect']['port'],
            database = config_dict['postgres']['connect']['database'])
    except (Exception, psycopg2.Error) as error:
        print ("Error while connecting to PostgreSQL", error)

    finally:
        print("Connected!")

    return connection


# Query Postgres and get exclusions
def get_exclusions(connection, exclusion_type):
    sql_statement = "SELECT exclusion_key, client_key, exclusion_name, " \
                    "exclusion_definition " \
                    "FROM public.exclusions " \
                    "where exclusion_type_name = '" + exclusion_type + \
                    "' and exclusion_key not in (1, 115, 117, 116)"
    when_statement = ""
    try:
        with connection:
            cur = connection.cursor()
            cur.execute(sql_statement)

            case_statement = ""
            when_logic = ""

            while True:
                row = cur.fetchone()
                if row is None:
                    break
                exclusion_key = row[0]
                exclusion_name = row[2]
                exclusion_definition = row[3]

                exclusion_key_string = "\\\"exclusion_key\\\": \\\"" \
                                       + str(exclusion_key) + "\\\""
                exclusion_event = build_exclusion_events(exclusion_definition)
                concat_statement = "concat('{" + exclusion_key_string \
                                   + ", \\\"calc_logic\\\" : \\\"', " \
                                   + exclusion_event \
                                   + ", ' > @current_date\\\"}')"
                when_statement = when_statement + " WHEN (" \
                                 + build_exclusion_conditions(
                    exclusion_definition) + ") THEN " + \
                                 concat_statement + "\n"

            if when_statement == "":
                case_statement = "No Records Found For Exclusion_Type: " \
                                 + exclusion_type
            else:
                case_statement = "CASE " + "\n" + when_statement \
                                 + " END as " + exclusion_type

            return case_statement

    except (Exception, psycopg2.Error) as error:
        print ("Error PostgreSQL", error)

    finally:
        # close cursor
        if connection:
            cur.close()

        # Build exclusion conditions from json rule


def build_exclusion_conditions(json_rule):
    y = json.dumps(json_rule)
    jsonData = json.loads(y)
    andCondition = ""
    for conditions in jsonData['conditions']['all']:
        condition_value = ""

        # evaluate operator and value
        if conditions['value'] == "NULL":
            condition_value = conditions['value']
        elif (
                conditions['operator'] == "IN"
                or conditions['operator'] == "NOT IN"
        ):
            individualValuesArray = conditions['value'].split(",")
            for individualValue in individualValuesArray:
                condition_value += "'" + individualValue + "',"
                condition_value = condition_value[:-1]  # Remove last comma
                condition_value = "(" + condition_value + ")"
        else:
            condition_value = "'" + conditions['value'] + "'"

        andCondition += conditions['column'] + " " + conditions[
            'operator'] + " " + condition_value + " and "

    # remove trailing and
    andCondition = andCondition[:-5]

    return andCondition


# Build exclusion events from json rule
def build_exclusion_events(json_rule):
    y = json.dumps(json_rule)
    jsonData = json.loads(y)
    for events in jsonData['events']:
        if events['type'] == 'function':

            functionName = events['params']['name']
            if functionName == "dateadd":
                date_add_function = build_date_add_function(
                    events['params']['params'])
    return date_add_function


# Build date format and add function
def build_date_add_function(params):
    # Specific to Spark SQL
    date_function = ""
    if (params['interval'].upper() == "DAY"):
        date_function = "date_add"
    elif (params['interval'].upper() == "MONTH"):
        date_function = "add_months"

    date_function = "date_format(" + date_function + "(" + params[
        'date'] + ", " + params['increment'] + "), 'YYYY-MM-dd')"
    return date_function

# ---------Main---------

# if(exclusion_type == ""):
#    exclusion_type = "LAG"
#    print("Using default exclusion_type: LAG")
# else:
#    print("Running with exclusion_type:" + exclusion_type)


# Get db connection
# connection = connect_db()


# Query to get exclusions
# get_exclusions(connection, 'Expiration')
# get_exclusions(connection, 'Lag')
# exclusions = get_exclusions(connection, exclusion_type)
# print(exclusions)

# Close connection
# if(connection):
#    connection.close()
#    print("PostgreSQL connection is closed")
