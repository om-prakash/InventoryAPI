from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.storagelevel import *
from exclusion_module import connect_db
from exclusion_module import get_exclusions

import argparse

parser = argparse.ArgumentParser()
parser.add_argument("--exclusion_type", type=str)
exclusion_type = ""
args = parser.parse_args()
if args.exclusion_type:
    exclusion_type = args.exclusion_type.upper()


sc = SparkContext.getOrCreate()
spark = SparkSession.builder.getOrCreate()



print("Starting...")

#Connect to database
connection = connect_db()


#Get Exclusion Type from args
if(exclusion_type == ""):
    exclusion_type = "LAG"
    print("Using default exclusion_type: LAG")
else:
    print("Running with exclusion_type:" + exclusion_type)


#Get exclusions and return as case statement
exclusions = get_exclusions(connection, exclusion_type)
print(exclusions)

if(connection):
    connection.close()
    print("Postgres connection is closed")


#Set claim file
df = spark.read.csv('/user/charlesbachetti/TestClaimData.csv', header=True, nullValue='NA', inferSchema=True)
df.createOrReplaceTempView("temp1")


#Query claim with case statement
sql_statement = "SELECT CnlyClmNum, CnlyPaidDt, " + exclusions + " FROM temp1"
spark.sql(sql_statement).show(truncate = False)



spark.stop()
