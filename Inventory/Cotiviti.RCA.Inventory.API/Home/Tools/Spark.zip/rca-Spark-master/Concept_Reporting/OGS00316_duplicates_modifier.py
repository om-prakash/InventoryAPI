import subprocess
import argparse

from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

sc = SparkContext.getOrCreate()
spark = SparkSession.builder.getOrCreate()

parser = argparse.ArgumentParser()
parser.add_argument("--ClientName")
args = parser.parse_args()
if args.ClientName:
    ClientName = args.ClientName.lower()

# test ClientName = 'anthem'
source_path = "/rca/refined/claim/" + ClientName
path = "/rca/concepts/OGS00316_duplicates_modifier/" + ClientName
rebuild_path = path + "_rebuild"
testCmd = "hdfs dfs -test -e "
removeCmd = "hdfs dfs -rm -r "
moveCmd = "hdfs dfs -mv "

# codes to sub.
amount_threshold = 25.00
exclude_mods = "'24', '27', '59', '76', '77', '80', '81', '82', 'AS', '91', " \
               "'HE', 'HF', 'HG', 'HN', 'HO', 'HQ', 'JW', 'UJ', 'TW', 'XS', " \
               "'XU', 'XE', 'SH', 'SJ', 'XP' "
exclude_hcpcs = "'J', '8', 'H'"
header_filter = "final_action_indicator = 1 " \
                "and claim_paid_amount > " + str(amount_threshold) + " " \
                "and paid_to_code = 'PROVIDER' " \
                "and its_bluecard_claim_type != 'HOST' " \
                "and other_insurance_type = 'CLIENT PRIMARY' " \
                "and rendering_provider_npi is not null "
line_filter = "filter("\
              "claim_detail, "\
              "x -> left(x.line_cpt_hcpcs_code,1) not in " \
              "(" + exclude_hcpcs + ") "\
              "and ifnull(x.line_cpt_hcpcs_code,'A') != 'A' " \
              "and x.line_cpt_hcpcs_code != 'X2628' "\
              "and ((x.line_paid_amount > 0 "\
              "and element_at(x.line_cpt_hcpcs_modifier, 1) is not null) "\
              "or (x.line_paid_amount > 25 "\
              "and element_at(x.line_cpt_hcpcs_modifier, 1) is null)) "\
              "and x.line_place_of_service_code not in ('41', '42') "\
              "and arrays_overlap(x.line_cpt_hcpcs_modifier, array("\
              + exclude_mods + ")) = False "\
              ")"
payload_fields = [
        "client_claim_id", "claim_key", "patient_member_id",
        "patient_key", "rendering_provider_key", "claim_service_from_date",
        "claim_service_to_date", "line_service_from_date",
        "line_service_to_date", "claim_paid_date", "claim_paid_amount",
        "claim_charge_amount", "claim_allowed_amount", "type_of_bill_code",
        "rendering_provider_client_id", "rendering_provider_tax_id",
        "rendering_provider_npi", "rendering_provider_state",
        "rendering_provider_full_name", "claim_line_count", "line_number",
        "line_submitted_units", "line_paid_units", "line_paid_amount",
        "line_charge_amount", "line_allowed_amount",  "client_received_date",
        "estimated_overpayment_amount", "line_cpt_hcpcs_code",
        "line_cpt_hcpcs_modifier", "line_revenue_code", "diagnosis_codes",
        "line_place_of_service_code", "insurance_lob",
        "client_platform_name", "link_id", "ranking", "client_key",
        "client_name", "patient_first_name", "patient_last_name", "join_key",
        "claim_patient_liability_amount", "claim_deductible_amount",
        "claim_copay_amount", "claim_coinsurance_amount",
        "line_patient_liability_amount", "line_deductible_amount",
        "line_copay_amount", "line_coinsurance_amount"
]

# following to be replaced by exclusion process
dfclaimsplus = spark.read\
    .parquet("/rca/Anthem/data/raw/parquet/dimensions/ClaimsWHSE_CPFlag")\
    .selectExpr("CnlyClmJoinKey as join_key")
dfnotouch = spark.read\
    .parquet("/refined/analytics/Anthem_Sqoop/HDP_NoTouchActive")\
    .filter("NoTouchDM = 1")\
    .selectExpr("CnlyClmJoinKey as join_key")\
    .union(dfclaimsplus)\
    .distinct()
dfscope = spark.read\
    .parquet("/rca/Anthem/data/raw/parquet/FactClaimHeader")\
    .filter("ExpDate > date_add(current_date(), 30)")\
    .selectExpr("CnlyClmJoinKey as join_key")\
    .subtract(dfnotouch)

dfclaimheader = spark.read\
    .parquet(source_path)\
    .filter(header_filter)\
    .withColumn("claim_detail_filtered",
                expr(line_filter)
                )\
    .filter("element_at(claim_detail_filtered,1) is not null ")\
    .withColumn("join_key", element_at("legacy_sys_ids", "cnlyclmjoinkey"))\
    .join(dfscope, "join_key", "inner")\
    .withColumn("dupe_count_header",
                expr(
                    "count(1) over "
                    "(partition by "
                    "patient_key, claim_type, rendering_provider_npi, "
                    "ifnull(billing_provider_npi,''), "
                    "billing_provider_tax_id, claim_service_from_date)"
                    )
                )\
    .filter("dupe_count_header > 1 ")\
    .repartition(10, "patient_key")\
    .withColumn("line", expr("explode(claim_detail_filtered)"))\
    .withColumn("claim_line_count", expr("size(claim_detail)"))\
    .select("*", "line.*")\
    .withColumn("has_modifiers",
                expr(
                    "case when element_at(line_cpt_hcpcs_modifier, 1) is null "
                    "then 0 else 1 end "
                    )
                )\
    .withColumn("line_cpt_hcpcs_code_custom_group",
                expr(
                    "case when left(line_cpt_hcpcs_code,1) = '9'"
                    "then concat(line_cpt_hcpcs_code, "
                    "primary_diagnosis_code)"
                    "else line_cpt_hcpcs_code end"
                    )
                )\
    .withColumn("link_id",
                expr(
                    "dense_rank() over "
                    "(order by "
                    "patient_key, claim_type, rendering_provider_npi, "
                    "ifnull(billing_provider_npi,''), "
                    "line_cpt_hcpcs_code_custom_group, "
                    "billing_provider_tax_id, line_service_from_date, "
                    "line_service_to_date, line_revenue_code)"
                    )
                )\
    .withColumn("line_unit_paid_amount_with_mods",
                expr(
                    "sum("
                    "case when has_modifiers = 0 then 0 "
                    "else line_paid_amount end) over "
                    "(partition by link_id) / "
                    "nullif(sum("
                    "case when has_modifiers = 0 then 0 "
                    "else line_paid_units end) over "
                    "(partition by link_id), 0)"
                    )
                )\
    .withColumn("claim_has_modifiers",
                expr(
                     "max(has_modifiers) over "
                     "(partition by link_id, claim_key)"
                     )
                )\
    .withColumn("estimated_overpayment_amount",
                expr(
                     "case when claim_has_modifiers = 1 then 0.0 "
                     "else ((line_paid_amount / nullif(line_paid_units, 0)) "
                     "- line_unit_paid_amount_with_mods) * line_paid_units end"
                     )
                )\
    .filter("estimated_overpayment_amount > 25 or claim_has_modifiers = 1")\
    .withColumn("dupe_count",
                expr(
                    "approx_count_distinct(claim_has_modifiers) over "
                    "(partition by link_id)"
                    )
                )\
    .filter("dupe_count > 1 ")\
    .withColumn("ranking",
                expr(
                     "row_number() over"
                     "(partition by link_id "
                     "order by has_modifiers, client_claim_id)"
                    )
                )\
    .select(payload_fields)\
    .orderBy("link_id", "ranking")

dfclaimheader.write.mode("overwrite").parquet(path)

# dfreview = spark.read.parquet(path)
# dfreview.withColumn("rnks", expr("max(ranking) over (partition by link_id) ")).filter("rnks = 2 ").withColumn("top", expr("dense_rank() over (order by link_id)")).filter("top <= 100 ").repartition(1).write.mode('overwrite').parquet("./batch54321")
chkR = subprocess.call(testCmd + rebuild_path + '/_SUCCESS', shell=True)
if chkR == 0:
    print('rebuild created successfully')
    chkC = subprocess.call(testCmd + path, shell=True)
    if chkC == 0:
        subprocess.call(removeCmd + path + 'part*', shell=True)
    subprocess.call(moveCmd + rebuild_path + '/* ' + path, shell = True)
    subprocess.call(removeCmd + rebuild_path, shell = True)

spark.stop()
