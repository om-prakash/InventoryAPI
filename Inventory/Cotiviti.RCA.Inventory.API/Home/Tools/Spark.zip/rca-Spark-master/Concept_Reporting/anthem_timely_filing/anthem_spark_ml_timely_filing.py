import datetime

from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.ml.feature import StandardScaler, StringIndexer, VectorAssembler
from pyspark.ml import Pipeline
from pyspark.ml.classification import LogisticRegression

sc = SparkContext.getOrCreate()
spark = SparkSession.builder.getOrCreate()

ct = datetime.datetime.now()
seed = ct.day

blockMB = 512
dictMB = 3
paddMB = 8
block_size = str(blockMB * 1024 * 1024)
dict_size = str(dictMB * 1024 * 1024)
padd_size = str(paddMB * 1024 * 1024)

sc._jsc.hadoopConfiguration().set('dfs.block.size', block_size)
sc._jsc.hadoopConfiguration().set('parquet.block.size', block_size)
sc._jsc.hadoopConfiguration().set('parquet.dictionary.page.size', dict_size)
sc._jsc.hadoopConfiguration().set('parquet.writer.max-padding', padd_size)

select_fields = [
    "client_claim_id", "claim_key", "patient_member_number",
    "patient_key", "rendering_provider_key", "claim_service_from_date",
    "claim_service_to_date", "claim_paid_date", "claim_paid_amount",
    "claim_charge_amount", "claim_allowed_amount", "type_of_bill_code",
    "rendering_provider_client_id", "rendering_provider_tax_id",
    "rendering_provider_npi", "rendering_provider_state",
    "billing_provider_client_id", "billing_provider_key",
    "billing_provider_tax_id", "billing_provider_npi", "claim_type",
    "client_received_date", "diagnosis_codes", "insurance_lob",
    "client_platform_id", "client_key", "join_key", "claim_sequence_rank",
    "claim_patient_liability_amount", "claim_deductible_amount",
    "claim_copay_amount", "claim_coinsurance_amount",
    "employer_group_number", "billing_provider_in_network_indicator",
    "final_action_indicator", "paid_to_code", "its_bluecard_claim_type",
    "other_insurance_type", "claim_original_paid_date",
    "overpayment_confirmed", "svc_recieved_dist", "pd_orig_pd_dist",
    "billing_provider_contract_id"
]
features = [
    "type_of_bill_code_ix", "rendering_provider_state_ix",
    "insurance_lob_ix", "client_platform_id", "claim_sequence_rank",
    "its_bluecard_claim_type_ix", "other_insurance_type_ix",
    "svc_recieved_dist", "pd_orig_pd_dist", "parind", "contract",
    "claim_type_ix"
]

flagschema = StructType(
    [StructField("join_key", LongType(), False),
     StructField("ClaimNum", StringType(), True),
     StructField("LineNum", StringType(), True),
     StructField("Auditor", StringType(), True),
     StructField("FlagStatus", StringType(), True),
     StructField("ReminderDate", DateType(), True),
     StructField("Note", StringType(), True),
     StructField("PotentialAmount", DecimalType(18, 2), True),
     StructField("ScreenName", StringType(), True),
     StructField("Report", StringType(), True),
     StructField("Project", StringType(), True),
     StructField("Reason", StringType(), True),
     StructField("AllFlags", StringType(), True),
     StructField("CreateDate", DateType(), True),
     StructField("CreateUser", StringType(), True)]
)

cpschema = StructType(
    [StructField("CnlyClmJoinKey", LongType(), False),
     StructField("client_tran_code", StringType(), False)]
)

flags = spark.read.schema(flagschema) \
    .csv("/rca/Anthem/data/raw/sqoop/dimensions/v_extract_FLAG_Data_Active",
         header = "false", sep = "|"
         ) \
    .filter(
    "lower(project) like '%timely%' "
    "and flagstatus in ('OP Identified on Related Claim', "
    "'Previously Identified', 'Low Dollar', "
    "'Claim Expired', 'Reminder') "
) \
    .select("join_key")

cp = spark \
    .read.schema(cpschema) \
    .csv("./tf_review/", header = "false", sep = "|") \
    .selectExpr("CnlyClmJoinKey as key ") \
    .union(flags).distinct()
cp.cache()
cp.collect()
dfclaimsplus = spark.read \
    .parquet("/rca/Anthem/data/raw/parquet/dimensions/ClaimsWHSE_CPFlag") \
    .select("CnlyClmJoinKey")
dfnotouch = spark.read \
    .parquet("/refined/analytics/Anthem_Sqoop/HDP_NoTouchActive") \
    .filter("NoTouchDM = 1") \
    .select("CnlyClmJoinKey") \
    .union(dfclaimsplus) \
    .distinct()
dfscope = spark.read \
    .parquet("/rca/Anthem/data/raw/parquet/FactClaimHeader") \
    .filter("CnlyFinal = 1 and ClmPaidAmtInt > 0 "
            "and CnlySor not in (1104,1060,994) and ExpDate > date_add("
            "current_date(), "
            "30)") \
    .select("CnlyClmJoinKey") \
    .subtract(dfnotouch)

clm_raw = spark.read.parquet('/rca/refined/claim/anthem/') \
    .withColumn("join_key",
                element_at("legacy_sys_ids", "cnlyclmjoinkey"))

clm = clm_raw \
    .join(cp, clm_raw.join_key == cp.key, "left") \
    .withColumn("overpayment_confirmed",
                expr(
                    "case when key is null then 0 ese 1 end"
                )
                ) \
    .withColumn("svc_recieved_dist",
                expr(
                    "datediff(client_received_date,claim_service_to_date)"
                )
                ) \
    .withColumn("pd_orig_pd_dist",
                expr(
                    "datediff(claim_paid_date,claim_original_paid_date)"
                )
                ) \
    .select(select_fields)

smp_nocp = clm.filter("overpayment_confirmed = 0").sample(False, 0.002, seed)
smp_cp = clm.filter("overpayment_confirmed = 1")
smp = smp_cp.union(smp_nocp) \
    .withColumn("train", expr("1"))

clm \
    .withColumn("CnlyClmJoinKey", expr("join_key")) \
    .join(dfscope, "CnlyClmJoinKey", "inner") \
    .select(select_fields) \
    .withColumn("train", expr("0")) \
    .union(smp) \
    .repartition(150) \
    .write.mode("overwrite") \
    .parquet("./tf_sampling")

clm_pre = spark.read.parquet("./tf_sampling")

assembler = Pipeline(stages = [
    StringIndexer(inputCol = "type_of_bill_code",
                  outputCol = "type_of_bill_code_ix")
        .setHandleInvalid("keep"),
    StringIndexer(inputCol = "rendering_provider_state",
                  outputCol = "rendering_provider_state_ix")
        .setHandleInvalid("keep"),
    StringIndexer(inputCol = "insurance_lob",
                  outputCol = "insurance_lob_ix")
        .setHandleInvalid("keep"),
    StringIndexer(inputCol = "its_bluecard_claim_type",
                  outputCol = "its_bluecard_claim_type_ix")
        .setHandleInvalid("keep"),
    StringIndexer(inputCol = "other_insurance_type",
                  outputCol = "other_insurance_type_ix")
        .setHandleInvalid("keep"),
    StringIndexer(inputCol = "billing_provider_in_network_indicator",
                  outputCol = "parind")
        .setHandleInvalid("keep"),
    StringIndexer(inputCol = "billing_provider_contract_id",
                  outputCol = "contract")
        .setHandleInvalid("keep"),
    StringIndexer(inputCol = "claim_type",
                  outputCol = "claim_type_ix")
        .setHandleInvalid("keep"),
    VectorAssembler(inputCols = features, outputCol = "features"),
    StandardScaler(inputCol = "features", outputCol = "Scaled_features")
])

claims = assembler.fit(clm_pre).transform(clm_pre)

lr = LogisticRegression(
    labelCol = "overpayment_confirmed",
    featuresCol = "Scaled_features",
    maxIter = 10
)

training_data = claims.filter("train = 1")
predict_data = claims.filter("train = 0")

model = lr.fit(training_data)
predict_train = model.transform(training_data)
predict_test = model.transform(predict_data)
