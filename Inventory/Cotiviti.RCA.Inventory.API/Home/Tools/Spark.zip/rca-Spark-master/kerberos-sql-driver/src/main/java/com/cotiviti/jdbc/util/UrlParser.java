package com.cotiviti.jdbc.util;

import java.util.*;
import java.util.stream.Collectors;

/**
 * A utility class to parse user specified JDBC connection url
 *
 * The new connection url has two new key value pairs that specify
 * the kerberos principal and keytab file
 */
public class UrlParser {
    // the key which used to specify Kerberos principal in connection url
    public final static String PRINCIPAL_KEY = "krb5Principal";
    // the key which used to specify Kerberos keytab file in connection url
    public final static String KEYTAB_KEY = "krb5Keytab";

    private final static String SQL_SERVER_PREFIX = "sqlserver";
    private final static String KRB_SQL_SERVER_PREFIX = "krb5ss";


    /**
     * Convert user specified connection url to valid SQL server JDBC url format
     * @param url JDBC connection url that user specified
     * @return A valid SQL server JDBC connection url
     */
    public static String toSqlServerUrl(String url) {
        StringBuilder sb = new StringBuilder();
        String head = head(url);
        sb.append(head.replace(KRB_SQL_SERVER_PREFIX, SQL_SERVER_PREFIX));
        sb.append(";");
        Map<String, String> properties = connectionProperties(url);
        for(Map.Entry<String, String> prop : properties.entrySet()) {
            if (prop.getKey().equalsIgnoreCase(PRINCIPAL_KEY) ||
            prop.getKey().equalsIgnoreCase(KEYTAB_KEY)) continue;
            sb.append(String.format("%1$s=%2$s;", prop.getKey(), prop.getValue()));
        }
        return sb.toString();
    }

    /**
     * Parse the connection url and get a map of connection properties
     * @param url JDBC connection url
     * @return A map of connection properties
     */
    public static Map<String, String> connectionProperties(String url) {
        List<AbstractMap.SimpleEntry<String, String>> properties = Arrays.stream(url.split(";"))
                .skip(1)
                .map(s -> s.split("="))
                .map(s -> new AbstractMap.SimpleEntry<>(s[0], s[1]))
                .collect(Collectors.toList());
        Map<String, String> result = new HashMap<>();
        for(AbstractMap.SimpleEntry<String, String> prop : properties) {
            result.put(prop.getKey(), prop.getValue());
        }
        return result;
    }

    private static String head(String url) {
        Optional<String> first = Arrays.stream(url.split(";"))
                .findFirst();
        return first.orElse("");
    }
}
