package com.cotiviti.jdbc;

import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * A class which registers our wrapper of SQL server driver
 */
public class Krb5SqlServerDriver extends Krb5SqlServer {
    // This static block initializes the driver when the class
    // is loaded by JVM.
    static {
        try {
            DriverManager.registerDriver(new Krb5SqlServerDriver());
        } catch(SQLException e) {
            throw new RuntimeException("Failed to register Krb5SqlServerDriver: " + e.getMessage());
        }
    }
}
