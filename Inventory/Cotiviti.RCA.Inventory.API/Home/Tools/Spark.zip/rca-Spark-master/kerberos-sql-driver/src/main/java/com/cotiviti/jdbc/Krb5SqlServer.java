package com.cotiviti.jdbc;

import com.cotiviti.jdbc.util.UrlParser;
import com.microsoft.sqlserver.jdbc.SQLServerDriver;
import com.microsoft.sqlserver.jdbc.SQLServerException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.security.UserGroupInformation;

import java.io.IOException;
import java.security.PrivilegedAction;
import java.sql.*;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Logger;

/**
 * A wrapper of Microsoft SQL Sever JDBC Driver
 *
 * This wrapper enables us to connect to SQL server via integration authentication
 * from Apache Spark
 */
public class Krb5SqlServer implements Driver {
    // wrapped original SQL Server driver object
    private final SQLServerDriver driver = new SQLServerDriver();

    @Override
    public Connection connect(String url, Properties info) throws SQLException {
        // get kerberos principal and keytab file from the connection url
        Map<String, String> properties = UrlParser.connectionProperties(url);
        String principal = properties.get(UrlParser.PRINCIPAL_KEY);
        System.out.println("DEBUG: principal=" + principal);
        String keytab = properties.get(UrlParser.KEYTAB_KEY);
        System.out.println("DEBUG: keytab=" + keytab);
        // build Hadoop configuration object and bind it to Hadoop security context
        Configuration conf = new Configuration();
        // look for the configuration xml files from classpath
        conf.addResource("core-site.xml");
        conf.addResource("hdfs-site.xml");
        UserGroupInformation.setConfiguration(conf);
        System.out.println("DEBUG: configuration initialized.");
        try {
            UserGroupInformation.getCurrentUser()
                    .setAuthenticationMethod(UserGroupInformation.AuthenticationMethod.KERBEROS);
            return UserGroupInformation.loginUserFromKeytabAndReturnUGI(principal, keytab)
                    .doAs((PrivilegedAction<Connection>) () -> {
                        try {
                            System.out.println("DEBUG: url=" + UrlParser.toSqlServerUrl(url));
                            return driver.connect(UrlParser.toSqlServerUrl(url), info);
                        } catch (SQLServerException sse) {
                            sse.printStackTrace();
                        }
                        return null;
                    });
        } catch (IOException e) {
            e.printStackTrace();
            throw new SQLException(e.getMessage());
        }
    }

    @Override
    public boolean acceptsURL(String url) throws SQLException {
        return driver.acceptsURL(url);
    }

    @Override
    public DriverPropertyInfo[] getPropertyInfo(String url, Properties info) throws SQLException {
        return driver.getPropertyInfo(url, info);
    }

    @Override
    public int getMajorVersion() {
        return driver.getMajorVersion();
    }

    @Override
    public int getMinorVersion() {
        return driver.getMinorVersion();
    }

    @Override
    public boolean jdbcCompliant() {
        return driver.jdbcCompliant();
    }

    @Override
    public Logger getParentLogger() {
        return driver.getParentLogger();
    }
}
