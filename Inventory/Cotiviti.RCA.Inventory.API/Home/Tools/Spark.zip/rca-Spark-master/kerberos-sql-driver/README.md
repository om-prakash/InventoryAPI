# Kerberos Enabled SQL Server Driver

## Background

Microsoft SQL Server supports kerberos authentication from
JVM. Because of [SPARK-12312](https://issues.apache.org/jira/browse/SPARK-12312)
, it does not work if we try to connect to SQL Server from 
Spark via kerberos authentication.

To overcome this issue before this Spark bug been fixed, we have to 
create a wrapper on top of SQL Server driver to pass correct 
kerberos token explicitly.

## Connection Url

To pass correct kerberos token, we add two new key value pairs to 
the original SQL Server JDBC connection url. An example looks like below:
```
"jdbc:krb5ss://claims.sql.dev.ccaintranet.com;databaseName=SpringDev;integratedSecurity=true;authenticationSchema=JavaKerberos;krb5Principal=<principal>;krb5Keytab=<keytab file>;"
```

**Highlighted Changes**
- "jdbc:sqlserver" => "jdbc:krb5ss"
- new key value pair: "krb5Principal=\<principal>"
- new key value pair: "krb5Keytab=\<keytab file>"

Also, we use integrated security and kerberos authentication in above connection url.

## Usage in Spark

In Spark, we use standard jdbc reader and writer as normal as long as 
we use correct driver and url.

![How to Use in Spark](images/how-to-use-in-spark.PNG)

While submitting to Yarn cluster, ensure to deploy below required files:
- our wrapper JDBC jar file
- the original Microsoft SQL Server driver jar file
- keytab file

In our sample Spark application, we have below files:

![file structure of sample Spark application](images/required-files.PNG)

An example of submit script looks like below:

```shell script
#!/usr/bin/env bash

export SPARK_HOME=/opt/cloudera/parcels/SPARK2-2.4.0.cloudera2-1.cdh5.13.3.p0.1041012/lib/spark2
spark-submit --class com.cotiviti.spark.poc.SQLServerAccessor \
--jars /home/spring.zhou/code/sql-accessor/mssql-jdbc-6.2.1.jre8.jar,/home/spring.zhou/code/sql-accessor/kerberos-sql-driver-1.0-SNAPSHOT.jar \
--files /home/spring.zhou/code/sql-accessor/spring.zhou.keytab \
--master yarn \
--deploy-mode client \
--driver-memory 2g \
--executor-memory 8g \
--executor-cores 5 \
--num-executors 3 \
--queue default \
/home/spring.zhou/code/sql-accessor/spring-spark-demo-1.0-SNAPSHOT.jar
```