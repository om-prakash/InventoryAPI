SELECT
    SRC_SBSCRBR_ID,
    SRC_MBR_SQNC_NBR,
    CASE
        WHEN SSN IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE SSN
    END AS SSN,
    MCID,
    CLM_NBR,
    CLM_DISP_CD,
    GL_POST_DT,
    CASE
        WHEN year(ADJDCTN_DT) >= year(current_date()) - 10
        AND year(ADJDCTN_DT) <= year(current_date()) THEN ADJDCTN_DT
        ELSE NULL
    END AS ADJDCTN_DT,
    ADJSTMNT_RSN_CD,
    CLM_LINE_NBR,
    SRC_MBR_FRST_NM,
    SRC_MBR_LAST_NM,
    ADJDCTN_STTS_CD,
    CASE
        WHEN REPLACE(PROV_ID, ' ', '') IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE REPLACE(PROV_ID, ' ', '')
    END AS PROV_ID,
    ADMT_DT,
    CASE
        WHEN ADMTG_DIAG_CD IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE ADMTG_DIAG_CD
    END AS ADMTG_DIAG_CD,
    BILL_CLSFCTN_CD,
    BILLD_SRVC_UNIT_CNT,
    CASE
        WHEN CHK_NBR = 'WAIT FIN DATA' THEN LEFT(CHK_NBR, 10)
        ELSE CHK_NBR
    END AS CHK_NBR,
    CLM_SRV_ADRS_LINE_1_TXT,
    CLM_SRV_ADRS_LINE_2_TXT,
    CLM_SRV_CITY_NM,
    CLM_SRV_ST_PRVNC_CD,
    CLM_SRV_ZIP_CD,
    CLM_SRV_ZIP_PLUS_4_CD,
    CLM_ADJSTMNT_KEY,
    CLM_ADJSTMNT_NBR,
    CLM_ITS_HOST_CD,
    CASE
        WHEN CLM_ITS_SCCF_NBR IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE CLM_ITS_SCCF_NBR
    END AS CLM_ITS_SCCF_NBR,
    CLM_LINE_SRVC_STRT_DT,
    CLM_LINE_SRVC_END_DT,
    CLM_LINE_STTS_CD,
    CAST(CLM_SOR_CD AS SMALLINT) AS CLM_SOR_CD,
    CLM_SRC_SPCLTY_CD,
    CMPNY_CF_CD,
    CNTRCT_EFCTV_DT,
    CNTRCT_TRMNTN_DT,
    CNTRCT_NM,
    CNTRCT_STTS_CD,
    BILLD_CHRG_AMT_INTRM,
    ALWD_AMT_INTRM,
    COB_SVNGS_AMT_INTRM,
    COINSRN_AMT_INTRM,
    CPAY_AMT_INTRM,
    DDCTBL_AMT_INTRM,
    NON_CVRD_AMT_INTRM,
    PAID_AMT_INTRM,
    BILLD_CHRG_AMT_ORGNL,
    ALWD_AMT_ORGNL,
    COB_SVNGS_AMT_ORGNL,
    COINSRN_AMT_ORGNL,
    CPAY_AMT_ORGNL,
    DDCTBL_AMT_ORGNL,
    NON_CVRD_AMT_ORGNL,
    PAID_AMT_ORGNL,
    BILLD_CHRG_AMT,
    ALWD_AMT,
    COB_SVNGS_AMT,
    COINSRN_AMT,
    CPAY_AMT,
    DDCTBL_AMT,
    NON_CVRD_AMT,
    PAID_AMT,
    CASE
        WHEN DIAG_1_CD IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_1_CD
    END AS DIAG_1_CD,
    CASE
        WHEN DIAG_2_CD IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_2_CD
    END AS DIAG_2_CD,
    CASE
        WHEN DIAG_3_CD IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_3_CD
    END AS DIAG_3_CD,
    CASE
        WHEN DIAG_4_CD IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_4_CD
    END AS DIAG_4_CD,
    CASE
        WHEN DIAG_1_CD_LN IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_1_CD_LN
    END AS DIAG_1_CD_LN,
    CASE
        WHEN DIAG_2_CD_LN IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_2_CD_LN
    END AS DIAG_2_CD_LN,
    CASE
        WHEN DIAG_3_CD_LN IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_3_CD_LN
    END AS DIAG_3_CD_LN,
    CASE
        WHEN DIAG_4_CD_LN IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_4_CD_LN
    END AS DIAG_4_CD_LN,
    CASE
        WHEN DIAG_5_CD_LN IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_5_CD_LN
    END AS DIAG_5_CD_LN,
    CASE
        WHEN DIAG_6_CD_LN IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_6_CD_LN
    END AS DIAG_6_CD_LN,
    CASE
        WHEN DIAG_7_CD_LN IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_7_CD_LN
    END AS DIAG_7_CD_LN,
    CASE
        WHEN DIAG_8_CD_LN IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_8_CD_LN
    END AS DIAG_8_CD_LN,
    CASE
        WHEN DIAG_9_CD_LN IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_9_CD_LN
    END AS DIAG_9_CD_LN,
    CASE
        WHEN DIAG_10_CD_LN IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_10_CD_LN
    END AS DIAG_10_CD_LN,
    RIGHT(
        CASE
            WHEN DRG_CD IN ('NA', 'UNK', '~01', '~02', '~03', '?', '') THEN ''
            ELSE CONCAT('000', DRG_CD)
        END,
        3
    ) AS DRG_CD,
    DSCHRG_DT,
    CASE
        WHEN DSCHRG_STTS_CD IN ('NA', 'UNK', '~01', '~02', '~03', '~DV') THEN ''
        ELSE DSCHRG_STTS_CD
    END AS DSCHRG_STTS_CD,
    EDCTNL_DGRE_TTL_CD,
    SRC_EDCTNL_DGRE_TTL_CD,
    ENCLARITY_ADRS_LINE_1_TXT,
    ENCLARITY_ADRS_LINE_2_TXT,
    ENCLARITY_SRV_CITY_NM,
    ENCLARITY_SRV_ZIP_CD,
    ENCLARITY_SRV_ZIP_PLUS_4_CD,
    ENCLARITY_ST_PRVNC_CD,
    ENCLARITY_SPCLTY_CD,
    ENCLARITY_SPCLTY_DESCRIPTION,
    FUNDG_CF_CD,
    HLTH_SRVC_CD,
    HLTH_SRVC_CDDescription,
    HLTH_SRVC_TYPE_CD,
    CASE
        WHEN ICD_PROC_CD_1 IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE ICD_PROC_CD_1
    END AS ICD_PROC_CD_1,
    CASE
        WHEN ICD_PROC_CD_2 IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE ICD_PROC_CD_2
    END AS ICD_PROC_CD_2,
    CASE
        WHEN ICD_PROC_CD_3 IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE ICD_PROC_CD_3
    END AS ICD_PROC_CD_3,
    CASE
        WHEN ICD_PROC_CD_4 IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE ICD_PROC_CD_4
    END AS ICD_PROC_CD_4,
    CASE
        WHEN ICD_PROC_CD_5 IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE ICD_PROC_CD_5
    END AS ICD_PROC_CD_5,
    CASE
        WHEN ICD_PROC_CD_6 IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE ICD_PROC_CD_6
    END AS ICD_PROC_CD_6,
    CASE
        WHEN ICD_PROC_CD_7 IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE ICD_PROC_CD_7
    END AS ICD_PROC_CD_7,
    CASE
        WHEN ICD_PROC_CD_8 IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE ICD_PROC_CD_8
    END AS ICD_PROC_CD_8,
    CASE
        WHEN ICD_PROC_CD_9 IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE ICD_PROC_CD_9
    END AS ICD_PROC_CD_9,
    CASE
        WHEN ICD_PROC_CD_10 IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE ICD_PROC_CD_10
    END AS ICD_PROC_CD_10,
    INDIV_PROV_FRST_NM,
    INDIV_PROV_LAST_NM,
    INDIV_PROV_MID_NM,
    INN_CD,
    INPAT_CD,
    CASE
        WHEN MBR_GNDR_CD IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE MBR_GNDR_CD
    END AS MBR_GNDR_CD,
    NULLIF(NULLIF(MBR_KEY, 'NA'), 'NAA') AS MBR_KEY,
    CASE
        WHEN MBR_RLTNSHP_CD IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE MBR_RLTNSHP_CD
    END AS MBR_RLTNSHP_CD,
    IFNULL(CAST(MBRSHP_SOR_CD AS SMALLINT), 0) AS MBRSHP_SOR_CD,
    MBU_CF_CD,
    CASE
        WHEN RTRIM(PROV_MEDCR_ID) IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE RTRIM(PROV_MEDCR_ID)
    END AS PROV_MEDCR_ID,
    RNDRG_PROV_ID_NPI,
    CLM_LINE_NDC,
    PAID_SRVC_UNIT_CNT,
    PARG_STTS_CD,
    PAT_ACCT_NBR,
    PDC_EFCTV_DT,
    PDC_TRMNTN_DT,
    PDC_NM,
    PLACE_OF_SRVC_CD,
    PRCHSR_ORG_NBR,
    PRCHSR_ORG_NM,
    PRMRY_CARR_RSPNSBLY_CD,
    PRMRY_SPCLTY_CD,
    PROC_MDFR_1_CD,
    PROC_MDFR_2_CD,
    PROC_MDFR_3_CD,
    PROC_MDFR_4_CD,
    PROD_CF_CD,
    PROV_ADRS_EFCTV_DT,
    PROV_ADRS_TRMNTN_DT,
    DOING_BUS_AS_NM,
    PROV_MDCD_ID,
    CASE
        WHEN CLM_LINE_PROV_ID_TYPE_CD IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE CLM_LINE_PROV_ID_TYPE_CD
    END AS CLM_LINE_PROV_ID_TYPE_CD,
    PROV_ORG_FULL_NM,
    CASE
        WHEN PROV_ORG_ID IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE PROV_ORG_ID
    END AS PROV_ORG_ID,
    IFNULL(CAST(PROV_SOR_CD AS SMALLINT), 0) AS PROV_SOR_CD,
    PROV_ADRS_LINE_1_TXT,
    PROV_ADRS_LINE_2_TXT,
    PROV_SRV_CITY_NM,
    PROV_SRV_ZIP_CD,
    PROV_SRV_ZIP_PLUS_4_CD,
    PROV_ST_PRVNC_CD,
    PROV_CNTY_NM,
    PROV_STTS_CD,
    CASE
        WHEN CLM_LINE_POA_CD_1 IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE CLM_LINE_POA_CD_1
    END AS CLM_LINE_POA_CD_1,
    CASE
        WHEN CLM_LINE_POA_CD_2 IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE CLM_LINE_POA_CD_2
    END AS CLM_LINE_POA_CD_2,
    CASE
        WHEN CLM_LINE_POA_CD_3 IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE CLM_LINE_POA_CD_3
    END AS CLM_LINE_POA_CD_3,
    CASE
        WHEN CLM_LINE_POA_CD_4 IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE CLM_LINE_POA_CD_4
    END AS CLM_LINE_POA_CD_4,
    CASE
        WHEN CLM_LINE_POA_CD_5 IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE CLM_LINE_POA_CD_5
    END AS CLM_LINE_POA_CD_5,
    CASE
        WHEN CLM_LINE_POA_CD_6 IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE CLM_LINE_POA_CD_6
    END AS CLM_LINE_POA_CD_6,
    CASE
        WHEN CLM_LINE_POA_CD_7 IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE CLM_LINE_POA_CD_7
    END AS CLM_LINE_POA_CD_7,
    CASE
        WHEN CLM_LINE_POA_CD_8 IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE CLM_LINE_POA_CD_8
    END AS CLM_LINE_POA_CD_8,
    CASE
        WHEN CLM_LINE_POA_CD_9 IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE CLM_LINE_POA_CD_9
    END AS CLM_LINE_POA_CD_9,
    CASE
        WHEN CLM_LINE_POA_CD_10 IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE CLM_LINE_POA_CD_10
    END AS CLM_LINE_POA_CD_10,
    RLTD_PRCHSR_ORG_NBR,
    REPLACE(RVNU_CD, 'UNK', '') AS RVNU_CD,
    ServicingProviderPhoneNumber,
    SGRP_NM,
    CASE
        WHEN REPLACE(SRC_BILLG_PROV_ID, ' ', '') IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE REPLACE(SRC_BILLG_PROV_ID, ' ', '')
    END AS SRC_BILLG_PROV_ID,
    CASE
        WHEN SRC_BILLG_PROV_ID_TYPE_CD IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE SRC_BILLG_PROV_ID_TYPE_CD
    END AS SRC_BILLG_PROV_ID_TYPE_CD,
    CASE
        WHEN SRC_BILLG_TAX_ID IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE SRC_BILLG_TAX_ID
    END AS SRC_BILLG_TAX_ID,
    SRC_CLM_DISP_CD,
    SRC_GRP_NBR,
    CASE
        WHEN SRC_HC_ID IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE SRC_HC_ID
    END AS SRC_HC_ID,
    SRC_MBR_BRTH_DT,
    SRC_MBR_ZIP_CD,
    SRC_MBR_ZIP_PLUS_4_CD,
    SRC_PROV_NM,
    SRC_PROV_ZIP_CD,
    SRC_SUBGRP_NBR,
    SRVC_RNDRG_TYPE_CD,
    TAX_ID,
    TAX_ID_PROV_EFCTV_DT,
    TAX_ID_PROV_TRMNTN_DT,
    TAX_ID_EIN_OR_SSN_CD,
    SRC_ALT_CLM_NBR,
    CLM_ADJDCTN_LVL_CD,
    CASE
        WHEN year(CHK_DT) >= year(current_date()) - 10
        AND year(CHK_DT) <= year(current_date()) THEN CHK_DT
        ELSE NULL
    END AS CHK_DT,
    CLM_RCVD_DT,
    ADJDCTN_TYPE_CD,
    CASE
        WHEN CLM_FORM_TYPE_CD IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE CLM_FORM_TYPE_CD
    END AS CLM_FORM_TYPE_CD,
    CLM_REIMBMNT_TYPE_CD,
    PGYBK_CD,
    SCNDRY_HLTH_SRVC_CD,
    CLM_LINE_ENCNTR_CD,
    PN_ID,
    CASE
        WHEN PAYE_MBR_KEY IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE PAYE_MBR_KEY
    END AS PAYE_MBR_KEY,
    ADMSN_HOUR_NBR,
    DSCHRG_HOUR_NBR,
    CASE
        WHEN ADMSN_TYPE_CD IN ('NA', 'UNK', '~01', '~02', '~03', '~DV') THEN ''
        ELSE ADMSN_TYPE_CD
    END AS ADMSN_TYPE_CD,
    CASE
        WHEN LENGTH(TYPE_OF_BILL_CD) = 4
        AND LIKE(TYPE_OF_BILL_CD, '0%') THEN RIGHT(TYPE_OF_BILL_CD, 3)
        ELSE TYPE_OF_BILL_CD
    END AS TYPE_OF_BILL_CD,
    ACTVTG_PLAN_CD,
    PARG_PLAN_CD,
    PRCSG_PLAN_CD,
    SRVCG_PLAN_CD,
    PAYE_TAX_ID_ZIP_CD,
    WLP_LOB_LCTN_LOB_CD,
    WLP_LOB_CVRG_CD,
    WLP_LOB_NTWK_CD,
    SRC_MEDCR_ALWD_AMT,
    SRC_MEDCR_DDCTBL_AMT,
    SRC_MEDCR_PAYMNT_AMT,
    MBR_PROD_ENRLMNT_EFCTV_DT,
    MBR_PROD_ENRLMNT_TRMNTN_DT,
    TOS_CD,
    CASE
        WHEN SRC_ADMSN_SRC_CD IN ('NA', 'UNK', '~01', '~02', '~03', '~DV') THEN ''
        ELSE SRC_ADMSN_SRC_CD
    END AS SRC_ADMSN_SRC_CD,
    CASE
        WHEN CLM_LINE_PA_NBR IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE CLM_LINE_PA_NBR
    END AS CLM_LINE_PA_NBR,
    PRIM_OTHR_INSRNC_TYPE_CD,
    PRIM_COB_EFCTV_DT,
    PRIM_COB_TRMNTN_DT,
    SEC_OTHR_INSRNC_TYPE_CD,
    SEC_COB_EFCTV_DT,
    SEC_COB_TRMNTN_DT,
    CASE
        WHEN MBR_MEDCR_NBR IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE MBR_MEDCR_NBR
    END AS MBR_MEDCR_NBR,
    MBR_MEDCR_A_EFCTV_DT,
    MBR_MEDCR_B_EFCTV_DT,
    EMPLYMNT_STTS_CD,
    EMPLYMNT_TRMNTN_DT,
    CASE
        WHEN SRC_INSTNL_NGTTD_SRVC_TERM_ID IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE SRC_INSTNL_NGTTD_SRVC_TERM_ID
    END AS SRC_INSTNL_NGTTD_SRVC_TERM_ID,
    LegacyProviderId,
    CASE
        WHEN SRC_MBR_CD IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE SRC_MBR_CD
    END AS SRC_MBR_CD,
    CLM_FORM_ENTRY_CD,
    CLM_SYS_ENTRY_DT,
    SRC_BRTH_WT_NBR,
    FFS_EQVLNT_AMT,
    CLM_STMNT_FROM_DT,
    CLM_STMNT_TO_DT,
    CASE
        WHEN DIAG_CD_1_PRFV IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_CD_1_PRFV
    END AS DIAG_CD_1_PRFV,
    CASE
        WHEN DIAG_CD_2_PRFV IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_CD_2_PRFV
    END AS DIAG_CD_2_PRFV,
    CASE
        WHEN DIAG_CD_3_PRFV IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_CD_3_PRFV
    END AS DIAG_CD_3_PRFV,
    CASE
        WHEN ECI_DIAG_1_CD IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE ECI_DIAG_1_CD
    END AS ECI_DIAG_1_CD,
    CASE
        WHEN ECI_DIAG_2_CD IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE ECI_DIAG_2_CD
    END AS ECI_DIAG_2_CD,
    CASE
        WHEN ECI_DIAG_3_CD IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE ECI_DIAG_3_CD
    END AS ECI_DIAG_3_CD,
    IFNULL(CAST(ICD_VRSN_CD AS TINYINT), 0) AS ICD_VRSN_CD,
    LoadFileName,
    LoadDate,
    CASE
        WHEN CLM_REIMB_MTHD_CD IN ('NA', 'UNK', '?') THEN ''
        ELSE CLM_REIMB_MTHD_CD
    END AS CLM_REIMB_MTHD_CD,
    CASE
        WHEN SRC_CLM_REIMB_MTHD_CD IN ('NA', 'UNK', '?', '~NA') THEN ''
        ELSE SRC_CLM_REIMB_MTHD_CD
    END AS SRC_CLM_REIMB_MTHD_CD,
    FEE_SCHED_ID,
    CASE
        WHEN SVRTY_OF_ILNS_CD IN ('NA', 'UNK', '?') THEN ''
        ELSE SVRTY_OF_ILNS_CD
    END AS SVRTY_OF_ILNS_CD,
    DRG_CODE_V24,
    DRG_CODE_V28,
    DRG_CODE_DEFAULT,
    IFNULL(CAST(DRG_CODE_DEFAULT_VRSN_NBR AS TINYINT), 0) AS DRG_CODE_DEFAULT_VRSN_NBR,
    RIGHT(
        CASE
            WHEN FNL_DRG_CD IN ('NA', 'UNK', '~01', '~02', '~03', '?', '') THEN ''
            ELSE concat('000', FNL_DRG_CD)
        END,
        3
    ) AS FNL_DRG_CD,
    CASE
        WHEN DRG_TYPE_CD IN ('NA', 'UNK', '?') THEN ''
        ELSE DRG_TYPE_CD
    END AS DRG_TYPE_CD,
    CASE
        WHEN DIAG_5_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_5_CD_H
    END AS DIAG_5_CD_H,
    CASE
        WHEN DIAG_6_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_6_CD_H
    END AS DIAG_6_CD_H,
    CASE
        WHEN DIAG_7_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_7_CD_H
    END AS DIAG_7_CD_H,
    CASE
        WHEN DIAG_8_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_8_CD_H
    END AS DIAG_8_CD_H,
    CASE
        WHEN DIAG_9_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_9_CD_H
    END AS DIAG_9_CD_H,
    CASE
        WHEN DIAG_10_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_10_CD_H
    END AS DIAG_10_CD_H,
    CASE
        WHEN DIAG_11_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_11_CD_H
    END AS DIAG_11_CD_H,
    CASE
        WHEN DIAG_12_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_12_CD_H
    END AS DIAG_12_CD_H,
    CASE
        WHEN DIAG_13_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_13_CD_H
    END AS DIAG_13_CD_H,
    CASE
        WHEN DIAG_14_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_14_CD_H
    END AS DIAG_14_CD_H,
    CASE
        WHEN DIAG_15_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_15_CD_H
    END AS DIAG_15_CD_H,
    CASE
        WHEN DIAG_16_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_16_CD_H
    END AS DIAG_16_CD_H,
    CASE
        WHEN DIAG_17_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_17_CD_H
    END AS DIAG_17_CD_H,
    CASE
        WHEN DIAG_18_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_18_CD_H
    END AS DIAG_18_CD_H,
    CASE
        WHEN DIAG_19_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_19_CD_H
    END AS DIAG_19_CD_H,
    CASE
        WHEN DIAG_20_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_20_CD_H
    END AS DIAG_20_CD_H,
    CASE
        WHEN DIAG_21_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_21_CD_H
    END AS DIAG_21_CD_H,
    CASE
        WHEN DIAG_22_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_22_CD_H
    END AS DIAG_22_CD_H,
    CASE
        WHEN DIAG_23_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_23_CD_H
    END AS DIAG_23_CD_H,
    CASE
        WHEN DIAG_24_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_24_CD_H
    END AS DIAG_24_CD_H,
    CASE
        WHEN DIAG_25_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_25_CD_H
    END AS DIAG_25_CD_H,
    CASE
        WHEN DIAG_26_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_26_CD_H
    END AS DIAG_26_CD_H,
    CASE
        WHEN DIAG_27_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_27_CD_H
    END AS DIAG_27_CD_H,
    CASE
        WHEN DIAG_28_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_28_CD_H
    END AS DIAG_28_CD_H,
    CASE
        WHEN DIAG_29_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_29_CD_H
    END AS DIAG_29_CD_H,
    CASE
        WHEN DIAG_30_CD_H IN ('NA', 'UNK', '~01', '~02', '~03') THEN ''
        ELSE DIAG_30_CD_H
    END AS DIAG_30_CD_H,
    MBRSHP_SRC_SYS_PROD_ID,
    MBR_MDCD_NBR,
    PPS_CD,
    PRCHSR_ORG_BNFT_CLS_ID,
    PRPY_RVW_IND_CD
FROM
    (
        SELECT
            *,
            row_number() OVER (
                PARTITION BY CLM_ADJSTMNT_KEY,
                CLM_LINE_NBR
                ORDER BY
                    PRMRY_CARR_RSPNSBLY_CD
            ) AS Rnk
        FROM
            acm
        WHERE GL_POST_DT IS NOT NULL
    ) AS d
WHERE
    d.Rnk = 1