SELECT
    a.claim_key,
    a.legacy_sys_ids,
    true AS ccv_exclusion
FROM
    ClmData a
    INNER JOIN CCVInput b
      ON element_at(a.legacy_sys_ids, 'cnlyclaimnum') = b.CnlyClaimNum