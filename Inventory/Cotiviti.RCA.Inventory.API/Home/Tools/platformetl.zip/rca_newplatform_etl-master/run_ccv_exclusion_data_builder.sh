#!/usr/bin/env bash

# This script is used to sqoop data sources that related to Anthem CCV Exclusion to HDFS and submit Spark jobs
# to transform sqooped data

# Two optional parameters can be provided:
# [1]: user name. if absent, use current user as default value
# [2]: yarn queue name. if absent, use root.users.[user] as default value

# Parameters with default values
UNAME=${1:-$USER}
QUEUE=${UNAME//./_dot_}
QUEUE="root.users.${QUEUE}"
QUEUE=${2:-$QUEUE}
CLIENT="Anthem"
JOB="ccv_exclusion_data_builder"
CONF_RES=$(ls -t ./conf/ | tr '\n', ',' | sed 's/,$//')
SQL_RES=$(ls -t ./sql/ | tr '\n', ',' | sed 's/,$//')
RES="${CONF_RES},${SQL_RES}"
# Get password from the pass.txt file in home directory
PASSWD=$(cat ~/pass.txt)

# Load shared functions
. ./util.sh

# Exit on error
set -e

# Trap ERR event to send notification
trap 'send_notification "Anthem CCV Tagging failed. User: ${UNAME} - Queue: ${QUEUE}"' ERR

# Send started notification to Teams
send_notification "Anthem CCV Exclusion Process started. User: ${UNAME} - Queue: ${QUEUE}"

# Spark - Begin CCV Exclusion
spark2-submit \
--master yarn \
--deploy-mode cluster \
--name "${CLIENT} CCV Exclusion Data Builder" \
--queue $QUEUE \
--jars ./lib/* \
--num-executors 20 \
--executor-memory 40G \
--executor-cores 5 \
--driver-memory 20G \
--py-files ./dependencies.zip,./jobs.zip \
--files ./conf/*,./sql/* \
--conf spark.sql.shuffle.partitions=400 \
./main.py --client_name ${CLIENT} --job ${JOB} --rs "${RES}" --job-args USER=${UNAME} PASS=${PASSWD}

# Set ACL
hdfs dfs -chmod -R 770 /rca/dev/anthem/exclusion/ccvexclusion/output

echo "Spark job ($JOB) completed."

# Send completed notification to Teams
send_notification "Anthem CCV Exclusion Tagging completed. User: ${UNAME} - Queue: ${QUEUE}"

# Exit
exit 0