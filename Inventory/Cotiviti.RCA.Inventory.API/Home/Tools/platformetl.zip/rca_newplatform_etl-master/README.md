# PySpark ETL Project Template

This project works as a template for PySpark ETL projects that created for new RCA platform. This template provides 
below conventions and utilities:

- Standard folder structure (conf, jars, jobs, schema, sql)
- Build and clean scripts
- Sample Spark submit script
- ETL configuration, classes and functions
- Sample ETL job
- Utilities
  * Configuration
  * Logging
  * HDFS FileSystem Utility
  
 ## How to Use
 
 1. Clone this project template from git repo
 2. Open this project in PyCharm and ensure packages that declared in requirements.txt installed in your virtual environment
 3. Add a new python file under jobs folder for your PySpark job and define a run method like below. You can refer to 
 the sample job module to get more information
     ```python
    from dependencies import DataFrameDict, extract, transform, load
    
    
    def run(context):
      """
      required run method to load aso raw data
      :param context: job context
      :return: None
      """
      # get logger from job context
      log = context.log
      log.info("Starting run() for job: ")
      # get Spark Session from job context
      spark = context.spark
      # get job configuration from job context
      config = context.config.aso_load
      # use job arguments to specify runtime values like load date
      job_args = context.config.submit_args.job_args
      df_dict = DataFrameDict()
      try:
        # extract dataframes from configured data sources
        extract(spark, config, job_args, df_dict)
        # transform
        transform(spark, config, df_dict)
        # load
        load(config, job_args, df_dict)
      except Exception as e:
        log.error("An error occurred while running job: {0} exception: {1}".format(str(__name__), str(e)))
        raise
    ```
 4. Add job config files under conf folder. The naming convention is {job module name}_dev_config.json for 
 dev environment and {job module name}_config.json for production environment
 5. Add sql files under sql folder. Those sql files used by spark sql function to transform or 
 enrich dataframes
 6. Add schema definition files in schema folder if necessary. The schema file is in JSON format
 7. Test job on local (use sample dataset on local to boost your productivity)
 8. When it's ready to deploy, run below bat command on windows to build distribution packages:
     ```shell script
     .\build.bat
     ```
 9. Upload distribution packages to the deployment folder on edge node of cluster
 10. Refer to the sample shell script to submit your ETL job on cluster
 
 ## Change Log
 
 We made below changes since the original version:
 
 - Remove database module from the dependencies
 
   We embrace the principle of separation of concern. Getting configuration from database is not core business 
   of ETL job. We created a utility tool and it can get configuration from database and then pass to ETL job
   
 - Add etl related classes, functions and configuration
   
   Those classes and functions provide basic building blocks to construct a general ETL pipeline
   
  - Refactor config dict
  
    Remove spark and log from the config dict and create a JobContext to encapsulate config, log and spark session
    
  - Use JobContext to encapsulate spark session, config and log and pass the context to job's run method
  
    From semantics point of view, use JobContext is better option and it will help when mocking a context during unit testing
    
  - Create build bat file for distribution
  
    The bat file allows us to build the dist packages on windows directly, no need to clone the source codes to 
    edge node and then build dist packages there.
    
  - Add pip requirements.txt
  
    This pip requirements.txt file can ensure we have same dependency packages across team members
    
  - Add a utility script to generate config file from database
  
    This tool generates a config JSON file from postgres database. In our vision, we will store our ETL configuration
    in postgres
    

 