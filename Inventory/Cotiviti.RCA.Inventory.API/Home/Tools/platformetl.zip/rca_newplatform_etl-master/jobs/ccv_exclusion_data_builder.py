from dependencies import DataFrameDict, extract, transform, load


def run(context):
    """
    required run method to build anthem ccv exclusion data
    :param context: job context
    :return: None
    """
    log = context.log
    log.info("Starting run() for job: " + str(__name__))
    spark = context.spark
    config = context.config.ccv_exclusion_data_builder
    # use job arguments to specify runtime values like load date
    job_args = context.config.submit_args.job_args
    df_dict = DataFrameDict()
    try:
        # extract dataframes from configured data sources
        extract(spark, config, job_args, df_dict)
        # transform
        transform(spark, config, df_dict)
        # load
        load(config, job_args, df_dict)
        # release cached dataframe
        if len(df_dict.cached_df) > 0:
            log.info("the count of cached dataframe is {}".format(len(df_dict.cached_df)))
            for key in df_dict.cached_df:
                df_dict.cached_df[key].unpersist()
    except Exception as e:
        log.error("An error occurred while running job: {0} exception: {1}".format(str(__name__), str(e)))
        raise
