#!/usr/bin/env bash

# This shell script is used to submit a Spark job to load raw aso claim data for Anthem

# One required parameter
# [1]: load date in yyyyMM format.

# Two optional parameters can be provided:
# [2]: user name. if absent, use current user as default value
# [3]: yarn queue name. if absent, use root.users.[user] as default value

LDT=${1:-''}
UNAME=${2:-$USER}
QUEUE=${UNAME//./_dot_}
QUEUE="root.users.${QUEUE}"
QUEUE=${3:-$QUEUE}

CLIENT="Anthem"
JOB="aso_load"
CONF=$(ls -t ./conf/ | tr '\n', ',' | sed 's/,$//')
SCHEMA=$(ls -t ./schema/ | tr '\n', ',' | sed 's/,$//')
SQL=$(ls -t ./sql/ | tr '\n', ',' | sed 's/,$//')
RES="${CONF},${SCHEMA},${SQL}"


# Load util functions
. ./util.sh

# Check if required parameter supplied
if [ -z "$LDT" ]; then
  send_notification "Required parameter not supplied. ${CLIENT} aso data load (${LDT}) failed. User: ${UNAME} - Queue: ${QUEUE}"
  exit 1
fi

# Exit on error
set -e

# Trap ERR event to send notification
trap 'send_notification "${CLIENT} aso data load (${LDT}) failed. User: ${UNAME} - Queue: ${QUEUE}"' ERR

# Send started notification to Teams
send_notification "${CLIENT} aso data load (${LDT}) started. User: ${UNAME} - Queue: ${QUEUE}"

# Submit Spark job to cluster to load aso raw data for Anthem
spark2-submit \
--master yarn \
--deploy-mode cluster \
--name "${CLIENT} ASO Data Load (${LDT})" \
--num-executors 5 \
--executor-memory 10G \
--executor-cores 5 \
--driver-memory 10G \
--py-files ./dependencies.zip,./jobs.zip \
--files ./conf/*,./schema/*,./sql/* \
./main.py --client_name ${CLIENT} --job ${JOB} --rs "${RES}" --job-args LoadDate=${LDT}

# Set ACL
hdfs dfs -chmod -R 770 /rca/dev/anthem/refined/claim/aso/${LDT}

# Send completed notification to Teams
send_notification "${CLIENT} aso data load (${LDT}) completed. User: ${UNAME} - Queue: ${QUEUE}"

# Exit
exit 0
