"""
This tool is used to retrieve the configuration for a specified client and generate a JSON file
"""
import psycopg2
from psycopg2.extras import RealDictCursor
import argparse
import traceback
import json


class PGConnInfo(object):
    def __init__(self, host, port, database, user, pwd):
        self.host = host
        self.port = port
        self.database = database
        self.user = user
        self.pwd = pwd


# establish connection to Postgres
def connect_db(conn_info):
    """
    Establishes a connection to the database.

    :return: object: connection object.
    """
    try:
        connection = psycopg2.connect(
            user=conn_info.user,
            password=conn_info.pwd,
            host=conn_info.host,
            port=conn_info.port,
            database=conn_info.database
        )
    except (Exception, psycopg2.Error) as error:
        print("Error while connecting to PostgreSQL", error)
        return None
    else:
        return connection


def query_table(conn_info, sql_query):
    """
    Run prebuilt sql select query.  Can handle a preformed select or a dynamic select with parameters
    parameterized queries need to be strings with %s in place where each param is to be subbed.
    where

    :param conn_info: an instance of PGConnInfo class
    :param sql_query: Sql query to run.
    :return: dict:
    """
    sql_cursor = None
    connection = None
    try:
        connection = connect_db(conn_info)
        if connection is None:
            raise Exception("Error while connecting to PostgreSQL.")
        sql_cursor = connection.cursor(cursor_factory=RealDictCursor)
        sql_cursor.execute(sql_query)
        result = sql_cursor.fetchone()
        return result
    finally:
        if connection:
            if sql_cursor:
                sql_cursor.close()
            connection.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', dest='host', type=str)
    parser.add_argument('--port', dest='port', type=int)
    parser.add_argument('--database', dest='database', type=str)
    parser.add_argument('--user', dest='user', type=str)
    parser.add_argument('--pwd', dest='pwd', type=str)
    parser.add_argument('--client', dest='client', type=str)
    parser.add_argument('--target', dest='target', type=str)
    args = parser.parse_args()
    conn_info = PGConnInfo(args.host, args.port, args.database, args.user, args.pwd)
    has_error = False
    try:
        sql = "SELECT config FROM etl_config WHERE client='{}'".format(args.client)
        result = query_table(conn_info, sql)
        if result is None:
            print("No configuration found for specified client {}".format(args.client))
        else:
            # write config to JSON file
            with open(args.target, 'w') as out:
                json.dump(result['config'], out)
    except Exception:
        has_error = True
        print('An error occurred. ' + traceback.format_exc())

    if has_error:
        exit(1)


if __name__ == "__main__":
    main()
