from pyspark import SparkFiles
from pyspark.sql.types import StructType
from pyspark.sql.functions import input_file_name
import os
import json
import sys


class SourceDef(object):
    """
    A class represents a definition of generic data source
    """

    def __init__(self, fmt, select, where, view, key, cache, repartition_by=None):
        """
        constructor of SourceDef
        :param fmt: source format
        :param select: selected columns delimit by comma. if empty, then select all columns
        :param where: where clause. if empty, then no filters applied
        :param view: spark sql temp view
        :param key: a dict key that points to loaded dataframe
        :param cache: a boolean value that indicates if need to cache the loaded dataframe
        :param repartition_by: a string that represents repartition columns, delimit by comma
        """
        fmt = fmt.strip()
        if fmt not in ('csv', 'parquet', 'avro', 'jdbc'):
            raise Exception("format in source definition is not supported.")
        if not isinstance(cache, bool):
            raise Exception("cache in source definition must be True or False.")
        key = key.strip()
        if len(key) == 0:
            raise Exception("key in source definition cannot be empty.")
        self.format = fmt
        self.select = select.strip()
        self.where = where.strip()
        self.view = view.strip()
        self.key = key
        self.cache = cache
        if repartition_by and len(repartition_by.strip()) > 0:
            self.repartition_by = repartition_by
        else:
            self.repartition_by = None


class FileSourceDef(SourceDef):
    """
    A class represents a definition of file data source. It inherits from SourceDef
    """

    def __init__(self, fmt, select, where, view, key, cache, path, repartition_by=None):
        """
        constructor of FileSourceDef
        :param fmt: source format
        :param select: selected columns delimit by comma. if empty, then select all columns
        :param where: where clause. if empty, then no filters applied
        :param view: spark sql temp view
        :param key: a dict key that points to loaded dataframe
        :param cache: a boolean value that indicates if need to cache the loaded dataframe
        :param path: path of source data
        :param repartition_by: a string that represents repartition columns, delimit by comma
        """
        super(FileSourceDef, self).__init__(fmt, select, where, view, key, cache, repartition_by)
        path = path.strip()
        if len(path) == 0:
            raise Exception("path in file source definition cannot be empty.")
        self.path = path


class CSVSourceDef(FileSourceDef):
    """
    A class represents a definition of csv file data source. It inherits from FileSourceDef
    """

    def __init__(self, fmt, select, where, view, key, cache, path, schema,
                 header, delimit, encoding, repartition_by=None):
        """
        constructor of FileSourceDef
        :param fmt: source format
        :param select: selected columns delimit by comma. if empty, then select all columns
        :param where: where clause. if empty, then no filters applied
        :param view: spark sql temp view
        :param key: a dict key that points to loaded dataframe
        :param cache: a boolean value that indicates if need to cache the loaded dataframe
        :param path: path of source data
        :param schema: explicit schema of csv file
        :param header: a boolean value that indicates if header row exists in the csv file
        :param delimit: column delimit of csv file
        :param encoding: encoding of csv file, if absent, use utf-8 as default
        :param repartition_by: a string that represents repartition columns, delimit by comma
        """
        super(CSVSourceDef, self).__init__(fmt, select, where, view, key, cache, path, repartition_by)
        schema = schema.strip()
        if len(schema) == 0:
            raise Exception("schema in csv file source definition cannot be empty.")
        self.schema = schema
        if not isinstance(header, bool):
            raise Exception("header in csv file source definition must be True or False.")
        self.header = header
        delimit = delimit.strip()
        if len(delimit) == 0:
            raise Exception('delimit in csv file source definition cannot be empty.')
        self.delimit = delimit
        encoding = encoding.strip()
        if len(encoding) == 0:
            encoding = 'utf-8'
        self.encoding = encoding


class JDBCSourceDef(SourceDef):
    """
    A class represents a definition of jdbc data source. It inherits from SourceDef
    """

    def __init__(self, fmt, select, where, view, key, cache, driver, url, query, fetch_size):
        """
        constructor of JDBCSourceDef
        :param fmt: source format
        :param select: selected columns delimit by comma. if empty, then select all columns
        :param where: where clause. if empty, then no filters applied
        :param view: spark sql temp view
        :param key: a dict key that points to loaded dataframe
        :param cache: a boolean value that indicates if need to cache the loaded dataframe
        :param driver: a string represents the full qualified class name of JDBC driver
        :param url: a string represents JDBC connection url
        :param query: a string represents SQL query statement
        :param fetch_size: an integer represents the fetch size of a round trip
        """
        super(JDBCSourceDef, self).__init__(fmt, select, where, view, key, cache)
        driver = driver.strip()
        if len(driver) == 0:
            raise Exception("driver in jdbc source cannot be empty.")
        self.driver = driver
        url = url.strip()
        if len(url) == 0:
            raise Exception("url in jdbc source cannot be empty.")
        self.url = url
        query = query.strip()
        if len(query) == 0:
            raise Exception("query in jdbc source cannot be empty.")
        self.query = query
        if not isinstance(fetch_size, int):
            raise Exception("fetch size in jdbc source must be int type.")
        if fetch_size < 1:
            raise Exception("fetch size in jdbc source cannot be less than 1.")
        self.fetch_size = fetch_size


class FlowDef(object):
    """
    A class represents a definition of flow (In our context, flow means a transformation)
    """

    def __init__(self, sql, key, view, cache, repartition_by=None):
        """
        constructor of FlowDef
        :param sql: sql statement or name of sql file
        :param key: a dict key that points to generated dataframe
        :param view: spark sql temp view
        :param cache: a boolean value that indicates if need to cache the generated dataframe
        :param repartition_by: a string that represents repartition columns, delimit by comma
        """
        sql = sql.strip()
        key = key.strip()
        if len(sql) == 0:
            raise Exception("sql in flow definition cannot be empty.")
        if len(key) == 0:
            raise Exception("key in flow definition cannot be empty.")
        if not isinstance(cache, bool):
            raise Exception("cache in flow definition must be True or False.")
        self.sql = sql
        self.key = key
        self.view = view.strip()
        self.cache = cache
        if repartition_by and len(repartition_by.strip()) > 0:
            self.repartition_by = repartition_by
        else:
            self.repartition_by = None


class SinkDef(object):
    """
    A class represents a definition of sink
    """

    def __init__(self, key, fmt, mode):
        """
        Constructor of SinkDef
        :param key: a dict key that points to a dataframe that to be sank
        :param fmt: format of sink. like parquet, avro or JDBC etc.
        :param mode: mode of Spark DataFrame writer
        """
        key = key.strip()
        fmt = fmt.strip()
        mode = mode.strip()
        if len(key) == 0:
            raise Exception("key in sink definition cannot be empty.")
        if len(fmt) == 0:
            raise Exception("format in sink definition cannot be empty.")
        if len(mode) == 0:
            raise Exception("mode in sink definition cannot be empty.")
        self.key = key
        self.format = fmt
        self.mode = mode


class FileSinkDef(SinkDef):
    """
    A class represents a definition of file sink. It inherits from SinkDef
    """

    def __init__(self, key, fmt, mode, path, compress, partition_by=None):
        """
        constructor of FileSinkDef
        :param key: a dict key that points to a dataframe that to be sank
        :param fmt: format of sink, like parquet, avro, etc.
        :param mode: mode of Spark DataFrame writer
        :param path: path of sink
        :param compress: a boolean value to indicate if compression needed
        :param partition_by: a string that represents partition columns, delimit by comma
        """
        super(FileSinkDef, self).__init__(key, fmt, mode)
        path = path.strip()
        # validate
        if len(path) == 0:
            raise Exception("path in file sink definition cannot be empty.")
        if not isinstance(compress, bool):
            raise Exception("compress in file sink definition must be True or False.")
        self.path = path
        self.compress = compress
        # partition columns
        if partition_by and len(partition_by.strip()) > 0:
            self.partition_by = partition_by
        else:
            self.partition_by = None


def source(spark, source_def):
    """
    return a dataframe from the defined data source
    currently only file data source supported. more data sources will be added in the future.
    :param spark: spark session
    :param source_def: the definition of source
    :return: dataframe
    """
    if isinstance(source_def, CSVSourceDef):
        # load schema from json schema definition
        schema_json = json.loads(read_spark_file(source_def.schema))
        schema = StructType.fromJson(schema_json)
        # https://stackoverflow.com/questions/51707067/remove-utf-8-literals-in-a-string-python
        # https://en.wikipedia.org/wiki/Mojibake
        if source_def.encoding != 'utf-8':
            if sys.version_info.major == 3:
                sep = source_def.delimit.encode('latin1').decode('utf8').encode('latin1').decode(source_def.encoding)
            else:
                sep = source_def.delimit.decode('utf8').encode('latin1').decode(source_def.encoding)
        else:
            sep = source_def.delimit
        print("DEBUG: Sep is {0}".format(sep))
        df = spark.read.csv(source_def.path, schema=schema, sep=sep, header=source_def.header,
                            ignoreLeadingWhiteSpace=True, ignoreTrailingWhiteSpace=True, encoding=source_def.encoding)
    elif isinstance(source_def, FileSourceDef):
        df = spark.read.format(source_def.format).load(source_def.path)
    elif isinstance(source_def, JDBCSourceDef):
        df = spark.read.format(source_def.format).option('driver', source_def.driver) \
            .option('url', source_def.url) \
            .option('query', source_def.query) \
            .option('fetchsize', source_def.fetch_size).load()
    else:
        raise Exception('source type is not supported.')
    # check where clause
    if len(source_def.where) > 0:
        df = df.where(source_def.where)
    # check select columns
    if len(source_def.select) > 0:
        columns = [col.strip() for col in source_def.select.split(',')]
        df = df.select(columns)
    # add an additional column to hold the name of load file if the source is file based
    if not isinstance(source_def, JDBCSourceDef):
        df = df.withColumn("ARK_IFN", input_file_name())
    # repartition
    if source_def.repartition_by:
        cols = source_def.repartition_by.split(',')
        cols = [col.strip() for col in cols]
        df = df.repartition(*cols)
    return df


def flow(spark, flow_def):
    """
    return a dataframe that generated via spark SQL statement
    :param spark: spark session
    :param flow_def: the definition of flow / transformation
    :return: dataframe
    """
    sql = flow_def.sql
    # if the specified sql is a file, then read its content
    if sql.endswith(".sql"):
        sql = read_spark_file(sql)
    df = spark.sql(sql)
    # if we need to repartition data
    if flow_def.repartition_by:
        cols = flow_def.repartition_by.split(',')
        cols = [col.strip() for col in cols]
        df = df.repartition(*cols)
    return df


def sink(df, sink_def):
    """
    sink a dataframe based on the sink definition
    currently only file sink supported. more sink types will be added in the future.
    :param df: dataframe to be sink
    :param sink_def: the definition of sink
    :return: None or Exception
    """
    if isinstance(sink_def, FileSinkDef):
        if df is not None:
            dfw = df.write.format(sink_def.format).mode(sink_def.mode)
            # only compress with snappy codec for now, if needed, we can add other codecs
            if sink_def.compress:
                dfw = dfw.option('compression', 'snappy')
            # partition
            if sink_def.partition_by:
                cols = sink_def.partition_by.split(',')
                cols = [col.strip() for col in cols]
                dfw = dfw.partitionBy(*cols)
            dfw.save(sink_def.path)
    else:
        raise Exception("only file data sink supported at this time.")


def read_spark_file(file_name):
    """
    return the content of a file in SparkFiles root folder
    :param file_name: name of file
    :return: content of file
    """
    path = os.path.join(SparkFiles.getRootDirectory(), file_name)
    # check if file exists
    if not os.path.exists(path):
        raise FileNotFoundError("the specified file {} not found.".format(file_name))
    with open(path, "r") as f:
        content = f.read()
    return content


class DataFrameDict(object):
    """
    A class includes two dictionaries that used to hold the points to generated dataframes and cached dataframes
    during the process of etl
    """

    def __init__(self):
        self.df = dict()
        self.cached_df = dict()


def extract(spark, config, job_args, df_dict):
    """
    extract from configured data sources and create dataframes for each data source
    :param spark: spark session
    :param config: configuration for the job
    :param job_args: arguments of job
    :param df_dict: an instance of DataFrameDict
    :return: None
    """
    if not job_args:
        job_args = {}
    sources = config.sources
    if len(sources) == 0:
        raise Exception("No source configured for job: {}".format(str(__name__)))
    # iterate configured data sources
    for src in sources:
        repartition_by = src.get("repartition_by")
        if src["format"] in ('parquet', 'avro'):
            source_def = FileSourceDef(src["format"], src["select_column"],
                                       src["where_clause"], src["temp_view"], src["key"], src["cache"],
                                       src["path"].format(**job_args), repartition_by)
        elif src["format"] == 'csv':
            source_def = CSVSourceDef(src["format"], src["select_column"],
                                      src["where_clause"], src["temp_view"], src["key"], src["cache"],
                                      src["path"].format(**job_args), src["schema"], src["header"],
                                      src["delimit"], src["encoding"], repartition_by)
        elif src["format"] == 'jdbc':
            source_def = JDBCSourceDef(src["format"], src["select_column"],
                                       src["where_clause"], src["temp_view"], src["key"], src["cache"],
                                       src["driver"], src["url"].format(**job_args), src["query"], src["fetch_size"])
        else:
            raise Exception("only file data source supported at this time.")
        # load the source
        if source_def:
            df = source(spark, source_def)
            # if cache is enabled
            if source_def.cache:
                df = df.cache()
                df_dict.cached_df[source_def.key] = df
            # if temp view is enabled
            if len(source_def.view) > 0:
                df.createOrReplaceTempView(source_def.view)
            # store df to global dict
            df_dict.df[source_def.key] = df


def transform(spark, config, df_dict):
    """
    use spark sql to transform or enrich dataframes
    :param spark: spark session
    :param config: configuration for the job
    :param df_dict: an instance of DataFrameDict
    :return: None
    """
    flows = config.flows
    for fl in flows:
        flow_def = FlowDef(fl["sql"], fl["key"], fl["temp_view"], fl["cache"], fl.get("repartition_by"))
        # run configured spark sql statement and return new generated dataframe
        df = flow(spark, flow_def)
        # if cache is enabled
        if flow_def.cache:
            df = df.cache()
            df_dict.cached_df[flow_def.key] = df
        # if temp view is enabled
        if len(flow_def.view) > 0:
            df.createOrReplaceTempView(flow_def.view)
        df_dict.df[flow_def.key] = df


def load(config, job_args, df_dict):
    """
    sink/load dataframes to external system like HDFS
    :param config: configuration for the job
    :param job_args: arguments of job
    :param df_dict: an instance of DataFrameDict
    :return: None
    """
    if not job_args:
        job_args = {}
    sinks = config.sinks
    if len(sinks) == 0:
        raise Exception("No sink configured for job: {}".format(str(__name__)))
    for s in sinks:
        if s["format"] in ('parquet', 'avro', 'csv'):
            sink_def = FileSinkDef(s["key"], s["format"], s["mode"], s["path"].format(**job_args),
                                   s["compress"], s.get('partition_by'))
        else:
            raise Exception("only file data sink supported at this time.")
        # get the dataframe based on the key
        df = df_dict.df[sink_def.key]
        sink(df, sink_def)
