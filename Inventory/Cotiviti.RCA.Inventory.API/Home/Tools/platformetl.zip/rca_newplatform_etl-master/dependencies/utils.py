"""
Compilation of non-spark Python functions.
"""
import subprocess


def merge_lists(original, incoming):
    """
    Deep merge two lists. Modifies original.
    Recursively call deep merge on each correlated element of list.
    If item type in both elements are
     a. dict: Call merge_dicts on both values.
     b. list: Recursively call merge_lists on both values.
     c. any other type: Value is overridden.
     d. conflicting types: Value is overridden.

    If length of incoming list is more that of original then extra values are appended.
    *destructive of original list, would need to be refactored to return a new list, would need to be done in
     conjunction with merge_dicts because of how the recursive interaction works*

     :param original: original list
     :param incoming: list to merge to original
    """
    common_length = min(len(original), len(incoming))
    for idx in range(common_length):
        if isinstance(original[idx], dict) and isinstance(incoming[idx], dict):
            merge_dicts(original[idx], incoming[idx])

        elif isinstance(original[idx], list) and isinstance(incoming[idx], list):
            merge_lists(original[idx], incoming[idx])

        else:
            original[idx] = incoming[idx]

    for idx in range(common_length, len(incoming)):
        original.append(incoming[idx])


def merge_dicts(original, incoming):
    """
    Deep merge two dictionaries. Modifies original.
    For key conflicts if both values are:
     a. dict: Recursively call merge_dicts on both values.
     b. list: Call merge_lists on both values.
     c. any other type: Value is overridden.
     d. conflicting types: Value is overridden.

     *destructive of original dict, would need to be refactored to return a new dict, would need to be done in
     conjunction with merge_lists because of how the recursive interaction works*

     :param original: original dictionary
     :param incoming: dictionary to merge to original

    """
    for key in incoming:
        if key in original:
            if isinstance(original[key], dict) and isinstance(incoming[key], dict):
                merge_dicts(original[key], incoming[key])

            elif isinstance(original[key], list) and isinstance(incoming[key], list):
                merge_lists(original[key], incoming[key])

            else:
                original[key] = incoming[key]
        else:
            original[key] = incoming[key]


def validate_hdfs_filebuild(file_path, temp_file_path, keep_backup=True, chmod_octal=770):
    """
    validates that the temp file path was successfully created in HDFS (based solely on the presence of a _SUCCESS
    file being created in the new path (no actual validation of the data takes place this just checks whether
    the Spark driver received a success from all executors and moved the created files out of temp)

    If the files were successfully created the existing prod files are moved to the backup (any existing backups are
    removed) and then the new files are moved to become the new "prod" files.

    :param file_path: the "prod" path to the files needing validation.  This should be the directory that would
    contain the files rather than any files themselves.
    :param temp_file_path: the newly created temp path that is intended to replace the prod files
    :param keep_backup: default True.  If True saves previous path as _backup.  If false removes previous.
    :param chmod_octal: default is 770 (rwxrwx---)  If a different value is supplied will apply the required chmod
    octal permissions, can be set to None to leave the default HDFS permissions.
    https://ss64.com/bash/chmod.html
    :return: BOOLEAN indicating success/failure
    """
    testCmd = 'hdfs dfs -test -e '
    removeCmd = 'hdfs dfs -rm -r -skipTrash '
    moveCmd = 'hdfs dfs -mv '
    chmodCmd = 'hdfs dfs -chmod -R '
    path = file_path.rstrip("/")
    temp_path = temp_file_path.rstrip("/")
    success = False

    if chmod_octal:
        subprocess.call(chmodCmd + str(chmod_octal) + ' ' + temp_path)

    check_success = subprocess.call(testCmd + temp_path + '/_SUCCESS', shell=True)
    if check_success == 0:
        print('files created successfully')

        check_for_current = subprocess.call(testCmd + path, shell=True)
        if check_for_current == 0:

            if keep_backup:
                check_for_backup = subprocess.call(testCmd + path + '_backup', shell=True)
                if check_for_backup == 0:
                    subprocess.call(removeCmd + path + '_backup', shell=True)

                subprocess.call(moveCmd + path + ' ' + path + '_backup', shell=True)

                print('original files backed up to ' + path + '_backup')
            else:
                subprocess.call(removeCmd + path, shell=True)

        final_move = subprocess.call(moveCmd + temp_path + ' ' + path, shell=True)

        if final_move == 0:
            success = True

    return success


def parse_nargs(arg, narg_dest):
    """
    parses nargs into a dictionary.  narg variables must be defined as key=val

    :param arg: input an argparse Namespace object
    :param narg_dest: input the destination of the nargs * submit argument.
    :return: new argparse Namespace object
    """
    argnamespace = arg
    narg = vars(argnamespace)
    d = {}
    if narg[narg_dest]:
        for i in narg[narg_dest]:
            if '=' in i:
                isplit = i.split('=', 1)
                key = isplit[0]
                value = isplit[1]
                d.update({key: value})
    argnamespace.__setattr__(narg_dest, d)
    return argnamespace


def get_list_of_dict_index(list_to_search, value, key):
    for i, item in enumerate(list_to_search):
        if isinstance(item, dict):
            if item[key] == value:
                return i


def get_dict_keys(input_dict):
    """
    Takes a dictionary as the input and returns a sorted list of all keys.  Nested dicts are returned using dot
    notation ie trunk.branch.leaf

    :param input_dict: dictionary to parse
    :return:
    """
    key_list = []

    if isinstance(input_dict, dict):
        for k in input_dict.keys():
            key_list.append(k)
            if isinstance(input_dict[k], dict):
                subkey_list = get_dict_keys(input_dict[k])
                for item in subkey_list:
                    key_list.append(k + '.' + item)

    return sorted(key_list)


class MasterDict(object):
    """
    MasterDict Class object.  Links an object to a dictionary that allows global dictionary management
    other modules can create an instance against one common dictionary and all changes will be kept in sync.
    instances can also be created against nested dictionaries and will still maintain a link between all instances
    regardless of initial nesting level.
    """

    def __init__(self, d):
        object.__setattr__(self, '_' + self.__class__.__name__ + '__dict', d)

    def __getitem__(self, name):
        value = None
        try:
            value = self.__dict[name]
            if isinstance(value, (dict, list)):  # recursively view sub-dicts/lists as objects
                value = MasterDict(value)
        except AttributeError:
            pass
        finally:
            return value

    def __setitem__(self, name, value):
        try:
            self.__dict[name] = value
        except IndexError:
            self.__dict.append(value)

    def __delitem__(self, name):
        del self.__dict[name]

    # Object-like access / updates
    def __getattr__(self, name):
        value = self[name]
        return value

    def __setattr__(self, name, value):
        self[name] = value

    def __delattr__(self, name):
        del self[name]

    def __repr__(self):
        return "%s(%r)" % (type(self).__name__, self.__dict)

    def __str__(self):
        return str(self.__dict)

    def __nonzero__(self):
        if self.__dict:
            return True
        else:
            return False

    def __iter__(self):
        return iter(self.__dict)

    def __eq__(self, y):
        if self.__dict == y:
            return True
        else:
            return False

    def __len__(self):
        if not isinstance(self.__dict, (list, tuple, dict)):
            return None
        try:
            length = len(self.__dict)
            return length
        except:
            return 0

    def append(self, value):
        d = self.__dict
        if d is None:
            d = []
        if not isinstance(d, (list, tuple)):
            raise TypeError("Append not implemented for " + str(type(d)) + ", can only be used for lists or tuples.")
        self.__dict.append(value)

    def keys(self):
        try:
            k = self.__dict.keys()
            return k
        except:
            return None

    def update(self, value):
        if not isinstance(value, dict):
            raise TypeError("Update method expected input type dict, received: " + str(type(value)))
        merge_dicts(self.__dict, value)

    def index(self, value):
        if isinstance(self.__dict, list):
            return self.__dict.index(value)
