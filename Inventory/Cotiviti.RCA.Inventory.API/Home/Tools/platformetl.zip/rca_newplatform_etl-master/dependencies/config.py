from pyspark import SparkFiles
from dependencies import merge_dicts, MasterDict
from os import listdir, path
import json

# Master config dictionary.  All activity should be managed through the master_config class instance. Class can be
# used like a traditional dictionary or like an object.
#     example
#       master_config['dictionary']['nested_dictionary']
#       master_config.dictionary.nested_dictionary
# new dictionary entries can be created by recursively adding 1 new level at a time or by submitting a dict
#     example
#         master_config.newdict1 = {}
#         master_config.newdict1.newdict2 = {"key":"value"} (can be any value that can be contained in a dict)
#         or
#         master_config.newdict1 = {newdict2{"key":"value"}
master_config = None


def init_master_config():
    global master_config
    if master_config is None:
        master_config = MasterDict({})
    return master_config


def get_configs(**kwargs):
    """
    initializes and return the config dict object

    :param kwargs: values checked are args
    :return: object: master config dict
    """
    config = init_master_config()
    # load configuration from submit args
    args = kwargs.get('args', None)
    if not args:
        config.submit_args = {'client_name': None}
    else:
        config.submit_args = vars(args)

    # load configuration from all config files in spark file folder
    load_configs_from_spark_files()

    return config


def load_configs_from_spark_files():
    """
    load all config files from spark files and merge into master config dict

    :return: None
    """
    config = init_master_config()
    # refresh the list of spark files
    refresh_spark_files()
    # only get config files from the list of spark files
    config_files = [filename
                    for filename in config.spark_files
                    if filename.endswith('config.json')]
    # if any config files found in the directory of spark files,
    # then merge them into master config dict
    if config_files:
        for f in config_files:
            file_path = SparkFiles.get(f)
            with open(file_path) as open_file:
                temp_dict = json.load(open_file)
            if temp_dict:
                merge_dicts(config, temp_dict)


def refresh_spark_files():
    """
    refreshes the spark_files and spark_files_dir values in the config dict object

    :return: none
    """
    config = init_master_config()
    config.spark_files_dir = SparkFiles.getRootDirectory()
    config.spark_files = listdir(config.spark_files_dir)


def add_spark_files(source_file_path, spark):
    """
    Used to add additional files to the SparkFiles path.  Generally only needed if files need to be initialized via
    python as spark processes can access files directly from HDFS.


    :param source_file_path: path to source file (files on hdfs can be referenced prefixed with hdfs:// ie
    hdfs:///rca/file.json)
    :param spark: an instance of SparkSession
    :return: string: returns the path to the newly added file in the spark files path.
    """
    config = init_master_config()
    refresh_spark_files()
    file_name = path.basename(source_file_path)
    spark_files_path = config.spark_files_dir
    output_path = None
    try:
        # if source file is not in the list of current spark files
        # then add it
        if file_name not in config.spark_files:
            spark.sparkContext.addFile(source_file_path)
            # refresh after adding
            refresh_spark_files()
        output_path = path.join(spark_files_path, file_name)
    finally:
        return output_path
