class JobContext(object):
    """
    A class represents an context of Job execution. It contains below attributes:
    spark - An instance of SparkSession
    config - An instance of MasterDict
    log - An instance of Log4J

    An instance of this class required as input argument in the run method of each job
    """

    def __init__(self, spark, config, log):
        if not spark or not config or not log:
            raise ValueError("spark, config or log cannot be None.")
        self.spark = spark
        self.config = config
        self.log = log
