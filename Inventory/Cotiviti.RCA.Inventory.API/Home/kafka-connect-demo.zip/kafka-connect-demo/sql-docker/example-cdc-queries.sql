--Check if Table is being tracked by CDC
USE [COB_Member]
GO

SELECT name, is_tracked_by_cdc
FROM sys.tables
WHERE is_tracked_by_cdc = 1



--Get capture instance name
USE [COB_Member]
GO

SELECT capture_instance FROM cdc.change_tables



--Query function for changes
USE [COB_Member]
GO

DECLARE @begin binary(10), @end binary(10);
SET @begin = sys.fn_cdc_get_min_lsn('dbo_T_Member_Eligibility');
SET @end   = sys.fn_cdc_get_max_lsn();

SELECT * FROM [cdc].[fn_cdc_get_all_changes_dbo_T_Member_Eligibility] (@begin, @end, N'ALL')--Check if Table is being tracked by CDC
USE [COB_Member]
GO

SELECT name, is_tracked_by_cdc
FROM sys.tables
WHERE is_tracked_by_cdc = 1



--Get capture instance name
USE [COB_Member]
GO

SELECT capture_instance FROM cdc.change_tables



--Query function for changes
USE [COB_Member]
GO

DECLARE @begin binary(10), @end binary(10);
SET @begin = sys.fn_cdc_get_min_lsn('dbo_T_Member_Eligibility');
SET @end   = sys.fn_cdc_get_max_lsn();

SELECT * FROM [cdc].[fn_cdc_get_all_changes_dbo_T_Member_Eligibility] (@begin, @end, N'ALL')