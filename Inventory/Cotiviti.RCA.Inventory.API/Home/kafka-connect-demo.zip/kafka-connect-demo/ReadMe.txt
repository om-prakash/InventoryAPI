After extracting the kafka-connect-demo folder:

1. Open VS Code and select File, Open Workspace from File
2. Navigate to the kafka-connect-demo folder and open the _kafka-connect-ws.code-workspace file
3. Open Terminal in VS Code
4. Run docker-compose up -d
5. After docker downloads and starts containers, confirm all are up and running by typing in the terminal: docker ps -a
6. Open Postman to configure the kafka connectors:
7. Import postman json connections file from the Postman folder
8. In Postman, execute: SetupConnector_CDC
9. In Postman, execute: SetupConnector_SINK
10. In Postman, you can confirm connectors are up and running by running: SetupConnector_CDC_STATUS and SetupConnector_SINK_STATUS
11. You can open SSMS and connect to the database with the following:
    Server name: localhost,14339
    Authentication: SQL Server Authentication
    Login: sa
    Password: Test#123

12. Connect to python container by opening terminal in VS Code, run docker exec -it python-docker bash
13. Once in the python-docker shell, navigate to mypy/member_claim
14. Run python3 member_claim_consumer.py

15. Open another instance of VS Code
16. Connect to python container by opening terminal in VS Code, run docker exec -it python-docker bash
17. Once in the python-docker shell, navigate to mypy/claim_calc_spend
18. Run python3 claim_calc_spend_consumer.py

19. Now you can update a record in SQL Server, [dbo].[T_Member_Eligibility]
20. Run view [dbo].[MemberSpend] to monitor if spend gets updated


