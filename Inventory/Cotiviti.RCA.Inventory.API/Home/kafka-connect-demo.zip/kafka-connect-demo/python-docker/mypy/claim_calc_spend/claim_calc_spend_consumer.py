#type: ignore
import sys
sys.path.append('/app/mypy/kafka_modules')
from kafka_consumer import MyKafkaConsumer
from claim_calc_spend_process import ClaimCalcSpendThread
import json
import time
import threading

#--Topics--
# member-claims         - counsumer
# T_Member_Calculated   - producer
# logging-topic         - producer

#intitialize member-claim kafka consumer
claim_calc = MyKafkaConsumer("member-claims", "member-claims_group")
my_consumer = claim_calc.get_consumer()


#get concept-topic messages
for msg in my_consumer:

    #parse message json
    data = json.dumps(msg.value)
 
    #execute thread to run claim-calc process
    x = ClaimCalcSpendThread(data)
    x.start_thread()