#type: ignore
import decimal
import sys
sys.path.append('/app/mypy/kafka_modules')
from kafka_producer import MyKafkaProducer
from datetime import timedelta, datetime
import threading
import time
import json
import collections
import pyodbc

class ClaimCalcSpendThread(object):
    process_name = "ClaimCalcSpend"

    # ---Init---
    def __init__(self, data):
        self.data = json.loads(data)

        #create a T_Member_Calculated and logging kafka producer
        self.memberCalcProducer = MyKafkaProducer("T_Member_Calculated")
        self.logging = MyKafkaProducer("logging-topic")

    # ---Start Thread---
    def start_thread(self):
        thread = threading.Thread(target=self.run, args=())
        # thread.daemon = True                            # Daemonize thread
        thread.start()                                  # Start the execution


    # ---Main---
    def run(self):
         # Example running of member claim process
        log_message = "starting " + self.process_name + " process"
        self.__log_process(1, log_message)


        # Example running of member claim process
        log_message = "getting claims"
        self.__log_process(2, log_message)

    
        # print(self.data)
        SpendSinceMedicare = sum(c['TotalPaidAmount'] for c in self.data)

        today = datetime.now()
        days30 = today - timedelta(days=30)
        days60 = today - timedelta(days=60)

        output_dict = [x for x in self.data if x['BeginDOS'] >= str(days30)]    
        TotalSpendLast30 = sum(c['TotalPaidAmount'] for c in output_dict)
        
        output_dict = [x for x in self.data if x['BeginDOS'] >= str(days60)]    
        TotalSpendLast60 = sum(c['TotalPaidAmount'] for c in output_dict)

        # Get memberId
        memberId = min(c['MemberId'] for c in self.data)


        schema_types = """"schema": {
                                "type": "struct",
                                "name": "T_Member_Eligibility",
                                "fields": [                                   
                                    {
                                        "field": "MemberId",
                                        "type": "string",
                                        "optional": false
                                    },
                                    {
                                        "field": "TotalSpendLast30",
                                        "type": "float",
                                        "optional": false
                                    },
                                    {
                                        "field": "TotalSpendLast60",
                                        "type": "float",
                                        "optional": false
                                    },
                                    {
                                        "field": "SpendSinceMedicare",
                                        "type": "float",
                                        "optional": false
                                    }
                                ]
                            }"""
        
        schema_payload = """"payload": {                               
                                "MemberId": "%s",
                                "TotalSpendLast30": %d,
                                "TotalSpendLast60": %d,
                                "SpendSinceMedicare": %d
                            }"""
        
        schema_payload = schema_payload % (memberId, TotalSpendLast30, TotalSpendLast60, SpendSinceMedicare)        
        schema_final = "{" + schema_types + "," + schema_payload + "}"

        schema_message = json.loads(schema_final)

        # Send message to T_Member_Calculated topic
        self.memberCalcProducer.send_message(schema_message)

        log_message = "finished."
        self.__log_process(3, log_message)



    # ---Log---
    def __log_process(self, step_number, log_message):
        now = datetime.now()
        date_time = now.strftime("%m/%d/%Y, %H:%M:%S")

        message = """{"process": "%s", "step-number": %d, "message": "%s", "timestamp": "%s"}"""        
        message = message % (self.process_name, step_number, log_message, date_time)
        message_json = json.loads(message)

        print(message_json)
        self.logging.send_message(message_json)

