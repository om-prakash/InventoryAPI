#type: ignore
import sys
sys.path.append('/app/mypy/kafka_modules')
from kafka_producer import MyKafkaProducer
#import datetime
from datetime import timedelta, datetime
import threading
import time
import json
import collections
import pyodbc
from decimal import Decimal


class JSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return json.JSONEncoder.default(self, obj)



class MemberClaimThread(object):
    process_name = "MemberClaim"

    # ---Init---
    def __init__(self, data):        
        # Get payload claims
        data_json = json.loads(data)
        self.payload = data_json["payload"]

        # Set values needed for query
        self.memberId = self.payload['MemberId']
        self.effectiveDate = self.serial_date_to_string(self.payload['EffectiveDate'])
        self.termDate = self.serial_date_to_string(self.payload['TermDate'])

        #create a memberClaimsProducer and logging kafka producer
        self.memberClaimsProducer = MyKafkaProducer("member-claims")
        self.logging = MyKafkaProducer("logging-topic")


    # ---Start Thread---
    def start_thread(self):
        thread = threading.Thread(target=self.run, args=())
        # thread.daemon = True                            # Daemonize thread
        thread.start()                                  # Start the execution


    # ---Main ---
    def run(self):
         # Example running of member claim process
        log_message = "starting " + self.process_name + " process"
        self.__log_process(1, log_message)


        # Example running of member claim process
        log_message = "getting claims"
        self.__log_process(2, log_message)

        server = 'sql2019,1433'
        database = 'COB_Member'
        username = 'sa'
        password = 'Test#123'
        cnx = pyodbc.connect('DRIVER={FreeTDS};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)


        cursor = cnx.cursor()
        cursor.execute("""select [ClaimNumber]
                                ,[MemberId]
                                ,[BeginDOS]
                                ,[EndDOS]
                                ,[PaidDate]
                                ,[TotalAllowedAmount]
                                ,[TotalPaidAmount]
                                ,[TotalChargeAmount]
                                ,[TotalCoInsuranceAmount]
                                ,[TotalCoPayAmount]
                                ,[TotalDeductAmount]
                          from [dbo].[T_Claim_Header] 
                          where MemberId = ? and BeginDOS between ? and ?""", self.memberId, self.effectiveDate, self.termDate)

        data = []
        rows = cursor.fetchall()
        cnt=0        

        for row in rows:
            d = collections.OrderedDict()
            d['ClaimNumber'] = row[0]
            d['MemberId'] = row[1]
            d['BeginDOS'] = row[2]
            d['EndDOS'] = row[3]
            d['PaidDate'] = row[4]
            d['TotalAllowedAmount'] = row[5]
            d['TotalPaidAmount'] = row[6]
            d['TotalChargeAmount'] = row[7]
            d['TotalCoInsuranceAmount'] = row[8]
            d['TotalCoPayAmount'] = row[9]
            d['TotalDeductAmount'] = row[10]
            data.append(d)
            cnt=cnt+1

        # Materialize json
        log_message = "materialize json output"
        self.__log_process(3, log_message)
        time.sleep(1)

        jd = json.dumps(data, cls=JSONEncoder, ensure_ascii=False)
        jl = json.loads(jd)

        # If no claims found, just post the memberId
        if cnt == 0:
            x = """ [{"MemberId": "%s", "BeginDOS": "9999-12-31", "TotalPaidAmount": 0}] """
            x = x % (self.memberId) 
            final_message = json.loads(x)
        else:
            final_message = jl  
       

        # Send message to member-claims topic
        self.memberClaimsProducer.send_message(final_message)

        log_message = "finished."
        self.__log_process(4, log_message)



    # ---Convert io.debezium.time.Date to date---
    def serial_date_to_string(self, srl_no):
        new_date = datetime(1970,1,1,0,0) + timedelta(srl_no)
        return new_date.strftime("%Y-%m-%d")


    # ---Log---
    def __log_process(self, step_number, log_message):
        now = datetime.now()
        date_time = now.strftime("%m/%d/%Y, %H:%M:%S")

        message = """{"process": "%s", "step-number": %d, "message": "%s", "timestamp": "%s"}"""        
        message = message % (self.process_name, step_number, log_message, date_time)
        message_json = json.loads(message)

        print(message_json)
        self.logging.send_message(message_json)