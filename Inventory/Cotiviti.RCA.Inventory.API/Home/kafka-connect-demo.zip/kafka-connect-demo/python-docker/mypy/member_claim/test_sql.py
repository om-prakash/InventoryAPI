#type: ignore

# import pyodbc
# print("About to SELECT DATA...")

# #Add your own SQL Server IP address, PORT, UID, PWD and Database
# conn = pyodbc.connect(
#     'DRIVER={FreeTDS};SERVER=**;PORT=**;DATABASE=**;UID=**;PWD=**', autocommit=True)
# cur = conn.cursor()

# #This is just an example
# cur.execute(
#     f"INSERT INTO [FootballPLayers] ([Name],[Age],[Job],[Country],[Married],[YearsEmployed]) VALUES ('Gheorghe Hagi','55','Manager','Romania','Y','6')")
# conn.commit()
# print('Should have inserted Hagi')
# cur.close()
# conn.close()

# tsql -H sql2019 -p 1433 -U sa -P Test#123
# https://stackoverflow.com/questions/9723656/whats-causing-unable-to-connect-to-data-source-for-pyodbc
# import pyodbc

# connection = pyodbc.connect('Driver={FreeTDS};'
#                             'Server=sql2019'
#                             'Database=COB_Member;'
#                             'UID=sa;'
#                             'PWD=Test#123')

# cursor = connection.cursor()

# cursor.execute("SELECT top 100 * FROM [dbo].[MemberData]")
# for row in cursor.fetchall():
#     print(row.Name)


# connection.close()

import pyodbc
# cnx = pyodbc.connect('Driver={FreeTDS};'
#                             'Server=sql2019'
#                             'Database=COB_Member;'
#                             'UID=sa;'
#                             'PWD=Test#123)
server = 'sql2019,1433' 
database = 'COB_Member' 
username = 'sa' 
password = 'Test#123'
cnx = pyodbc.connect('DRIVER={FreeTDS};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)

cursor = cnx.cursor()
cursor.execute("SELECT top 100 * FROM [dbo].[MemberData]")
for row in cursor:
  print(row.MemberId)