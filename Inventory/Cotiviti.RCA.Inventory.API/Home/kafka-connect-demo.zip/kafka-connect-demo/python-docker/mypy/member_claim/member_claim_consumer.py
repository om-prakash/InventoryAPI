#type: ignore
import sys
sys.path.append('/app/mypy/kafka_modules')
from kafka_consumer import MyKafkaConsumer
from member_claim_process import MemberClaimThread
import json
import time
import threading

#--Topics--
# sql2019.dbo.T_Member_Eligibility  -consumer
# member-claims                     - producer
# logging-topic                     - producer

#intitialize member-claim kafka consumer
member_claim = MyKafkaConsumer("sql2019.dbo.T_Member_Eligibility", "sql2019.dbo.T_Member_Eligibility_group")
my_consumer = member_claim.get_consumer()


#get concept-topic messages
for msg in my_consumer:

    #parse message json
    data = json.dumps(msg.value)
    
    #execute thread to run member-claim process
    x = MemberClaimThread(data)
    x.start_thread()