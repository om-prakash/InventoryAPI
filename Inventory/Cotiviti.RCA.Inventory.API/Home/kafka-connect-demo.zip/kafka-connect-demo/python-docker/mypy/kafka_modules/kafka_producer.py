# type: ignore

from kafka import KafkaProducer
import json

class MyKafkaProducer():
    bootstrap_servers = ['kafka:9092']

    # Constructor method with instance variables name and age
    def __init__(self, topic_name):
        self.topic_name = topic_name

    def send_message (self, json_message):
        # Initialize producer variable
        #serialize dict to string via json and encode to bytes via utf-8
        p = KafkaProducer(bootstrap_servers=self.bootstrap_servers, acks='all',value_serializer=lambda m: json.dumps(m, ensure_ascii=False).encode('utf-8'), batch_size=1024)

        

        item = json_message #"{'name': 'charlie'}"
        ack = p.send(self.topic_name, value=item)
        #p.flush(100)
        p.close()

        metadata = ack.get()
        # print(metadata.topic)
        # print(metadata.partition)
        # print("Message Sent")
