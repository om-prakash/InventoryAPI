# type: ignore
from kafka import KafkaConsumer
from json import loads

class MyKafkaConsumer():
    bootstrap_servers = ['kafka:9092']

    # Constructor method with instance variables name and age
    def __init__(self, topic_name, group_id):
        self.topic_name = topic_name
        self.group_id = group_id


    def get_consumer (self):
        self.consumer = KafkaConsumer (self.topic_name,
                                       group_id=self.group_id,      #None,
                                       bootstrap_servers = self.bootstrap_servers,
                                       auto_offset_reset="latest",            #'latest',  #'earliest'
                                       enable_auto_commit=True,
                                       auto_commit_interval_ms=1000,
                                       value_deserializer=lambda x: loads(x.decode('utf-8')))   #reset_offset_on_start=False not working

        return self.consumer



    def get_latest_message (self):
        self.consumer = KafkaConsumer (self.topic_name,
                                       group_id=self.group_id,      #None,
                                       bootstrap_servers = self.bootstrap_servers,
                                       auto_offset_reset="latest",            #'latest',  #'earliest'
                                       enable_auto_commit=True,
                                       auto_commit_interval_ms=1000,
                                       value_deserializer=lambda x: loads(x.decode('utf-8')))   #reset_offset_on_start=False not working

        # Read and print message from consumer
        for msg in self.consumer:
            #print("Topic Name=%s,Message=%s"%(msg.topic,msg.value))
            print ("%s:%d:%d: key=%s value=%s" % (msg.topic, msg.partition,
                                                    msg.offset, msg.key,
                                                    msg.value))


    def get_all_messages (self):
        consumer_all = KafkaConsumer (self.topic_name,
                                       group_id=None,
                                       bootstrap_servers = self.bootstrap_servers,
                                       auto_offset_reset="earliest",
                                       enable_auto_commit=True,
                                       auto_commit_interval_ms=1000,
                                       value_deserializer=lambda x: loads(x.decode('utf-8')))
        for msg in consumer_all:
            #print("Topic Name=%s,Message=%s"%(msg.topic,msg.value))
            print ("%s:%d:%d: key=%s value=%s" % (msg.topic, msg.partition,
                                                    msg.offset, msg.key,
                                                    msg.value))


