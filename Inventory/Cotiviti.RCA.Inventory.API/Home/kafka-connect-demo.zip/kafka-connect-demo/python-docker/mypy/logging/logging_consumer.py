# type: ignore
import sys
sys.path.append('/app/mypy/kafka_modules')
from kafka_consumer import MyKafkaConsumer
import json
import time

#Topics
# logging-topic

logging = MyKafkaConsumer("logging-topic", "logging-topic_group")    #"latest"   #"earliest"
my_consumer = logging.get_consumer()
#my_consumer = logging.get_all_messages()



#get concept-topic messages
for msg in my_consumer:            
    print ("%s:%d:%d: key=%s value=%s" % (msg.topic, msg.partition,
                                          msg.offset, msg.key,
                                          msg.value))
